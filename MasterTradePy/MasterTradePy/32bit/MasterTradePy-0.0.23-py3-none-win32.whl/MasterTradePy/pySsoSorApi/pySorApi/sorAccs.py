# -*- coding: utf-8 -*-
import ctypes
from enum import Enum
from .sorapi_c import *
from .sortablemgr import *
from .utility import Map

class CAErrCode(Enum):
    #找不到dll.
    ERR_DLLNotFound = -2
    #dll沒提供必要的fn.
    ERR_DLLUnknown = -1
    #沒有錯誤.
    ERR_Success = 0
    #CertConfig 格式錯誤.
    ERR_CertConfigFormat = 1
    #無法開啟:憑證儲存區.
    ERR_CertStore = 2
    #找不到有效憑證: 找不到指定Subjects的憑證, 或超過有效日期.
    ERR_NoAvailCert = 3

class DigSgnHandler():
    ''' 簽章輔助功能'''
    def __init__(self, dllName, certConfig, sgnact):
        self.__dllHandle = ctypes.cdll.LoadLibrary(dllName)
        if self.__dllHandle == None:
            return
        self.__ErrCode = CAErrCode.ERR_DLLNotFound

        #LoadCert() 傳回的 caHandle 不是 thread safe!
        #如果需要 multi thread 簽章,
        #則請在每個 thread 建立一個 caHandle
        self.__fnLoadCert = self.__dllHandle.LoadCert
        if self.__fnLoadCert == None:
            return
        self.__fnLoadCert.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.POINTER(ctypes.c_uint)]
        self.__fnLoadCert.restype = ctypes.POINTER(ctypes.c_int)

        #建立簽章
        #<param name="caHandle">由LoadCert()取得的憑證Handle</param>
        #<param name="msg">要簽章的訊息</param>
        #<param name="iDigSgnAtMsgPos">簽章訊息要插入在 msg 的哪個位置,
        #       ＝0: 放在最前方
        #       ＜0: 不簽章, 直接傳回 msg
        #       ＞strlen(msg)傳回: "\n" "Invalid msg size or iDigSgnAtMsgPos"
        #</param>
        #<returns>若第1碼為 '\n' 則表示為失敗訊息, 否則傳回插入簽章後的訊息內容</returns>
        self.__fnMakeDigSgn = self.__dllHandle.MakeDigSgn
        if self.__fnMakeDigSgn == None:
            return
        self.__fnMakeDigSgn.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_char_p, ctypes.c_int]
        self.__fnMakeDigSgn.restype = ctypes.c_char_p

        errCode = ctypes.c_uint()
        self.__CAHandle = self.__fnLoadCert(certConfig.encode("utf-8"), sgnact, ctypes.byref(errCode)) # fnLoadCert(certConfig, sgnact, &__ErrCode)
        if self.__CAHandle == 0:
            return
        self.__ErrCode = CAErrCode(errCode.value)

        self.__fnFreeCert = self.__dllHandle.FreeCert
        if self.__fnFreeCert != None:
            self.__fnFreeCert.argtypes = [ctypes.POINTER(ctypes.c_int)]
        return

    def CAErrCode(self):
        return self.__ErrCode
    def Dispose(self):
        if (self.__dllHandle == None):
            return
        if (self.__fnFreeCert):
            self.__fnFreeCert(self.__CAHandle)
        self.__dllHandle = None
    def IsCertOK(self):
        return (self.__CAHandle > 0)
    def MakeDigSgn(self, msg, iDigSgnAtMsgPos):
        if (iDigSgnAtMsgPos < 0):
            return ''
        if (self.__fnMakeDigSgn == None):
            msg = 'Load MakeDigSgn function FAIL.'
            return msg
        if (self.__CAHandle == None):
            msg = 'Cert FAIL.'
            return msg

        rst = self.__fnMakeDigSgn(self.__CAHandle, msg, iDigSgnAtMsgPos)
        if (len(rst) > 0 and rst[0] == '\n'): #簽章失敗
            msg = rst[1:]
            return msg
        return rst

class Acc():
    '''交易帳號'''
    def __init__(self, mkt, brkNo, ivacNo, subacNo, name):
        if isinstance(mkt, str):
            self.__Mkt = int(mkt)
        elif isinstance(mkt, int):
            self.__Mkt = mkt

        self.__BrkNo = brkNo
        self.__IvacNo = ivacNo.zfill(7)
        self.__SubacNo = subacNo
        self.__Name = name
        self.__Acno = self.__MakeAcno(brkNo, ivacNo, subacNo)
        self.__DigSgnHandler = None
        '''
        if (bin(self.__Mkt & SorMktFlags.TwStk.value) != '0b0'):
            print('TwStk')
        if (bin(self.__Mkt & SorMktFlags.TwFuo.value) != '0b0'):
            print('TwFuo')
        if (bin(self.__Mkt & SorMktFlags.FrStk.value) != '0b0'):
            print('FrStk')
        if (bin(self.__Mkt & SorMktFlags.FrFuo.value) != '0b0'):
            print('FrFuo')
        if (bin(self.__Mkt & SorMktFlags.TwfQuot.value) != '0b0'):
            print('TwfQuot')
        if (bin(self.__Mkt & SorMktFlags.CnFuo.value) != '0b0'):
            print('CnFuo')
        '''
    def __MakeAcno(self, brkNo, ivacNo, subacNo):
        '''建立[帳號字串] = "brkNo-ivacNo", 如果有 subacNo 則為 "brkNo-ivacNo-subacNo"'''
        acno = brkNo
        if ivacNo:
            acno = acno + '-' + ivacNo
        if subacNo:
            acno = acno + '-' + subacNo
        return acno

    def MktFlag(self):
        '''可交易市場旗標'''
        return self.__Mkt
    def BrkNo(self):
        '''投資人所屬券商代號'''
        return self.__BrkNo
    def IvacNo(self):
        '''投資人帳號'''
        return self.__IvacNo
    def SubacNo(self):
        '''子帳號'''
        return self.__SubacNo
    def Name(self):
        return self.__Name
    def Key(self):
        '''帳號Key: "BrkNo-IvacNo" 或 "BrkNo-IvacNo-SubacNo"'''
        return self.__Acno
    def LoadCertConfig(self, dllName, cert, sgnact):
        '''載入簽章憑證'''
        self.FreeCertConfig()
        if cert:
            self.__DigSgnHandler = DigSgnHandler(dllName, cert, sgnact)
            return self.__DigSgnHandler.IsCertOK
        return True
    def FreeCertConfig(self):
        '''釋放簽章憑證'''
        if (self.__DigSgnHandler):
            self.__DigSgnHandler.Dispose()
            self.__DigSgnHandler = None
    def MakeDigSgn(self, msg, iDigSgnAtMsgPos):
        '''將要傳送的信息簽章'''
        '''<param name="msg">要簽章的訊息, </param>
           <param name="iDigSgnAtMsgPos">簽章要放在msg的哪個位置</param>
           <returns>訊息放在msg傳回</returns>
        '''
        message = ''
        if (self.__DigSgnHandler):
            message = self.__DigSgnHandler.MakeDigSgn(msg, iDigSgnAtMsgPos)
        else:
            message = msg
        return message
    def CAErrCode(self):
        '''憑證載入是否正確'''
        if (self.__DigSgnHandler):
            return self.__DigSgnHandler.CAErrCode()
        else:
            return CAErrCode.ERR_Success

class Accs():
    '''交易帳號列表'''
    def __init__(self):
        self.__List = []
        self.__Dict = {}
        return

    def Add(self, acc, caDllName, cert, sgnact):
        '''增加一個帳號'''
        if (acc.Key) in self.__Dict:
            return False
        acc.LoadCertConfig(caDllName, cert, sgnact)
        self.__Dict[acc.Key]= acc
        self.__List.append(acc)
        return True
    def Clear(self):
        '''清除全部帳號'''
        for acc in self.__List:
            acc.FreeCertConfig()
        del self.__List[:]
        self.__Dict.clear()
    def TryGetValue(self, acno):
        '''嘗試取的一個帳號, 如果帳號不存在則傳回None, acno = "BrkNo-IvacNo" 或 "BrkNo-IvacNo-SubacNo"'''
        if (acno) in self.__Dict:
            return self.__Dict[acno]
        return None
    def Values(self):
        '''取得帳號列表'''
        return self.__List
    def Count(self):
        '''取得帳號筆數'''
        return self.__List.count
    def SorTableParser(self, table, caDLLName, sgnact):
        '''從 SorTable 取得可用帳號列表'''
        if (table == None):
            return
        idxMkt = table.GetFieldIndex('mkt')
        idxCert = table.GetFieldIndex('cert')
        if (idxMkt != None):
            idxAcno = table.GetFieldIndex('acno')
            idxName = table.GetFieldIndex('name')
            for d in table.RecordData:
                data = d.split('\x01')
                mkt = data[idxMkt]
                name = data[idxName]
                cert = ''
                if idxCert:
                    cert = data[idxCert]
                acno = data[idxAcno]
                acnos = acno.split('-')
                if len(acnos) == 1:
                    acc = Acc(mkt, acnos[0], None, None, name)
                else:
                    sub = ''
                    if len(acnos) == 3:
                        sub = acnos[2]
                    acc = Acc(mkt, acnos[0], acnos[1], sub, name)
                self.Add(acc, caDLLName, cert, sgnact)
