# -*- coding: utf-8 -*-
import json
import os
import platform
import sys
import threading

class Utility():
    # function declaration
    @staticmethod
    def showPID():
        print ("PID:" + Utility.getPID())
    @staticmethod
    def showTID():
        print ("TID:" + Utility.getTID())
    @staticmethod
    def getPID():
        return str(os.getpid())
    @staticmethod
    def getTID():
        return str(threading._get_ident())
    @staticmethod
    def getDynamicLibPath(libName):
        filepath = os.path.dirname(os.path.abspath(__file__))
        libExt = ".so"
        if(platform.system()=="Windows"):
            libExt = ".dll"
        filePath = os.path.join(filepath, libName + libExt)
        if not os.path.isfile(filePath):
            filePath = os.path.join(filepath, 'lib' + libName + libExt)
        return filePath
    @staticmethod
    def loadJson(filename):
        data = {}
        with open(filename, 'r') as f:
            data = json.load(f)
        return data

class Map(object):
    def __init__(self, missingValue = None):
        self.__MissingValue = missingValue
        self.Clear()
    def __str__(self):
        return str(self.__Map)
    def Keys(self):
        return self.__OrderedKeys
    def Values(self):
        return self.__Map.values()
    def ContainKey(self, key):
        return self.__Map.__contains__(key)
    def Set(self, key, value):
        if not key in self.__Map:
            self.__OrderedKeys.append(key)
        self.__Map[key] = value
    def Get(self, key):
        if key in self.__Map:
            return self.__Map[key]
        return self.__MissingValue
    def Join(self, key2val, pair2pair, end):
        res = ''
        for key in self.__OrderedKeys:
            if len(res) > 0:
                res += pair2pair
            res += key + key2val + self.__Map[key]
        res += end
        return res
    def Update(self, dictionary):
        for k in dictionary:
            self.Set(k, dictionary[k])
    def Clear(self):
        self.__Map = {}
        self.__OrderedKeys = []
    def Save(self, name):
        with open(name, 'w') as outfile:
            json.dump(self.__Map, outfile)
    def Load(self, name):
        try:
            with open(name) as json_file:
                self.__Map = json.load(json_file)
        except:
            self.__Map = {}
