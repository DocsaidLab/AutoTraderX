# -*- coding: utf-8 -*-

from .sorapi_c import *

class SorFlowCtrlSender():
    def __init__(self, sorApiC, sorClient):
        self.__SorApiC = sorApiC
        self.__SorClient = sorClient
        self.__SorFlowCtrlSender = self.__SorApiC.CSorFlowCtrlSender_Create(self.__SorClient)
    def __exit__(self, type, value, trace):
        self.Dispose()
    def Dispose(self):
        self.__SorApiC.CSorFlowCtrlSender_Delete(self.__SorFlowCtrlSender)
    def IsFlowCfg(self):                    #是否需要流量管制.
        return self.__SorApiC.CSorFlowCtrlSender_IsFlowCfg(self.__SorFlowCtrlSender)
    def PendingCount(self):                 #取得現在排隊的數量.
        return self.__SorApiC.CSorFlowCtrlSender_PendingCount(self.__SorFlowCtrlSender)
    def SetFlowCtrl(self, rate, rateMS):    #設定相關流量管制參數.
        return self.__SorApiC.CSorFlowCtrlSender_SetFlowCtrl(self.__SorFlowCtrlSender, rate, rateMS)
    def AckParser(self, msgCode, acks):     #自動處理 SetAckTime() 相關事項.
        return self.__SorApiC.CSorFlowCtrlSender_AckParser(self.__SorFlowCtrlSender, msgCode, acks)
    def SendSorRequest(self, reqmsg):       #送出一筆下單要求, 若無法立即送出, 則會放到Queue之中自動傳送.
        return self.__SorApiC.CSorFlowCtrlSender_SendSorRequest(self.__SorFlowCtrlSender, reqmsg, len(reqmsg))
    def SendSorRequests(self, reqmsg):      #送出一批下單要求, 傳回[立即送出]的筆數, 其餘要求會放到Queue之中自動傳送.
        return self.__SorApiC.CSorFlowCtrlSender_SendSorRequests(self.__SorFlowCtrlSender, reqmsg, len(reqmsg))
