# -*- coding: utf-8 -*-
import ctypes
import datetime
import logging
import os
import platform
import re
import threading
import time
import sys

from enum import Enum
from .sorapi_c import *
from .sorFlowCtrlSender import SorFlowCtrlSender
from .sortablemgr import SorTableMgr
from .utility import Map
# import ptvsd


class SorClientState(Enum):
    #切斷連線: 呼叫 Disconnect() 斷線.
    SorClientState_Disconnected = -1
    #連線失敗: 網路層無法建立與SORS的連線.
    SorClientState_LinkFail = -2
    #連線後斷線: 網路層斷線.
    SorClientState_LinkBroken = -3
    #網路層可連線,但對方不是SORS服務.
    SorClientState_UnknownServer = -4
    #登入失敗.
    SorClientState_SignonError = -5
    #連線失敗: 主機拒絕連線訊息.
    SorClientState_ConnectError = -6
    #連線中斷: 送出的 Heartbeat 主機沒有回覆.
    SorClientState_HeartbeatTimeout = -7
    #建構後, 尚未進行連線.
    SorClientState_Idle = 0
    #網路層連線中.
    SorClientState_Linking = 1
    #已與SORS建立已連線: 已初步溝通完畢:已取得SORS服務端名稱.
    SorClientState_Connected = 2
    #已登入券商系統, 可以進行下單或其他操作.
    SorClientState_ApReady = 3

class SorMktFlags(Enum):
    #無可交易市場.
    Nothing = 0x00
    #台灣證券.
    TwStk = 0x01
    #台灣期權.
    TwFuo = 0x02
    #國外證券.
    FrStk = 0x04
    #國外期權.
    FrFuo = 0x08
    #台灣期權報價.
    TwfQuot = 0x10
    #大陸期權.
    CnFuo = 0x20

class SorApi():

    TReqStep_Pending ='0'               #委託要求處理中
    TReqStep_BackConfirm = '3'          #本機委託要求退回給使用者(或營業主管)確定or強迫
    TReqStep_Queuing = '5'              #本機委託要求排隊中
    TReqStep_Sending = '6'              #本機委託要求傳送中
    TReqStep_Sent = '7'                 #本機委託要求已送出(等回報)
    TReqStep_PartReject = '88'          #部份結束(失敗):例如:收到報價單的Bid失敗,Offer尚未回覆
    TReqStep_PartFinish = '89'          #部份結束:例如收到報價單的其中一邊,還缺另一邊
    TReqStep_Finished = '90'            #委託要求已結束
    TReqStep_DupFinished = '91'         #重複的[結束]回報,例如:報價單,先收到Bid成交,再收到Offer成功,此時Offer成功的回報就是TReqStep_DupFinished
    TReqStep_UnknownFail = '95'         #委託要求狀態不明(例如:送出後斷線)
    TReqStep_Reject = '99'              #委託要求拒絕
    TReqStep_RptSuggestNew = '100'      #先收到成交回報,所建立的新單(遺漏正常新單回報)
    TReqStep_RptPartFilled = '110'      #配合 TReqKind_RptFilled: 部份成交
    TReqStep_RptFullFilled = '111'      #配合 TReqKind_RptFilled: 全部成交
    TReqStep_RptExchgKilled = '120'     #委託因IOC/FOK未成交而取消

    TOrderSt_NewPending = TReqStep_Pending             #尚未處理
    TOrderSt_Force = TReqStep_BackConfirm              #新單要求退回給使用者(或營業主管)確定or強迫
    TOrderSt_NewQueuing = TReqStep_Queuing             #新單排隊中
    TOrderSt_NewSending = TReqStep_Sending             #新單傳送中
    TOrderSt_Sent = TReqStep_Sent                      #新單已送出(等回報)
    TOrderSt_InternalCanceling ='81'                   #內部刪除 [其他主機 NewQueuing] 的委託.
    TOrderSt_InternalCanceled ='91'                    #新單尚未送出就被刪單
    TOrderSt_NewUnknownFail = TReqStep_UnknownFail     #新單要求狀態不明(例如:送出後斷線)
    TOrderSt_NewReject = TReqStep_Reject               #新單要求拒絕
    TOrderSt_Accepted = '101'                          #委託已接受(交易所已接受)
    TOrderSt_PartFilled = TReqStep_RptPartFilled       #部份成交
    TOrderSt_FullFilled = TReqStep_RptFullFilled       #全部成交
    TOrderSt_IOCFOKNotFilled = TReqStep_RptExchgKilled #一般:委託因IOC/FOK未成交而取消.報價:時間到自動刪單,有新報價舊報價自動刪單.
    TOrderSt_ExchgKilled = TOrderSt_IOCFOKNotFilled

    def __init__(self, callbacks=None, connParam='', sysid='', user='', password=''):
        log_filename = datetime.datetime.now().strftime("./logs/%Y%m%d.log")
        directory = os.path.dirname(log_filename)
        if not os.path.exists(directory):
            os.makedirs(directory)
        logging.basicConfig(level=logging.DEBUG,
                format='%(asctime)s %(name)-8s %(levelname)-6s %(message)s',
                datefmt='%H:%M:%S',
                filename=log_filename)

        self.__AppName    = "PythonSorApi"
        self.__AppVersion = "1.0.0.0"
        self.__connectEvent = threading.Event()
        self.__orderEvent = threading.Event()
        self.SorApiC_ = SorApiC()
        self.SorTableMgr_ = SorTableMgr(self.SorApiC_)
        self.ReportMaps_ = []
        self.__prepareCallbacks()
        self.__ReqSeqNo = 0
        self.__Callbacks = Map()
        self.AppendCallbacks(callbacks)
        self.__connParam = connParam
        self.__sysid = sysid
        self.__user = user
        self.__password = password
        self.__ApReady = False
        self.__ConnCount = 0    #連線次數
        self.__TimeOutCount = 1
        self.__ReqId2SorRID = Map()
        #連線物件建立
        self.__SorClient = self.SorApiC_.CSorClient_Create(self.csorClientHandler_, ctypes.py_object(self))
        #流量管制物件建立
        self.SorFlowCtrlSender_ = SorFlowCtrlSender(self.SorApiC_, self.__SorClient)
        self.__TimeOutSecs = 10
        self.Codeing = self.SorApiC_.Codeing()
        self.SOH = self.SorApiC_.SOH()
        self.LF = self.SorApiC_.LF()

    def __exit__(self, type, value, trace):
        self.Dispose()
    def __prepareCallbacks(self):
        self.onSorUnknownMsgCodeEventCallback   = OnSorUnknownMsgCodeEvent(SorApi.__onSorUnknownMsgCodeEvent)
        self.onSorConnectEventCallback          = OnSorConnectEvent(SorApi.__onSorConnectEvent)
        self.onSorApReadyEventCallback          = OnSorApReadyEvent(SorApi.__onSorApReadyEvent)
        self.onSorTaskResultEventCallback       = OnSorTaskResultEvent(SorApi.__onSorTaskResultEvent)
        self.onSorChgPassResultEventCallback    = OnSorChgPassResultEvent(SorApi.__onSorChgPassResultEvent)
        self.onSorRequestAckEventCallback       = OnSorRequestAckEvent(SorApi.__onSorRequestAckEvent)
        self.onSorReportEventCallback           = OnSorReportEvent(SorApi.__onSorReportEvent)
        self.onSorClientDeleteCallback          = OnSorClientDelete(SorApi.__onSorClientDelete)

        self.csorClientHandler_                 = CSorClientHandler(            #建構 call back事件
            OnSorUnknownMsgCodeEvent=self.onSorUnknownMsgCodeEventCallback,
            OnSorConnectEvent=self.onSorConnectEventCallback,
            OnSorApReadyEvent=self.onSorApReadyEventCallback,
            OnSorTaskResultEvent=self.onSorTaskResultEventCallback,
            OnSorChgPassResultEvent=self.onSorChgPassResultEventCallback,
            OnSorRequestAckEvent=self.onSorRequestAckEventCallback,
            OnSorReportEvent=self.onSorReportEventCallback,
            OnSorClientDelete=self.onSorClientDeleteCallback)

    def GetSorRid(self, reqId):
        return self.__ReqId2SorRID.Get(reqId)
    def AppendCallbacks(self, callbacks):
        if callbacks != None:
            for key in callbacks.Keys():
                callbackList = self.__Callbacks.Get(key)
                if callbackList == None:
                    callbackList = []
                callbackList.append(callbacks.Get(key))
                self.__Callbacks.Set(key, callbackList)
    def WaitConnect(self, count = 3):
        self.__TimeOutCount = count
        self.__connectEvent.wait(self.__TimeOutSecs)
        if not self.__ApReady:
            import errno
            raise OSError(errno.ETIMEDOUT, 'SorApi Connect timeout!')
    def NotifyConnectSuccess(self):
        self.__connectEvent.set()
    def WaitOrderComplete(self):
        self.__orderEvent.clear()
        # 最多等一秒,避免 deadlock
        self.__orderEvent.wait(1.0)
    def NotifyOrderComplete(self):
        self.__orderEvent.set()
    def Connect(self, connParam, sysid, user, password):
        '''建立與SORS的連線並登入'''
        self.SorApiC_.CSorClient_Connect(self.__SorClient,
                                 connParam,        # connParam
                                 self.__AppName,   # cliApName
                                 self.__AppVersion,# cliApVer
                                 sysid,            # sysid
                                 user,             # user
                                 password          # pass
        )
    def Disconnect(self):
        '''切斷連線'''
        self.SorApiC_.CSorClient_Disconnect(self.__SorClient)
    def Dispose(self):
        '''物件刪除'''
        #流量管制物件刪除
        self.SorFlowCtrlSender_.Dispose()
        #連線物件刪除
        self.SorApiC_.CSorClient_Delete(self.__SorClient)
        #logging.info('SorClient.Dispose')
    def ChgPass(self, user, oldpass, newpass):
        self.SorApiC_.CSorClient_ChgPass(self.__SorClient, user, oldpass, newpass)
    def SendRequest(self, tableType, tableName, args, acc = None, waitOrderComplete=True):
        '''送出一筆下單要求, 若無法立即送出, 則會放到Queue之中自動傳送'''
        table = self.SorTableMgr_.GetTable(tableType, tableName)
        tableID = table.GetID()
        if tableID == None:
            #print ('no table id')
            return
        L = 0
        iDigSgnAtMsgPos = -1

        reqmsg = self.SorApiC_.GetCmdType()
        for idx in range(table.GetFieldCount()):
            fldName = table.FieldIndex2Name[idx]
            m = args.Get(fldName)
            if (L > 0):
                reqmsg = reqmsg + self.SOH
            L = L + 1
            if (fldName == 'DigSgn' and acc != None):
                iDigSgnAtMsgPos = len(reqmsg)
                msg2 = acc.MakeDigSgn(reqmsg, iDigSgnAtMsgPos)
                reqmsg = msg2
            else:
                if (m == '' or m == None):
                    continue
                else:
                    reqmsg = reqmsg + m
        reqCmd = self.GetStr(self.SOH + tableID + self.LF + reqmsg)
        reqStr = self.__GetRequestStr(reqCmd)

        self.SorFlowCtrlSender_.SendSorRequest(reqStr)
        if waitOrderComplete == True:
            self.WaitOrderComplete()
    def SendSorRequest(self, msgCode, reqCtx):
        '''送出SORS要求訊息'''
        self.SorApiC_.CSorClient_SendSorRequest(self.__SorClient, msgCode, reqCtx, len(reqCtx))
    def GetNextReqId(self):
        '''取得下一個ReqID'''
        return self.__ReqSeqNo + 1
    def __GetRequestStr(self, reqStr):
        self.__ReqSeqNo = self.GetNextReqId()
        return "-----" + str(self.__ReqSeqNo) + reqStr
    def ParseSorReport(self, reportMsg):
        '''回報解析'''
        rep = []
        rs = reportMsg.split('\n')
        for index in range(0, len(rs),2):
            tnames = rs[index].split('\x01')
            flds = rs[index+1].split('\x01')
            #print('tnames len:{}-{}'.format(len(tnames), tnames))
            if len(tnames) == 0:
                index = index + 1
                continue
            elif len(tnames) == 1:
                # 委託回補
                table = self.SorTableMgr_.GetTable('ORD', tnames[0])
                #print('table name:{}'.format(table))
                if table == None:
                    #print ('no table id :{}'.format(tnames))
                    continue
            else:
                table = self.SorTableMgr_.GetTable('RPT', tnames[1])
            res = Map()
            if table != None:
                res = table.GetFieldMap(flds)
                if sys.version_info[0] > 2:   #.Python版本處理.
                    for key in res.Keys():
                        r = res.Get(key)
                        if isinstance(r, bytes):
                            res.Set(key, r.decode(self.Codeing))
                else:
                    for key in res.Keys():
                        res.Set(key, res.Get(key).decode(self.Codeing))
                res.Set('Table', table) #將SorTable物件傳遞出去.
                rep.append(res)
        return rep
    def NotifyCallback(self, callbackName, args):
        '''事件回呼傳遞'''
        callbackList = self.__Callbacks.Get(callbackName)
        if(callbackList != None):
            for callback in callbackList:
                if callback:
                    callback(self, args)
    def AppendReport(self, reportMsg):
        # ptvsd.break_into_debugger()
        rep = self.ParseSorReport(reportMsg)
        reportAppended = False
        for r in rep:
            self.ReportMaps_.append(r)
            reportAppended = True
        lastRep = self.ReportMaps_[-1]
        orderSt = int(lastRep.Get('OrderSt') or 0)
        OrgSorRID = lastRep.Get('OrgSorRID')
        ExpectSorRID = self.__ReqId2SorRID.Get(str(self.__ReqSeqNo))
        if orderSt >= 90 and ExpectSorRID == OrgSorRID:
            self.NotifyOrderComplete()

        return reportAppended
    def ApReady(self):              #Ap是否Ready
        return self.__ApReady
    def SgnResult(self):            #取得登入結果.
        return self.SorApiC_.CSorClient_SgnResult(self.__SorClient)
    def State(self):                #取得現在的連線狀態.
        return self.SorApiC_.CSorClient_State(self.__SorClient)
    def IsSessionConnected(self):   #是否已與SORS建立連線(包含已登入 or 登入失敗).
        return self.SorApiC_.CSorClient_IsSessionConnected(self.__SorClient)
    def RecoverAll(self):           #回補全部
        cmd = '-----1'+'\x01'+'D'
        self.SendSorRequest(0x83, cmd)
    def RecoverMatch(self):         #補有成交(或UserID相同)的委託,含成交明細
        cmd = '-----1'+'\x01'+'M'
        self.SendSorRequest(0x83, cmd)
    def RecoverWorking(self):       #僅回補還在 [交易所委託簿] 的委託: 還有剩餘量的委託
        cmd = '-----1'+'\x01'+'w'
        self.SendSorRequest(0x83, cmd)
    def GetStr(self, result):       #依Python版本,取得字串
        '''依.Python版本,取得字串'''
        if sys.version_info[0] > 2:   #.Python版本處理.
            if isinstance(result, bytes):
                return result.decode(self.Codeing)
            else:
                return result
        else:
            return result

    @staticmethod
    def __onSorUnknownMsgCodeEvent(sender, userdata, msgCode, pk, pksz):
        #logging.info('onSorUnknownMsgCodeEvent:' + msgCode)
        pass
    #Sor主機連接回覆
    @staticmethod
    def __onSorConnectEvent(sender, userdata, errmsg):
        msg = userdata.GetStr(errmsg)
        args = Map()
        args.Set('sender', userdata)
        args.Set('errmsg', msg)
        userdata.NotifyCallback('OnSorConnectEvent', args)
        userdata.__ConnCount = userdata.__ConnCount + 1
        #logging.info('onSorConnectEvent:{}-{}'.format(userdata.__ConnCount, errmsg))
        if userdata.__ConnCount == userdata.__TimeOutCount:
            userdata.NotifyConnectSuccess()
        pass
    #登入成功可以開始下單作業
    @staticmethod
    def __onSorApReadyEvent(sender, userdata):
        #logging.info('onSorApReadyEvent:' + Utility.getPID())
        sgnResult = userdata.SgnResult()
        userdata.SorTableMgr_.Parse(sgnResult)
        args = Map()
        args.Set('sender', userdata)

        #下單帳號回傳
        tableAccs = userdata.SorTableMgr_.GetSingleTable('Accs')
        if tableAccs != None:
            args.Set('Accs', tableAccs)
            #logging.info('Accs Table_RecordsCount:{}'.format(tableAccs.GetRecordsCount()))

        tableHead = userdata.SorTableMgr_.GetSingleTable('head')
        if tableHead != None:
            args.Set('head', tableHead)

        #取出流量管制參數.
        tableFlowCtrl = userdata.SorTableMgr_.GetSingleTable('FlowCtrl')
        if tableFlowCtrl != None:
            args.Set('FlowCtrl', tableFlowCtrl)

        userdata.__ApReady = True
        userdata.NotifyCallback('OnSorApReadyAck', args)
        userdata.NotifyConnectSuccess()
    #執行指定作業回覆
    @staticmethod
    def __onSorTaskResultEvent(sender, userdata, taskResult):
        args = Map()
        args.Set('sender', userdata)
        args.Set('taskResult', taskResult)
        args.Set('WorkID', userdata.SorApiC_.CSorTaskResult_WorkID(taskResult))
        args.Set('TableCount', userdata.SorApiC_.CSorTaskResult_TableCount(taskResult))
        args.Set('OrigResult', userdata.SorApiC_.CSorTaskResult_OrigResult(taskResult))

        #logging.info('__onSorTaskResultEvent:' + str(args))

        userdata.NotifyCallback('OnSorTaskResult', args)
        pass
    #密碼變更作業回覆
    @staticmethod
    def __onSorChgPassResultEvent(sender, userdata, user, result):
        #logging.info('onSorChgPassResultEvent')
        pass
    #Sor Request Ack
    @staticmethod
    def __onSorRequestAckEvent(sender, userdata, msgCode, result):
        resultMsg = userdata.GetStr(result)
        args = Map()
        args.Set('msgCode', msgCode)
        args.Set('result', resultMsg)
        if (msgCode == 129):
            resArray = resultMsg.split('\x01')
            userdata.__ReqId2SorRID.Set(resArray[0], resArray[1])
        userdata.NotifyCallback('OnSorRequestAck', args)
    #委託回補 or 委託回報 or 成交回報
    @staticmethod
    def __onSorReportEvent(sender, userdata, result):
        # ptvsd.break_into_debugger()
        resultMsg = userdata.GetStr(result)
        args = Map()
        args.Set('result', resultMsg)
        if userdata.AppendReport(resultMsg):
            userdata.NotifyCallback('OnSorReport', args)
    @staticmethod
    def __onSorClientDelete(sender, userdata):
        #print ('onSorClientDelete')
        pass
