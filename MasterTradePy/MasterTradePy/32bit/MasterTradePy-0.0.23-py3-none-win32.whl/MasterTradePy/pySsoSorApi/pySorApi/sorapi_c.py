# -*- coding: utf-8 -*-
import ctypes
import enum
import os
import sys
from .utility import *

# class declaration

'''
struct CSorClient
{
   /// 系統保留,您唯一能做的是判斷==NULL表示無效.
   const void* Impl_;
};
'''
class CSorClient(ctypes.Structure):
    _fields_=[("Impl_", ctypes.c_void_p)]

'''
/// SORS作業結果, 透過 CSorClient_SgnResult() 取得, 或 CSorClientHandler::OnSorTaskResultEvent 事件通知 得到.
struct CSorTaskResult
{
    /// 系統保留,您唯一能做的是判斷==NULL表示無效.
    const void* Impl_;
};
'''
class CSorTaskResult(ctypes.Structure):
    _fields_=[("Impl_", ctypes.c_void_p)]

'''
/// SORS資料表型別, 透過 CSorTaskResult_NameTable(), CSorTaskResult_IndexTable() 取得.
struct CSorTable
{
    /// 系統保留,您唯一能做的是判斷==NULL表示無效.
    const void* Impl_;
};
'''
class CSorTable(ctypes.Structure):
    _fields_=[("Impl_", ctypes.c_void_p)]
'''
/// 透過 CSorField_Properties(), CSorTable_Properties() 取得.
struct CSorProperties
{
    /// 系統保留,您唯一能做的是判斷==NULL表示無效.
    const void* Impl_;
};
'''
class CSorProperties(ctypes.Structure):
    _fields_=[("Impl_", ctypes.c_void_p)]
'''
/// SORS [資料表] 的 [欄位列表], 透過 CSorTable_Fields() 取得.
struct CSorFields
{
    /// 系統保留,您唯一能做的是判斷==NULL表示無效.
    const void* Impl_;
};
'''
class CSorFields(ctypes.Structure):
    _fields_=[("Impl_", ctypes.c_void_p)]
'''
/// SORS資料表裡面的 [一個欄位] 型別, 透過 CSorFields_NameField(), CSorFields_IndexField() 取得.
struct CSorField
{
    /// 系統保留,您唯一能做的是判斷==NULL表示無效.
    const void* Impl_;
};
'''
class CSorField(ctypes.Structure):
    _fields_=[("Impl_", ctypes.c_void_p)]
'''
    defgroup flow  流量管制輔助
       流量管制輔助下單函式
       流量管制輔助類別, 透過 CSorFlowCtrl_Create() 建立, 不用時須使用 CSorFlowCtrl_Delete() 刪除.
'''
class CSorFlowCtrl(ctypes.Structure):
    _fields_=[("Impl_", ctypes.c_void_p)]

# 從 [管制狀態] 變成 [可下單狀態], 透過此處通知.
# 此處的通知可能會在 SetAckTime() 返回前,
# 或使用 StartCheckTimer() 啟動計時器檢查, 並在某 thread 之中通知.
# 在呼叫 StartCheckTimer() 之前, 會先停止計時器.
#void (*OnSorFlowCtrlFree) (const CSorFlowCtrl& sender, void* userdata);
OnSorFlowCtrlFree = ctypes.CFUNCTYPE(None, ctypes.POINTER(CSorFlowCtrl), ctypes.py_object)
'''
   /// 建立流量管制輔助時, 可指定流量管制解除時的callback,
   /// 會在某 thread 之中 callback, 使用時請注意 thread 安全問題!
'''
class CSorFlowCtrlHandler(ctypes.Structure):
    _fields_=[("OnSorFlowCtrlFree", OnSorFlowCtrlFree)]
'''
/// 傳送下單要求前先檢查流量管制, 被管制的要求, 就放在 Queue 裡面, 等解除管制時自動送出,
/// 透過 CSorFlowCtrlSender_Create() 建立, 不用時須透過 CSorFlowCtrlSender_Delete() 刪除.
struct CSorFlowCtrlSender
{
    /// 系統保留,您唯一能做的是判斷==NULL表示無效.
    const void* Impl_;
};
'''
class CSorFlowCtrlSender(ctypes.Structure):
    _fields_=[("Impl_", ctypes.c_void_p)]

'''
   /// SorClient現在狀態.
'''
class CSorClientState(enum.Enum):
    #切斷連線: 呼叫 Disconnect() 斷線.
    SorClientState_Disconnected = -1,
    #連線失敗: 網路層無法建立與SORS的連線.
    SorClientState_LinkFail = -2,
    #連線後斷線: 網路層斷線.
    SorClientState_LinkBroken = -3,
    #網路層可連線,但對方不是SORS服務.
    SorClientState_UnknownServer = -4,
    #登入失敗.
    SorClientState_SignonError = -5,
    #連線失敗: 主機拒絕連線訊息.
    SorClientState_ConnectError = -6,
    #連線中斷: 送出的 Heartbeat 主機沒有回覆.
    SorClientState_HeartbeatTimeout = -7,
    #建構後, 尚未進行連線.
    SorClientState_Idle = 0,
    #網路層連線中.
    SorClientState_Linking = 1,
    #已與SORS建立已連線: 已初步溝通完畢:已取得SORS服務端名稱.
    SorClientState_Connected = 2,
    #已登入券商系統, 可以進行下單或其他操作.
    SorClientState_ApReady = 3,

# callback type declaration
#/// 當收到[不明訊息]時的通知.
#void (SorApi_CALL *OnSorUnknownMsgCodeEvent) (const struct CSorClient* sender, void* userdata, int msgCode, const char* pk, int pksz);
OnSorUnknownMsgCodeEvent = ctypes.CFUNCTYPE(None, ctypes.POINTER(CSorClient), ctypes.py_object, ctypes.c_int, ctypes.c_char_p, ctypes.c_int)
#/// SORS連線訊息通知, if(errmsg.empty()) 表示成功, 此時可呼叫 sender.ServerName() 取得主機名稱.
#void (SorApi_CALL *OnSorConnectEvent) (const struct CSorClient* sender, void* userdata, const char* errmsg);
OnSorConnectEvent = ctypes.CFUNCTYPE(None, ctypes.POINTER(CSorClient), ctypes.py_object, ctypes.c_char_p)
#/// SORS已備妥,可以下單或執行特定作業.
#void (SorApi_CALL *OnSorApReadyEvent) (const struct CSorClient* sender, void* userdata);
OnSorApReadyEvent = ctypes.CFUNCTYPE(None, ctypes.POINTER(CSorClient), ctypes.py_object)
#/// 一般作業結果通知.
#void (SorApi_CALL *OnSorTaskResultEvent) (const struct CSorClient* sender, void* userdata, const struct CSorTaskResult* taskResult);
OnSorTaskResultEvent = ctypes.CFUNCTYPE(None, ctypes.POINTER(CSorClient), ctypes.py_object, ctypes.POINTER(CSorTaskResult))
#/// 改密碼結果, if(result.empty()) 改密碼成功! else result=失敗訊息.
#void (SorApi_CALL *OnSorChgPassResultEvent) (const struct CSorClient* sender, void* userdata, const char* user, const char* result);
OnSorChgPassResultEvent = ctypes.CFUNCTYPE(None, ctypes.POINTER(CSorClient), ctypes.py_object, ctypes.c_char_p)
#/// 下單回覆.
#void (SorApi_CALL *OnSorRequestAckEvent) (const struct CSorClient* sender, void* userdata, int msgCode, const char* result);
OnSorRequestAckEvent = ctypes.CFUNCTYPE(None, ctypes.POINTER(CSorClient), ctypes.py_object, ctypes.c_int, ctypes.c_char_p)
#/// 委託回補, 委託主動回報, 成交回報.
#void (SorApi_CALL *OnSorReportEvent) (const struct CSorClient* sender, void* userdata, const char* result);
OnSorReportEvent = ctypes.CFUNCTYPE(None, ctypes.POINTER(CSorClient), ctypes.py_object, ctypes.c_char_p)
#/// 當 sender 要被殺死前的通知.
#void (SorApi_CALL *OnSorClientDelete) (const struct CSorClient* sender, void* userdata);
OnSorClientDelete = ctypes.CFUNCTYPE(None, ctypes.POINTER(CSorClient), ctypes.py_object)
'''
struct CSorClientHandler
{
   /// 當收到[不明訊息]時的通知.
   void (SorApi_CALL *OnSorUnknownMsgCodeEvent) (const struct CSorClient* sender, void* userdata, int msgCode, const char* pk, int pksz);
   /// SORS連線訊息通知, if(errmsg.empty()) 表示成功, 此時可呼叫 sender.ServerName() 取得主機名稱.
   void (SorApi_CALL *OnSorConnectEvent) (const struct CSorClient* sender, void* userdata, const char* errmsg);
   /// SORS已備妥,可以下單或執行特定作業.
   void (SorApi_CALL *OnSorApReadyEvent) (const struct CSorClient* sender, void* userdata);
   /// 一般作業結果通知.
   void (SorApi_CALL *OnSorTaskResultEvent) (const struct CSorClient* sender, void* userdata, const struct CSorTaskResult* taskResult);
   /// 改密碼結果, if(result.empty()) 改密碼成功! else result=失敗訊息.
   void (SorApi_CALL *OnSorChgPassResultEvent) (const struct CSorClient* sender, void* userdata, const char* user, const char* result);
   /// 下單回覆.
   void (SorApi_CALL *OnSorRequestAckEvent) (const struct CSorClient* sender, void* userdata, int msgCode, const char* result);
   /// 委託回補, 委託主動回報, 成交回報.
   void (SorApi_CALL *OnSorReportEvent) (const struct CSorClient* sender, void* userdata, const char* result);
   /// 當 sender 要被殺死前的通知.
   void (SorApi_CALL *OnSorClientDelete) (const struct CSorClient* sender, void* userdata);
};
'''
class CSorClientHandler(ctypes.Structure):
    _fields_=[
        ("OnSorUnknownMsgCodeEvent", OnSorUnknownMsgCodeEvent),
        ("OnSorConnectEvent", OnSorConnectEvent),
        ("OnSorApReadyEvent", OnSorApReadyEvent),
        ("OnSorTaskResultEvent", OnSorTaskResultEvent),
        ("OnSorChgPassResultEvent", OnSorChgPassResultEvent),
        ("OnSorRequestAckEvent", OnSorRequestAckEvent),
        ("OnSorReportEvent", OnSorReportEvent),
        ("OnSorClientDelete", OnSorClientDelete)
    ]


class SorApiC():
    def __init__(self):
        try:
            if platform.system() == "Windows":
                # 設定 libns search path
                os.environ['PATH'] = os.path.dirname(os.path.abspath(__file__)) + os.pathsep + os.environ['PATH']
            self.__sorapi = ctypes.windll.LoadLibrary(Utility.getDynamicLibPath("SorApi"))
        except BaseException as e:
            print (e.args[-1])
            os._exit(-1)
        self.__confiureApiPrototype()
    def __confiureApiPrototype(self):
        '''
        SorApi_DECL CSorClient SorApi_CALL
        CSorClient_Create (const struct CSorClientHandler* evHandler, void* userdata)
        '''
        self.__sorapi.CSorClient_Create.argtypes = [ctypes.POINTER(CSorClientHandler), ctypes.py_object]
        self.__sorapi.CSorClient_Create.restype = CSorClient
        '''
        /// 解構 CSorClient.
        SorApi_DECL void SorApi_CALL
            CSorClient_Delete (struct CSorClient* client);
        '''
        self.__sorapi.CSorClient_Delete.argtypes = [ctypes.POINTER(CSorClient)]
        '''
        /// 取得現在的狀態.
        SorApi_DECL ESorClientState SorApi_CALL
            CSorClient_State(const CSorClient& client);
        '''
        self.__sorapi.CSorClient_State.argtypes = [ctypes.POINTER(CSorClient)]
        self.__sorapi.CSorClient_State.restype = CSorClientState
        '''
        /// 是否已與SORS建立連線, 取得SORS服務端名稱 (包含已登入 or 登入失敗).
        SorApi_DECL bool SorApi_CALL
            CSorClient_IsSessionConnected(const CSorClient& client);
        '''
        self.__sorapi.CSorClient_IsSessionConnected.argtypes = [ctypes.POINTER(CSorClient)]
        self.__sorapi.CSorClient_IsSessionConnected.restype = ctypes.c_bool
        '''
        /// 建立與SORS的連線並登入.
        /// \param client    由 CSorClient_Create() 或 CSorClient_Create_OnMessageLoop() 所建立的物件.
        /// \param connParam 連線參數, 格式: "host:port", host = SORS 主機 ip 或 domain name
        /// \param cliApName 客戶端AP名稱.
        /// \param cliApVer  客戶端AP版本, 格式: "a.b.c.d"
        /// \param sysid     連線使用的系統代號,由券商指定.
        /// \param user      使用者ID
        /// \param pass      使用者密碼.
        SorApi_DECL SorApi_bool_t SorApi_CALL
            CSorClient_Connect ( struct CSorClient* client
                                , const char* connParam
                                , const char* cliApName
                                , const char* cliApVer
                                , const char* sysid
                                , const char* user
                                , const char* pass);
        '''
        self.__sorapi.CSorClient_Connect.argtypes = [ctypes.POINTER(CSorClient), ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
        self.__sorapi.CSorClient_Connect.restype = ctypes.c_bool
        '''
        /// 切斷連線.
        SorApi_DECL void SorApi_CALL
            CSorClient_Disconnect(CSorClient& client);
        '''
        self.__sorapi.CSorClient_Disconnect.argtypes = [ctypes.POINTER(CSorClient)]
        '''
        /// 取得登入結果.
        SorApi_DECL struct CSorTaskResult SorApi_CALL
            CSorClient_SgnResult(const struct CSorClient* client);
        '''
        self.__sorapi.CSorClient_SgnResult.argtypes = [ctypes.POINTER(CSorClient)]
        self.__sorapi.CSorClient_SgnResult.restype = CSorTaskResult
        '''
        /// 改密碼, 必須先建立連線(已收到主機名)才能改密碼.
        SorApi_DECL bool SorApi_CALL
            CSorClient_ChgPass (const CSorClient& client, const char* user, const char* oldpass, const char* newpass);
        '''
        self.__sorapi.CSorClient_ChgPass.argtypes = [ctypes.POINTER(CSorClient), ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
        self.__sorapi.CSorClient_ChgPass.restype = ctypes.c_bool
        '''
        /// 送出SORS要求訊息.
        /// reqCtx裡面不可有中文,因為在取 reqCtx.Length 時, .NET裡面一個中文字長度=1, 但ASCII(big5)中文字長度=2
        /// <param name="msgCode">0x81=下單要求, 0x83=回補要求, 0x84=無流量管制時的無ACK下單要求</param>
        /// <param name="reqCtx">要送出的下單要求內容,前5碼必須保留給header</param>
        /// <returns>true成功送出,false=無法送出(例如:0x80查詢超過流量上限)</returns>
        '''
        self.__sorapi.CSorClient_SendSorRequest.argtypes = [ctypes.POINTER(CSorClient), ctypes.c_int, ctypes.c_char_p, ctypes.c_int]
        self.__sorapi.CSorClient_SendSorRequest.restype = ctypes.c_bool
        '''
        /// 此Task的識別碼.
           SorApi_DECL const char* SorApi_CALL
                 CSorTaskResult_WorkID(const CSorTaskResult& taskr);
        '''
        self.__sorapi.CSorTaskResult_WorkID.argtypes = [ctypes.POINTER(CSorTaskResult)]
        self.__sorapi.CSorTaskResult_WorkID.restype = ctypes.c_char_p
        '''
        /// 取得原始結果字串.
           SorApi_DECL const char* SorApi_CALL
                 CSorTaskResult_OrigResult(const CSorTaskResult& taskr);
        '''
        self.__sorapi.CSorTaskResult_OrigResult.argtypes = [ctypes.POINTER(CSorTaskResult)]
        self.__sorapi.CSorTaskResult_OrigResult.restype = ctypes.c_char_p
        '''
        /// 使用 tableName 取得結果資料表.
           SorApi_DECL CSorTable SorApi_CALL
                 CSorTaskResult_NameTable(const CSorTaskResult& taskr, const char* tableName);
        '''
        self.__sorapi.CSorTaskResult_NameTable.argtypes = [ctypes.POINTER(CSorTaskResult), ctypes.c_char_p]
        self.__sorapi.CSorTaskResult_NameTable.restype = CSorTable
        '''
        /// 取得資料表數量.
        SorApi_DECL unsigned SorApi_CALL
            CSorTaskResult_TableCount(const struct CSorTaskResult* taskr);
        '''
        self.__sorapi.CSorTaskResult_TableCount.argtypes = [ctypes.POINTER(CSorTaskResult)]
        self.__sorapi.CSorTaskResult_TableCount.restype = ctypes.c_int
        '''
        /// 使用 index 取得資料表.
        SorApi_DECL struct CSorTable SorApi_CALL
            CSorTaskResult_IndexTable(const struct CSorTaskResult* taskr, unsigned index);
        '''
        self.__sorapi.CSorTaskResult_IndexTable.argtypes = [ctypes.POINTER(CSorTaskResult), ctypes.c_uint]
        self.__sorapi.CSorTaskResult_IndexTable.restype = CSorTable
        '''
        /// 取得指定的屬性, 若屬性不存在則傳回NULL.
        SorApi_DECL const char* SorApi_CALL
            CSorProperties_Get(const struct CSorProperties* props, const char* propertyName);
        '''
        self.__sorapi.CSorProperties_Get.argtypes = [ctypes.POINTER(CSorProperties), ctypes.c_char_p]
        self.__sorapi.CSorProperties_Get.restype = ctypes.c_char_p
        '''
        /// 取得屬性集合(例如:Table,Field) 的 名稱.
        SorApi_DECL const char* SorApi_CALL
            CSorProperties_Name(const struct CSorProperties* props);
        '''
        self.__sorapi.CSorProperties_Name.argtypes = [ctypes.POINTER(CSorProperties)]
        self.__sorapi.CSorProperties_Name.restype = ctypes.c_char_p
        '''
        /// 取得SORS傳來的 [顯示文字] 屬性, 如果無此屬性, 則傳回 Name.
        SorApi_DECL const char* SorApi_CALL
            CSorProperties_DisplayText(const struct CSorProperties* props);
        '''
        self.__sorapi.CSorProperties_DisplayText.argtypes = [ctypes.POINTER(CSorProperties)]
        self.__sorapi.CSorProperties_DisplayText.restype = ctypes.c_char_p
        '''
        /// 取得SORS傳來的 [說明文字] 屬性, 如果無此屬性, 則傳回 DisplayText().
        SorApi_DECL const char* SorApi_CALL
            CSorProperties_Description(const struct CSorProperties* props);
        '''
        self.__sorapi.CSorProperties_Description.argtypes = [ctypes.POINTER(CSorProperties)]
        self.__sorapi.CSorProperties_Description.restype = ctypes.c_char_p
        '''
        /// 取得屬性集合的顯示字串, 不含名稱屬性, 使用 0x01 分隔.
        SorApi_DECL const char* SorApi_CALL
            CSorProperties_ToString(const struct CSorProperties* props);
        '''
        self.__sorapi.CSorProperties_ToString.argtypes = [ctypes.POINTER(CSorProperties)]
        self.__sorapi.CSorProperties_ToString.restype = ctypes.c_char_p
        '''
        /// 取得表格屬性列表.
        SorApi_DECL struct CSorProperties SorApi_CALL
            CSorTable_Properties(const struct CSorTable* table);
        '''
        self.__sorapi.CSorTable_Properties.argtypes = [ctypes.POINTER(CSorTable)]
        self.__sorapi.CSorTable_Properties.restype = CSorProperties
        '''
        /// 取得表格的資料筆數.
        SorApi_DECL int SorApi_CALL
            CSorTable_RecordsCount(const CSorTable& table);
        '''
        self.__sorapi.CSorTable_RecordsCount.argtypes = [ctypes.POINTER(CSorTable)]
        self.__sorapi.CSorTable_RecordsCount.restype = ctypes.c_int
        '''
        /// 取得表格的某資料的某欄位內容, 傳回NULL表示無該筆資料或欄位.
        SorApi_DECL const char* SorApi_CALL
            CSorTable_RecordIndexField (const CSorTable& table, int recordIndex, int fieldIndex);
        '''
        self.__sorapi.CSorTable_RecordIndexField.argtypes = [ctypes.POINTER(CSorTable), ctypes.c_int, ctypes.c_int]
        self.__sorapi.CSorTable_RecordIndexField.restype = ctypes.c_char_p
        '''
        /// 取得表格的某資料的某欄位內容, 傳回NULL表示無該筆資料或欄位.
        SorApi_DECL const char* SorApi_CALL
            CSorTable_RecordField (const CSorTable& table, int recordIndex, const CSorField& field);
        '''
        self.__sorapi.CSorTable_RecordField.argtypes = [ctypes.POINTER(CSorTable), ctypes.c_int, ctypes.POINTER(CSorField)]
        self.__sorapi.CSorTable_RecordField.restype = ctypes.c_char_p
        '''
        /// 取得表格的欄位列表.
        SorApi_DECL struct CSorFields SorApi_CALL
            CSorTable_Fields(const struct CSorTable* table);
        '''
        self.__sorapi.CSorTable_Fields.argtypes = [ctypes.POINTER(CSorTable)]
        self.__sorapi.CSorTable_Fields.restype = CSorFields
        '''
        /// 用欄位名稱取得欄位,若不存在則傳回NULL.
        SorApi_DECL CSorField SorApi_CALL
            CSorFields_NameField(const CSorFields& fields, const char* fieldName);
        '''
        self.__sorapi.CSorFields_NameField.argtypes = [ctypes.POINTER(CSorFields), ctypes.c_char_p]
        self.__sorapi.CSorFields_NameField.restype = CSorField
        '''
        /// 用索引取得欄位,若不存在則傳回NULL.
        SorApi_DECL CSorField SorApi_CALL
            CSorFields_IndexField(const CSorFields& fields, int index);
        '''
        self.__sorapi.CSorFields_IndexField.argtypes = [ctypes.POINTER(CSorFields), ctypes.c_int]
        self.__sorapi.CSorFields_IndexField.restype = CSorField
        '''
        /// 取得欄位數量.
        SorApi_DECL int SorApi_CALL
            CSorFields_Count(const CSorFields& fields);
        '''
        self.__sorapi.CSorFields_Count.argtypes = [ctypes.POINTER(CSorFields)]
        self.__sorapi.CSorFields_Count.restype = ctypes.c_int
        '''
        /// 取得欄位屬性列表.
        SorApi_DECL struct CSorProperties SorApi_CALL
            CSorField_Properties(const struct CSorField* field);
        '''
        self.__sorapi.CSorField_Properties.argtypes = [ctypes.POINTER(CSorField)]
        self.__sorapi.CSorField_Properties.restype = CSorProperties
        '''
        /// 取得欄位的索引, < 0 表示欄位有誤.
        SorApi_DECL int SorApi_CALL
            CSorField_Index(const struct CSorField* field);
        '''
        self.__sorapi.CSorField_Index.argtypes = [ctypes.POINTER(CSorField)]
        self.__sorapi.CSorField_Index.restype = ctypes.c_int
        '''
        /// 建構 CSorFlowCtrlSender, owner 必須先用 CSorClient_Create() 建立好, owner死掉前必須先呼叫 CSorFlowCtrlSender_Delete().
        SorApi_DECL struct CSorFlowCtrlSender SorApi_CALL
            CSorFlowCtrlSender_Create (struct CSorClient* owner);
        '''
        self.__sorapi.CSorFlowCtrlSender_Create.argtypes = [ctypes.POINTER(CSorClient)]
        self.__sorapi.CSorFlowCtrlSender_Create.restype = CSorFlowCtrlSender
        '''
        /// 刪除 CSorFlowCtrlSender.
        SorApi_DECL void SorApi_CALL
            CSorFlowCtrlSender_Delete (struct CSorFlowCtrlSender* fcSender);
        '''
        self.__sorapi.CSorFlowCtrlSender_Delete.argtypes = [ctypes.POINTER(CSorFlowCtrlSender)]
        '''
        /// 設定相關流量管制參數.
        SorApi_DECL void SorApi_CALL
            CSorFlowCtrlSender_SetFlowCtrl(CSorFlowCtrlSender& fcSender, int rate, int rateMS);
        '''
        self.__sorapi.CSorFlowCtrlSender_SetFlowCtrl.argtypes = [ctypes.POINTER(CSorFlowCtrlSender), ctypes.c_int, ctypes.c_int]
        '''
        /// 是否需要流量管制.
        SorApi_DECL bool SorApi_CALL
            CSorFlowCtrlSender_IsFlowCfg (CSorFlowCtrlSender& fcSender);
        '''
        self.__sorapi.CSorFlowCtrlSender_IsFlowCfg.argtypes = [ctypes.POINTER(CSorFlowCtrlSender)]
        self.__sorapi.CSorFlowCtrlSender_IsFlowCfg.restype = ctypes.c_bool
        '''
        /// 取得現在排隊的數量.
        SorApi_DECL unsigned SorApi_CALL
            CSorFlowCtrlSender_PendingCount (const CSorFlowCtrlSender& fcSender);
        '''
        self.__sorapi.CSorFlowCtrlSender_PendingCount.argtypes = [ctypes.POINTER(CSorFlowCtrlSender)]
        self.__sorapi.CSorFlowCtrlSender_PendingCount.restype = ctypes.c_int
        '''
        /// Ack Parser, 自動處理 SetAckTime() 相關事項.
        SorApi_DECL void SorApi_CALL
            CSorFlowCtrlSender_AckParser (CSorFlowCtrlSender& fcSender, int msgCode, const char* acks);
        '''
        self.__sorapi.CSorFlowCtrlSender_AckParser.argtypes = [ctypes.POINTER(CSorFlowCtrlSender), ctypes.c_int, ctypes.c_char_p]
        '''
        /// 設定 Ack 筆數.
        SorApi_DECL void SorApi_CALL
            CSorFlowCtrlSender_SetAckTime (CSorFlowCtrlSender& fcSender, int msgCode, unsigned ackCount);
        '''
        self.__sorapi.CSorFlowCtrlSender_SetAckTime.argtypes = [ctypes.POINTER(CSorFlowCtrlSender), ctypes.c_int, ctypes.c_int]
        '''
        /// 送出一筆下單要求, 若無法立即送出, 則會放到Queue之中自動傳送.
        /// \param fcSender 透過 CSorFlowCtrlSender_Create() 所建立的物件.
        /// \param reqmsg   需保留 5 bytes header.
        /// \param reqmsgLen reqmsg要送出的長度(包含前5碼的保留).
        /// 傳回 true=已立即送出, false=已放到Queue之中等候送出.
        SorApi_DECL SorApi_bool_t SorApi_CALL
            CSorFlowCtrlSender_SendSorRequest (struct CSorFlowCtrlSender* fcSender, char* reqmsg, unsigned reqmsgLen);
        '''
        self.__sorapi.CSorFlowCtrlSender_SendSorRequest.argtypes = [ctypes.POINTER(CSorFlowCtrlSender), ctypes.c_char_p, ctypes.c_int]
        self.__sorapi.CSorFlowCtrlSender_SendSorRequest.restype = ctypes.c_bool
        '''
        /// 送出一批下單要求, 傳回[立即送出]的筆數, 其餘要求會放到Queue之中自動傳送.
        /// \param fcSender 透過 CSorFlowCtrlSender_Create() 所建立的物件.
        /// \param reqs     需保留 5 bytes header,  每筆下單要求之間用 '\n' 分隔, 返回時reqs內容可能會被改變.
        /// \param reqsLen  reqs要送出的長度(包含前5碼的保留).
        SorApi_DECL unsigned SorApi_CALL
            CSorFlowCtrlSender_SendSorRequests (struct CSorFlowCtrlSender* fcSender, char* reqs, unsigned reqsLen);
        '''
        self.__sorapi.CSorFlowCtrlSender_SendSorRequests.argtypes = [ctypes.POINTER(CSorFlowCtrlSender), ctypes.c_char_p, ctypes.c_int]
        self.__sorapi.CSorFlowCtrlSender_SendSorRequests.restype = ctypes.c_int
    def GetCmdType(self):
        '''取得指令初始型態'''
        if sys.version_info[0] > 2:
            return bytes(0)
        else:
            return ''
    def Codeing(self):
        '''訊息編碼'''
        return 'cp950'#ori=big5
    def SOH(self):
        '''分隔符號'''
        if sys.version_info[0] > 2:
            return b'\x01'
        else:
            return '\x01'
    def LF(self):
        '''斷行符號'''
        if sys.version_info[0] > 2:
            return b'\n'
        else:
            return '\n'
    # C Api wrapper
    def CSorClient_Create(self, evHandler, userdata):
        return self.__sorapi.CSorClient_Create(evHandler, userdata)
    def CSorClient_Connect(self, client, connParam, cliApName, cliApVer, sysid, user, password):
        '''建立與SORS的連線並登入'''
        if sys.version_info[0] > 2:
            return self.__sorapi.CSorClient_Connect(client,
                ctypes.c_char_p(connParam.encode('utf-8')),
                ctypes.c_char_p(cliApName.encode('utf-8')),
                ctypes.c_char_p(cliApVer.encode('utf-8')),
                ctypes.c_char_p(sysid.encode('utf-8')),
                ctypes.c_char_p(user.encode('utf-8')),
                ctypes.c_char_p(password.encode('utf-8')))
        else:
            return self.__sorapi.CSorClient_Connect(client,
                ctypes.c_char_p(connParam),
                ctypes.c_char_p(cliApName),
                ctypes.c_char_p(cliApVer),
                ctypes.c_char_p(sysid),
                ctypes.c_char_p(user),
                ctypes.c_char_p(password))
    def CSorClient_Disconnect(self, client):
        '''切斷連線'''
        return self.__sorapi.CSorClient_Disconnect(client)
    def CSorClient_Delete(self, client):
        self.__sorapi.CSorClient_Delete(client)
    def CSorClient_IsSessionConnected(self, client):
        return self.__sorapi.CSorClient_IsSessionConnected(client)
    def CSorClient_SgnResult(self, client):
        return self.__sorapi.CSorClient_SgnResult(client)
    def CSorClient_ChgPass(self, client, user, oldpass, newpass):
        return self.__sorapi.CSorClient_ChgPass(client, user, oldpass, newpass)
    def CSorClient_SendSorRequest(self, client, msgCode, reqCtx, reqLen):
        '''送出SORS要求訊息'''
        if sys.version_info[0] > 2:
            return self.__sorapi.CSorClient_SendSorRequest(client, msgCode, reqCtx.encode(self.Codeing()), reqLen)
        else:
            return self.__sorapi.CSorClient_SendSorRequest(client, msgCode, reqCtx, reqLen)
    def CSorClient_State(self, client):
        return self.__sorapi.CSorClient_State(client)
    def CSorTaskResult_WorkID(self, taskr):
        if sys.version_info[0] > 2:
            return self.__sorapi.CSorTaskResult_WorkID(taskr).decode(self.Codeing())
        else:
            return self.__sorapi.CSorTaskResult_WorkID(taskr)
    def CSorTaskResult_OrigResult(self, taskr):
        return self.__sorapi.CSorTaskResult_OrigResult(taskr)
    def CSorTaskResult_NameTable(self, taskr, tableName):
        return self.__sorapi.CSorTaskResult_NameTable(taskr, tableName)
    def CSorTaskResult_TableCount(self, taskr):
        return self.__sorapi.CSorTaskResult_TableCount(taskr)
    def CSorTaskResult_IndexTable(self, taskr, index):
        return self.__sorapi.CSorTaskResult_IndexTable(taskr, index)
    def CSorTable_Properties(self, table):
        return self.__sorapi.CSorTable_Properties(table)
    def CSorTable_RecordsCount(self, table):
        return self.__sorapi.CSorTable_RecordsCount(table)
    def CSorTable_RecordIndexField(self, table, recordIndex, fieldIndex):
        return self.__sorapi.CSorTable_RecordIndexField(table, recordIndex, fieldIndex)
    def CSorTable_RecordField(self, table, recordIndex, field):
        if sys.version_info[0] > 2:
            return self.__sorapi.CSorTable_RecordField(table, recordIndex, field).decode(self.Codeing())
        else:
            return self.__sorapi.CSorTable_RecordField(table, recordIndex, field)
    def CSorProperties_Get(self, props, propertyName):
        if sys.version_info[0] > 2:
            return self.__sorapi.CSorProperties_Get(props, propertyName.encode(self.Codeing()))
        else:
            return self.__sorapi.CSorProperties_Get(props, propertyName)
    def CSorProperties_Name(self, props):
        if sys.version_info[0] > 2:
            return self.__sorapi.CSorProperties_Name(props).decode(self.Codeing())
        else:
            return self.__sorapi.CSorProperties_Name(props)
    def CSorProperties_DisplayText(self, props):
        return self.__sorapi.CSorProperties_DisplayText(props)
    def CSorProperties_Description(self, props):
        return self.__sorapi.CSorProperties_Description(props)
    def CSorProperties_ToString(self, props):
        return self.__sorapi.CSorProperties_ToString(props)
    def CSorTable_Fields(self, table):
        return self.__sorapi.CSorTable_Fields(table)
    def CSorFields_NameField(self, fields, fieldName):
        return self.__sorapi.CSorFields_NameField(fields, fieldName)
    def CSorFields_IndexField(self, fields, index):
        return self.__sorapi.CSorFields_IndexField(fields, index)
    def CSorFields_Count(self, fields):
        return self.__sorapi.CSorFields_Count(fields)
    def CSorField_Properties(self, field):
        return self.__sorapi.CSorField_Properties(field)
    def CSorField_Index(self, field):
        return self.__sorapi.CSorField_Index(field)
    def CSorFlowCtrlSender_Create(self, client):
        return self.__sorapi.CSorFlowCtrlSender_Create(client)
    def CSorFlowCtrlSender_Delete(self, fcSender):
        return self.__sorapi.CSorFlowCtrlSender_Delete(fcSender)
    def CSorFlowCtrlSender_SetFlowCtrl(self, fcSender, rate, rateMS):
        return self.__sorapi.CSorFlowCtrlSender_SetFlowCtrl(fcSender, rate, rateMS)
    def CSorFlowCtrlSender_IsFlowCfg(self, fcSender):
        return self.__sorapi.CSorFlowCtrlSender_IsFlowCfg(fcSender)
    def CSorFlowCtrlSender_PendingCount(self, fcSender):
        return self.__sorapi.CSorFlowCtrlSender_PendingCount(fcSender)
    def CSorFlowCtrlSender_AckParser(self, fcSender,  msgCode, acks):
        if sys.version_info[0] > 2:
            return self.__sorapi.CSorFlowCtrlSender_AckParser(fcSender, msgCode, acks.encode(self.Codeing()))
        else:
            return self.__sorapi.CSorFlowCtrlSender_AckParser(fcSender, msgCode, acks)
    def CSorFlowCtrlSender_SetAckTime (self, fcSender, msgCode, ackCount):
        return self.__sorapi.CSorFlowCtrlSender_SetAckTime(fcSender, msgCode, ackCount)
    def CSorFlowCtrlSender_SendSorRequest(self, fcSender, reqmsg, reqmsgLen):
        if sys.version_info[0] > 2:
            return self.__sorapi.CSorFlowCtrlSender_SendSorRequest(fcSender, reqmsg.encode(self.Codeing()), reqmsgLen)
        else:
            return self.__sorapi.CSorFlowCtrlSender_SendSorRequest(fcSender, reqmsg, reqmsgLen)
    def CSorFlowCtrlSender_SendSorRequests(self, fcSender, reqmsg, reqmsgLen):
        return self.__sorapi.CSorFlowCtrlSender_SendSorRequests(fcSender, reqmsg, reqmsgLen)
