from .pySorApi.sorapi import SorApi
from .pySorApi.utility import Map

import requests
import base64
import json
import configparser
import os

class user:
    def __init__(self):
        self.accounts = []
        self.sys_id = ""
        self.xtrade2_host = ""
        self.password = ""

class SsoSorApi:
    def __init__(self, callbacks: Map = None):
        self.callables = callbacks
        self.user = None
        
    def __set_user_data(self, original_user_data):
        user_data = base64.b64decode(original_user_data)
        decoded_user_data = user_data.decode('latin_1').replace('\\', '\\\\')
        json_user_data = json.loads(decoded_user_data, strict = False)
        #主機
        for e in json_user_data['iniFile']:
            if e['fname'] == 'SYS_XTRADE.ini':
                self.user = user()
                for row in e['data'].split('\n'):
                    line = row.split('=')
                    if(len(line) < 2):
                        continue
                    if(line[0] == 'edConnParam'):
                        self.user.xtrade2_host = line[1]
                    elif(line[0] == 'edSysID'):
                        self.user.sys_id = line[1]
                    elif(line[0] == 'edPassWord'):
                        self.password = line[1]
                    
        
        #帳號
        stk_accounts = json_user_data['accounts']
        for stk_account in stk_accounts:
            if stk_account['server'] == 'stk':
                _accounts = {'account': stk_account['account'], 'ib':  stk_account['IB']}
                self.user.accounts.append(_accounts)


    def __connect_sso(self, sso_url: str, sso_user: str, sso_password: str) -> bool:
        r = requests.get(f'{sso_url}/tc4grpright/getSsoClassID.jsp?TradingAccount={sso_user}&password={sso_password}')
        try:
            requests_json = r.json()
            if requests_json['result'] == 'true': 
                print('SSO登入成功')
                self.__set_user_data(requests_json['user_data'])
                return True
            else:
                print('SSO登入失敗')
                return False
        except:
            print('SSO伺服器錯誤')
            return False

    def create_connection(self, sso_url: str, user: str, password: str):
        if self.__connect_sso(sso_url, user, password):
            obj_sorapi = SorApi(self.callables)
            obj_sorapi.Connect(self.user.xtrade2_host, self.user.sys_id, user, self.password)
            return obj_sorapi
        else:
            return None