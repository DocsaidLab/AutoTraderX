from dataclasses import dataclass, field
from MasterTradePy.constant import AccountStatus, ReqResultRowType, Side, OrderType, TradingSession, Exchange, TradingType, TradingUnit, PriceType, RequestType, RCode, BasicReqResult
from abc import ABCMeta, abstractmethod
from MasterTradePy.error import MTPYError
import json
import typing
import os

@dataclass
class Basic:
    symbol: str
    name: str
    refPrice: str
    riseStopPrice: str
    fallStopPrice: str

@dataclass
class Inventory:
    symbol: str
    qty: str
    qtyCredit: str
    qtyDebit: str
    qtyZero: str
    
@dataclass    
class Inventory_S:
    symbol: str
    qty: str
    qtyCredit: str
    qtyDebit: str
    qtyZero: str

@dataclass
class SecInvQty:
    symbol:str
    "股票代碼"
    secInvQty:str
    "總券源股數"
    usedQty: str
    "已使用股數"

@dataclass
class CrQtyAndDbQty:
    Symbol:str
    "股票代碼"
    IsCrStop:str
    "是否停資(Y/N)"
    CrQty: str
    "融資配額股數"
    s_crQty:str

    IsDbStop:str
    "是否停券(Y/N)"
    DbQty:str
    "融券配額股數"
    s_dbQty:str

    CrRate:str
    "資成數"
    DbRate:str
    "券成數"
    CanShortUnderUnchanged:str
    "平盤下是否可下券(Y/N)"
    DayTrade:str
    "X=可現股當沖;Y=僅可先買後賣沖;其他為不可現股當沖"    
    DayTradeCName:str 
    "X=可現股當沖;Y=僅可先買後賣沖;其他為不可現股當沖"
    crflag:str
    "信用交易資格"
    lumsg:str
    "平盤下可券"
    dtemsg:str
    "可當沖"
    result:str
    "資券配額查詢結果"
    
       
class SystemEvent:
    def __init__(self, code: RCode, message):
        self.code = code
        self.message = message
        
    def __str__(self):
        return f"{self.code}:{self.message}"
        

class UserLoginReply:
    def __init__(self, **j):
        self.result : bool = j.get('result', False)
        self.message = j.get('message', '')
        self.ssoUrl = j.get('ssoUrl', '')
        self.host = j.get('host', '')
        self.sysId = j.get('sysId', '')
        self.password = j.get('password', '')
        self.list : list = j.get('list', [])
        
    #{"ssoUrl":"http://192.168.5.135:8080","host":"202.39.34.93:7053","sysId":"API","password":"1234","list":[{"uid":"J122573770","account":"592u9808086","statusCode":1}],"result":true,"message":"trade account retrieved"}
    
class UserLogin:
    def __init__(self, username: str, password: str, source_type: str, request_type: RequestType, is_sim, is_event) -> None:
        self.username = username
        self.password = password
        self.source_type = source_type
        self.request_type = request_type
        self.ip = "0.0.0.0"
        self.isSIM = is_sim
        self.isEvent = is_event
        
    def to_json(self) -> str:
        mapping = {'username': 'uid', 'password': 'pass', 'source_type': 'source', 'request_type': 'requestType'}
        return json.dumps({mapping.get(k, k): v for k, v in self.__dict__.items()})
    
@dataclass
class OrderQtyChange:
    ordNo: str = field(default="")
    qty: str = field(default="")
    tradingAccount: str = ""

@dataclass
class OrderPriceChange:
    ordNo: str = field(default="")
    price: str = field(default="")
    tradingAccount: str = ""
         
@dataclass
class Order:
    sorRID: str = field(init = False, default='')
    exchange: Exchange = field(init = False, default=Exchange.TWSE)
    tradingSession: TradingSession = ""
    side: Side = field(default="")
    symbol: str = field(default="")
    priceType: PriceType = field(default="")
    price: str = field(default="")
    tradingUnit: TradingUnit = field(default=0)
    qty: str = field(default="")
    orderType: OrderType = field(default="")
    tradingType: TradingType = field(init = False, default="")
    brokerNo: str = field(init = False, default="")
    userDef: str = ""
    tradingAccount: str = ""
    ordNo: str = field(init = False, default="")
    trxTime: str = field(init = False, default="")
    lastdealTime: str = field(init = False, default="")
    status: str = field(init = False, default="")
    leavesQty: str = field(init = False, default="")
    cumQty: str = field(init = False, default="") #+++
    dealPri: str = field(init = False, default="") #+++
    tableName : str = "" #+++
   
@dataclass
class ReportOrder:
    orgOrder: Order
    order: Order
    lastMessage: str = field(init = False, default="")
    scBalance: str =  field(init = False, default="")

@dataclass
class ReqResult:
    type: ReqResultRowType
    values: typing.List[str]
    def __init__(self, raw: str, type: ReqResultRowType):
        self.values = raw.split('|')
        self.type = type
        
    def GetData(self, idx: BasicReqResult):
        return self.values[idx.value]
        
       
class ReqResults:
    results : typing.List[ReqResult]
    rowCount = 0
    def __init__(self, wid: str, raw: typing.List[str]):
        self.wid = wid
        self.raw = raw
        self.results = list()
        for idx, data in enumerate(raw):
            if data and idx == 0 and data.find("rowCount") != -1:
                self.rowCount = int(data[data.index('=')+1:])
                self.results = [None] * (int(self.rowCount) + 1)
            if data and self.results and idx >= 1:
                if idx == 1:
                    self.results[idx - 1] = ReqResult(data, ReqResultRowType.FIELDS)
                else:
                    self.results[idx - 1] = ReqResult(data, ReqResultRowType.VALUES)
    
    def GetData(self, row: int, field: BasicReqResult):
        return self.results[row].GetData(field)
            

class MarketTrader(metaclass=ABCMeta):
    @ abstractmethod
    def OnNewOrderReply(self, data) -> None:
        pass

    @ abstractmethod
    def OnChangeReply(self, data) -> None:
        pass

    @ abstractmethod
    def OnCancelReply(self, data) -> None:
        pass
    
    @ abstractmethod
    def OnReport(self, data) -> None:
        pass

    @ abstractmethod
    def OnAnnouncementEvent(self, data)->None:
        pass
    
    @ abstractmethod
    def OnSystemEvent(self, event: SystemEvent) -> None:
        pass
            
    @ abstractmethod        
    def OnError(self, error: MTPYError):
        pass
    
    @ abstractmethod        
    def OnReqResult(self, workid: str, data):
        pass
