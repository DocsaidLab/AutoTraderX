import setuptools
with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="MasterTradePy",
    version="0.0.22",
    author="SYLIN",
    author_email="sylin@masterlink.com.tw",
    description="MasterLink TWSE Trading Python API package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(),
    package_dir={'': '.'},
    install_requires=['requests', 'solace-pubsubplus'],
    include_package_data=True,
    package_data={
        '': ['*.dll'],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
