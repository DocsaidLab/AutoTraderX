# cmd = input('0: 結束\n1: 下單\n2: 改量\n3: 改價\n4: 期初庫存\n5: 庫存\n')

# if len(cmd) < 7:
#     cmd = cmd.zfill(7)
# print(cmd)
# if cmd == '0':
#     print("0")
# else:
#     print("f")
import chardet

with open("/dev/tty", "rb") as f:
     encoding = chardet.detect(f.read()).get("encoding")

print(encoding)

"""64bit
    is_64bits = sys.maxsize > 2**32
    if is_64bits==False:
        print("執行版本錯誤,請使用python-64bit版本")
        os.system("pause")
        sys.exit(0)
"""
"""32bit
    is_64bits = sys.maxsize > 2**32
    if is_64bits:
        print("執行版本錯誤,請使用python-32bit版本")
        os.system("pause")
        sys.exit(0)
"""