from enum import Enum
from dataclasses import dataclass

ACTION_BUY = "Buy"
ACTION_SELL = "Sell"

ORDER_TYPE_ROD = "ROD"
ORDER_TYPE_IOC = "IOC"
ORDER_TYPE_FOK = "FOK"

PRICE_TYPE_LMT = "L"
PRICE_TYPE_MKT = "M"

class RCode(Enum):
    OK = 0
    FAIL = -1
    ACCOUNT_NOT_FOUND = -2
    
# 來源別
class Src(str, Enum):
    # API
    API = "P"

# 交易所   
class Exchange(str, Enum):
    TWSE = "TWSE"

# 交易時段
class TradingSession(str, Enum):
    # 普通
    NORMAL = "N"
    # 盤後
    FIXED_NORMAL = "F"
    # 盤中零股
    ODD = "R"
    # 盤後零股
    FIXED_ODD = "L"

# 買賣別  
class Side(str, Enum):
    # 買進
    Buy = "B"
    # 賣出
    Sell = "S"

# 委託方式(效期)    
class OrderType(str, Enum):
    # 當日有效
    ROD = "R"
    # 立即成交，否則取消
    IOC = "I"
    # 立即全部成交，否則取消
    FOK = "F"

# 委託方式(價格)   
class PriceType(str, Enum):
    # 限價單
    LMT = "L"
    # 市價單
    MKT = "M"

# 委託別
class TradingType(str, Enum):
    # 集保
    CUSTODY = "G"

# 交易單位     
class TradingUnit(int,Enum):
    COMMON = 1000
    ODD = 1


@dataclass
class Config:
    _instance = None
    XTRADE_HOST: str = '172.18.5.31:7053'
    XTRADE_SYSID: str = 'API'
    SOL_SESSION_HOST: str = '172.18.8.49:55555'
    SOL_SESSION_VPN_NAME: str = 'api'
    SOL_SESSION_USERNAME: str = 'QuoteAPI_TW'
    SOL_SESSION_PASSWORD: str = 'ml2856'
    SOL_SESSION_REAPPLY_SUBSCRIPTIONS: str = '1'
    SOL_SESSION_CONNECTION_TIMEOUT_MS: int = 5000
    SOL_SESSION_SUBSCRIPTION_LIMIT: int = 100
    SOL_SESSION_CLIENT_NAME: str = ''
    USER_AUTH_URL: str = ''
    USER_SOURCE_TYPE: str = 'MQCS'
    USER_AUTH_TOPIC: str = 'DAPI/REQ/TW/AUTH/NEW'
    SYSANNTWS = "DAPI/Quote/TWS/ANN"
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
class RequestType(int, Enum):
    QuoteAPI = 0
    TradeQPI = 1

class AccountStatus(int, Enum):
    NotApplied = 0
    NotVerified = 1
    Verified = 2
    #已確認認證
    Approved = 3

class RCode(Enum):
    OK = 0
    WOULD_BLOCK = 1
    IN_PROGRESS = 2
    NOT_READY = 3
    EOS = 4
    NOT_FOUND = 5
    NOEVENT = 6
    INCOMPLETE = 7
    ROLLBACK = 8
    CLIENT_TESTING = 9
    RECONNECTED = 10
    PART_USER_VERIFIED = 11
    FAIL = -1
    CONNECTION_REFUSED = -2
    ALREADY_EXISTS = -3
    NO_EXISTS = -4
    CLIENT_NOT_READY = -5
    SUBSCRIPTION_LIMIT_EXCEEDED = -6
    USER_NOT_APPLIED = -7
    QUEUE_IS_FULL = -8
    CONNECTION_FAIL = -9
    LOGON_FAIL = -10
    SUBSCRIPTION_TOPIC_FAIL = -11
    CACHE_REQUEST_EXCEPTION = -12
    DOWNLOAD_PRODUCT_FAIL = -13
    USER_NOT_VERIFIED = -14
    REQUEST_TIMEOUT = -15   
    ACCOUNT_CA_ERROR = -16
    ACCOUNT_NOT_FOUND = -17
    UNKNOWN = -9999
    
class BasicReqResult(Enum):
    unikey = 0
    StkNo = 1
    PriUpLmt = 2
    PriDnLmt = 3
    PriRef = 4
    LastDate = 5
    Name = 13
    IsBelowRefSBL =19
    DTMark = 20

class Market(Enum):
    TSE = 'T' # 上市
    OTC = 'O' # 上櫃
    TES = 'R' # 興櫃
    
class InventoryReqResult(Enum):
    stock_no = 0 # 股票代號
    qtycn = 1 # 現股股數
    qtycr = 2 # 融資股數
    qtydb = 3 # 融券股數
    market = 4 # 市場別 (T:上市 , O:上櫃 , R:興櫃)
    qtyzero = 4 # 零股股數
    #庫存
    qtycnn=6 #即時集保股數(不含零股)
    qtycrn=7 #資未銷股數
    qtydbn=8 #券未銷股數
    qtyap5n=9 #零股股數餘額



class SecInvQtyResult(Enum):
    symbol = 0
    secInvQty = 2
    usedQty = 3
    bkrNoAccNo = 3

class CrQtyAndDbQtyResult(Enum):
    symbol = 0
    IsCrStop = 3    #是否停資(Y/N)
    CrQty = 2       #融資配額股數
    CrRate = 4      #資成數
    
    
    IsDbStop = 3    #是否停券(Y/N)
    DbQty = 2       #融券配額股數 
    DbRate = 5      #券成數

    crflag = 8      #信用交易資格
    lumsg = 10        #平盤下可券 
    dtemsg = 11       #可當沖  

    CanShortUnderUnchanged = 8
    DayTrade = 9

       
class ReqResultRowType(Enum):
    FIELDS = 0
    VALUES = 1
    
class SorReqType(Enum):
    BASIC = 0
    INVENTORY_S = 1
    INVENTORY = 2
    SecInvQty = 3
    ProdCrQty = 4
    ProdDbQty = 5

