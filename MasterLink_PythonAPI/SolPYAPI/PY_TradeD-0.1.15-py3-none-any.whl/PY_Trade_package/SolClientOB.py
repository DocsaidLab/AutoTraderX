import datetime #line:1
from threading import Lock #line:2
from PY_Trade_package .SolLog import *#line:3
from PY_Trade_package .SolPYAPI_Model import *#line:4
from PY_Trade_package .Helper import MQCSHelper #line:5
from solace .messaging .messaging_service import MessagingService #line:7
from solace .messaging .publisher .outbound_message import OutboundMessage #line:8
from solace .messaging .resources .topic import Topic #line:9
from solace .messaging .resources .topic_subscription import TopicSubscription #line:10
from enum import Enum #line:11
from solace .messaging .resources .cached_message_subscription_request import CachedMessageSubscriptionRequest #line:12
from solace .messaging .utils .cache_request_outcome_listener import CacheRequestOutcomeListener #line:13
from solace .messaging .utils .cache_request_outcome import CacheRequestOutcome #line:14
class Stats_Rx (Enum ):#line:17
    DirectBytes =0 #line:18
    "Direct data bytes received"#line:19
    Bytes =1 #line:20
    "Direct data bytes received"#line:21
    DirectMsgs =2 #line:22
    "Direct data messages received"#line:23
    Msgs =3 #line:24
    "Direct data messages received"#line:25
    NonEmptyReads =4 #line:26
    "non-empty reads"#line:27
    DiscardMsgIndication =5 #line:28
    "Messages with discard indication"#line:29
    DiscardSMFUnknownElement =6 #line:30
    "Invalid messages (SMF parser Error)"#line:31
    DiscardMsgTooBig =7 #line:32
    "Receive message too large"#line:33
    AcksSent =8 #line:34
    "Guaranteed Delivery Acknowledgements sent"#line:35
    DiscardsDuplicate =9 #line:36
    "Duplicate Guaranteed Delivery messages received"#line:37
    DiscardsNoMatchingFlow =10 #line:38
    "Guaranteed Delivery messages with unknown flow"#line:39
    DiscardsOutOfOrder =11 #line:40
    "Out of order Guaranteed Delivery messages received"#line:41
    PersistentBytes =12 #line:42
    "Guaranteed Delivery (Persistent) bytes received"#line:43
    PersistentMsgs =13 #line:44
    "Guaranteed Delivery (Persistent) messages received"#line:45
    NonPersitentBytes =14 #line:46
    "Guaranteed Delivery (Non-Persistent) bytes received"#line:47
    NonPersistentMsgs =15 #line:48
    "Guaranteed Delivery (Non-Persistent) messages received"#line:49
    ControlMsgs =16 #line:50
    "Control (non-data) messages received"#line:51
    ControlBytes =17 #line:52
    "Control (non-data) bytes received"#line:53
    TotalDataBytes =18 #line:54
    "Data bytes received"#line:55
    TotalDataMsgs =19 #line:56
    "Data messages received"#line:57
    CompressedBytes =20 #line:58
    "Bytes received before decompression"#line:59
    ReplyMsg =21 #line:60
    "Reply messages received"#line:61
    ReplyMsgDiscard =22 #line:62
    "Reply messages discarded due to no outstanding request"#line:63
    CacheRequestOkResponse =23 #line:64
    "Cache Requests completed ok"#line:65
    CacheRequestFulfillData =24 #line:66
    "Cache Requests fulfilled by live data"#line:67
    CacheRequestErrorResponse =25 #line:68
    "Cache Requests failed due to solCache error response"#line:69
    CacheRequestDiscardResponse =26 #line:70
    "Cached Request Response discarded due to errors in response format"#line:71
    CacheMsg =27 #line:72
    "Cached messages delivered to application"#line:73
    FoundCutThroughSync =28 #line:74
    "On a cut-through Flow, the number of times the Flow entered cut-through delivery mode."#line:75
    LostCutThroughSync =29 #line:76
    "On a cut-through Flow, the number of times the Flow left cut-through delivery mode to resynchronize with the Guaranteed message storage on the appliance."#line:77
    LostCutThroughSyncGM =30 #line:78
    "On a cut-through Flow, the number of times the Flow left cut-through delivery mode to resynchronize with the Guaranteed message storage due to receiving a Guaranteed message that was not previously received as Direct."#line:79
    OverflowCutThroughSyncBuffer =31 #line:80
    "On a cut-through Flow, the number of times the synchronization buffer overflowed, delaying synchronization."#line:81
    AlreadyCutThrough =32 #line:82
    "On a cut-through Flow, the number of Guaranteed messages discarded because they had already been received on the cut-through Flow."#line:83
    DiscardFromCutThroughSync =33 #line:84
    "On a cut-through Flow, the number of messages discarded from the synchronization list other than those discarded due to overflow."#line:85
    DiscardMessageFlowUnboundPending =34 #line:86
    "On a transacted flow, the number of messages discarded because the flow is in a UNBOUND pending state."#line:87
    DiscardMessageTransactionRollback =35 #line:88
    "On a transacted flow, the number of messages discarded after a transaction rollback and becomes a message comes in with prevMsgId=0."#line:89
    DiscardTransactionResponse =36 #line:90
    "On a transacted session, the number of transaction responses discarded due to reconnection."#line:91
class SolClient :#line:93
    host =''#line:95
    vpn =''#line:96
    username =''#line:97
    password =''#line:98
    cacheName ='dc01'#line:99
    clientName =''#line:100
    cacheRequestTimeoutInMsecs =50000 #line:101
    requestTimeoutInMsecs =50000 #line:102
    session =None #line:103
    context =None #line:104
    Jan1st1970 =datetime .datetime (1970 ,1 ,1 ,0 ,0 ,0 ,tzinfo =datetime .timezone .utc )#line:106
    def __init__ (O00000O000O0O000O ,OO0000O0OOOOOOO0O :str ,OOOO0OO00O00OOO00 :str ,O00O0OO0OO00OOOOO :str ,OO000OO0O0O00O0OO :str ,O0OOO0O0000OO000O :SolaceLog ,clientName :str =""):#line:107
        ""#line:108
        O00000O000O0O000O .host =OO0000O0OOOOOOO0O #line:109
        O00000O000O0O000O .vpn =OOOO0OO00O00OOO00 #line:110
        O00000O000O0O000O .username =O00O0OO0OO00OOOOO #line:111
        O00000O000O0O000O .password =OO000OO0O0O00O0OO #line:112
        if clientName =="":#line:113
            O0000OOOO0OO00000 =int ((datetime .datetime .now (datetime .timezone .utc )-O00000O000O0O000O .Jan1st1970 ).total_seconds ()*1000 )#line:114
            O00OOOO0OOO0O0000 =MQCSHelper .extractIp ()#line:115
            O00000O000O0O000O .clientName =f"MQCS:{O00O0OO0OO00OOOOO}:{O00OOOO0OOO0O0000}:{O0000OOOO0OO00000}"#line:116
        else :#line:117
            O00000O000O0O000O .clientName =clientName #line:118
        O00000O000O0O000O .lockObj =Lock ()#line:119
        O00000O000O0O000O .lock_RequestID =Lock ()#line:120
        O00000O000O0O000O ._fLast_RequestID =0 #line:121
        O00000O000O0O000O ._log =O0OOO0O0000OO000O #line:122
        O00000O000O0O000O ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"init SolClient: host={O00000O000O0O000O.host}, vpn={O00000O000O0O000O.vpn}, username={O00000O000O0O000O.username}, password={O00000O000O0O000O.password}, clientName={O00000O000O0O000O.clientName}")#line:123
        O00000O000O0O000O ._is_connected =False #line:124
    def PrintRxStats (O0OO0000OO000OOOO ):#line:126
        ""#line:127
        O0O0O0O00000OO0OO =""#line:129
        O00OOO000OO0O00O0 =list (Stats_Rx )#line:130
        O0O0O0O00000OO0OO =O0O0O0O00000OO0OO +"Session Rx stats: "#line:131
        for O0O0O0O00OO0O00OO in range (len (O00OOO000OO0O00O0 )):#line:132
            try :#line:133
                O0O0O0O00000OO0OO =O0O0O0O00000OO0OO +f"\n\t{O0O0O0O00OO0O00OO} {O00OOO000OO0O00O0[O0O0O0O00OO0O00OO]}"#line:134
            except Exception as O00000000O0O0O00O :#line:135
                O0OO0000OO000OOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"PrintRxStats exception!{O0O0O0O00OO0O00OO}")#line:136
    def SendRequestSync (OOOOO00OO0OOO00O0 ,O0OOO0OOOO000OO0O :str ,O0OO00000OO0000OO :str ,Ecoding :str ="utf-8")->str :#line:145
        ""#line:147
        return OOOOO00OO0OOO00O0 .SendRequestSyncX (O0OOO0OOOO000OO0O ,O0OO00000OO0000OO ,OOOOO00OO0OOO00O0 .requestTimeoutInMsecs ,Ecoding );#line:148
    def SendRequestSyncX (O0OOOO0000OOO0OO0 ,OO000O00O0OO0O0OO :str ,OO000O0O0O0O00OO0 :str ,OO000OO000OO0OO00 :int ,O0OO0OOO00OO0O0OO :str )->str :#line:150
        ""#line:152
        O0OOOO0000OOO0OO0 ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"request topic={OO000O00O0OO0O0OO}, message={OO000O0O0O0O00OO0}, timeout={OO000OO000OO0OO00}")#line:153
        OOOO0O0OOOOOOO000 =""#line:154
        if OO000O00O0OO0O0OO .startswith ("QuoteOvs/"):#line:155
            O0OO0OOO00OO0O0OO ='big5'#line:156
        O0OOOOO0O0OO0O000 =bytearray (f'{OO000O0O0O0O00OO0}',O0OO0OOO00OO0O0OO )#line:158
        OO000OO000OOOO0OO :OutboundMessage =O0OOOO0000OOO0OO0 ._message_service .message_builder ().build (payload =O0OOOOO0O0OO0O000 )#line:159
        try :#line:160
            with O0OOOO0000OOO0OO0 .lockObj :#line:161
                OOOO0O0OOOOOOO000 =O0OOOO0000OOO0OO0 ._message_requester .publish_await_response (request_message =OO000OO000OOOO0OO ,request_destination =Topic .of (OO000O00O0OO0O0OO ),reply_timeout =OO000OO000OO0OO00 )#line:165
                OOO00OOO0O0O0OO00 =OOOO0O0OOOOOOO000 .get_payload_as_bytes ().decode (O0OO0OOO00OO0O0OO )#line:166
            return OOO00OOO0O0O0OO00 #line:167
        except Exception as O00000OO0000OOOO0 :#line:168
            O0OOOO0000OOO0OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"SendRequestSyncX Request failed, return code{O00000OO0000OOOO0}")#line:169
        return ""#line:170
    def createConnection (OOOO0OOOOO00O0O00 ,OO00OO0O00000000O )->RCode :#line:172
        OOOO0OOOOO00O0O00 ._log .Add (arg1 =SolLogType .Info ,arg2 ="Start Create Connection")#line:173
        O0OO000OOOO0O0OOO :RCode =RCode .FAIL #line:175
        OO0O0O0OO00OO0OO0 :dict ={}#line:177
        OO0O0O0OO00OO0OO0 ["solace.messaging.transport.host"]=OOOO0OOOOO00O0O00 .host #line:178
        OO0O0O0OO00OO0OO0 ["solace.messaging.service.vpn-name"]=OOOO0OOOOO00O0O00 .vpn #line:179
        OO0O0O0OO00OO0OO0 ["solace.messaging.authentication.basic.username"]=OOOO0OOOOO00O0O00 .username #line:180
        OO0O0O0OO00OO0OO0 ["solace.messaging.authentication.basic.password"]=OOOO0OOOOO00O0O00 .password #line:181
        OO0O0O0OO00OO0OO0 ['solace.messaging.transport.reconnection-attempts']=5 #line:182
        if OOOO0OOOOO00O0O00 .clientName !="":#line:183
            OO0O0O0OO00OO0OO0 ["solace.messaging.client.name"]=OOOO0OOOOO00O0O00 .clientName #line:184
        try :#line:185
            with OOOO0OOOOO00O0O00 .lockObj :#line:186
                OOOO0OOOOO00O0O00 ._message_service =MessagingService .builder ().from_properties (OO0O0O0OO00OO0OO0 ).build ()#line:187
                OOOO0OOOOO00O0O00 ._message_service .connect ()#line:188
                OOOO0OOOOO00O0O00 ._message_receiver =OOOO0OOOOO00O0O00 ._message_service .create_direct_message_receiver_builder ().build ()#line:190
                OOOO0OOOOO00O0O00 ._message_receiver .start ()#line:191
                OOOO0OOOOO00O0O00 ._message_receiver .receive_async (OO00OO0O00000000O )#line:193
                OOOO0OOOOO00O0O00 ._direct_publish_service =OOOO0OOOOO00O0O00 ._message_service .create_direct_message_publisher_builder ().build ()#line:195
                OOOO0OOOOO00O0O00 ._message_requester =OOOO0OOOOO00O0O00 ._message_service .request_reply ().create_request_reply_message_publisher_builder ().build ().start ()#line:196
                OOOO0OOOOO00O0O00 ._is_connected =OOOO0OOOOO00O0O00 ._message_service .is_connected #line:197
                if OOOO0OOOOO00O0O00 ._is_connected :#line:198
                    O0OO000OOOO0O0OOO =RCode .OK #line:199
                else :#line:200
                    O0OO000OOOO0O0OOO =RCode .FAIL #line:201
        except Exception as O000OOO00000000O0 :#line:203
            OOOO0OOOOO00O0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Create Connection Fail. {O000OOO00000000O0}")#line:204
        OOOO0OOOOO00O0O00 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"End of Create Connection: rc={O0OO000OOOO0O0OOO}")#line:206
        return O0OO000OOOO0O0OOO #line:207
    def AddSubscription (OO0OO000OOOOO0O0O ,OO00000O0O0O0OOO0 :str )->RCode :#line:210
        return OO0OO000OOOOO0O0O .AddSubscriptionX (OO00000O0O0O0OOO0 ,False )#line:211
    def AddSubscriptionX (OOO00000OOO000OO0 ,O0OO0OOOOO0O0O00O :str ,O0000OO0000O0OOOO :bool ):#line:213
        OOO00000OOO000OO0 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"AddSubscription: topic={O0OO0OOOOO0O0O00O}, withCache={O0000OO0000O0OOOO}")#line:214
        O0OOO0OOO000O000O :RCode =RCode .FAIL #line:215
        if OOO00000OOO000OO0 ._is_connected :#line:216
            try :#line:217
                with OOO00000OOO000OO0 .lockObj :#line:218
                    OOO00000OOO000OO0 ._message_receiver .add_subscription (TopicSubscription .of (O0OO0OOOOO0O0O00O ))#line:219
                O0OOO0OOO000O000O =RCode .OK #line:220
                return O0OOO0OOO000O000O #line:221
            except Exception as O0OOO000OOOOOO00O :#line:222
                OOO00000OOO000OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Session subscribe: topic={O0OO0OOOOO0O0O00O} {O0OOO000OOOOOO00O}")#line:223
        return O0OOO0OOO000O000O #line:224
    def AddSubscriptionXUid (OO0O00O0OO0000OO0 ,O000O00OO00000O0O :str ,OOO0O000O0OO00OOO :str ,OO0O0OO0OO00O0O0O :bool ):#line:226
        OOOO000O0O00OO0OO =O000O00OO00000O0O +"/"+OOO0O000O0OO00OOO [:-6 ]+"******"#line:227
        O000O00OO00000O0O =O000O00OO00000O0O +"/"+OOO0O000O0OO00OOO #line:228
        OO0O00O0OO0000OO0 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"AddSubscription: topic={OOOO000O0O00OO0OO}, withCache={OO0O0OO0OO00O0O0O}")#line:229
        O000000000OO00000 :RCode =RCode .FAIL #line:230
        if OO0O00O0OO0000OO0 ._is_connected :#line:231
            try :#line:232
                with OO0O00O0OO0000OO0 .lockObj :#line:233
                    OO0O00O0OO0000OO0 ._message_receiver .add_subscription (TopicSubscription .of (O000O00OO00000O0O ))#line:234
                O000000000OO00000 =RCode .OK #line:235
                return O000000000OO00000 #line:236
            except Exception as OO0OO00OOO0OO0000 :#line:237
                OO0O00O0OO0000OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Session subscribe: topic={O000O00OO00000O0O} {OO0OO00OOO0OO0000}")#line:238
        return O000000000OO00000 #line:239
    def AddSubscriptionlist (OO0O0O000OO00OOO0 ,OOO00O00O0OO000O0 :list ,O00OO00O0O0000000 :bool ):#line:241
        OO0O0O000OO00OOO0 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"AddSubscriptionlist: topic={OOO00O00O0OO000O0}, withCache={O00OO00O0O0000000}")#line:242
        OO00OOO00O0OO0O00 :RCode #line:243
        for OO000000O0O000OO0 in OOO00O00O0OO000O0 :#line:244
            OO00OOO00O0OO0O00 =OO0O0O000OO00OOO0 .AddSubscriptionX (OO000000O0O000OO0 ,O00OO00O0O0000000 )#line:245
            if OO00OOO00O0OO0O00 !=RCode .OK :#line:246
                OO0O0O000OO00OOO0 .RemoveSubscriptionlist (OOO00O00O0OO000O0 )#line:247
                return RCode .FAIL #line:248
        return RCode .OK #line:250
    def RemoveSubscriptionlist (OO0O000O0O00OOOO0 ,OO0OOO000000000OO :list ):#line:253
        for O0000OO00000O0OO0 in OO0OOO000000000OO :#line:254
            OOOOOO0O00O0O0000 =OO0O000O0O00OOOO0 .RemoveSubscription (O0000OO00000O0OO0 )#line:255
            if OOOOOO0O00O0O0000 !=RCode .OK :#line:256
                OO0O000O0O00OOOO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"RemoveSubscription: rc={OOOOOO0O00O0O0000}")#line:257
        return RCode .OK #line:258
    def RemoveSubscription (OO000OO00O0OO0O0O ,OOOOO0OOO0O0OO0O0 :str ):#line:260
        OO0OO00OOOOO00000 :RCode =RCode .FAIL #line:261
        try :#line:262
            with OO000OO00O0OO0O0O .lockObj :#line:263
                OO000OO00O0OO0O0O ._message_receiver .remove_subscription (TopicSubscription .of (OOOOO0OOO0O0OO0O0 ))#line:264
            OO0OO00OOOOO00000 =RCode .OK #line:265
            return OO0OO00OOOOO00000 #line:266
        except Exception as OOO000O0000000OOO :#line:267
            OO000OO00O0OO0O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Session Unsubscribe: topic={OOOOO0OOO0O0OO0O0} {OOO000O0000000OOO}")#line:268
        return OO0OO00OOOOO00000 #line:270
    def DisConnect (O0O0O00O0O00O0O00 ):#line:272
        O000OOO00000OOOOO =RCode .OK #line:273
        if O0O0O00O0O00O0O00 ._is_connected :#line:274
            O000OOO00000OOOOO :RCode =RCode .FAIL #line:275
            try :#line:276
                with O0O0O00O0O00O0O00 .lockObj :#line:277
                    O0O0O00O0O00O0O00 ._message_receiver .terminate ()#line:278
                    O0O0O00O0O00O0O00 ._message_requester .terminate ()#line:279
                    O0O0O00O0O00O0O00 ._message_service .disconnect ()#line:280
                O000OOO00000OOOOO =RCode .OK #line:281
            except Exception as OO0OOOOOOOOO00OO0 :#line:282
                O0O0O00O0O00O0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DisConnect:{OO0OOOOOOOOO00OO0}")#line:283
                O000OOO00000OOOOO =RCode .FAIL #line:284
            finally :#line:285
                pass #line:286
        return O000OOO00000OOOOO #line:288
    def request_cached_only (OO000O0OOOO0000O0 ,OO0OO00OO000O00O0 :str ,O0OOO0O0OO0OO0000 :str ,OOOOO0OOO00OOO00O :int ,O000OO0O0000OOO00 :int ):#line:290
        try :#line:291
            with OO000O0OOOO0000O0 .lockObj :#line:292
                O0OOO0000O0OO00OO =CachedMessageSubscriptionRequest .cached_only (OO0OO00OO000O00O0 ,TopicSubscription .of (O0OOO0O0OO0OO0000 ),OOOOO0OOO00OOO00O )#line:293
                OOO000O00OOO0O000 =MyCacheRequestOutcomeListener (OO000O0OOOO0000O0 )#line:294
                OO000O0OOOO0000O0 ._message_receiver .request_cached (O0OOO0000O0OO00OO ,O000OO0O0000OOO00 ,OOO000O00OOO0O000 )#line:296
        except Exception as O00OO0O0O0O0OO00O :#line:297
            OO000O0OOOO0000O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Error request_cached_only:{O00OO0O0O0O0OO00O}")#line:298
    def GetRequestID (O000OO00O0OO0O0O0 ):#line:300
        try :#line:301
            with O000OO00O0OO0O0O0 .lock_RequestID :#line:302
                OOOOOOOOOO00O00O0 =int (datetime .datetime .now ().strftime ("%y%m%d%H%M%S%f"))#line:303
                if OOOOOOOOOO00O00O0 <O000OO00O0OO0O0O0 ._fLast_RequestID :#line:304
                    OOOOOOOOOO00O00O0 =O000OO00O0OO0O0O0 ._fLast_RequestID +1 #line:305
                O000OO00O0OO0O0O0 ._fLast_RequestID =OOOOOOOOOO00O00O0 #line:306
                return OOOOOOOOOO00O00O0 #line:307
        except Exception as O00O00O0O000OOOOO :#line:308
            O000OO00O0OO0O0O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Error GetRequestID:{O00O00O0O000OOOOO}")#line:309
class MyCacheRequestOutcomeListener (CacheRequestOutcomeListener ):#line:311
    def __init__ (OO0OOOO0O0OOOO000 ,O0000000OOO00O00O )->None :#line:312
        OO0OOOO0O0OOOO000 ._log :SolaceLog =O0000000OOO00O00O #line:313
    def on_completion (O0OOOOOO0O0OOOO00 ,O0OO0O00O00O00000 :CacheRequestOutcome ,OO0OOO000000O000O :int ,O0O00O00OO0000O00 :Exception ):#line:315
        if O0OO0O00O00O00000 ==CacheRequestOutcome .FAILED :#line:316
            O0OOOOOO0O0OOOO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Mycache completion fail: result:{O0OO0O00O00O00000} id:{OO0OOO000000O000O} exception:{O0O00O00OO0000O00}")#line:317
