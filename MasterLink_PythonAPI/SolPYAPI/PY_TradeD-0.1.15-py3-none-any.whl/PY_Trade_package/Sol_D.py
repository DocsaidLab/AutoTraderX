import os
import pathlib

from PY_Trade_package.MarketDataMart import MarketDataMart
from PY_Trade_package.MasterQuoteDAPIOB import MasterQuoteDAPI
from PY_Trade_package.SolPYAPIOB import TQryStkProdMap,TQryStkProdRec
from PY_Trade_package.SolPYAPI_Model import RCode


class Sol_D():
    def __init__(self,mdm: MarketDataMart, pypath:str):  
        
        self.__solace = MasterQuoteDAPI(mdm,pypath)
        super().__init__()

    def Login(self, aUsername:str, aPassword:str, exchange:str, aIsSIM:bool=False)->RCode:
        return self.__solace.Login(aUsername, aPassword, exchange, aIsSIM)
    
    def DisConnect(self):
        return self.__solace.DisConnect()

    def Set_OnLogEvent(self, func:callable):        
        self.__solace.Set_OnLogEvent(func)
    def Set_OnInterruptEvent(self, func:callable):        
        self.__solace.Set_OnInterruptEvent(func)    
    def Set_OnLoginResultEvent_DAPI(self, func:callable):
        self.__solace.OnLoginResultEvent_DAPI = func
    def Set_OnAnnouncementEvent_DAPI(self, func:callable):
        self.__solace.OnAnnouncementEvent_DAPI = func
    def Set_OnVerifiedEvent_DAPI(self, func:callable):
        self.__solace.OnVerifiedEvent_DAPI = func
    def Set_OnSystemEvent_DAPI(self, func:callable):
        self.__solace.OnSystemEvent_DAPI = func
    def Set_OnUpdateBasic_DAPI(self, func:callable):
        self.__solace.OnUpdateBasic_DAPI = func
    def Set_OnMatch_DAPI(self, func:callable):
        self.__solace.OnMatch_DAPI = func

    def Subscribe(self, exchange:str, symbol:str)->RCode:
        return self.__solace.Subscribe(exchange,symbol)
    
    def Unsubscribe(self, exchange:str, symbol:str)->RCode:
        return self.__solace.Unsubscribe(exchange, symbol)
    
    def QryProdID_NormalStock(self):
        """取個一般上市上櫃股票商品檔(不含零股/權證)
        return  1:RCode
                2:out TQryStkProdMap mapProd"""
        ret, mapProd =  self.__solace.QryProdID_NormalStock()
        return ret, mapProd
    
   

class TQryStkProdMapX(TQryStkProdMap):
    def __init__(self, mapping=None, **kwargs):
        super().__init__(mapping, **kwargs)

    def __setitem__(self, key, value):
        return super().__setitem__(key, value)
    
class TQryStkProdRecX(TQryStkProdRec):
    def __init__(self) -> None:
        super().__init__()
