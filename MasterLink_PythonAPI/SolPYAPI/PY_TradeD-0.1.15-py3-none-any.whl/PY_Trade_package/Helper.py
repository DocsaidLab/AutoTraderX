import socket
import os
import configparser


class MQCSHelper:
    @staticmethod
    def extractIp():
        localIP = ''
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            """ original code
            socket.Connect("10.255.255.255", 1);
            IPEndPoint endPoint = socket.LocalEndPoint as IPEndPoint;
            localIP = endPoint.Address.ToString();
            """
            s.connect(('10.255.255.255', 1))
            localIP = s.getsockname()[0]
        return localIP
    
class IniFile:

    # MaxSectionSize:int = 32767
    m_path:str
    config:configparser.ConfigParser
    def __init__(self, path: str):
        """
        Initializes a new instance of the IniFile class.

        Args:
            path (str): The path of the INI file.
        """       
        if not os.path.exists(path):
            with open(path, 'w') as f:
                pass
        self.m_path = os.path.abspath(path)
        self.config = configparser.ConfigParser()        
        self.config.read(self.m_path, encoding='utf-8')
        
    @property
    def Path(self) -> str:
        """
        Gets the full path of the INI file this object instance is operating on.

        Returns:
            str: A file path.
        """
        return self.m_path
    def GetString(self, section_name: str, key_name: str, default_value: str) -> str:
        if section_name is None:
            raise ValueError("sectionName cannot be None")
        if key_name is None:
            raise ValueError("keyName cannot be None")
        if section_name in self.config:
            if key_name in self.config[section_name]:
                return self.config[section_name][key_name]
        
        return default_value