import json #line:1
import logging #line:2
import os #line:3
import pathlib #line:4
import re #line:5
import socket #line:6
from threading import Lock #line:7
import threading #line:8
from time import sleep #line:9
from PY_Trade_package .Helper import IniFile #line:10
from PY_Trade_package .Product import *#line:11
from PY_Trade_package .SolClientOB import SolClient #line:12
from PY_Trade_package .SolPYAPIOB import *#line:13
from PY_Trade_package .MarketDataMart import MarketDataMart ,SystemEvent #line:14
from solace .messaging .receiver .message_receiver import MessageHandler ,InboundMessage #line:15
import hashlib #line:16
class TMarketKind (Enum ):#line:18
    ALL =0 #line:19
    FUT =1 #line:20
    STK =2 #line:21
    OVS =3 #line:22
class TVerifyResult ():#line:23
    MarketKind :TMarketKind #line:24
    IsSucc :bool #line:25
    Msg :str #line:26
    def __init__ (O0O00OO0O0O0OOO0O ,OOO0000O0O0OOO00O :bool ,O000000OOO0000000 :TMarketKind ,OO0O0O0O000OO0OOO :str )->None :#line:27
        O0O00OO0O0O0OOO0O .IsSucc =OOO0000O0O0OOO00O #line:28
        O0O00OO0O0O0OOO0O .MarketKind =O000000OOO0000000 #line:29
        O0O00OO0O0O0OOO0O .Msg =OO0O0O0O000OO0OOO #line:30
class Constants :#line:32
    ""#line:33
    AuthTopic ="DAPI/REQ/TW/AUTH/NEW"#line:35
    CheckTopicTX_TWSE ="DAPI/Quote/TWS/S/TSE/*/TX"#line:36
    CheckTopicBAS_TWSE ="DAPI/Quote/TWS/S/TSE/*/BAS"#line:37
    CheckTopicTX_TAIFEX ="DAPI/Quote/TWF/FUT/*/TX"#line:38
    CheckTopicBAS_TAIFEX ="DAPI/Quote/TWF/FUT/*/BAS"#line:39
    Topic_TWSE_SYSANNOUNCEMENT ="DAPI/Quote/TWS/ANN"#line:41
    Topic_TAIFEX_SYSANNOUNCEMENT ="DAPI/Quote/TWF/ANN"#line:42
    def __setattr__ (O00OO0O0OOOOO00O0 ,*_OOO0OOOOO000OO0O0 ):#line:44
        raise Exception ("Tried to change the value of a constant")#line:45
class MasterQuoteDAPI :#line:48
    _api :SolAPI =None #line:49
    _client :SolClient =None #line:50
    _client_RevAnn :SolClient =None #line:51
    _Username :str #line:52
    _Password :str #line:53
    _IsSIM :bool #line:54
    def __init__ (O00O000O0OO0OOOO0 ,OOOO0OO0O00OO0O0O :MarketDataMart ,O0000O0OOO00O0000 :str ,loglv =logging .INFO ,conlv =logging .INFO ):#line:56
        O00O000O0OO0OOOO0 ._api =SolAPI (OOOO0OO0O00OO0O0O ,O0000O0OOO00O0000 ,False ,loglv ,conlv )#line:57
    def Set_OnLogEvent (O0OOOO0O0O00OOOOO ,O0OO0O00000O0OOO0 :callable ):#line:59
        O0OOOO0O0O00OOOOO ._api .Set_OnLogEvent (O0OO0O00000O0OOO0 )#line:60
    def Set_OnInterruptEvent (O0000O00OO0O00OO0 ,O0OOOO00OO00O0O0O :callable ):#line:62
        O0000O00OO0O00OO0 ._api .Set_OnInterruptEvent (O0OOOO00OO00O0O0O )#line:63
    def __OOOOOOO0O0OO0OO00 (OO0OO00OO0OOO0O00 ,OO0O0O0OO00OOO0OO :'InboundMessage'):#line:65
        if OO0O0O0OO00OOO0OO .get_payload_as_bytes ()==None :#line:66
            OO0OO00OO0OOO0O00 ._api ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QuoteHandler.OnMessage Exception Null Data, topic:{OO0O0O0OO00OOO0OO.get_destination_name()}")#line:67
            O0000OO00O00O0OOO =SystemEvent (RCode .FAIL ,f"QuoteHandler.OnMessage Exception: Null Data, topic:{OO0O0O0OO00OOO0OO.get_destination_name()}")#line:68
            OO0OO00OO0OOO0O00 .Fire_OnSystemEvent_DAPI (O0000OO00O00O0OOO )#line:69
            return #line:70
        OOO000OO0O0OO0OO0 :str =OO0O0O0OO00OOO0OO .get_payload_as_bytes ().decode ('utf-8')#line:72
        OO0OO00OO000O000O :str =OO0O0O0OO00OOO0OO .get_destination_name ()#line:73
        O00OO00000O0OOO00 =re .match (r"^DAPI/Quote/TWS/(S|W|Idx|Z|\*)/(TSE|OTC|\*)/(.+)/TX/[A-Z0-9]+$",OO0OO00OO000O000O )#line:74
        O00O0000OO0O0OOOO =re .match (r"^DAPI/Quote/TWF/(FUT|OPT|\*)/(.+)/TX/[A-Z0-9]+$",OO0OO00OO000O000O )#line:75
        O0OOOO0OOO00OOOOO =re .match (r"^DAPI/Quote/TWS/(S|W|Idx|Z|\*)/(TSE|OTC|\*)/(.+)/BAS/[A-Z0-9]+$",OO0OO00OO000O000O )#line:76
        O0OOOO00OOOO0O00O =re .match (r"^DAPI/Quote/TWF/(FUT|OPT|\*)/(.+)/BAS/[A-Z0-9]+$",OO0OO00OO000O000O )#line:77
        O00OOOO00000O0O0O =re .match (r"DAPI/Quote/TWS/ANN",OO0OO00OO000O000O )#line:78
        O00OO00O0O00OOOOO =re .match (r"DAPI/Quote/TWF/ANN",OO0OO00OO000O000O )#line:79
        if O0OOOO0OOO00OOOOO :#line:81
            OOOO0OOO0OOO00O0O :TStkQtBase =TStkQtBase ()#line:82
            OOOO0OOO0OOO00O0O .Handle_BAS (OOO000OO0O0OO0OO0 )#line:83
            OOO00000O0000OO00 :TStkQuoteData =TStkQuoteData (TStkProdKind .pkNone ,OOOO0OOO0OOO00O0O .StkNo ,False )#line:84
            OOO00000O0000OO00 .HL =TStkQtHL ()#line:85
            OOO00000O0000OO00 .BAS =OOOO0OOO0OOO00O0O #line:86
            O0OOO0OOOOO0OOO0O :ProductBasic_Stk =ProductBasic_Stk (OOO00000O0000OO00 )#line:87
            OO0OO00OO0OOO0O00 .Fire_OnUpdateBasic_DAPI (O0OOO0OOOOO0OOO0O )#line:88
        elif O0OOOO00OOOO0O00O :#line:89
            O00000000O0OOOO0O :TFutQtBase =TFutQtBase ()#line:90
            O00000000O0OOOO0O .Handle_BAS (OOO000OO0O0OO0OO0 )#line:91
            OOO00000O0000OO00 :TFutQuoteData =TFutQuoteData (TFutProdKind .pkNone ,O00000000O0OOOO0O .OrdProdID ,False )#line:92
            OOO00000O0000OO00 .HL =TFutQtHL ()#line:93
            OOO00000O0000OO00 .BAS =O00000000O0OOOO0O #line:94
            O0OOO0OOOOO0OOO0O :ProductBasic_Fut =ProductBasic_Fut (OOO00000O0000OO00 )#line:96
            OO0OO00OO0OOO0O00 .Fire_OnUpdateBasic_DAPI (O0OOO0OOOOO0OOO0O )#line:98
        elif O00OO00000O0OOO00 :#line:99
            O00OOOOO0O0O0O0O0 :TStkQtTX =TStkQtTX (False )#line:100
            O00OOOOO0O0O0O0O0 .Handle_TX (OOO000OO0O0OO0OO0 )#line:101
            OO000O0O0O000O00O :ProductTick_Stk =ProductTick_Stk (None )#line:102
            OO000O0O0O000O00O .Upt_TX (O00OOOOO0O0O0O0O0 )#line:103
            OO000O0O0O000O00O .Symbol =O00OOOOO0O0O0O0O0 .fTX [0 ]#line:104
            OO0OO00OO0OOO0O00 .Fire_OnMatch_DAPI (OO000O0O0O000O00O )#line:106
        elif O00O0000OO0O0OOOO :#line:107
            O00OO0O0OO000O0O0 :TFutQtTX =TFutQtTX (False )#line:108
            O00OO0O0OO000O0O0 .Handle_TX (OOO000OO0O0OO0OO0 )#line:109
            OO000O0O0O000O00O :ProductTick_Fut =ProductTick_Fut (None )#line:110
            OO000O0O0O000O00O .Upt_TX (O00OO0O0OO000O0O0 )#line:111
            OO0OO00OO0OOO0O00 .Fire_OnMatch_DAPI (OO000O0O0O000O00O )#line:113
        elif O00OOOO00000O0O0O or O00OO00O0O00OOOOO :#line:114
            OO0OO00OO0OOO0O00 .Fire_OnAnnouncementEvent_DAPI (OOO000OO0O0OO0OO0 )#line:115
    def DoQuoteConn (OO0OO00O0OO0O0000 ,OOO0O000O00O00OOO :str ):#line:120
        ""#line:121
        O000OOOOO0O00O0OO =OO0OO00O0OO0O0000 .Connect (OOO0O000O00O00OOO )#line:123
        return O000OOOOO0O00O0OO #line:124
    def DisConnect (OO00OOOOOO000OO0O )->RCode :#line:130
        OO00OOOOOO000OO0O ._client .DisConnect ()#line:131
        OO00OOOOOO000OO0O .__O0O0OO00OOOOOO0O0 ._run =False #line:132
        OO00OOOOOO000OO0O ._client_RevAnn .DisConnect ()#line:133
        OO00OOOOOO000OO0O .__OO00O0OO000OOOOO0 ._run =False #line:134
        return OO00OOOOOO000OO0O ._api .DisConnect ()#line:136
    def Login (OO0OO0O00OOOO000O ,OOO0OO0O00O00OO0O :str ,OO000O0O0OO0OOOOO :str ,OO000000OO0O0O000 :str ,aIsSIM :bool =False )->RCode :#line:141
        ""#line:142
        OO0OO0O00OOOO000O ._Username =OOO0OO0O00O00OO0O #line:143
        OO0OO0O00OOOO000O ._Password =OO0OO0O00OOOO000O .MD5Pwd (OO000O0O0OO0OOOOO )#line:144
        OO0OO0O00OOOO000O ._IsSIM =aIsSIM #line:145
        OO000O000OO0000OO :RCode =RCode .FAIL #line:147
        try :#line:149
            O00O0OOO0O0OOOO00 :str =os .path .join (pathlib .Path (OO0OO0O00OOOO000O ._api ._pypath ).parent .absolute (),'Configs')#line:151
            O0000000O000OOO0O :str =os .path .join (O00O0OOO0O0OOOO00 ,"SYS_SOLACE.ini")#line:152
            OO00OO00OOOO0O0OO :IniFile =IniFile (O0000000O000OOO0O )#line:153
            OOO0000O0OO0OOO00 :str =OO00OO00OOOO0O0OO .GetString ("Solace","Host","")#line:155
            O000O0OO0OOO00OO0 :str =OO00OO00OOOO0O0OO .GetString ("Solace","Vpn","")#line:156
            O0OO00O0000000OO0 :str =OO00OO00OOOO0O0OO .GetString ("Solace","Username","")#line:157
            OOOO0OO00O0O00O0O :str =OO00OO00OOOO0O0OO .GetString ("Solace","Password","")#line:158
            OO0OO0O00OOOO000O ._api ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"API Login: Host={OOO0000O0OO0OOO00},Vpn={O000O0OO0OOO00OO0},_Username={OOO0OO0O00O00OO0O},Password={OO000O0O0OO0OOOOO}")#line:160
            if OO0OO0O00OOOO000O ._client ==None :#line:163
                OO0OO0O00OOOO000O ._client =SolClient (OOO0000O0OO0OOO00 ,O000O0OO0OOO00OO0 ,O0OO00O0000000OO0 ,OOOO0OO00O0O00O0O ,OO0OO0O00OOOO000O ._api ._log )#line:164
                OO0OO0O00OOOO000O ._client_RevAnn =SolClient (OOO0000O0OO0OOO00 ,O000O0OO0OOO00OO0 ,"Recover_ANN",OOOO0OO00O0O00O0O ,OO0OO0O00OOOO000O ._api ._log )#line:165
            OO0OO0O00OOOO000O ._api ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"Start Auth: solace host={OOO0000O0OO0OOO00}")#line:167
            if hasattr (OO0OO0O00OOOO000O ,'_MasterQuoteDAPI__fWorkThr_HandleQuote'):#line:168
                OO0OO0O00OOOO000O .__O0O0OO00OOOOOO0O0 ._run =True #line:169
            else :#line:170
                OO0OO0O00OOOO000O .__O0O0OO00OOOOOO0O0 =TSolMsgThrdClass_DAPI ("Trd_HandleQuote_DAPI",OO0OO0O00OOOO000O ._api ._log ,OO0OO0O00OOOO000O .__OOOOOOO0O0OO0OO00 )#line:171
            if hasattr (OO0OO0O00OOOO000O ,'_MasterQuoteDAPI__fWorkThr_HandleQuote_RevAnn'):#line:173
                OO0OO0O00OOOO000O .__OO00O0OO000OOOOO0 ._run =True #line:174
            else :#line:175
                OO0OO0O00OOOO000O .__OO00O0OO000OOOOO0 =TSolMsgThrdClass_DAPI ("Trd_HandleQuote_DAPI_RevAnn",OO0OO0O00OOOO000O ._api ._log ,OO0OO0O00OOOO000O .__OOOOOOO0O0OO0OO00 )#line:176
            if OO0OO0O00OOOO000O ._client ._is_connected ==False :#line:178
                OO000O000OO0000OO =OO0OO0O00OOOO000O ._client .createConnection (OO0OO0O00OOOO000O .__O0O0OO00OOOOOO0O0 )#line:179
                if OO000O000OO0000OO !=RCode .OK :#line:180
                    OO0OO0O00OOOO000O ._api ._log .Add (arg1 =SolLogType .Info ,arg2 =f"Create Auth Connection Fail: rc={OO000O000OO0000OO}")#line:181
                    OO000O000OO0000OO =RCode .FAIL #line:182
                    OO0OO0O00OOOO000O .Fire_OnLoginResultEvent_DAPI (False ,"[Login]驗證主機(Sol)連線失敗!")#line:183
                    return OO000O000OO0000OO #line:184
                else :#line:185
                    OO0OO0O00OOOO000O .SubSysAnnouncement ()#line:187
            OO00000O000OO0O0O =OO0OO0O00OOOO000O .DoQuoteConn (OO000000OO0O0O000 )#line:189
            return OO00000O000OO0O0O #line:190
        except Exception as O0OO00O0OOO000OOO :#line:191
            OO0OO0O00OOOO000O .Fire_OnLoginResultEvent_DAPI (False ,f"[Login]Failed: error={O0OO00O0OOO000OOO}")#line:192
            return RCode .FAIL #line:193
    def MD5Pwd (O00O0OO0OO00OOOO0 ,O0OOO00000O00000O ):#line:195
        try :#line:196
            OOOO0O0O00OO00OOO =hashlib .md5 (O0OOO00000O00000O .encode ()).hexdigest ()#line:197
            return OOOO0O0O00OO00OOO #line:198
        except Exception as O0OO00O00OOOOOOO0 :#line:199
            O00O0OO0OO00OOOO0 .Fire_OnLoginResultEvent_DAPI (False ,f"[Login]MD5Pwd Failed: error={O0OO00O00OOOOOOO0}")#line:200
        return ""#line:201
    def Auth_TWSE (O0O0O00OO0O0OOO00 ,O0O00O000OOOOO0OO :UserLoginReply )->RCode :#line:203
        ""#line:204
        O0OO00O00O00OO000 :RCode =RCode .FAIL #line:205
        O0OO00O00O00OO000 =O0O0O00OO0O0OOO00 ._client .AddSubscriptionXUid (Constants .CheckTopicBAS_TWSE ,O0O00O000OOOOO0OO .uid ,False )#line:206
        if O0OO00O00O00OO000 ==RCode .OK :#line:207
            O0OO00O00O00OO000 =O0O0O00OO0O0OOO00 ._client .AddSubscriptionXUid (Constants .CheckTopicTX_TWSE ,O0O00O000OOOOO0OO .uid ,False )#line:208
            if O0OO00O00O00OO000 ==RCode .OK :#line:209
                O0O000000O00O0OOO =SystemEvent (O0OO00O00O00OO000 ,"[Auth_TWSE] Sub Verified TWSE OK")#line:210
                O0O0O00OO0O0OOO00 .Fire_OnSystemEvent_DAPI (O0O000000O00O0OOO )#line:211
            else :#line:212
                O0OO00O00O00OO000 =RCode .SUBSCRIPTION_FAIL #line:213
                O0O000000O00O0OOO =SystemEvent (O0OO00O00O00OO000 ,"[Auth_TWSE] Sub Verified TWSE Subscription for Failed(TX)")#line:214
                O0O0O00OO0O0OOO00 .Fire_OnSystemEvent_DAPI (O0O000000O00O0OOO )#line:215
        else :#line:217
            O0OO00O00O00OO000 =RCode .SUBSCRIPTION_FAIL #line:218
            O0O000000O00O0OOO =SystemEvent (O0OO00O00O00OO000 ,"[Auth_TWSE] Sub Verified TWSE Subscription for Failed(BAS)")#line:219
            O0O0O00OO0O0OOO00 .Fire_OnSystemEvent_DAPI (O0O000000O00O0OOO )#line:220
        return O0OO00O00O00OO000 #line:222
    def Auth_TAIFEX (O00OOO0OO0OOO0O0O ,O0OOO0O0O0O0O0000 :UserLoginReply )->RCode :#line:226
        ""#line:227
        OOOO00000O0O000OO :RCode =RCode .FAIL #line:229
        OOOO00000O0O000OO =O00OOO0OO0OOO0O0O ._client .AddSubscriptionXUid (Constants .CheckTopicBAS_TAIFEX ,O0OOO0O0O0O0O0000 .uid ,False )#line:231
        if OOOO00000O0O000OO ==RCode .OK :#line:232
            OOOO00000O0O000OO =O00OOO0OO0OOO0O0O ._client .AddSubscriptionXUid (Constants .CheckTopicTX_TAIFEX ,O0OOO0O0O0O0O0000 .uid ,False )#line:233
            if OOOO00000O0O000OO ==RCode .OK :#line:234
                O0OO0O000O0OOOOO0 =SystemEvent (OOOO00000O0O000OO ,"[Auth_TAIFEX] Sub Verified TAIFEX OK")#line:235
                O00OOO0OO0OOO0O0O .Fire_OnSystemEvent_DAPI (O0OO0O000O0OOOOO0 )#line:236
            else :#line:237
                OOOO00000O0O000OO =RCode .SUBSCRIPTION_FAIL #line:238
                O0OO0O000O0OOOOO0 =SystemEvent (OOOO00000O0O000OO ,"[Auth_TAIFEX] Sub Verified TAIFEX Subscription for Failed(TX)")#line:239
                O00OOO0OO0OOO0O0O .Fire_OnSystemEvent_DAPI (O0OO0O000O0OOOOO0 )#line:240
        else :#line:241
            OOOO00000O0O000OO =RCode .SUBSCRIPTION_FAIL #line:242
            O0OO0O000O0OOOOO0 =SystemEvent (OOOO00000O0O000OO ,"[Auth_TAIFEX] Sub Verified TAIFEX Subscription for  Failed(BAS)")#line:243
            O00OOO0OO0OOO0O0O .Fire_OnSystemEvent_DAPI (O0OO0O000O0OOOOO0 )#line:244
            return OOOO00000O0O000OO #line:245
        return OOOO00000O0O000OO #line:246
    def Connect (OOO000OO00OO0OO00 ,OO0OO00O00OO0O0OO :str )->RCode :#line:250
        ""#line:251
        try :#line:252
            OOO00000OO0OOO0OO :RCode =RCode .OK #line:253
            OO0O0O000OOOO000O :UserLogin =UserLogin (OOO000OO00OO0OO00 ._Username ,OOO000OO00OO0OO00 ._Password ,"MQCS",RequestType .QuoteAPI .value ,OOO000OO00OO0OO00 .ExtractIp (),OOO000OO00OO0OO00 ._IsSIM )#line:256
            O0000O00O0OO0O0O0 :str =f'{{"uid":"{OO0O0O000OOOO000O.uid}", "pass":"{OO0O0O000OOOO000O.password}", "source":"{OO0O0O000OOOO000O.source}", "requestType":{OO0O0O000OOOO000O.requestType}, "ip":"{OO0O0O000OOOO000O.ip}" , "isSIM":{"true" if OO0O0O000OOOO000O.isSIM else "false"}}}'#line:260
            OOO000OO00OO0OO00 ._api ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"Start Auth: solace content={OO0O0O000OOOO000O}")#line:262
            OOOO0OOO0OO000OOO :str =OOO000OO00OO0OO00 ._client .SendRequestSync (Constants .AuthTopic ,O0000O00O0OO0O0O0 ,"utf-8")#line:265
            if OOOO0OOO0OO000OOO .isspace ()or OOOO0OOO0OO000OOO ==None or len (OOOO0OOO0OO000OOO )==0 :#line:267
                OOO00000OO0OOO0OO =RCode .FAIL #line:268
                OOO000OO00OO0OO00 .Fire_OnLoginResultEvent_DAPI (False ,"[登入回覆.失敗]error=No Response")#line:269
                OOO000OO00OO0OO00 ._api ._log .Add (arg1 =SolLogType .Info ,arg2 ="[Login]Failed: error=No Response")#line:270
                return OOO00000OO0OOO0OO #line:271
            OOO000OO00OO0OO00 ._api ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"End Auth: response={OOOO0OOO0OO000OOO}")#line:273
            O0O0O00O00000OOOO =json .loads (OOOO0OOO0OO000OOO )#line:277
            O0OOOOOOOOOO00OO0 =UserLoginReply ()#line:279
            if 'result'in OOOO0OOO0OO000OOO :#line:280
                O0OOOOOOOOOO00OO0 .result =O0O0O00O00000OOOO ['result']#line:281
            if 'uid'in OOOO0OOO0OO000OOO :#line:282
                O0OOOOOOOOOO00OO0 .uid =O0O0O00O00000OOOO ['uid']#line:283
            if 'accountStatus'in OOOO0OOO0OO000OOO :#line:284
                O0OOOOOOOOOO00OO0 .accountStatus =O0O0O00O00000OOOO ['accountStatus']#line:285
            if 'requestType'in OOOO0OOO0OO000OOO :#line:286
                O0OOOOOOOOOO00OO0 .requestType =O0O0O00O00000OOOO ['requestType']#line:287
            if 'typeName'in OOOO0OOO0OO000OOO :#line:288
                O0OOOOOOOOOO00OO0 .typeName =O0O0O00O00000OOOO ['typeName']#line:289
            if 'hostName'in OOOO0OOO0OO000OOO :#line:290
                O0OOOOOOOOOO00OO0 .hostName =O0O0O00O00000OOOO ['hostName']#line:291
            if 'vpnName'in OOOO0OOO0OO000OOO :#line:292
                O0OOOOOOOOOO00OO0 .vpnName =O0O0O00O00000OOOO ['vpnName']#line:293
            if 'userName'in OOOO0OOO0OO000OOO :#line:294
                O0OOOOOOOOOO00OO0 .userName =O0O0O00O00000OOOO ['userName']#line:295
            if 'password'in OOOO0OOO0OO000OOO :#line:296
                O0OOOOOOOOOO00OO0 .password =O0O0O00O00000OOOO ['password']#line:297
            if 'message'in OOOO0OOO0OO000OOO :#line:298
                O0OOOOOOOOOO00OO0 .message =O0O0O00O00000OOOO ['message']#line:299
            if 'announcement'in OOOO0OOO0OO000OOO :#line:300
                O0OOOOOOOOOO00OO0 .announcement =O0O0O00O00000OOOO ['announcement']#line:301
            if 'compressLevel'in OOOO0OOO0OO000OOO :#line:302
                O0OOOOOOOOOO00OO0 .compressLevel =O0O0O00O00000OOOO ['compressLevel']#line:303
            if 'twsPsaStatus'in OOOO0OOO0OO000OOO :#line:304
                O0OOOOOOOOOO00OO0 .twsPsaStatus =O0O0O00O00000OOOO ['twsPsaStatus']#line:305
            if 'twfPsaStatus'in OOOO0OOO0OO000OOO :#line:306
                O0OOOOOOOOOO00OO0 .twfPsaStatus =O0O0O00O00000OOOO ['twfPsaStatus']#line:307
            if not (O0OOOOOOOOOO00OO0 .announcement ==None or O0OOOOOOOOOO00OO0 .announcement .isspace ()or len (O0OOOOOOOOOO00OO0 .announcement )==0 ):#line:309
                OOO000OO00OO0OO00 .Fire_OnAnnouncementEvent_DAPI (O0OOOOOOOOOO00OO0 .announcement )#line:310
            OOO000OO00OO0OO00 ._api ._log .Add (arg1 =SolLogType .Info ,arg2 =f"UserLoginReply.Result: {O0OOOOOOOOOO00OO0.result}")#line:313
            if O0OOOOOOOOOO00OO0 .result ==True :#line:315
                if O0OOOOOOOOOO00OO0 .twsPsaStatus !=2 and O0OOOOOOOOOO00OO0 .twfPsaStatus !=2 :#line:317
                    OOO00000OO0OOO0OO =RCode .USER_NOT_VERIFIED #line:318
                    OOO000OO00OO0OO00 .Fire_OnLoginResultEvent_DAPI (False ,"證券,期貨 尚未驗證公告，請至元富官網進行「驗證公告」")#line:319
                    return OOO00000OO0OOO0OO #line:320
                elif OO0OO00O00OO0O0OO =="TWS"and O0OOOOOOOOOO00OO0 .twsPsaStatus !=2 :#line:321
                    OOO00000OO0OOO0OO =RCode .USER_NOT_VERIFIED #line:322
                    OOO000OO00OO0OO00 .Fire_OnLoginResultEvent_DAPI (False ,"證券尚未驗證公告，請至元富官網進行「驗證公告」")#line:323
                    return OOO00000OO0OOO0OO #line:324
                elif OO0OO00O00OO0O0OO =="TWF"and O0OOOOOOOOOO00OO0 .twfPsaStatus !=2 :#line:325
                    OOO00000OO0OOO0OO =RCode .USER_NOT_VERIFIED #line:326
                    OOO000OO00OO0OO00 .Fire_OnLoginResultEvent_DAPI (False ,"期貨尚未驗證公告，請至元富官網進行「驗證公告」")#line:327
                    return OOO00000OO0OOO0OO #line:328
                OOO000OO00OO0OO00 ._client_RevAnn .createConnection (OOO000OO00OO0OO00 .__OO00O0OO000OOOOO0 )#line:331
                OOO000OO00OO0OO00 ._client_RevAnn .request_cached_only ("dc01",Constants .Topic_TWSE_SYSANNOUNCEMENT ,60000 ,OOO000OO00OO0OO00 ._client_RevAnn .GetRequestID ())#line:332
                if O0OOOOOOOOOO00OO0 .accountStatus [0 ]==AccountStatus .NotApplied .value and O0OOOOOOOOOO00OO0 .accountStatus [1 ]==AccountStatus .NotApplied .value :#line:335
                    OOO00000OO0OOO0OO =RCode .USER_NOT_APPLIED #line:336
                    OOO000OO00OO0OO00 .Fire_OnVerifiedEvent_DAPI (TVerifyResult (False ,TMarketKind .ALL ,"尚未提出API申請，\n請至元富官網 https://tmlapi.masterlink.com.tw/web_api/service/home 提出申請"))#line:338
                    return OOO00000OO0OOO0OO #line:339
                else :#line:341
                    OOO0OO00OOO00O0OO :RCode =RCode .FAIL #line:344
                    OOOO00O0000000OO0 :RCode =RCode .FAIL #line:345
                    OOO0OO00OOO00O0OO =OOO000OO00OO0OO00 .Auth_TWSE (O0OOOOOOOOOO00OO0 )#line:347
                    OOOO00O0000000OO0 =OOO000OO00OO0OO00 .Auth_TAIFEX (O0OOOOOOOOOO00OO0 )#line:349
                    if O0OOOOOOOOOO00OO0 .accountStatus [0 ]==AccountStatus .NotVerified .value and O0OOOOOOOOOO00OO0 .accountStatus [1 ]==AccountStatus .NotVerified .value :#line:352
                        OOO00000OO0OOO0OO =RCode .USER_NOT_VERIFIED_TWSE_TAIFEX #line:354
                        OOO000OO00OO0OO00 .Fire_OnSystemEvent_DAPI (SystemEvent (OOO00000OO0OOO0OO ,"[驗證失敗]請至元富官網報價驗證頁面，按下[證券驗證]與[期貨驗證]按鈕進行驗證"))#line:355
                        OOO000OO00OO0OO00 .Fire_OnVerifiedEvent_DAPI (TVerifyResult (False ,TMarketKind .ALL ,"請至元富官網報價驗證頁面，\n按下[證券驗證]與[期貨驗證]按鈕進行驗證"))#line:356
                        return OOO00000OO0OOO0OO #line:357
                    else :#line:358
                        if O0OOOOOOOOOO00OO0 .accountStatus [0 ]==AccountStatus .Verified .value or O0OOOOOOOOOO00OO0 .accountStatus [1 ]==AccountStatus .Verified .value :#line:359
                            if OO0OO00O00OO0O0OO =="TWS"and O0OOOOOOOOOO00OO0 .accountStatus [0 ]==AccountStatus .NotVerified .value :#line:360
                                OOO000OO00OO0OO00 .Fire_OnVerifiedEvent_DAPI (TVerifyResult (False ,TMarketKind .STK ,"請至元富官網報價驗證頁面，按下[證券驗證]按鈕進行驗證"))#line:362
                                OOO00000OO0OOO0OO =RCode .USER_NOT_VERIFIED_TWSE #line:363
                                return OOO00000OO0OOO0OO #line:365
                            elif OO0OO00O00OO0O0OO =="TWF"and O0OOOOOOOOOO00OO0 .accountStatus [1 ]==AccountStatus .NotVerified .value :#line:366
                                OOO00000OO0OOO0OO =RCode .USER_NOT_VERIFIED_TAIFEX #line:368
                                OOO000OO00OO0OO00 .Fire_OnVerifiedEvent_DAPI (SystemEvent (False ,TMarketKind .FUT ,"請至元富官網報價驗證頁面，按下[期貨驗證]按鈕進行驗證"))#line:369
                                return OOO00000OO0OOO0OO #line:371
                    OOO000OO00OO0OO00 ._api ._log .Add (arg1 =SolLogType .Info ,arg2 =f"Quote Srv Connect rc={OOO00000OO0OOO0OO}, rc_TWSE={OOOO00O0000000OO0}, rc_TAIFEX={OOO0OO00OOO00O0OO}")#line:374
                    if O0OOOOOOOOOO00OO0 .accountStatus [0 ]==AccountStatus .Verified .value or O0OOOOOOOOOO00OO0 .accountStatus [1 ]==AccountStatus .Verified .value :#line:377
                        OOO000OO00OO0OO00 .Fire_OnSystemEvent_DAPI (SystemEvent (RCode .OK ,"準備行情連線..."))#line:378
                        OOO00000OO0OOO0OO =OOO000OO00OO0OO00 ._api .Connect (O0OOOOOOOOOO00OO0 .hostName ,O0OOOOOOOOOO00OO0 .vpnName ,O0OOOOOOOOOO00OO0 .userName ,O0OOOOOOOOOO00OO0 .password ,O0OOOOOOOOOO00OO0 .compressLevel )#line:380
                        if OOO00000OO0OOO0OO !=RCode .OK :#line:382
                            OOO000OO00OO0OO00 ._api ._log .Add (arg1 =SolLogType .Info ,arg2 =f"Quote Srv Connect Fail: rc={OOO00000OO0OOO0OO}")#line:383
                            return RCode .FAIL #line:384
                    else :#line:385
                        OOO000OO00OO0OO00 .Fire_OnSystemEvent_DAPI (SystemEvent (RCode .FAIL ,"行情尚未驗證成功, 無法執行情連線!"))#line:386
            else :#line:387
                OOO00000OO0OOO0OO =RCode .USER_VERIFICATION_FAIL #line:388
                OOO000OO00OO0OO00 .Fire_OnLoginResultEvent_DAPI (False ,f"[登入回覆.失敗]{O0OOOOOOOOOO00OO0.message}")#line:389
                OOO000OO00OO0OO00 ._api ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[Login]Failed: error={O0OOOOOOOOOO00OO0.message} rc={OOO00000OO0OOO0OO}")#line:390
                return OOO00000OO0OOO0OO #line:391
            return OOO00000OO0OOO0OO #line:392
        except Exception as OOO0O0O0000O0OO00 :#line:393
            OOO000OO00OO0OO00 .Fire_OnLoginResultEvent_DAPI (False ,f"[登入回覆.失敗]{OOO0O0O0000O0OO00}")#line:394
            OOO000OO00OO0OO00 ._api ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[Login Reply]Failed: error={OOO0O0O0000O0OO00}")#line:395
            return RCode .FAIL #line:396
    def Subscribe (OOO0000O00OO00O00 ,OOO0000OOO00OO00O :str ,O0OOO0000OO0000O0 :str )->RCode :#line:403
        ""#line:406
        return OOO0000O00OO00O00 ._api .Subscribe (OOO0000OOO00OO00O ,O0OOO0000OO0000O0 )#line:407
    def Unsubscribe (OO000O000O0O0O0OO ,O000OOOOO0O000O00 :str ,O000OOOOOOOOOO00O :str )->RCode :#line:408
        ""#line:411
        return OO000O000O0O0O0OO ._api .Unsubscribe (O000OOOOO0O000O00 ,O000OOOOOOOOOO00O )#line:412
    def OvsSubscribe (OO0O0O0OOO0OO0000 ,OOO0O0O0OO0O0O0O0 :str ):#line:414
        ""#line:416
        OO0O0O0OOO0OO0000 ._api .OvsSubscribe (OOO0O0O0OO0O0O0O0 )#line:417
    def OvsUnSubscribe (O0OO0OO0O0O000000 ,OOOOO0OOO0OOO0OOO :str ):#line:418
        ""#line:420
        O0OO0OO0O0O000000 ._api .OvsUnSubscribe (OOOOO0OOO0OOO0OOO )#line:421
    def QryProdID_NormalStock (OOOOOO0OOO0O0O000 )->RCode :#line:426
        ""#line:427
        OO0OO0OO00O0O0000 ,OOOO000O0O0OO0OO0 =OOOOOO0OOO0O0O000 ._api .QryProdID_NormalStock ()#line:428
        return OO0OO0OO00O0O0000 ,OOOO000O0O0OO0OO0 #line:429
    def QryProd_FutCom2 (O0OOOO0OOO0O00OOO )->RCode :#line:430
        ""#line:431
        OOOO000OO0000OOO0 ,O0O000OO000O00O00 =O0OOOO0OOO0O00OOO ._api .QryProd_FutCom2 ()#line:432
        return OOOO000OO0000OOO0 ,O0O000OO000O00O00 #line:433
    def QryProd_Fut (OOO0O0O00O0O0O000 ,O0OO000OO000OO000 :bool ,O0OO0OOOO0OOOOOO0 :bool ,OOOO0OOO00O00O000 :bool )->RCode :#line:435
        ""#line:436
        O00OOO0000000O0OO ,O0O0OOO0O0O0OOOOO =OOO0O0O00O0O0O000 ._api .QryProd_Fut (O0OO000OO000OO000 ,O0OO0OOOO0OOOOOO0 ,OOOO0OOO00O00O000 )#line:437
        return O00OOO0000000O0OO ,O0O0OOO0O0O0OOOOO #line:438
    def QryProd_Opt (O0O0O0O0O0OO000OO ,O0O0OO0OOO000OO0O :bool ,O00OOOOO0O000O0O0 :bool ,OO00O00O00O0O0O00 :bool )->RCode :#line:440
        ""#line:441
        OOOOOO0O00OOO0O00 ,O0000O0OOO0OO00OO =O0O0O0O0O0OO000OO ._api .QryProd_Opt (O0O0OO0OOO000OO0O ,O00OOOOO0O000O0O0 ,OO00O00O00O0O0O00 )#line:442
        return OOOOOO0O00OOO0O00 ,O0000O0OOO0OO00OO #line:443
    def QryProd_OvsFut (OOOOOO0O0OOO00O0O )->bool :#line:445
        ""#line:446
        OO0O00O0000OO00OO ,OO0OO000OOO0OO0O0 =OOOOOO0O0OOO00O0O ._api .QryProd_OvsFut ()#line:447
        return OO0O00O0000OO00OO ,OO0OO000OOO0OO0O0 #line:448
    def QryProd_OvsOpt (OOOOOOOO0O0O00O0O )->bool :#line:449
        ""#line:450
        O0O0OOOO00O000O00 ,O00OO00O00000OOOO =OOOOOOOO0O0O00O0O ._api .QryProd_OvsOpt ()#line:451
        return O0O0OOOO00O000O00 ,O00OO00O00000OOOO #line:452
    def SubSysAnnouncement (O0OO0O0O0OO00O0O0 ):#line:457
        ""#line:458
        try :#line:459
            OO0O0000OOO00O000 :RCode =RCode .FAIL #line:460
            OO0O0000OOO00O000 =O0OO0O0O0OO00O0O0 ._client .AddSubscription (Constants .Topic_TWSE_SYSANNOUNCEMENT )#line:461
            if OO0O0000OOO00O000 !=RCode .OK :#line:462
                O0OO0O0O0OO00O0O0 .Fire_OnSystemEvent_DAPI (SystemEvent (RCode .SUBSCRIPTION_FAIL ,f"[SubSysAnnouncement]Subscription for TWS_SysAnnouncement Failed, rc={OO0O0000OOO00O000}"))#line:463
        except Exception as O0OOOOO0O0O000OO0 :#line:464
            O0OO0O0O0OO00O0O0 ._api ._log .Add (arg1 =SolLogType .Error ,arg2 =f"SubSysMsg fail, error={O0OOOOO0O0O000OO0}")#line:465
            O0OO0O0O0OO00O0O0 .Fire_OnSystemEvent_DAPI (SystemEvent (RCode .FAIL ,f"[SubSysMsg]Failed: error={O0OOOOO0O0O000OO0}"))#line:466
    def ExtractIp (OOO000OO0OO0OOO00 )->str :#line:468
        ""#line:469
        OO0OO0O0O0OOOOO0O =""#line:470
        with socket .socket (socket .AF_INET ,socket .SOCK_DGRAM )as O0OOO0OOO00OO000O :#line:471
            O0OOO0OOO00OO000O .connect (('10.255.255.255',1 ))#line:472
            OO0OO0O0O0OOOOO0O =O0OOO0OOO00OO000O .getsockname ()[0 ]#line:473
        return OO0OO0O0O0OOOOO0O #line:474
    OnLoginResultEvent_DAPI :callable =None #line:478
    def Fire_OnLoginResultEvent_DAPI (O0000OO00O0OOO0OO ,O0OOO0OOOOO00OOOO :bool ,O0O00OO0OOOO0O00O :str ):#line:479
        if O0000OO00O0OOO0OO .OnLoginResultEvent_DAPI ==None :#line:480
            return #line:481
        if O0000OO00O0OOO0OO .OnLoginResultEvent_DAPI !=None :#line:482
            O0000OO00O0OOO0OO .OnLoginResultEvent_DAPI (O0OOO0OOOOO00OOOO ,O0O00OO0OOOO0O00O )#line:483
    OnSystemEvent_DAPI :callable =None #line:487
    def Fire_OnSystemEvent_DAPI (O000OO0OOOOO000OO ,O0OOOOOOO0OO000O0 :SystemEvent ):#line:488
        if O000OO0OOOOO000OO .OnSystemEvent_DAPI ==None :#line:489
            return #line:490
        if O000OO0OOOOO000OO .OnSystemEvent_DAPI !=None :#line:491
            O000OO0OOOOO000OO .OnSystemEvent_DAPI (O0OOOOOOO0OO000O0 )#line:492
    OnAnnouncementEvent_DAPI :callable =None #line:495
    def Fire_OnAnnouncementEvent_DAPI (OOO00O0O0OO00000O ,OO00O00O0000O00OO :str ):#line:496
        if OOO00O0O0OO00000O .OnAnnouncementEvent_DAPI ==None :#line:497
            return #line:498
        if OOO00O0O0OO00000O .OnAnnouncementEvent_DAPI !=None :#line:499
            OOO00O0O0OO00000O .OnAnnouncementEvent_DAPI (OO00O00O0000O00OO )#line:500
    OnVerifiedEvent_DAPI :callable =None #line:503
    def Fire_OnVerifiedEvent_DAPI (OO0OOOOO0OOO000OO ,OO00OOOO0OOO0O0O0 :TVerifyResult ):#line:504
        if OO0OOOOO0OOO000OO .OnVerifiedEvent_DAPI ==None :#line:505
            return #line:506
        if OO0OOOOO0OOO000OO .OnVerifiedEvent_DAPI !=None :#line:508
            OO0OOOOO0OOO000OO .OnVerifiedEvent_DAPI (OO00OOOO0OOO0O0O0 )#line:509
    OnMatch_DAPI :callable =None #line:512
    def Fire_OnMatch_DAPI (OO00000O000OO0OOO ,O0O0OO0OO000O0O00 :ProductTick ):#line:513
        if OO00000O000OO0OOO .OnMatch_DAPI ==None :#line:514
            return #line:515
        if OO00000O000OO0OOO .OnMatch_DAPI !=None :#line:516
            OO00000O000OO0OOO .OnMatch_DAPI (O0O0OO0OO000O0O00 )#line:517
    OnUpdateBasic_DAPI :callable =None #line:521
    def Fire_OnUpdateBasic_DAPI (O0OO00OOOOOO00OOO ,OO0O00000OO0OO0OO :ProductBasic ):#line:522
        if O0OO00OOOOOO00OOO .OnUpdateBasic_DAPI ==None :#line:523
            return #line:524
        if O0OO00OOOOOO00OOO .OnUpdateBasic_DAPI !=None :#line:525
            O0OO00OOOOOO00OOO .OnUpdateBasic_DAPI (OO0O00000OO0OO0OO )#line:526
        else :#line:527
            pass #line:528
class TSolMsgThrdClass_DAPI (MessageHandler ):#line:535
    ""#line:536
    def __init__ (O0OO000000OO00O0O ,OOO000OOOO0OO0O00 :str ,O00OOOOO000OO00O0 :logging .Logger ,O0O0000O000O0OO0O ):#line:539
        O0OO000000OO00O0O ._name =OOO000OOOO0OO0O00 #line:540
        O0OO000000OO00O0O ._msgHandler =O0O0000O000O0OO0O #line:541
        O0OO000000OO00O0O ._lock =Lock ()#line:542
        O0OO000000OO00O0O ._log =O00OOOOO000OO00O0 #line:543
        O0OO000000OO00O0O ._list =[]#line:544
        O0OO000000OO00O0O ._run =True #line:545
        O0OO000000OO00O0O .thrd =threading .Thread (target =O0OO000000OO00O0O .OnThread ,name =O0OO000000OO00O0O ._name )#line:546
        O0OO000000OO00O0O .thrd .start ()#line:547
    def OnThread (O0O0OO00OO0OOOOOO ):#line:549
        O00O0O0O00OO0O0O0 =[]#line:550
        OOO0O0O00O0OO000O ,OOOO0OO0O00OO00O0 ,O00O00O0O0000OOO0 =0 ,0 ,0 #line:551
        while O0O0OO00OO0OOOOOO ._run :#line:552
            try :#line:554
                with O0O0OO00OO0OOOOOO ._lock :#line:555
                    O00O0O0O00OO0O0O0 =O0O0OO00OO0OOOOOO ._list .copy ()#line:556
                    OOO0O0O00O0OO000O =len (O00O0O0O00OO0O0O0 )#line:557
                    if (len (O0O0OO00OO0OOOOOO ._list )>2000 )and OOO0O0O00O0OO000O ==OOOO0OO0O00OO00O0 :#line:558
                        O0O0OO00OO0OOOOOO ._list =[]#line:559
                for O00O00O0O0000OOO0 in range (OOOO0OO0O00OO00O0 ,OOO0O0O00O0OO000O ):#line:561
                    O0O0OO00OO0OOOOOO ._msgHandler (O00O0O0O00OO0O0O0 [O00O00O0O0000OOO0 ])#line:562
                OOOO0OO0O00OO00O0 =OOO0O0O00O0OO000O #line:564
            except Exception as OOO0OO0O0000O0O00 :#line:565
                O0O0OO00OO0OOOOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"TSolMsgThrdClass_DAPI send_request exception! exception={OOO0OO0O0000O0O00}")#line:567
            finally :#line:568
                sleep (0.001 )#line:569
    def Add (OO00O000000OO0OO0 ,O0000O000O00O00OO :'InboundMessage'):#line:571
        with OO00O000000OO0OO0 ._lock :#line:572
            OO00O000000OO0OO0 ._list .append (O0000O000O00O00OO )#line:573
    def on_message (OO0OOO00OOO0000O0 ,OO0OOO00O0O0OOOOO :'InboundMessage'):#line:575
        ""#line:576
        OO0OOO00OOO0000O0 .Add (OO0OOO00O0O0OOOOO )#line:577
