from collections import UserDict #line:3
import decimal #line:4
from enum import Enum #line:5
import math #line:6
from pydoc_data import topics #line:7
import queue #line:8
import threading #line:9
from threading import Lock #line:10
import time #line:11
from typing import Union #line:12
from solace .messaging .messaging_service import MessagingService ,ReconnectionListener ,ReconnectionAttemptListener ,ServiceInterruptionListener ,ServiceEvent #line:14
from solace .messaging .receiver .message_receiver import MessageHandler ,InboundMessage #line:15
from solace .messaging .publisher .outbound_message import OutboundMessage #line:16
from solace .messaging .resources .topic import Topic #line:17
from solace .messaging .resources .topic_subscription import TopicSubscription #line:18
from solace .messaging .utils .cache_request_outcome import CacheRequestOutcome #line:19
from solace .messaging .resources .cached_message_subscription_request import CachedMessageSubscriptionRequest #line:20
from solace .messaging .receiver .receiver_cache_requests import ReceiverCacheRequests #line:21
from solace .messaging .receiver .inbound_message import *#line:22
from solace .messaging .utils .life_cycle_control import TerminationNotificationListener #line:23
from solace .messaging .utils .cache_request_outcome_listener import CacheRequestOutcomeListener #line:24
from solace .messaging .utils ._termination_notification_util import TerminationNotificationEvent #line:25
from solace .messaging .receiver .direct_message_receiver import DirectMessageReceiver #line:26
from solace .messaging .publisher .request_reply_message_publisher import RequestReplyMessagePublisher #line:27
from solace .messaging .publisher .publisher_health_check import PublisherReadinessListener #line:28
from datetime import datetime #line:29
import json #line:31
import os #line:32
from os .path import dirname #line:33
from decimal import Decimal #line:34
from PY_Trade_package .MarketDataMart import MarketDataMart ,SystemEvent #line:35
from PY_Trade_package .Product import ProductSnapshot ,ProductTick_Fut ,ProductTick_Stk ,TMapPrdOvs ,TMapPrdSnapshot #line:36
from PY_Trade_package .SolPYAPI_Model import *#line:38
from PY_Trade_package .SolLog import *#line:40
import logging #line:41
from time import sleep #line:42
class TStkQuoteConnStu (Enum ):#line:45
    stuUnConn =0 #line:46
    """未連線"""#line:47
    stuConnIng =10 #line:48
    """連線中"""#line:49
    stuConnected =20 #line:50
    """初次連線成功"""#line:51
    stuReConnected =21 #line:52
    """再次連線成功"""#line:53
    stuDisConnIng =30 #line:54
    """準備斷線"""#line:55
class TStkProdKind (Enum ):#line:58
    pkNone =0 #line:59
    pkNormal =10 #line:60
    """一般證券"""#line:61
    pkIndex =20 #line:62
    """指數商品(EX:加權指數)"""#line:63
class STKxFUT (Enum ):#line:66
    STK =0 #line:67
    FUT =1 #line:68
    OPT =2 #line:69
    OVSFUT =3 #line:70
class TStkQtBase ():#line:74
    fHasBAS =False #line:75
    TopicTX :str =""#line:77
    Topic5Q :str =""#line:78
    TopicHL :str =""#line:79
    fBAS =[]#line:81
    StkNo :str #line:82
    """證券代碼"""#line:83
    StkName :str #line:84
    """證券中文"""#line:85
    RefPriceOrg :str #line:86
    """參考價"""#line:87
    LimitPrice_UpOrg :str #line:88
    """漲停價"""#line:89
    LimitPrice_DownOrg :str #line:90
    """跌停價"""#line:91
    IndustryCategory :str #line:92
    "產業別"#line:93
    StockCategory :str #line:94
    "證券別"#line:95
    StockAnomalyCode :str #line:96
    "股票異常代碼"#line:97
    BoardRemark :str #line:98
    "板別註記"#line:99
    ClassRemark :str #line:100
    "類股註記"#line:101
    NonTenFaceValueIndicator :str #line:102
    "非10元面額註記"#line:103
    AbnormalRecommendationIndicator :str #line:104
    "異常推介個股註記"#line:105
    AbnormalSecuritiesIndicator :str #line:106
    "特殊異常證券註記"#line:107
    DayTradingIndicator :str #line:108
    "可現股當沖註記"#line:109
    TradingUnit :str #line:110
    "交易單位"#line:111
    def Get_TradingUnit (OO0O00O00O0000000 ):#line:112
        return OO0O00O00O0000000 .TransToInt (OO0O00O00O0000000 .fBAS [30 ])#line:113
    TickSizeInfo :str #line:114
    """跳動點資訊"""#line:115
    TotQtyPre :str #line:116
    """(前交易日)成交總量"""#line:117
    TotAmtPre :str #line:118
    """(前交易日)成交總額"""#line:119
    RefPPre :str #line:121
    "上一交易日參考價"#line:122
    CPPre :str #line:123
    "上一交易日收盤價"#line:124
    def __init__ (OO0OOO00OOO000O00 ,topic :str =""):#line:126
        if topic !="":#line:127
            O0OOO000OO0OO0000 =topic .split ("/")#line:128
            O0OOO000OO0OO0000 [len (O0OOO000OO0OO0000 )-1 ]="HL"#line:129
            OO0OOO00OOO000O00 .TopicHL ="/".join (O0OOO000OO0OO0000 )#line:130
            O0OOO000OO0OO0000 [len (O0OOO000OO0OO0000 )-1 ]="TX"#line:131
            OO0OOO00OOO000O00 .TopicTX ="/".join (O0OOO000OO0OO0000 )#line:132
            O0OOO000OO0OO0000 [len (O0OOO000OO0OO0000 )-1 ]="5Q"#line:133
            OO0OOO00OOO000O00 .Topic5Q ="/".join (O0OOO000OO0OO0000 )#line:134
    def Get_RefPrice (OO0O00OOOOO0O0OOO )->decimal :#line:137
        return OO0O00OOOOO0O0OOO .TransToDecimal (OO0O00OOOOO0O0OOO .fBAS [4 ])#line:138
    def Get_LimitPrice_Up (O0O0O0000000OOOO0 )->decimal :#line:140
        return O0O0O0000000OOOO0 .TransToDecimal (O0O0O0000000OOOO0 .fBAS [5 ])#line:141
    def Get_LimitPrice_Down (O0O00OOO000OOOOOO )->decimal :#line:143
        return O0O00OOO000OOOOOO .TransToDecimal (O0O00OOO000OOOOOO .fBAS [6 ])#line:144
    def Get_TotQtyPre (O000000O000000OOO )->decimal :#line:146
        return O000000O000000OOO .TransToDecimal (O000000O000000OOO .fBAS [34 ])#line:147
    def Get_TotAmtPre (O0OOO00OO0O0000O0 )->decimal :#line:149
        return O0OOO00OO0O0000O0 .TransToDecimal (O0OOO00OO0O0000O0 .fBAS [35 ])#line:150
    def Handle_BAS (OOO000OOO0000OO00 ,O0O0OOOO0OO0OOOO0 :str ):#line:152
        OOO000OOO0000OO00 .fBAS =O0O0OOOO0OO0OOOO0 .split ('|')#line:153
        OOO000OOO0000OO00 .fHasBAS =len (OOO000OOO0000OO00 .fBAS )>0 #line:154
        OOO000OOO0000OO00 .StkNo =OOO000OOO0000OO00 .fBAS [0 ]#line:155
        OOO000OOO0000OO00 .StkName =OOO000OOO0000OO00 .fBAS [1 ]#line:156
        OOO000OOO0000OO00 .RefPriceOrg =OOO000OOO0000OO00 .fBAS [4 ]#line:157
        OOO000OOO0000OO00 .LimitPrice_UpOrg =OOO000OOO0000OO00 .fBAS [5 ]#line:158
        OOO000OOO0000OO00 .LimitPrice_DownOrg =OOO000OOO0000OO00 .fBAS [6 ]#line:159
        OOO000OOO0000OO00 .IndustryCategory =OOO000OOO0000OO00 .fBAS [7 ]#line:160
        OOO000OOO0000OO00 .StockCategory =OOO000OOO0000OO00 .fBAS [8 ]#line:161
        OOO000OOO0000OO00 .StockAnomalyCode =OOO000OOO0000OO00 .fBAS [10 ]#line:162
        OOO000OOO0000OO00 .BoardRemark =OOO000OOO0000OO00 .fBAS [11 ]#line:163
        OOO000OOO0000OO00 .ClassRemark =OOO000OOO0000OO00 .fBAS [12 ]#line:164
        OOO000OOO0000OO00 .NonTenFaceValueIndicator =OOO000OOO0000OO00 .fBAS [13 ]#line:165
        OOO000OOO0000OO00 .AbnormalRecommendationIndicator =OOO000OOO0000OO00 .fBAS [14 ]#line:166
        OOO000OOO0000OO00 .AbnormalSecuritiesIndicator =OOO000OOO0000OO00 .fBAS [15 ]#line:167
        OOO000OOO0000OO00 .DayTradingIndicator =OOO000OOO0000OO00 .fBAS [16 ]#line:168
        OOO000OOO0000OO00 .TradingUnit =OOO000OOO0000OO00 .fBAS [30 ]#line:169
        OOO000OOO0000OO00 .TickSizeInfo =OOO000OOO0000OO00 .fBAS [33 ]#line:170
        OOO000OOO0000OO00 .TotQtyPre =OOO000OOO0000OO00 .fBAS [34 ]#line:171
        OOO000OOO0000OO00 .TotAmtPre =OOO000OOO0000OO00 .fBAS [35 ]#line:172
        OOO000OOO0000OO00 .RefPPre =OOO000OOO0000OO00 .fBAS [36 ]#line:173
        OOO000OOO0000OO00 .CPPre =OOO000OOO0000OO00 .fBAS [37 ]#line:174
        if OOO000OOO0000OO00 .TopicTX !="":#line:175
            O0OOO0OOO000OO000 =OOO000OOO0000OO00 .TopicHL .split ("/")#line:176
            O0OOO0OOO000OO000 [len (O0OOO0OOO000OO000 )-2 ]=OOO000OOO0000OO00 .StkNo #line:177
            OOO000OOO0000OO00 .TopicHL ="/".join (O0OOO0OOO000OO000 )#line:178
            O0OOO0OOO000OO000 =OOO000OOO0000OO00 .TopicTX .split ("/")#line:179
            O0OOO0OOO000OO000 [len (O0OOO0OOO000OO000 )-2 ]=OOO000OOO0000OO00 .StkNo #line:180
            OOO000OOO0000OO00 .TopicTX ="/".join (O0OOO0OOO000OO000 )#line:181
            O0OOO0OOO000OO000 =OOO000OOO0000OO00 .Topic5Q .split ("/")#line:182
            O0OOO0OOO000OO000 [len (O0OOO0OOO000OO000 )-2 ]=OOO000OOO0000OO00 .StkNo #line:183
            OOO000OOO0000OO00 .Topic5Q ="/".join (O0OOO0OOO000OO000 )#line:184
    def TransToInt (OOO0O000OOO000OO0 ,OOOO00OOO0OO0OOO0 :str )->int :#line:187
        try :#line:189
            return int (OOOO00OOO0OO0OOO0 )#line:190
        except Exception as OO0OOO00OO00000O0 :#line:191
            pass #line:192
        return 0 #line:194
    def TransToDecimal (OO00O00O0O0OOOO00 ,O0O0O0O0OO00000OO :str )->decimal :#line:196
        try :#line:197
            return Decimal (O0O0O0O0OO00000OO )#line:198
        except Exception as OO00O00O00000O0OO :#line:199
            print (f"Not a Decimal{OO00O00O00000O0OO}")#line:200
        return 0 #line:201
class TStkQtHL ():#line:202
    HasHL =False #line:203
    fHL =[]#line:204
    TopicTX :str =""#line:205
    Topic5Q :str =""#line:206
    Market :str =""#line:208
    """市場別(TSE/OTC)"""#line:209
    StkKind :str =""#line:210
    """"證券別(S/W/Idx)"""#line:211
    Symbol :str =""#line:212
    """委託商品代碼(2330)"""#line:213
    DealTime :str =""#line:214
    """撮合時間(成交)(EX:173547.32700)"""#line:215
    DealSn :str =""#line:216
    """成交序號"""#line:217
    def Get_DealSn (OO00O00OO0O00OO0O )->int :#line:219
        return OO00O00OO0O00OO0O .TransToInt (OO00O00OO0O00OO0O .fHL [4 ])#line:220
    Sn_5Q :str =""#line:221
    """五檔序號(指數類=空字串)"""#line:222
    def Get_Sn_5Q (O00000OO000O00OOO )->int :#line:224
        return O00000OO000O00OOO .TransToInt (O00000OO000O00OOO .fHL [5 ])#line:225
    DealPriceOrg :str =""#line:226
    """成交價"""#line:227
    def Get_DealPrice (OOO0O0O00O0O0O0OO )->decimal :#line:229
        return OOO0O0O00O0O0O0OO .TransToDecimal (OOO0O0O00O0O0O0OO .fHL [6 ])#line:230
    DealPrice :decimal #line:233
    """成交價"""#line:234
    DealQty :str =""#line:235
    """成交單量(指數類=0)"""#line:236
    def Get_DealQty2Dec (OOO0OO0O00OO00O00 )->decimal :#line:238
        return OOO0OO0O00OO00O00 .TransToDecimal (OOO0OO0O00OO00O00 .fHL [7 ])#line:239
    def Get_DealQty2Int (O00O0O0OO00000OOO )->int :#line:241
        return O00O0O0OO00000OOO .TransToInt (O00O0O0OO00000OOO .fHL [7 ])#line:242
    HighPriceOrg :str =""#line:244
    """當日最高價"""#line:245
    def Get_HighPrice (OO0OO00O0000OOO00 )->decimal :#line:247
        return OO0OO00O0000OOO00 .TransToDecimal (OO0OO00O0000OOO00 .fHL [8 ])#line:248
    LowPriceOrg :str =""#line:250
    """當日最低價"""#line:251
    def Get_LowPrice (OO0OOO0OOOOO00O0O )->decimal :#line:253
        return OO0OOO0OOOOO00O0O .TransToDecimal (OO0OOO0OOOOO00O0O .fHL [9 ])#line:254
    TotAmt :str =""#line:256
    """成交總額(指數類=0)"""#line:257
    def Get_TotAmt2Dec (OOO0000O00O00OOOO )->decimal :#line:259
        return OOO0000O00O00OOOO .TransToDecimal (OOO0000O00O00OOOO .fHL [10 ])#line:260
    def Get_TotAmt2Int (OOO0O0000000O0O00 )->int :#line:262
        return OOO0O0000000O0O00 .TransToInt (OOO0O0000000O0O00 .fHL [10 ])#line:263
    TotQty :str =""#line:265
    """成交總量(指數類=0)"""#line:266
    def Get_TotQty2Dec (O0O000OO00OOOOO0O )->decimal :#line:268
        return O0O000OO00OOOOO0O .TransToDecimal (O0O000OO00OOOOO0O .fHL [11 ])#line:269
    def Get_TotQty2Int (O0O0O0O0O00O0OOOO )->int :#line:271
        return O0O0O0O0O00O0OOOO .TransToInt (O0O0O0O0O00O0OOOO .fHL [11 ])#line:272
    FirstDerivedBuyPrice :str =""#line:275
    "衍生委託單第一檔買進價格"#line:276
    FirstDerivedBuyQty :str =""#line:277
    "衍生委託單第一檔買進價格數量"#line:278
    FirstDerivedSellPrice :str =""#line:279
    "衍生委託單第一檔賣出價格數量"#line:280
    FirstDerivedSellQty :str =""#line:281
    "衍生委託單第一檔賣出價格數量"#line:282
    OpenPriceOrg :str =""#line:284
    """開盤價"""#line:285
    def Get_OpenPrice (OOOOOO0OOO000OOOO )->decimal :#line:287
        return OOOOOO0OOO000OOOO .TransToDecimal (OOOOOO0OOO000OOOO .fHL [42 ])#line:288
    TryMark_Deal :str =""#line:290
    "成交試撮註記(試撮=1, 非試撮=0)"#line:291
    TryMark_5Q :str =""#line:292
    "五檔試撮註記(試撮=1, 非試撮=0)"#line:293
    fAryB5Q_P =[13 ,15 ,17 ,19 ,21 ]#line:296
    """買五檔價在字串中的位置"""#line:297
    fAryB5Q_Q =[14 ,16 ,18 ,20 ,22 ]#line:298
    """買五檔價在字串中的位置"""#line:299
    """買5檔的檔數"""#line:301
    B5QCountOrg :str =""#line:302
    """買5檔的檔數(指數類=0)"""#line:303
    B5QCount =0 #line:304
    """買5檔的檔數(指數類=0)"""#line:305
    def B5Q_POrg (O0OO00O00000OO00O ,OOOO00O00O0OO0OOO :int )->str :#line:307
        ""#line:308
        if OOOO00O00O0OO0OOO >O0OO00O00000OO00O .B5QCount :#line:309
            return ""#line:310
        else :#line:311
            return O0OO00O00000OO00O .fHL [O0OO00O00000OO00O .fAryB5Q_P [OOOO00O00O0OO0OOO -1 ]]#line:312
    def Get_B5Q_P (O00000O00O0O00O0O ,OO0O0O0O0OO000OOO :int )->decimal :#line:314
        ""#line:315
        if OO0O0O0O0OO000OOO >O00000O00O0O00O0O .B5QCount :#line:316
            return 0 #line:317
        else :#line:318
            return O00000O00O0O00O0O .TransToDecimal (O00000O00O0O00O0O .fHL [O00000O00O0O00O0O .fAryB5Q_P [OO0O0O0O0OO000OOO -1 ]])#line:319
    def B5Q_QOrg (O0000000OO00OOO00 ,O0O0OO000OO000O0O :int )->str :#line:321
        ""#line:322
        if (O0O0OO000OO000O0O >O0000000OO00OOO00 .B5QCount ):#line:323
            return ""#line:324
        else :#line:325
            return O0000000OO00OOO00 .fHL [O0000000OO00OOO00 .fAryB5Q_Q [O0O0OO000OO000O0O -1 ]]#line:326
    def Get_B5Q_Q (O0OO00000OOO00000 ,O0OOOO0O0OO0OO000 :int )->int :#line:328
        ""#line:329
        if (O0OOOO0O0OO0OO000 >O0OO00000OOO00000 .B5QCount ):#line:330
            return 0 #line:331
        else :#line:332
            return O0OO00000OOO00000 .TransToInt (O0OO00000OOO00000 .fHL [O0OO00000OOO00000 .fAryB5Q_Q [O0OOOO0O0OO0OO000 -1 ]])#line:333
    fAryS5Q_P =[24 ,26 ,28 ,30 ,32 ]#line:336
    """賣五檔價在字串中的位置"""#line:337
    fAryS5Q_Q =[25 ,27 ,29 ,31 ,33 ]#line:338
    """賣五檔價在字串中的位置"""#line:339
    S5QCountOrg :str =""#line:341
    """賣5檔的檔數(指數類=0)"""#line:342
    S5QCount :int #line:343
    def S5Q_POrg (O000OO00OOOO00000 ,O00OOOOO0OOO0000O :int )->str :#line:345
        ""#line:346
        if O00OOOOO0OOO0000O >O000OO00OOOO00000 .S5QCount :#line:347
            return ""#line:348
        else :#line:349
            return O000OO00OOOO00000 .fHL [O000OO00OOOO00000 .fAryS5Q_P [O00OOOOO0OOO0000O -1 ]]#line:350
    def Get_S5Q_P (OO0OOO0000O00O00O ,O0OO0O000O0O0O0O0 :int )->decimal :#line:352
        ""#line:353
        if O0OO0O000O0O0O0O0 >OO0OOO0000O00O00O .S5QCount :#line:354
            return 0 #line:355
        else :#line:356
            return OO0OOO0000O00O00O .TransToDecimal (OO0OOO0000O00O00O .fHL [OO0OOO0000O00O00O .fAryS5Q_P [O0OO0O000O0O0O0O0 -1 ]])#line:357
    def S5Q_QOrg (O00O00000OO00O0OO ,OOO00OOO0000O0O00 :int )->str :#line:359
        ""#line:360
        if OOO00OOO0000O0O00 >O00O00000OO00O0OO .S5QCount :#line:361
            return ""#line:362
        else :#line:363
            return O00O00000OO00O0OO .fHL [O00O00000OO00O0OO .fAryS5Q_Q [OOO00OOO0000O0O00 -1 ]]#line:364
    def Get_S5Q_Q (OOO000O000O00OOO0 ,OO0O0OOOOOO000O00 :int )->int :#line:366
        ""#line:367
        if OO0O0OOOOOO000O00 >OOO000O000O00OOO0 .fS5QCount :#line:368
            return 0 #line:369
        else :#line:370
            return OOO000O000O00OOO0 .TransToInt (OOO000O000O00OOO0 .fHL [OOO000O000O00OOO0 .fAryS5Q_Q [OO0O0OOOOOO000O00 -1 ]])#line:371
    WholeTotAmt :str #line:375
    """整體市場成交總額"""#line:376
    def Get_WholeTotAmt (O00OO000O0OO0OO0O )->int :#line:378
        return O00OO000O0OO0OO0O .TransToInt (O00OO000O0OO0OO0O .fHL [34 ])#line:379
    WholeTotQty :str #line:381
    """整體市場成交數量"""#line:382
    def Get_WholeTotQty (OO0OOO00OO0O00O00 )->int :#line:384
        return OO0OOO00OO0O00O00 .TransToInt (OO0OOO00OO0O00O00 .fHL [35 ])#line:385
    WholeDealCount :str #line:387
    """整體市場成交筆數"""#line:388
    def Get_WholeDealCount (O0000OOO0OO0O00OO )->int :#line:390
        return O0000OOO0OO0O00OO .TransToInt (O0000OOO0OO0O00OO .fHL [36 ])#line:391
    SumBuyOrderCount :str #line:393
    """整體市場委託買進筆數"""#line:394
    def Get_SumBuyOrderCount (OO0OO0000000OOOO0 )->int :#line:396
        return OO0OO0000000OOOO0 .TransToInt (OO0OO0000000OOOO0 .fHL [37 ])#line:397
    SumSellOrderCount :str #line:399
    """整體市場委託賣出筆數"""#line:400
    def Get_SumSellOrderCount (OO0O0000O0O0OO0OO )->int :#line:402
        return OO0O0000O0O0OO0OO .TransToInt (OO0O0000O0O0OO0OO .fHL [38 ])#line:403
    SumBuyOrderQty :str #line:405
    """整體市場委託買進數量"""#line:406
    def Get_SumBuyOrderQty (O00000O00O0OO00O0 )->int :#line:408
        return O00000O00O0OO00O0 .TransToInt (O00000O00O0OO00O0 .fHL [39 ])#line:409
    SumSellOrderQty :str #line:411
    """整體市場委託賣出數量"""#line:412
    def Get_SumSellOrderQty (O0O0OOO0O000O0O00 )->int :#line:414
        return O0O0OOO0O000O0O00 .TransToInt (O0O0OOO0O000O0O00 .fHL [40 ])#line:415
    def Handle_HL (O00OOOO000OO00000 ,OOO0O00OO00O0000O :str ):#line:418
        O00OOOO000OO00000 .fHL =OOO0O00OO00O0000O .split ('|')#line:419
        O00OOOO000OO00000 .HasHL =len (O00OOOO000OO00000 .fHL )>0 #line:420
        O00OOOO000OO00000 .Market =O00OOOO000OO00000 .fHL [0 ]#line:422
        O00OOOO000OO00000 .StkKind =O00OOOO000OO00000 .fHL [1 ]#line:423
        O00OOOO000OO00000 .Symbol =O00OOOO000OO00000 .fHL [2 ]#line:424
        O00OOOO000OO00000 .DealTime =O00OOOO000OO00000 .fHL [3 ]#line:425
        O00OOOO000OO00000 .DealSn =O00OOOO000OO00000 .fHL [4 ]#line:426
        O00OOOO000OO00000 .Sn_5Q =O00OOOO000OO00000 .fHL [5 ]#line:427
        O00OOOO000OO00000 .DealPriceOrg =O00OOOO000OO00000 .fHL [6 ]#line:428
        O00OOOO000OO00000 .DealPrice =O00OOOO000OO00000 .TransToDecimal (O00OOOO000OO00000 .DealPriceOrg )#line:429
        O00OOOO000OO00000 .DealQty =O00OOOO000OO00000 .fHL [7 ]#line:430
        O00OOOO000OO00000 .HighPriceOrg =O00OOOO000OO00000 .fHL [8 ]#line:431
        O00OOOO000OO00000 .LowPriceOrg =O00OOOO000OO00000 .fHL [9 ]#line:432
        O00OOOO000OO00000 .TotAmt =O00OOOO000OO00000 .fHL [10 ]#line:433
        O00OOOO000OO00000 .TotQty =O00OOOO000OO00000 .fHL [11 ]#line:434
        O00OOOO000OO00000 .FirstDerivedBuyPrice =O00OOOO000OO00000 .fHL [35 ]#line:435
        O00OOOO000OO00000 .FirstDerivedBuyQty =O00OOOO000OO00000 .fHL [36 ]#line:436
        O00OOOO000OO00000 .FirstDerivedSellPrice =O00OOOO000OO00000 .fHL [37 ]#line:437
        O00OOOO000OO00000 .FirstDerivedSellQty =O00OOOO000OO00000 .fHL [38 ]#line:438
        O00OOOO000OO00000 .B5QCountOrg =O00OOOO000OO00000 .fHL [12 ]#line:440
        O00OOOO000OO00000 .B5QCount =O00OOOO000OO00000 .TransToInt (O00OOOO000OO00000 .B5QCountOrg )#line:441
        O00OOOO000OO00000 .S5QCountOrg =O00OOOO000OO00000 .fHL [23 ]#line:442
        O00OOOO000OO00000 .S5QCount =O00OOOO000OO00000 .TransToInt (O00OOOO000OO00000 .S5QCountOrg )#line:443
        O00OOOO000OO00000 .WholeTotAmt =O00OOOO000OO00000 .fHL [34 ]#line:444
        O00OOOO000OO00000 .WholeTotQty =O00OOOO000OO00000 .fHL [35 ]#line:445
        O00OOOO000OO00000 .WholeDealCount =O00OOOO000OO00000 .fHL [36 ]#line:446
        O00OOOO000OO00000 .SumBuyOrderCount =O00OOOO000OO00000 .fHL [37 ]#line:447
        O00OOOO000OO00000 .SumSellOrderCount =O00OOOO000OO00000 .fHL [38 ]#line:448
        O00OOOO000OO00000 .SumBuyOrderQty =O00OOOO000OO00000 .fHL [39 ]#line:449
        O00OOOO000OO00000 .SumSellOrderQty =O00OOOO000OO00000 .fHL [40 ]#line:450
        O00OOOO000OO00000 .OpenPriceOrg =O00OOOO000OO00000 .fHL [42 ]#line:452
        O00OOOO000OO00000 .TryMark_Deal =O00OOOO000OO00000 .fHL [43 ]#line:453
        O00OOOO000OO00000 .TryMark_5Q =O00OOOO000OO00000 .fHL [44 ]#line:454
        if O00OOOO000OO00000 .HasHL :#line:455
            O00OOOO000OO00000 .TopicTX =f"Quote/TWS/{O00OOOO000OO00000.StkKind}/{O00OOOO000OO00000.Market}/{O00OOOO000OO00000.Symbol}/TX"#line:456
            O00OOOO000OO00000 .Topic5Q =f"Quote/TWS/{O00OOOO000OO00000.StkKind}/{O00OOOO000OO00000.Market}/{O00OOOO000OO00000.Symbol}/5Q"#line:457
    def TransToInt (OO0O00000OO0O0OOO ,O00O0OO00O000000O :str )->int :#line:461
        try :#line:462
            return int (O00O0OO00O000000O )#line:463
        except Exception as O00OOO00OOO000OO0 :#line:464
            return 0 #line:465
    def TransToDecimal (O00OOOO00OO0O0OO0 ,OOOOO00O0OOOOOO0O :str )->decimal :#line:467
        try :#line:468
            return Decimal (OOOOO00O0OOOOOO0O )#line:469
        except Exception as OO00OOOO00O000O0O :#line:470
            return 0 #line:471
    def __init__ (O0000O0O0OOOOOOOO )->None :#line:474
        pass #line:475
    def __str__ (OO0O0OOO0O0O0OOO0 )->str :#line:477
        return f"""Market:{OO0O0OOO0O0O0OOO0.Market} StkKind:{OO0O0OOO0O0O0OOO0.StkKind} Symbol:{OO0O0OOO0O0O0OOO0.Symbol} DealTime:{OO0O0OOO0O0O0OOO0.DealTime}"""+"""DealSn:{self.DealSn} Sn_5Q:{self.Sn_5Q} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty}"""+"""HighPriceOrg:{self.HighPriceOrg} LowPriceOrg:{self.LowPriceOrg} TotAmt:{self.TotAmt} TotQty:{self.TotQty}"""+"""B5QCountOrg:{self.B5QCountOrg} S5QCount:{self.S5QCount} WholeTotAmt:{self.WholeTotAmt} WholeTotQty:{self.WholeTotQty}"""+"""WholeDealCount:{self.WholeDealCount} SumBuyOrderCount:{self.SumBuyOrderCount} SumSellOrderCount:{self.SumSellOrderCount}"""+"""SumBuyOrderQty:{self.SumBuyOrderQty} SumSellOrderQty:{self.SumSellOrderQty} OpenPriceOrg:{self.OpenPriceOrg}"""#line:483
class TStkQtTX :#line:484
    fTX =[]#line:485
    HL_Sn_5Q =0 #line:486
    """來自HL回補的5檔序號(當收到即時成交行情時,若帶五檔行情,需判斷是否比HL紀錄的還大, 若比較小, 表示很久沒有成交行情, 但五檔一直在變動, 則不可使用成交行情裡的五檔資料)"""#line:487
    HL_TotAmt :decimal =0 #line:488
    """來自HL的成交總額，用於累加收到成交行情時的成交價*成交單量*交易單位"""#line:489
    BAS_TradingUnit =1 #line:490
    """來自BAS的交易單位用，用於累加收到成交行情時的成交價*成交單量*交易單位"""#line:491
    def Handle_TXRcv (O00000OOOO0000OO0 ,O0OOOOO0O0O00O0OO :str ):#line:493
        ""#line:494
        try :#line:495
            OOOO00OO00OO0O0OO :int =0 #line:496
            O00OO0OO00OOOO0O0 :int =0 #line:497
            O0O0O0O00000OOOO0 =O0OOOOO0O0O00O0OO .split ('|')#line:498
            if O0O0O0O00000OOOO0 [4 ]==TSolQuoteStkSet .TryMark_No :#line:500
                O00000OOOO0000OO0 .fPROC_HandleData =O00000OOOO0000OO0 .HandleData #line:501
                if O00000OOOO0000OO0 .fTX ==None :#line:503
                    O00000OOOO0000OO0 .fTX =O0O0O0O00000OOOO0 #line:504
                    O00000OOOO0000OO0 .SetData ()#line:505
                else :#line:506
                    O00OO0OO00OOOO0O0 =O00000OOOO0000OO0 .TransToInt (O0O0O0O00000OOOO0 [3 ])#line:507
                    OOOO00OO00OO0O0OO =O00000OOOO0000OO0 .Get_DealSn ()#line:508
                    if O00OO0OO00OOOO0O0 >OOOO00OO00OO0O0OO :#line:509
                        O00000OOOO0000OO0 .fTX =O0O0O0O00000OOOO0 #line:510
                        O00000OOOO0000OO0 .SetData ()#line:511
                O00000OOOO0000OO0 .fPROC_CalcHightLowPrice ()#line:513
                O00000OOOO0000OO0 .CalTotalTradingAmount ()#line:514
                OOOO00OO00OO0O0OO =O00000OOOO0000OO0 .Get_DealSn ()#line:517
                if OOOO00OO00OO0O0OO >=O00000OOOO0000OO0 .HL_Sn_5Q :#line:518
                    O00000OOOO0000OO0 .fB5QCount =O00000OOOO0000OO0 .TransToInt (O00000OOOO0000OO0 .B5QCountOrg )#line:520
                    O00000OOOO0000OO0 .fS5QCount =O00000OOOO0000OO0 .TransToInt (O00000OOOO0000OO0 .S5QCountOrg )#line:522
                else :#line:523
                    O00000OOOO0000OO0 .fB5QCount =0 #line:524
                    O00000OOOO0000OO0 .fS5QCount =0 #line:525
            else :#line:526
                O00000OOOO0000OO0 .fPROC_HandleData =O00000OOOO0000OO0 .HandleData_TryMarket #line:527
                O00000OOOO0000OO0 .fPROC_HandleData (O0OOOOO0O0O00O0OO )#line:528
        except Exception as O0OOO00OO0000O00O :#line:529
            pass #line:530
    def Handle_TX (O00OOOOOO0O000O0O ,O00O000OO0OO0OOOO :str ):#line:532
        ""#line:533
        O00OOOOOO0O000O0O .fPROC_HandleData (O00O000OO0OO0OOOO )#line:534
    def HandleData_TryMarket (OOOOOOOO00OO0O0OO ,OO00OOOOOO00000O0 :str ):#line:538
        ""#line:539
        if OO00OOOOOO00000O0 .split ('|')[4 ]==TSolQuoteStkSet .TryMark_No :#line:540
            OO000O00O0000O0OO =OOOOOOOO00OO0O0OO .HandleData #line:541
            OO000O00O0000O0OO (OO00OOOOOO00000O0 )#line:542
        else :#line:543
            OOOOOOOO00OO0O0OO .fTX =OO00OOOOOO00000O0 .split ('|')#line:544
            OOOOOOOO00OO0O0OO .SetData ()#line:545
            OOOOOOOO00OO0O0OO .B5QCount =OOOOOOOO00OO0O0OO .TransToInt (OOOOOOOO00OO0O0OO .B5QCountOrg )#line:546
            OOOOOOOO00OO0O0OO .S5QCount =OOOOOOOO00OO0O0OO .TransToInt (OOOOOOOO00OO0O0OO .S5QCountOrg )#line:547
    def HandleData (O00O0O0OO0OOOO0O0 ,OO0OO00O0O00O0O00 :str ):#line:549
        ""#line:550
        O00O0O0OO0OOOO0O0 .fTX =OO0OO00O0O00O0O00 .split ('|')#line:551
        O00O0O0OO0OOOO0O0 .SetData ()#line:552
        O00O0O0OO0OOOO0O0 .fPROC_CalcHightLowPrice ()#line:553
        O00O0O0OO0OOOO0O0 .CalTotalTradingAmount ()#line:554
        O00O0O0OO0OOOO0O0 .B5QCount =O00O0O0OO0OOOO0O0 .TransToInt (O00O0O0OO0OOOO0O0 .B5QCountOrg )#line:555
        O00O0O0OO0OOOO0O0 .S5QCount =O00O0O0OO0OOOO0O0 .TransToInt (O00O0O0OO0OOOO0O0 .S5QCountOrg )#line:556
    def SetData (OO00OO0000000OO00 ):#line:558
        OO00OO0000000OO00 .SysTime =OO00OO0000000OO00 .fTX [1 ]#line:559
        OO00OO0000000OO00 .DealTime =OO00OO0000000OO00 .fTX [2 ]#line:560
        OO00OO0000000OO00 .DealSn =OO00OO0000000OO00 .fTX [3 ]#line:561
        OO00OO0000000OO00 .TryMark =OO00OO0000000OO00 .fTX [4 ]#line:562
        OO00OO0000000OO00 .Has5Q =OO00OO0000000OO00 .fTX [5 ]#line:563
        if len (OO00OO0000000OO00 .fTX )>8 :#line:564
            OO00OO0000000OO00 .IsOpenRecord =OO00OO0000000OO00 .fTX [8 ][4 ]=='1'#line:565
        if len (OO00OO0000000OO00 .fTX )>8 :#line:566
            OO00OO0000000OO00 .IsCloseRecord =OO00OO0000000OO00 .fTX [8 ][5 ]=='1'#line:567
        OO00OO0000000OO00 .TotQty =OO00OO0000000OO00 .fTX [9 ]#line:568
        OO00OO0000000OO00 .DealPriceOrg =OO00OO0000000OO00 .fTX [10 ]#line:569
        OO00OO0000000OO00 .DealQty =OO00OO0000000OO00 .fTX [11 ]#line:570
        OO00OO0000000OO00 .B5QCountOrg =OO00OO0000000OO00 .fTX [12 ]#line:571
        OO00OO0000000OO00 .S5QCountOrg =OO00OO0000000OO00 .fTX [23 ]#line:572
        OO00OO0000000OO00 .WholeTotAmt =OO00OO0000000OO00 .fTX [34 ]#line:574
        OO00OO0000000OO00 .WholeTotQty =OO00OO0000000OO00 .fTX [35 ]#line:575
        OO00OO0000000OO00 .WholeDealCount =OO00OO0000000OO00 .fTX [36 ]#line:576
        OO00OO0000000OO00 .SumBuyOrderCount =OO00OO0000000OO00 .fTX [37 ]#line:577
        OO00OO0000000OO00 .SumSellOrderCount =OO00OO0000000OO00 .fTX [38 ]#line:578
        OO00OO0000000OO00 .SumBuyOrderQty =OO00OO0000000OO00 .fTX [39 ]#line:579
        OO00OO0000000OO00 .SumSellOrderQty =OO00OO0000000OO00 .fTX [40 ]#line:580
        OO00OO0000000OO00 .IsFixedPriceTransaction =OO00OO0000000OO00 .fTX [41 ]#line:581
    fPROC_HandleData :callable =None #line:584
    """PROC_HandleData"""#line:585
    SysTime :str #line:589
    """系統時間Unix Timestamp(us)(EX:1642553376085607)"""#line:590
    DealTime :str #line:591
    """撮合時間(成交)(EX:085229.843665)"""#line:592
    DealSn :str #line:593
    """序號(成交序號、5檔序號)"""#line:594
    def Get_DealSn (OOO0000OOOOO000O0 )->int :#line:596
        return OOO0000OOOOO000O0 .TransToInt (OOO0000OOOOO000O0 .fTX [3 ])#line:597
    TryMark ="1"#line:598
    """試撮註記(試撮=1, 非試撮=0)"""#line:599
    Has5Q :str #line:600
    """五檔揭示註記(揭示=1, 不揭示=0)"""#line:601
    IsOpenRecord :bool =False #line:603
    """此筆是否為開盤行情(False:僅代表此筆非開盤行情, 並不代表盤中或收盤狀態)"""#line:604
    IsCloseRecord :bool =False #line:605
    """此筆是否為收盤行情(False:僅代表此筆非收盤行情, 並不代表盤中或開盤狀態)"""#line:606
    TotQty :str #line:608
    """成交總量"""#line:609
    def Get_TotQty2Dec (O0O0O00OOO00O0O00 )->decimal :#line:611
        return O0O0O00OOO00O0O00 .TransToDecimal (O0O0O00OOO00O0O00 .fTX [9 ])#line:612
    def Get_TotQty2Int (OOO00000O00000O00 )->int :#line:614
        return OOO00000O00000O00 .TransToInt (OOO00000O00000O00 .fTX [9 ])#line:615
    DealPriceOrg :str #line:617
    """成交價"""#line:618
    def Get_DealPrice (OO00000OOOOO0OO00 )->decimal :#line:620
        return OO00000OOOOO0OO00 .TransToDecimal (OO00000OOOOO0OO00 .fTX [10 ])#line:621
    DealQty :str #line:623
    """成交單量"""#line:624
    def Get_DealQty2Dec (OO00O00O000OO0O00 )->decimal :#line:626
        return OO00O00O000OO0O00 .TransToDecimal (OO00O00O000OO0O00 .fTX [11 ])#line:627
    def Get_DealQty2Int (OOOOOO0O0OO00O0O0 )->int :#line:629
        return OOOOOO0O0OO00O0O0 .TransToInt (OOOOOO0O0OO00O0O0 .fTX [11 ])#line:630
    fAryB5Q_P =[13 ,15 ,17 ,19 ,21 ]#line:634
    """買五檔價在字串中的位置"""#line:635
    fAryB5Q_Q =[14 ,16 ,18 ,20 ,22 ]#line:636
    """買五檔價在字串中的位置"""#line:637
    B5QCountOrg :str #line:640
    """買5檔的檔數"""#line:641
    B5QCount :int #line:642
    """買5檔的檔數"""#line:643
    def B5Q_POrg (O00OO000OOO0O0O00 ,OOOOOO0O0O000OOO0 :int )->str :#line:645
        ""#line:646
        if (OOOOOO0O0O000OOO0 >O00OO000OOO0O0O00 .B5QCount ):#line:647
            return ""#line:648
        else :#line:649
            return O00OO000OOO0O0O00 .fTX [O00OO000OOO0O0O00 .fAryB5Q_P [OOOOOO0O0O000OOO0 -1 ]]#line:650
    def Get_B5Q_P (OO0O0O0OO000O0OO0 ,OO000000OOOOO0O00 :int )->decimal :#line:652
        ""#line:653
        if (OO000000OOOOO0O00 >OO0O0O0OO000O0OO0 .B5QCount ):#line:654
            return 0 #line:655
        else :#line:656
            return OO0O0O0OO000O0OO0 .TransToDecimal (OO0O0O0OO000O0OO0 .fTX [OO0O0O0OO000O0OO0 .fAryB5Q_P [OO000000OOOOO0O00 -1 ]])#line:657
    def B5Q_QOrg (OOO000OO0OOOOOO0O ,O0O00O00OO00O0O00 :int )->str :#line:659
        ""#line:660
        if (O0O00O00OO00O0O00 >OOO000OO0OOOOOO0O .B5QCount ):#line:661
            return ""#line:662
        else :#line:663
            return OOO000OO0OOOOOO0O .fTX [OOO000OO0OOOOOO0O .fAryB5Q_Q [O0O00O00OO00O0O00 -1 ]]#line:664
    def Get_B5Q_Q (O0O000O0OOO00000O ,OOO0000O0OO0O000O :int )->int :#line:666
        ""#line:667
        if (OOO0000O0OO0O000O >O0O000O0OOO00000O .B5QCount ):#line:668
            return 0 #line:669
        else :#line:670
            return O0O000O0OOO00000O .TransToInt (O0O000O0OOO00000O .fTX [O0O000O0OOO00000O .fAryB5Q_Q [OOO0000O0OO0O000O -1 ]])#line:671
    fAryS5Q_P =[24 ,26 ,28 ,30 ,32 ]#line:675
    """賣五檔價在字串中的位置"""#line:676
    fAryS5Q_Q =[25 ,27 ,29 ,31 ,33 ]#line:677
    """賣五檔價在字串中的位置"""#line:678
    S5QCountOrg :str #line:681
    """賣5檔的檔數"""#line:682
    S5QCount :int #line:683
    """賣5檔的檔數"""#line:684
    def S5Q_POrg (OO00O0OOOO000O00O ,O00OOOOO0000OOO0O :int )->str :#line:686
        ""#line:687
        if (O00OOOOO0000OOO0O >OO00O0OOOO000O00O .S5QCount ):#line:688
            return ""#line:689
        else :#line:690
            return OO00O0OOOO000O00O .fTX [OO00O0OOOO000O00O .fAryS5Q_P [O00OOOOO0000OOO0O -1 ]]#line:691
    def Get_S5Q_P (OOOOOOOOOO0000OOO ,OO0OOOO000000OO00 :int )->decimal :#line:693
        ""#line:694
        if (OO0OOOO000000OO00 >OOOOOOOOOO0000OOO .S5QCount ):#line:695
            return 0 #line:696
        else :#line:697
            return OOOOOOOOOO0000OOO .TransToDecimal (OOOOOOOOOO0000OOO .fTX [OOOOOOOOOO0000OOO .fAryS5Q_P [OO0OOOO000000OO00 -1 ]])#line:698
    def S5Q_QOrg (O000O0O0OO0OO0O0O ,O0O00OO0OOO0O00OO :int )->str :#line:700
        ""#line:701
        if (O0O00OO0OOO0O00OO >O000O0O0OO0OO0O0O .S5QCount ):#line:702
            return ""#line:703
        else :#line:704
            return O000O0O0OO0OO0O0O .fTX [O000O0O0OO0OO0O0O .fAryS5Q_Q [O0O00OO0OOO0O00OO -1 ]]#line:705
    def Get_S5Q_Q (O00OO00000OOOO0OO ,OO0OO00O0O0O0OO00 :int )->int :#line:707
        ""#line:708
        if (OO0OO00O0O0O0OO00 >O00OO00000OOOO0OO .S5QCount ):#line:709
            return 0 #line:710
        else :#line:711
            return O00OO00000OOOO0OO .TransToInt (O00OO00000OOOO0OO .fTX [O00OO00000OOOO0OO .fAryS5Q_Q [OO0OO00O0O0O0OO00 -1 ]])#line:712
    fDealPrice =0 #line:716
    """成交價"""#line:717
    HighPrice =0 #line:718
    """當日最高價"""#line:719
    LowPrice =0 #line:720
    """當日最低價"""#line:721
    def CalcHightLowPrice (OOO0OOO000O00000O ):#line:723
        ""#line:724
        try :#line:725
            O00OO00OO0OOO0OO0 =OOO0OOO000O00000O .Get_DealPrice ()#line:726
            OOO0OOO000O00000O .HighPrice =math .Max (O00OO00OO0OOO0OO0 ,OOO0OOO000O00000O .HighPrice )#line:727
            if OOO0OOO000O00000O .LowPrice ==0 :#line:728
                OOO0OOO000O00000O .LowPrice =O00OO00OO0OOO0OO0 #line:729
            else :#line:730
                OOO0OOO000O00000O .LowPrice =math .Min (O00OO00OO0OOO0OO0 ,OOO0OOO000O00000O .LowPrice )#line:731
        except :#line:733
            pass #line:734
    def CalcHightLowPrice_None (OO0O0000O0OOOOOOO ):#line:736
        pass #line:737
    fPROC_CalcHightLowPrice :callable =None #line:740
    """PROC_CalcHightLowPrice """#line:741
    fDealQty :int =0 #line:746
    def CalTotalTradingAmount (O00OO00000000000O ):#line:749
        ""#line:750
        try :#line:752
            O00OO00000000000O .fDealQty =O00OO00000000000O .Get_DealQty2Int ()#line:753
            O00OO00000000000O .HL_TotAmt +=O00OO00000000000O .fDealPrice *O00OO00000000000O .fDealQty *O00OO00000000000O .BAS_TradingUnit #line:756
        except Exception as O000O0O0000O000OO :#line:757
            pass #line:758
    WholeTotAmt :str #line:763
    "整體市場成交總額"#line:764
    def Get_WholeTotAmt (OO0O0OO0O0O000OO0 )->int :#line:765
        return OO0O0OO0O0O000OO0 .TransToInt (OO0O0OO0O0O000OO0 .fTX [34 ])#line:766
    WholeTotQty :str #line:767
    "整體市場成交數量"#line:768
    def Get_WholeTotQty (OO0OO00O0000O00O0 )->int :#line:769
        return OO0OO00O0000O00O0 .TransToInt (OO0OO00O0000O00O0 .fTX [35 ])#line:770
    WholeDealCount :str #line:771
    "整體市場成交筆數"#line:772
    def Get_WholeDealCount (OOOOOOOOOOOOO0OO0 )->int :#line:773
        return OOOOOOOOOOOOO0OO0 .TransToInt (OOOOOOOOOOOOO0OO0 .fTX [36 ])#line:774
    SumBuyOrderCount :str #line:775
    "整體市場委託買進筆數"#line:776
    def Get_SumBuyOrderCount (O0OOOOOOOO000OO0O )->int :#line:777
        return O0OOOOOOOO000OO0O .TransToInt (O0OOOOOOOO000OO0O .fTX [37 ])#line:778
    SumSellOrderCount :str #line:779
    "整體市場委託賣出筆數"#line:780
    def Get_SumSellOrderCount (O0O0OOOO0O0000O00 )->int :#line:781
        return O0O0OOOO0O0000O00 .TransToInt (O0O0OOOO0O0000O00 .fTX [38 ])#line:782
    SumBuyOrderQty :str #line:783
    "整體市場委託買進數量"#line:784
    def Get_SumBuyOrderQty (OO0O0000OO0OO000O ):#line:785
        return OO0O0000OO0OO000O .TransToInt (OO0O0000OO0OO000O .fTX [39 ])#line:786
    SumSellOrderQty :str #line:787
    "整體市場委託賣出數量"#line:788
    def Get_SumSellOrderQty (OOOO0OOO0O0O00000 ):#line:789
        return OOOO0OOO0O0O00000 .TransToInt (OOOO0OOO0O0O00000 .fTX [40 ])#line:790
    IsFixedPriceTransaction :str #line:791
    "是否為定盤交易"#line:792
    def TransToInt (O0OO000O0O00000O0 ,O0OO0O0O00000OO0O :str )->int :#line:797
        try :#line:798
            return int (O0OO0O0O00000OO0O )#line:799
        except Exception as O00000O0O0OOOO0O0 :#line:800
            return 0 #line:801
    def TransToDecimal (O0O0O000O00O00O00 ,OO00O0O0OO0OOOOOO :str )->decimal :#line:803
        try :#line:804
            return Decimal (OO00O0O0OO0OOOOOO )#line:805
        except Exception as OOO000OOO0OO0OOOO :#line:806
            return 0 #line:807
    def __init__ (OOOO0000OOO0O0O00 ,OO0O00OO0OOOOO0OO :bool )->None :#line:810
        OOOO0000OOO0O0O00 .fPROC_CalcHightLowPrice =OOOO0000OOO0O0O00 .CalcHightLowPrice_None #line:811
        if OO0O00OO0OOOOO0OO :#line:812
            OOOO0000OOO0O0O00 .fPROC_CalcHightLowPrice =OOOO0000OOO0O0O00 .CalcHightLowPrice #line:813
        OOOO0000OOO0O0O00 .fPROC_HandleData =OOOO0000OOO0O0O00 .HandleData_TryMarket #line:815
    def __str__ (O00O0O0OOO0OO0OO0 )->str :#line:817
        return f"""SysTime:{O00O0O0OOO0OO0OO0.SysTime} DealTime:{O00O0O0OOO0OO0OO0.DealTime} DealSn:{O00O0O0OOO0OO0OO0.DealSn} TryMark:{O00O0O0OOO0OO0OO0.TryMark}"""+"""Has5Q:{self.Has5Q} TotQty:{self.TotQty} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty}"""+"""B5QCountOrg:{self.B5QCountOrg} S5QCountOrg:{self.S5QCountOrg} fTX:{self.fTX}"""#line:820
class TStkQt5Q ():#line:821
    f5Q =[]#line:822
    def Handle_5Q (OOO00O0O0OO0O000O ,OO00O00OO0OOOOO0O :str ):#line:824
        OOO00O0O0OO0O000O .fPROC_HandleData (OO00O00OO0OOOOO0O )#line:825
    def HandleData_TryMarket (OOOOOO0OOO00O0OOO ,O0OOOO0O0OO0OO0OO :str ):#line:828
        ""#line:829
        if O0OOOO0O0OO0OO0OO .split ('|')[4 ]==TSolQuoteStkSet .TryMark_No :#line:830
            OOOOOO0OOO00O0OOO .fPROC_HandleData =OOOOOO0OOO00O0OOO .HandleData #line:831
            OOOOOO0OOO00O0OOO .fPROC_HandleData (O0OOOO0O0OO0OO0OO )#line:832
        else :#line:833
            OOOOOO0OOO00O0OOO .f5Q =O0OOOO0O0OO0OO0OO .split ('|')#line:834
            OOOOOO0OOO00O0OOO .SetData ()#line:835
            OOOOOO0OOO00O0OOO .B5QCount =OOOOOO0OOO00O0OOO .TransToInt (OOOOOO0OOO00O0OOO .B5QCountOrg )#line:836
            OOOOOO0OOO00O0OOO .S5QCount =OOOOOO0OOO00O0OOO .TransToInt (OOOOOO0OOO00O0OOO .S5QCountOrg )#line:837
    def HandleData (O00000O00OOO0O0O0 ,OO0000OOO0000O0O0 :str ):#line:839
        O00000O00OOO0O0O0 .f5Q =OO0000OOO0000O0O0 .split ('|')#line:840
        O00000O00OOO0O0O0 .SetData ()#line:841
        O00000O00OOO0O0O0 .B5QCount =O00000O00OOO0O0O0 .TransToInt (O00000O00OOO0O0O0 .B5QCountOrg )#line:842
        O00000O00OOO0O0O0 .S5QCount =O00000O00OOO0O0O0 .TransToInt (O00000O00OOO0O0O0 .S5QCountOrg )#line:843
    def SetData (O0OO0O0O0OO00OO00 ):#line:845
        O0OO0O0O0OO00OO00 .SysTime =O0OO0O0O0OO00OO00 .f5Q [1 ]#line:846
        O0OO0O0O0OO00OO00 .DataTime =O0OO0O0O0OO00OO00 .f5Q [2 ]#line:847
        O0OO0O0O0OO00OO00 .DealSn =O0OO0O0O0OO00OO00 .f5Q [3 ]#line:848
        if len (O0OO0O0O0OO00OO00 .f5Q )>4 :#line:849
            O0OO0O0O0OO00OO00 .TryMark =O0OO0O0O0OO00OO00 .f5Q [4 ]#line:850
        if len (O0OO0O0O0OO00OO00 .f5Q )>8 :#line:851
            O0OO0O0O0OO00OO00 .IsOpenRecord =O0OO0O0O0OO00OO00 .f5Q [8 ][4 ]=='1'#line:852
        if len (O0OO0O0O0OO00OO00 .f5Q )>8 :#line:853
            O0OO0O0O0OO00OO00 .IsCloseRecord =O0OO0O0O0OO00OO00 .f5Q [8 ][5 ]=='1'#line:854
        O0OO0O0O0OO00OO00 .TotQty =O0OO0O0O0OO00OO00 .f5Q [9 ]#line:856
        O0OO0O0O0OO00OO00 .B5QCountOrg =O0OO0O0O0OO00OO00 .f5Q [12 ]#line:857
        O0OO0O0O0OO00OO00 .S5QCountOrg =O0OO0O0O0OO00OO00 .f5Q [23 ]#line:858
    fPROC_HandleData =None #line:861
    """PROC_HandleData"""#line:862
    SysTime :str #line:865
    """系統時間Unix Timestamp(us)(EX:1642553376085607)"""#line:866
    DataTime :str #line:867
    """資料時間(交易所)(EX:173547.32700)"""#line:868
    DealSn :str #line:869
    """序號(5檔序號)"""#line:870
    def Get_DealSn (O0O0O00OO0OO0O0OO )->int :#line:872
        return O0O0O00OO0OO0O0OO .TransToInt (O0O0O00OO0OO0O0OO .f5Q [3 ])#line:873
    TryMark ="1"#line:874
    """試撮註記(試撮=1, 非試撮=0)"""#line:875
    IsOpenRecord :bool =False #line:877
    """此筆是否為開盤行情(False:僅代表此筆非開盤行情, 並不代表盤中或收盤狀態)"""#line:878
    IsCloseRecord :bool =False #line:879
    """此筆是否為收盤行情(False:僅代表此筆非收盤行情, 並不代表盤中或開盤狀態)"""#line:880
    TotQty :str #line:882
    """成交總量"""#line:883
    def Get_TotQty2Dec (O0OO00000OO0OOO00 )->decimal :#line:885
        return O0OO00000OO0OOO00 .TransToDecimal (O0OO00000OO0OOO00 .f5Q [9 ])#line:886
    def Get_TotQty2Int (O00000OOO00OO00O0 )->int :#line:888
        return O00000OOO00OO00O0 .TransToInt (O00000OOO00OO00O0 .f5Q [9 ])#line:889
    fAryB5Q_P =[13 ,15 ,17 ,19 ,21 ]#line:892
    """買五檔價在字串中的位置"""#line:893
    fAryB5Q_Q =[14 ,16 ,18 ,20 ,22 ]#line:894
    """買五檔價在字串中的位置"""#line:895
    B5QCountOrg :str #line:897
    """買5檔的檔數"""#line:898
    B5QCount :int #line:899
    """買5檔的檔數"""#line:900
    def B5Q_POrg (OOOOOO0OOOOOOO00O ,O0OO0OO0OOOOOOO00 :int )->str :#line:902
        ""#line:903
        if (O0OO0OO0OOOOOOO00 >OOOOOO0OOOOOOO00O .B5QCount ):#line:904
            return ""#line:905
        else :#line:906
            return OOOOOO0OOOOOOO00O .f5Q [OOOOOO0OOOOOOO00O .fAryB5Q_P [O0OO0OO0OOOOOOO00 -1 ]]#line:907
    def Get_B5Q_P (OO00O0OO00OO0O000 ,O0OOO0O0O00O000OO :int )->decimal :#line:909
        ""#line:910
        if (O0OOO0O0O00O000OO >OO00O0OO00OO0O000 .B5QCount ):#line:911
            return 0 #line:912
        else :#line:913
            return OO00O0OO00OO0O000 .TransToDecimal (OO00O0OO00OO0O000 .f5Q [OO00O0OO00OO0O000 .fAryB5Q_P [O0OOO0O0O00O000OO -1 ]])#line:914
    def B5Q_QOrg (OO00OO0O0OOO0OOO0 ,OOO00000O0O0O0OO0 :int )->str :#line:916
        ""#line:917
        if (OOO00000O0O0O0OO0 >OO00OO0O0OOO0OOO0 .B5QCount ):#line:918
            return ""#line:919
        else :#line:920
            return OO00OO0O0OOO0OOO0 .f5Q [OO00OO0O0OOO0OOO0 .fAryB5Q_Q [OOO00000O0O0O0OO0 -1 ]]#line:921
    def Get_B5Q_Q (OOO0O0O00O00000OO ,OO0000000O0O0000O :int )->int :#line:923
        ""#line:924
        if (OO0000000O0O0000O >OOO0O0O00O00000OO .B5QCount ):#line:925
            return 0 #line:926
        else :#line:927
            return OOO0O0O00O00000OO .TransToInt (OOO0O0O00O00000OO .f5Q [OOO0O0O00O00000OO .fAryB5Q_Q [OO0000000O0O0000O -1 ]])#line:928
    fAryS5Q_P =[24 ,26 ,28 ,30 ,32 ]#line:932
    """賣五檔價在字串中的位置"""#line:933
    fAryS5Q_Q =[25 ,27 ,29 ,31 ,33 ]#line:934
    """賣五檔價在字串中的位置"""#line:935
    S5QCountOrg :str #line:937
    """賣5檔的檔數"""#line:938
    S5QCount :int #line:939
    """賣5檔的檔數"""#line:940
    def S5Q_POrg (O000O00OO0O0000OO ,OO00OO0O0OO000OOO :int )->str :#line:942
        ""#line:943
        if (OO00OO0O0OO000OOO >O000O00OO0O0000OO .S5QCount ):#line:944
            return ""#line:945
        else :#line:946
            return O000O00OO0O0000OO .f5Q [O000O00OO0O0000OO .fAryS5Q_P [OO00OO0O0OO000OOO -1 ]]#line:947
    def Get_S5Q_P (OOO000O0O0000OO00 ,O0OOO00OOOO00O00O :int )->decimal :#line:949
        ""#line:950
        if (O0OOO00OOOO00O00O >OOO000O0O0000OO00 .S5QCount ):#line:951
            return 0 #line:952
        else :#line:953
            return OOO000O0O0000OO00 .TransToDecimal (OOO000O0O0000OO00 .f5Q [OOO000O0O0000OO00 .fAryS5Q_P [O0OOO00OOOO00O00O -1 ]])#line:954
    def S5Q_QOrg (O000OOO0OO00OOOOO ,OOOOO0OOOO00O00O0 :int )->str :#line:956
        ""#line:957
        if (OOOOO0OOOO00O00O0 >O000OOO0OO00OOOOO .S5QCount ):#line:958
            return ""#line:959
        else :#line:960
            return O000OOO0OO00OOOOO .f5Q [O000OOO0OO00OOOOO .fAryS5Q_Q [OOOOO0OOOO00O00O0 -1 ]]#line:961
    def Get_S5Q_Q (OO0O0O0OO0OO0OOOO ,O0OO0000O0OO00000 :int )->int :#line:963
        ""#line:964
        if (O0OO0000O0OO00000 >OO0O0O0OO0OO0OOOO .S5QCount ):#line:965
            return 0 #line:966
        else :#line:967
            return OO0O0O0OO0OO0OOOO .TransToInt (OO0O0O0OO0OO0OOOO .f5Q [OO0O0O0OO0OO0OOOO .fAryS5Q_Q [O0OO0000O0OO00000 -1 ]])#line:968
    def TransToInt (O0O00OO000O0OOOOO ,OOO000O0O0000O00O :str )->int :#line:972
        try :#line:973
            return int (OOO000O0O0000O00O )#line:974
        except Exception as O0OOO0OOOO0OO00OO :#line:975
            return 0 #line:976
    def TransToDecimal (O0OOOO0OO0O00OO00 ,OOOOOO0OOO0O0OOOO :str )->decimal :#line:978
        try :#line:979
            return Decimal (OOOOOO0OOO0O0OOOO )#line:980
        except Exception as OO0OO0O000OO0000O :#line:981
            return 0 #line:982
    def __init__ (OO0O000OO0000O00O )->None :#line:985
        OO0O000OO0000O00O .fPROC_HandleData =OO0O000OO0000O00O .HandleData_TryMarket #line:987
    def __str__ (O00OO0000OOOOO0OO )->str :#line:989
        return f"""SysTime:{O00OO0000OOOOO0OO.SysTime} DataTime:{O00OO0000OOOOO0OO.DataTime} DealSn:{O00OO0000OOOOO0OO.DealSn} TryMark:{O00OO0000OOOOO0OO.TryMark}"""+"""TotQty:{self.TotQty} B5QCountOrg:{self.B5QCountOrg} S5QCountOrg:{self.S5QCountOrg} f5Q:{self.f5Q}"""#line:991
class TStkQtIDX ():#line:992
    fIDX =[]#line:993
    def Handle_IDXRcv (O0OO0OOOOOO00OO0O ,OOO00OO0O00OOO0OO :str ):#line:995
        ""#line:996
        try :#line:997
            OOO0O0000O00OO0OO :int =0 #line:998
            O0OOOO0OO00O0OOO0 :int =0 #line:999
            OOOO000O000OO0O00 =OOO00OO0O00OOO0OO .split ('|')#line:1000
            if O0OO0OOOOOO00OO0O .fIDX ==None :#line:1001
                O0OO0OOOOOO00OO0O .fIDX =OOOO000O000OO0O00 #line:1002
            else :#line:1003
                O0OOOO0OO00O0OOO0 =O0OO0OOOOOO00OO0O .TransToInt (OOOO000O000OO0O00 [3 ])#line:1004
                OOO0O0000O00OO0OO =O0OO0OOOOOO00OO0O .Get_DealSn ()#line:1005
                if O0OOOO0OO00O0OOO0 >OOO0O0000O00OO0OO :#line:1006
                    O0OO0OOOOOO00OO0O .fIDX =OOOO000O000OO0O00 #line:1007
                    O0OO0OOOOOO00OO0O .SetData ()#line:1008
                O0OO0OOOOOO00OO0O .fPROC_CalcHightLowPrice ()#line:1010
        except Exception as OO000O00OO0O0O000 :#line:1012
            pass #line:1013
    def Handle_IDX (O0O0OO0O00OOOO0O0 ,O000OO00000OO00OO :str ):#line:1015
        ""#line:1016
        O0O0OO0O00OOOO0O0 .fIDX =O000OO00000OO00OO .split ('|')#line:1017
        O0O0OO0O00OOOO0O0 .SetData ()#line:1018
        O0O0OO0O00OOOO0O0 .fPROC_CalcHightLowPrice ()#line:1019
    def SetData (O00000OO0OO0000O0 ):#line:1021
        O00000OO0OO0000O0 .SysTime =O00000OO0OO0000O0 .fIDX [1 ]#line:1022
        O00000OO0OO0000O0 .DealTime =O00000OO0OO0000O0 .fIDX [2 ]#line:1023
        O00000OO0OO0000O0 .DealSn =O00000OO0OO0000O0 .fIDX [3 ]#line:1024
        O00000OO0OO0000O0 .DealPriceOrg =O00000OO0OO0000O0 .fIDX [10 ]#line:1026
        O00000OO0OO0000O0 .WholeTotAmt =O00000OO0OO0000O0 .fIDX [34 ]#line:1027
        O00000OO0OO0000O0 .TotQty =O00000OO0OO0000O0 .fIDX [35 ]#line:1029
        O00000OO0OO0000O0 .WholeTotQty =O00000OO0OO0000O0 .fIDX [35 ]#line:1030
        O00000OO0OO0000O0 .WholeDealCount =O00000OO0OO0000O0 .fIDX [36 ]#line:1031
        O00000OO0OO0000O0 .SumBuyOrderCount =O00000OO0OO0000O0 .fIDX [37 ]#line:1032
        O00000OO0OO0000O0 .SumSellOrderCount =O00000OO0OO0000O0 .fIDX [38 ]#line:1033
        O00000OO0OO0000O0 .SumBuyOrderQty =O00000OO0OO0000O0 .fIDX [39 ]#line:1034
        O00000OO0OO0000O0 .SumSellOrderQty =O00000OO0OO0000O0 .fIDX [40 ]#line:1035
    SysTime :str #line:1038
    """系統時間Unix Timestamp(us)(EX:1642553376085607)"""#line:1039
    DealTime :str #line:1040
    """撮合時間(成交)(EX:085229.843665)"""#line:1041
    DealSn :str #line:1042
    """序號"""#line:1043
    def Get_DealSn (O00OO0OO0OOOO0O0O )->int :#line:1045
        return O00OO0OO0OOOO0O0O .TransToInt (O00OO0OO0OOOO0O0O .fIDX [3 ])#line:1046
    TotQty :str #line:1047
    """成交總量"""#line:1048
    def Get_TotQty2Dec (OO0OO000OO0O0O0O0 )->decimal :#line:1050
        return OO0OO000OO0O0O0O0 .TransToDecimal (OO0OO000OO0O0O0O0 .fIDX [35 ])#line:1051
    def Get_TotQty2Int (OO0000000O000OO00 )->int :#line:1053
        return OO0000000O000OO00 .TransToInt (OO0000000O000OO00 .fIDX [35 ])#line:1054
    DealPriceOrg :str #line:1055
    """成交價"""#line:1056
    def Get_DealPrice (O00O00O0OOO000000 )->decimal :#line:1058
        return O00O00O0OOO000000 .TransToDecimal (O00O00O0OOO000000 .fIDX [10 ])#line:1059
    fDealPrice =0 #line:1062
    """成交價"""#line:1063
    HighPrice =0 #line:1064
    """當日最高價"""#line:1065
    LowPrice =0 #line:1066
    """當日最低價"""#line:1067
    def CalcHightLowPrice (OOO0000O00000000O ):#line:1069
        ""#line:1070
        try :#line:1071
            OOO0000O00000000O .fDealPrice =OOO0000O00000000O .Get_DealPrice ()#line:1072
            OOO0000O00000000O .HighPrice =math .Max (OOO0000O00000000O .fDealPrice ,OOO0000O00000000O .HighPrice )#line:1074
            if OOO0000O00000000O .LowPrice ==0 :#line:1075
                OOO0000O00000000O .LowPrice =OOO0000O00000000O .fDealPrice #line:1076
            else :#line:1077
                OOO0000O00000000O .LowPrice =math .Min (OOO0000O00000000O .fDealPrice ,OOO0000O00000000O .LowPrice )#line:1078
        except Exception as O000O0000O0O0O00O :#line:1079
            pass #line:1080
    def CalcHightLowPrice_None (OO000000O0OO0O000 ):#line:1082
        pass #line:1083
    fPROC_CalcHightLowPrice =None #line:1086
    """PROC_CalcHightLowPrice"""#line:1087
    HasWholeMarketData :bool #line:1092
    WholeTotAmt :str #line:1094
    """整體市場成交總額"""#line:1095
    def Get_WholeTotAmt (OOOOO00O0OO0OO0O0 )->int :#line:1097
        if (OOOOO00O0OO0OO0O0 .HasWholeMarketData ):#line:1098
            return OOOOO00O0OO0OO0O0 .TransToInt (OOOOO00O0OO0OO0O0 .fIDX [34 ])#line:1099
    def Get_WholeTotAmt (O000000O000OO00OO )->decimal :#line:1101
        if (O000000O000OO00OO .HasWholeMarketData ):#line:1102
            return O000000O000OO00OO .TransToDecimal (O000000O000OO00OO .fIDX [34 ])#line:1103
        else :#line:1104
            return 0 #line:1105
    WholeTotQty :str #line:1107
    """整體市場成交數量"""#line:1108
    def Get_WholeTotQty (OOO000O000O0OO00O )->int :#line:1110
        if (OOO000O000O0OO00O .HasWholeMarketData ):#line:1111
            return OOO000O000O0OO00O .TransToInt (OOO000O000O0OO00O .fIDX [35 ])#line:1112
        else :#line:1113
            return 0 #line:1114
    WholeDealCount :str #line:1115
    """整體市場成交筆數"""#line:1116
    def Get_WholeDealCount (O0OOOOO00OOO0O0O0 )->int :#line:1118
        if O0OOOOO00OOO0O0O0 .HasWholeMarketData :#line:1119
            return O0OOOOO00OOO0O0O0 .TransToInt (O0OOOOO00OOO0O0O0 .fIDX [36 ])#line:1120
        else :#line:1121
            return 0 #line:1122
    SumBuyOrderCount :str #line:1124
    """整體市場委託買進筆數"""#line:1125
    def Get_SumBuyOrderCount (O0O000O0O0O0O0000 )->int :#line:1127
        if O0O000O0O0O0O0000 .HasWholeMarketData :#line:1128
            return O0O000O0O0O0O0000 .TransToInt (O0O000O0O0O0O0000 .fIDX [37 ])#line:1129
        else :#line:1130
            return 0 #line:1131
    SumSellOrderCount :str #line:1132
    """整體市場委託賣出筆數"""#line:1133
    def Get_SumSellOrderCount (O000O0O00O0O000O0 )->int :#line:1135
        if O000O0O00O0O000O0 .HasWholeMarketData :#line:1136
            return O000O0O00O0O000O0 .TransToInt (O000O0O00O0O000O0 .fIDX [38 ])#line:1137
        else :#line:1138
            return 0 #line:1139
    SumBuyOrderQty :str #line:1140
    """整體市場委託買進數量"""#line:1141
    def Get_SumBuyOrderQty (OO0000O000O0O00O0 )->int :#line:1143
        if OO0000O000O0O00O0 .HasWholeMarketData :#line:1144
            return OO0000O000O0O00O0 .TransToInt (OO0000O000O0O00O0 .fIDX [39 ])#line:1145
        else :#line:1146
            return 0 #line:1147
    SumSellOrderQty :str #line:1148
    """整體市場委託賣出數量"""#line:1149
    def Get_SumSellOrderQty (OOO0O0OO0OOO0OO00 )->int :#line:1151
        if OOO0O0OO0OOO0OO00 .HasWholeMarketData :#line:1152
            return OOO0O0OO0OOO0OO00 .TransToInt (OOO0O0OO0OOO0OO00 .fIDX [40 ])#line:1153
        else :#line:1154
            return 0 #line:1155
    def TransToInt (OO0OOOO0OO00O00O0 ,O00O0O0OOO00OOOOO :str )->int :#line:1159
        try :#line:1160
            return int (O00O0O0OOO00OOOOO )#line:1161
        except Exception as O000O0000OO00O000 :#line:1162
            return 0 #line:1163
    def TransToDecimal (OO0OO000OOOOOOOO0 ,O0O00OO0O0O000OO0 :str )->decimal :#line:1165
        try :#line:1166
            return Decimal (O0O00OO0O0O000OO0 )#line:1167
        except Exception as OOO00OO0O00O000O0 :#line:1168
            return 0 #line:1169
    def __init__ (O000OOO0OOO00O000 ,OOO0O0O0000OO00OO :bool )->None :#line:1172
        ""#line:1173
        O000OOO0OOO00O000 .fPROC_CalcHightLowPrice =O000OOO0OOO00O000 .CalcHightLowPrice_None #line:1175
        if (OOO0O0O0000OO00OO ):#line:1176
            O000OOO0OOO00O000 .fPROC_CalcHightLowPrice =O000OOO0OOO00O000 .CalcHightLowPrice #line:1177
class TStkQuoteData :#line:1178
    BAS :TStkQtBase =None #line:1180
    HL :TStkQtHL =None #line:1181
    QtTX :TStkQtTX =None #line:1182
    Qt5Q :TStkQt5Q =None #line:1183
    QtIDX :TStkQtIDX =None #line:1184
    def __init__ (OOOOOO0000O0OOO00 ,OOOOOO0O0OO0O0OO0 :TStkProdKind ,O0OO0000O000000OO :str ,O0OO0O0O0O0O00OO0 :bool )->None :#line:1186
        ""#line:1187
        OOOOOO0000O0OOO00 .SolIce =O0OO0000O000000OO #line:1188
        OOOOOO0000O0OOO00 .ProdKind :TStkProdKind =OOOOOO0O0OO0O0OO0 #line:1189
        OOOOOO0000O0OOO00 ._lock =Lock ()#line:1190
        OOOOOO0000O0OOO00 .UpdateBAS =True #line:1191
        OOOOOO0000O0OOO00 .UpdateHL =False #line:1192
        if OOOOOO0O0OO0O0OO0 ==TStkProdKind .pkNormal :#line:1193
            OOOOOO0000O0OOO00 .BAS =TStkQtBase ()#line:1194
            OOOOOO0000O0OOO00 .HL =TStkQtHL ()#line:1195
            OOOOOO0000O0OOO00 .QtTX =TStkQtTX (O0OO0O0O0O0O00OO0 )#line:1196
            OOOOOO0000O0OOO00 .Qt5Q =TStkQt5Q ()#line:1197
        elif OOOOOO0O0OO0O0OO0 ==TStkProdKind .pkIndex :#line:1198
            OOOOOO0000O0OOO00 .BAS =TStkQtBase ()#line:1199
            OOOOOO0000O0OOO00 .HL =TStkQtHL ()#line:1200
            OOOOOO0000O0OOO00 .QtIDX =TStkQtIDX (O0OO0O0O0O0O00OO0 )#line:1201
    def SetDataInit (O000OO0O000OO0O0O ):#line:1228
        ""#line:1229
        if O000OO0O000OO0O0O .ProdKind ==TStkProdKind .pkNormal :#line:1230
            O000OO0O000OO0O0O .QtTX .HighPrice =O000OO0O000OO0O0O .HL .Get_HighPrice ()#line:1232
            O000OO0O000OO0O0O .QtTX .LowPrice =O000OO0O000OO0O0O .HL .Get_LowPrice ()#line:1233
            O000OO0O000OO0O0O .QtTX .HL_Sn_5Q =O000OO0O000OO0O0O .HL .Get_Sn_5Q ()#line:1235
            O000OO0O000OO0O0O .QtTX .BAS_TradingUnit =O000OO0O000OO0O0O .BAS .Get_TradingUnit ()#line:1237
            O000OO0O000OO0O0O .QtTX .HL_TotAmt =O000OO0O000OO0O0O .HL .Get_TotAmt2Int ()#line:1239
        elif O000OO0O000OO0O0O .ProdKind ==TStkProdKind .pkIndex :#line:1240
            O000OO0O000OO0O0O .QtIDX .HighPrice =O000OO0O000OO0O0O .HL .Get_HighPrice ()#line:1242
            O000OO0O000OO0O0O .QtIDX .LowPrice =O000OO0O000OO0O0O .HL .Get_LowPrice ()#line:1243
class TObjStkQuoteMap (UserDict ):#line:1258
    ""#line:1260
    """各商品拆解行情proc(EX:2330的TX與5Q, 行情拆解,是不同Proc)
        Dictionary<string, PROC_Handle_StkRTQuote> MapQtProc = new Dictionary<string, PROC_Handle_StkRTQuote>();"""#line:1263
    DefProc_TX :callable =None #line:1268
    DefProc_5Q :callable =None #line:1269
    DefProc_Idx :callable =None #line:1270
    def __init__ (O0OO0O0O000OO00O0 ,mapping =None ,**O000OOO0OO00OO000 ):#line:1271
        if mapping is not None :#line:1272
            mapping ={str (O000O0O0O0O000O00 ).upper ():OO0O000OO0OOO000O for O000O0O0O0O000O00 ,OO0O000OO0OOO000O in mapping .items ()}#line:1275
        else :#line:1276
            mapping ={}#line:1277
        if O000OOO0OO00OO000 :#line:1278
            mapping .update ({str (O0000000OO0O0O000 ).upper ():OOOO0O000OO0OO00O for O0000000OO0O0O000 ,OOOO0O000OO0OO00O in O000OOO0OO00OO000 .items ()})#line:1281
        O0OO0O0O000OO00O0 .MapQtProc ={}#line:1282
        super ().__init__ (mapping )#line:1283
    def __setitem__ (OO00O0O000O00OO00 ,OO000O0O00O00OOO0 ,OOOOOO00O0O0O000O ):#line:1285
        super ().__setitem__ (OO000O0O00O00OOO0 ,OOOOOO00O0O0O000O )#line:1286
    def AddRcvData (OO000OOOOOO0OO0O0 ,OO00000000000O0OO :TStkProdKind ,O0OO0OO0O0OO00000 :str ,OOO00OOO0OO00O0O0 :str ,OO0OOO0O0O0O0O00O :bool ):#line:1288
        ""#line:1293
        OO00O000OOOOO000O =""#line:1294
        O000O00O0OOOO00O0 :TStkQuoteData =None #line:1295
        try :#line:1296
            OO0000O00O0000000 =json .loads (OOO00OOO0OO00O0O0 )#line:1299
            if "status"in OO0000O00O0000000 and len (OO0000O00O0000000 ["status"])>0 :#line:1300
                if OO0000O00O0000000 ["status"][0 ]=="error":#line:1301
                    OO00O000OOOOO000O =f"[證][AddRcvData](aSolIce={O0OO0OO0O0OO00000}, aData={OOO00OOO0OO00O0O0})行情回補資料有誤!"#line:1302
                    return False ,O000O00O0OOOO00O0 ,OO00O000OOOOO000O #line:1303
            if "BAS"in OO0000O00O0000000 and len (OO0000O00O0000000 ["BAS"])==0 :#line:1304
                OO00O000OOOOO000O =f"[證][AddRcvData](aSolIce={O0OO0OO0O0OO00000}, aData={OOO00OOO0OO00O0O0})沒有BAS資料!"#line:1305
                return False ,O000O00O0OOOO00O0 ,OO00O000OOOOO000O #line:1306
            if "HL"in OO0000O00O0000000 and len (OO0000O00O0000000 ["HL"])==0 :#line:1307
                OO00O000OOOOO000O =f"[證][AddRcvData](aSolIce={O0OO0OO0O0OO00000}, aData={OOO00OOO0OO00O0O0})沒有HL資料!"#line:1308
                return False ,O000O00O0OOOO00O0 ,OO00O000OOOOO000O #line:1309
            if OO000OOOOOO0OO0O0 .data .get (O0OO0OO0O0OO00000 )is None :#line:1312
                O00O00OOOOOOOOO00 =TStkQuoteData (OO00000000000O0OO ,O0OO0OO0O0OO00000 ,OO0OOO0O0O0O0O00O )#line:1313
                O00O00OOOOOOOOO00 .BAS .Handle_BAS (OO0000O00O0000000 ["BAS"][0 ])#line:1314
                O00O00OOOOOOOOO00 .HL .Handle_HL (OO0000O00O0000000 ["HL"][0 ])#line:1315
                O00O00OOOOOOOOO00 .SetDataInit ()#line:1316
                O000O00O0OOOO00O0 =O00O00OOOOOOOOO00 #line:1317
                OO000OOOOOO0OO0O0 [O0OO0OO0O0OO00000 ]=O00O00OOOOOOOOO00 #line:1318
                return True ,O000O00O0OOOO00O0 ,""#line:1319
            else :#line:1320
                O00O00OOOOOOOOO00 :TStkQuoteData =OO000OOOOOO0OO0O0 [O0OO0OO0O0OO00000 ]#line:1321
                with O00O00OOOOOOOOO00 ._lock :#line:1322
                    O00O00OOOOOOOOO00 .BAS .Handle_BAS (OO0000O00O0000000 ["BAS"][0 ])#line:1323
                    O00O00OOOOOOOOO00 .HL .Handle_HL (OO0000O00O0000000 ["HL"][0 ])#line:1324
                    O00O00OOOOOOOOO00 .SetDataInit ()#line:1325
                    O000O00O0OOOO00O0 =O00O00OOOOOOOOO00 #line:1326
                return True ,O000O00O0OOOO00O0 ,""#line:1327
        except Exception as O0OOOO0OO0O00OO0O :#line:1328
            OO00O000OOOOO000O =f"[證][AddRcvData](aSolIce={O0OO0OO0O0OO00000}, aData={OOO00OOO0OO00O0O0}){O0OOOO0OO0O00OO0O}"#line:1329
            return False ,O000O00O0OOOO00O0 ,OO00O000OOOOO000O #line:1330
    def AddDataBySolIce (OOO0O0O0OOOO0000O ,OO00O0OOOO0O0O0O0 :bool ,OO000O0O0O000OOO0 :str ,OO000OOOO00O0O0OO ,O0OOOO0OO0OO0O00O :bool ,topic :str =""):#line:1332
        ""#line:1340
        try :#line:1341
            OOO00000O00000O0O :str =""#line:1342
            O00OOO00000OOO00O :TObjStkQuoteMap =TObjStkQuoteMap ()#line:1343
            if OO000OOOO00O0O0OO .get ("BAS")is not None :#line:1345
                for O00O0O00O0O000O0O in OO000OOOO00O0O0OO ["BAS"]:#line:1346
                    OOO0OO0OOOOO00OO0 :TStkQtBase =TStkQtBase (topic )#line:1347
                    OOO0OO0OOOOO00OO0 .Handle_BAS (O00O0O00O0O000O0O )#line:1348
                    if O00OOO00000OOO00O .data .get (OOO0OO0OOOOO00OO0 .StkNo )is None :#line:1349
                        O0O0000O0O0OOO000 :TStkQuoteData =TStkQuoteData (TStkProdKind .pkNormal ,OOO0OO0OOOOO00OO0 .StkNo ,O0OOOO0OO0OO0O00O )#line:1350
                        O0O0000O0O0OOO000 .BAS =OOO0OO0OOOOO00OO0 #line:1351
                        O0O0000O0O0OOO000 .UpdateHL =False #line:1352
                        O0O0000O0O0OOO000 .QtTX .BAS_TradingUnit =OOO0OO0OOOOO00OO0 .Get_TradingUnit ()#line:1354
                        O00OOO00000OOO00O [OOO0OO0OOOOO00OO0 .StkNo ]=O0O0000O0O0OOO000 #line:1355
                    if topic !="":#line:1356
                        O00OO0000O00OO0OO :str =OOO0OO0OOOOO00OO0 .TopicTX #line:1357
                        OO000O000000OOOOO :str =OOO0OO0OOOOO00OO0 .Topic5Q #line:1358
                        OOO0O0O0OOOO0000O [O00OO0000O00OO0OO ]=O0O0000O0O0OOO000 #line:1359
                        OOO0O0O0OOOO0000O [OO000O000000OOOOO ]=O0O0000O0O0OOO000 #line:1360
                        if OOO0O0O0OOOO0000O .MapQtProc .get (O00OO0000O00OO0OO )is None :#line:1361
                            OOO0O0O0OOOO0000O .MapQtProc [O00OO0000O00OO0OO ]=OOO0O0O0OOOO0000O .DefProc_TX #line:1362
                        if OOO0O0O0OOOO0000O .MapQtProc .get (OO000O000000OOOOO )is None :#line:1363
                            OOO0O0O0OOOO0000O .MapQtProc [OO000O000000OOOOO ]=OOO0O0O0OOOO0000O .DefProc_5Q #line:1364
            if OO000OOOO00O0O0OO .get ("HL")is not None :#line:1367
                for OOOOO000O0OOO0O0O in OO000OOOO00O0O0OO ["HL"]:#line:1368
                    O000000OO00OO0OOO =TStkQtHL ()#line:1369
                    O000000OO00OO0OOO .Handle_HL (OOOOO000O0OOO0O0O )#line:1370
                    if O00OOO00000OOO00O .data .get (O000000OO00OO0OOO .Symbol ):#line:1371
                        O0O0000O0O0OOO000 =O00OOO00000OOO00O [O000000OO00OO0OOO .Symbol ]#line:1372
                        O0O0000O0O0OOO000 .UpdateHL =True #line:1373
                        O0O0000O0O0OOO000 .HL =O000000OO00OO0OOO #line:1374
                        O0O0000O0O0OOO000 .SetDataInit ()#line:1375
                    if topic =="":#line:1376
                        O00OO0000O00OO0OO :str =O000000OO00OO0OOO .TopicTX #line:1377
                        OO000O000000OOOOO :str =O000000OO00OO0OOO .Topic5Q #line:1378
                        OOO0O0O0OOOO0000O [O00OO0000O00OO0OO ]=O0O0000O0O0OOO000 #line:1379
                        OOO0O0O0OOOO0000O [OO000O000000OOOOO ]=O0O0000O0O0OOO000 #line:1380
                        if OOO0O0O0OOOO0000O .MapQtProc .get (O00OO0000O00OO0OO )is None :#line:1381
                            OOO0O0O0OOOO0000O .MapQtProc [O00OO0000O00OO0OO ]=OOO0O0O0OOOO0000O .DefProc_TX #line:1382
                        if OOO0O0O0OOOO0000O .MapQtProc .get (OO000O000000OOOOO )is None :#line:1383
                            OOO0O0O0OOOO0000O .MapQtProc [OO000O000000OOOOO ]=OOO0O0O0OOOO0000O .DefProc_5Q #line:1384
            return len (O00OOO00000OOO00O )>0 ,O00OOO00000OOO00O ,OOO00000O00000O0O #line:1386
        except Exception as O0OO00O000OO0OO0O :#line:1387
            OOO00000O00000O0O =f"[證][AddDataBySolIce](aIsCat={OO00O0OOOO0O0O0O0}, aSolIce={OO000O0O0O000OOO0}){O0OO00O000OO0OO0O}"#line:1388
        return False ,O00OOO00000OOO00O ,OOO00000O00000O0O #line:1389
    def AddIdxDataBySolIce (OOOO0O00O0OO000O0 ,O000O000O00000000 :bool ,O0000000OOOO0OOO0 :str ,O00O0OO0000OOO0O0 ,OOO0OO0000000OO00 :bool ):#line:1391
        ""#line:1398
        try :#line:1399
            O0O000000OOO0OOOO =""#line:1400
            O00O0O0000OOOO0OO :TObjStkQuoteMap =TObjStkQuoteMap ()#line:1401
            for O0000000O0O000O0O in O00O0OO0000OOO0O0 ["BAS"]:#line:1403
                OOO0O0O0O0OO000OO :TStkQtBase =TStkQtBase ()#line:1404
                OOO0O0O0O0OO000OO .Handle_BAS (O0000000O0O000O0O )#line:1405
                if O00O0O0000OOOO0OO .data .get (OOO0O0O0O0OO000OO .StkNo )is None :#line:1406
                    OOO000O0O0O0OOO00 :TStkQuoteData =TStkQuoteData (TStkProdKind .pkIndex ,OOO0O0O0O0OO000OO .StkNo ,OOO0OO0000000OO00 )#line:1407
                    OOO000O0O0O0OOO00 .BAS =OOO0O0O0O0OO000OO #line:1408
                    O00O0O0000OOOO0OO [OOO0O0O0O0OO000OO .StkNo ]=OOO000O0O0O0OOO00 #line:1409
            for O0000000O0O000O0O in O00O0OO0000OOO0O0 ["HL"]:#line:1412
                O00O00000OOO0OOO0 =TStkQtHL ()#line:1413
                O00O00000OOO0OOO0 .Handle_HL (O0000000O0O000O0O )#line:1414
                if O00O0O0000OOOO0OO .data .get (O00O00000OOO0OOO0 .Symbol ):#line:1415
                    OOO000O0O0O0OOO00 =O00O0O0000OOOO0OO [O00O00000OOO0OOO0 .Symbol ]#line:1416
                    OOO000O0O0O0OOO00 .HL =O00O00000OOO0OOO0 #line:1417
                    OOO000O0O0O0OOO00 .SetDataInit ()#line:1418
                    OO000000OO000000O :O0000000O0O000O0O =OOO000O0O0O0OOO00 .HL .TopicTX #line:1420
                    OOOO0O00O0OO000O0 [OO000000OO000000O ]=OOO000O0O0O0OOO00 #line:1422
                    if OOOO0O00O0OO000O0 .MapQtProc .get (OO000000OO000000O )is None :#line:1424
                        OOOO0O00O0OO000O0 .MapQtProc [OO000000OO000000O ]=OOOO0O00O0OO000O0 .DefProc_Idx #line:1425
            return len (O00O0O0000OOOO0OO )>0 ,O00O0O0000OOOO0OO ,O0O000000OOO0OOOO #line:1427
        except Exception as O0000OOOO00O00O0O :#line:1428
            O0O000000OOO0OOOO =f"[證][AddIdxDataBySolIce](aIsCat={O000O000O00000000}, aSolIce={O0000000OOOO0OOO0}){O0000OOOO00O00O0O}"#line:1429
        return False ,O00O0O0000OOOO0OO ,O0O000000OOO0OOOO #line:1430
    def GetItem_BySolIce (OO0O00O0O0OOOOO0O ,OO0O00O0OOO0OOO00 :str ):#line:1433
        ""#line:1438
        try :#line:1439
            O0000OOO0O0OOO00O =[]#line:1440
            for OOO00O00OOO0000OO ,OO0OOO0OOOOOOO000 in OO0O00O0O0OOOOO0O .items ():#line:1441
                OOOO00OOO0OOO000O :TStkQuoteData #line:1442
                OOOO00OOO0OOO000O =OO0OOO0OOOOOOO000 #line:1443
                if OOOO00OOO0OOO000O .SolIce ==OO0O00O0OOO0OOO00 :#line:1444
                    O0000OOO0O0OOO00O .append (OOO00O00OOO0000OO )#line:1445
            if O0000OOO0O0OOO00O is None or len (O0000OOO0O0OOO00O )==0 :#line:1446
                return False ,[],f"[證][GetItem_BySolIce](aSolIce={OO0O00O0OOO0OOO00})商品已不存存!"#line:1447
            else :#line:1448
                return True ,O0000OOO0O0OOO00O ,""#line:1449
        except Exception as OOO0O0O00OOOOO0O0 :#line:1450
            return False ,[],f"[證][GetItem_BySolIce](aSolIce={OO0O00O0OOO0OOO00}){OOO0O0O00OOOOO0O0}"#line:1451
    def GetItem_ByCategory (OOO0000O00OO00O00 ,OO0000OOO0O00OOO0 :str ):#line:1452
        ""#line:1455
        try :#line:1457
            O000O0OO000OOO0O0 =[]#line:1458
            for O000000OO00O0OO0O ,OO00OOOOO00000O0O in OOO0000O00OO00O00 .items ():#line:1459
                O00OOOOO0O0OO000O :TStkQuoteData =OO00OOOOO00000O0O #line:1460
                OO0O0O0O0O0OO00O0 =O000000OO00O0OO0O .split ('/')#line:1461
                if OO0O0O0O0O0OO00O0 [2 ]==OO0000OOO0O00OOO0 :#line:1462
                    O000O0OO000OOO0O0 .append (O000000OO00O0OO0O )#line:1463
            if O000O0OO000OOO0O0 is None or len (O000O0OO000OOO0O0 )==0 :#line:1465
                return False ,[],f"[證][GetItem_ByCategory](aCat={OO0000OOO0O00OOO0})商品已不存存!"#line:1466
            else :#line:1467
                return True ,O000O0OO000OOO0O0 ,""#line:1468
        except Exception as O0OO0O0O0OO0O0000 :#line:1470
            return False ,[],f"[證][GetItem_ByCategory](aCat={OO0000OOO0O00OOO0}){O0OO0O0O0OO0O0000}"#line:1471
class TQryStkProdMap (UserDict ):#line:1475
    def __init__ (OO0O0O0O00O0O0OOO ,mapping =None ,**O0OO00OOOO0OOOOOO ):#line:1476
        if mapping is not None :#line:1477
            mapping ={str (O0000OO0OO0O0OOO0 ).upper ():O0O0O0OOOO0OOOOOO for O0000OO0OO0O0OOO0 ,O0O0O0OOOO0OOOOOO in mapping .items ()}#line:1480
        else :#line:1481
            mapping ={}#line:1482
        if O0OO00OOOO0OOOOOO :#line:1483
            mapping .update ({str (OOOO00OOO0O000OO0 ).upper ():O00O000000O0O0OOO for OOOO00OOO0O000OO0 ,O00O000000O0O0OOO in O0OO00OOOO0OOOOOO .items ()})#line:1486
        super ().__init__ (mapping )#line:1487
    """Dictionary<string, TQryStkProdRec>"""#line:1488
    def __setitem__ (O0OO00OOOOOOOOOO0 ,O0OO0OO0O0O0O00O0 ,O0O00O0000O0OOOOO ):#line:1490
        super ().__setitem__ (O0OO0OO0O0O0O00O0 ,O0O00O0000O0OOOOO )#line:1491
class TQryStkProdRec ():#line:1494
    tmpBase :TStkQtBase =None #line:1495
    tmpHL :TStkQtHL =None #line:1496
    def SetDataInit (O0O0O000000O00O00 ):#line:1498
        pass #line:1499
class TFutQtBase :#line:1505
    fHasBAS :bool =False #line:1507
    TopicTX :str =""#line:1508
    Topic5Q :str =""#line:1509
    TopicHL :str =""#line:1510
    Topic5QTOT :str =""#line:1511
    TopicBAS :str =""#line:1512
    fBAS =[]#line:1514
    DECIMAL_LOCATOR_Org :int =0 #line:1516
    """價格欄位小數位數"""#line:1517
    DECIMAL_LOCATOR_Dgt :decimal =1 #line:1518
    """價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"""#line:1519
    OrdProdID :str #line:1520
    """商品委託代碼(EX:CDFC3)"""#line:1521
    RefPriceOrg :str #line:1522
    """參考價"""#line:1523
    def Get_RefPrice2Str (O0OO0OO0O00O0OOOO )->str :#line:1525
        return O0OO0OO0O00O0OOOO .TransPrice2Str (O0OO0OO0O00O0OOOO .fBAS [4 ])#line:1526
    def Get_RefPrice2Dec (OOO0OOO0000OO00OO )->decimal :#line:1528
        return OOO0OOO0000OO00OO .TransPrice2Dec (OOO0OOO0000OO00OO .fBAS [4 ])#line:1529
    LimitPrice_UpOrg :str #line:1531
    """漲停價"""#line:1532
    def Get_LimitPrice_Up2Str (O00O00OOO0OO00000 )->str :#line:1534
        return O00O00OOO0OO00000 .TransPrice2Str (O00O00OOO0OO00000 .fBAS [5 ])#line:1535
    def Get_LimitPrice_Up2Dec (OOOOO000O0O000OO0 )->decimal :#line:1537
        return OOOOO000O0O000OO0 .TransPrice2Dec (OOOOO000O0O000OO0 .fBAS [5 ])#line:1538
    LimitPrice_DownOrg :str #line:1540
    """跌停價"""#line:1541
    ProdKind :str #line:1543
    """契約種類"""#line:1544
    def Get_LimitPrice_Down2Str (O0O0O000000OOOO00 )->str :#line:1546
        return O0O0O000000OOOO00 .TransPrice2Str (O0O0O000000OOOO00 .fBAS [6 ])#line:1547
    def Get_LimitPrice_Down2Dec (O00OO0O00000O00OO )->decimal :#line:1549
        return O00OO0O00000O00OO .TransPrice2Dec (O00OO0O00000O00OO .fBAS [6 ])#line:1550
    IdxDgtOrg :str #line:1552
    """指數小數位數"""#line:1553
    def Get_IdxDgtOrg (O00OOOO000OO00O0O )->int :#line:1555
        return O00OOOO000OO00O0O .TransToInt (O00OOOO000OO00O0O .fBAS [8 ])#line:1556
    StrikePriceDecimalLocator :str #line:1558
    "選擇權商品代號之履約價小數位數"#line:1559
    BeginDate :str #line:1561
    "上市日期"#line:1562
    EndDate :str #line:1563
    "下市日期"#line:1564
    FlowGroup :str #line:1565
    "流程群組"#line:1566
    DeliveryDate :str #line:1567
    "最後結算日"#line:1568
    DynamicBanding :str #line:1569
    "適用動態價格穩定"#line:1570
    ProdID :str #line:1572
    """契約代號 (EX:CDF)"""#line:1573
    FutName :str #line:1574
    """期貨契約中文(EX:小型環球晶)"""#line:1575
    StkNo :str #line:1576
    """現股代碼(EX:2330)"""#line:1577
    ValuePerUnitOrg :str #line:1578
    """契約乘數"""#line:1579
    def Get_ValuePerUnit (OO00OOO000O00O000 )->decimal :#line:1581
        return OO00OOO000O00O000 .TransToDecimal (OO00OOO000O00O000 .fBAS [18 ])#line:1582
    StatusCode :str #line:1584
    "狀態碼"#line:1585
    Currency :str #line:1586
    "幣別"#line:1587
    AcceptQuoteFlag :str #line:1588
    "是否可報價"#line:1589
    BlockTradeFlag :str #line:1590
    "是否可鉅額交易"#line:1591
    ExpiryType :str #line:1592
    "到期別"#line:1593
    UnderlyingType :str #line:1594
    "現貨類別"#line:1595
    MarketCloseGroup :str #line:1596
    "商品收盤時間群組"#line:1597
    EndSession :str #line:1598
    MktType :str #line:1600
    """早午盤識別(早盤:0, 午盤:1)"""#line:1601
    SettleMth :str #line:1602
    """交割月"""#line:1603
    CallPutType :str #line:1604
    """C/P"""#line:1605
    StrikeP :str #line:1606
    """履約價"""#line:1607
    PreTotalMatchQty :str #line:1609
    """昨日成交總量"""#line:1610
    PreOpenInterest :str #line:1611
    """昨日未平倉合約數"""#line:1612
    PreTodayRefPrice :str #line:1613
    """昨日參考價"""#line:1614
    def Get_PreTodayRefPrice2Str (OO0O0O000O00O0O00 ):#line:1615
        return OO0O0O000O00O0O00 .TransPrice2Dec (OO0O0O000O00O0O00 .fBAS [31 ])#line:1616
    def Get_PreTodayRefPrice2Dec (O0OOOOOO0O0O00O0O ):#line:1617
        return O0OOOOOO0O0O00O0O .TransPrice2Dec (O0OOOOOO0O0O00O0O .fBAS [31 ])#line:1618
    PreClosePrice :str #line:1620
    """昨日收盤價"""#line:1621
    def Get_PreClosePrice2Str (OOO0000OOOO0000OO ):#line:1622
        return OOO0000OOOO0000OO .TransPrice2Str (OOO0000OOOO0000OO .fBAS [32 ])#line:1623
    def Get_PreClosePrice2Dec (OO0OOOO0000OOOOO0 ):#line:1624
        return OO0OOOO0000OOOOO0 .TransPrice2Dec (OO0OOOO0000OOOOO0 .fBAS [32 ])#line:1625
    PreSettlePrice :str #line:1627
    """昨日結算價"""#line:1628
    def Get_PreSettlePrice2Str (O0O0000O0OO0OOOOO ):#line:1629
        return O0O0000O0OO0OOOOO .TransPrice2Str (O0O0000O0OO0OOOOO .fBAS [33 ])#line:1630
    def Get_PreSettlePrice2Dec (O0O0OO00O0O0O00OO ):#line:1631
        return O0O0OO00O0O0O00OO .TransPrice2Dec (O0O0OO00O0O0O00OO .fBAS [33 ])#line:1632
    TickSizeInfo :str #line:1634
    """跳動點資訊"""#line:1635
    def Handle_BAS (O0OO000O00000OOO0 ,OO0OO0O00OOOO0OOO :str ):#line:1638
        O0OO000O00000OOO0 .fBAS =OO0OO0O00OOOO0OOO .split ("|")#line:1639
        O0OO000O00000OOO0 .fHasBAS =len (O0OO000O00000OOO0 .fBAS )>0 #line:1640
        O0OO000O00000OOO0 .OrdProdID =O0OO000O00000OOO0 .fBAS [0 ]#line:1641
        O0OO000O00000OOO0 .RefPriceOrg =O0OO000O00000OOO0 .fBAS [4 ]#line:1642
        O0OO000O00000OOO0 .LimitPrice_UpOrg =O0OO000O00000OOO0 .fBAS [5 ]#line:1643
        O0OO000O00000OOO0 .LimitPrice_DownOrg =O0OO000O00000OOO0 .fBAS [6 ]#line:1644
        O0OO000O00000OOO0 .ProdKind =O0OO000O00000OOO0 .fBAS [7 ]#line:1645
        O0OO000O00000OOO0 .IdxDgtOrg =O0OO000O00000OOO0 .fBAS [8 ]#line:1646
        O0OO000O00000OOO0 .StrikePriceDecimalLocator =O0OO000O00000OOO0 .fBAS [9 ]#line:1647
        O0OO000O00000OOO0 .BeginDate =O0OO000O00000OOO0 .fBAS [10 ]#line:1648
        O0OO000O00000OOO0 .EndDate =O0OO000O00000OOO0 .fBAS [11 ]#line:1649
        O0OO000O00000OOO0 .FlowGroup =O0OO000O00000OOO0 .fBAS [12 ]#line:1650
        O0OO000O00000OOO0 .DeliveryDate =O0OO000O00000OOO0 .fBAS [13 ]#line:1651
        O0OO000O00000OOO0 .DynamicBanding =O0OO000O00000OOO0 .fBAS [14 ]#line:1652
        O0OO000O00000OOO0 .ProdID =O0OO000O00000OOO0 .fBAS [15 ]#line:1653
        O0OO000O00000OOO0 .FutName =O0OO000O00000OOO0 .fBAS [16 ]#line:1654
        O0OO000O00000OOO0 .StkNo =O0OO000O00000OOO0 .fBAS [17 ]#line:1655
        O0OO000O00000OOO0 .ValuePerUnitOrg =O0OO000O00000OOO0 .fBAS [18 ]#line:1656
        O0OO000O00000OOO0 .StatusCode =O0OO000O00000OOO0 .fBAS [19 ]#line:1657
        O0OO000O00000OOO0 .Currency =O0OO000O00000OOO0 .fBAS [20 ]#line:1658
        O0OO000O00000OOO0 .AcceptQuoteFlag =O0OO000O00000OOO0 .fBAS [21 ]#line:1659
        O0OO000O00000OOO0 .BlockTradeFlag =O0OO000O00000OOO0 .fBAS [22 ]#line:1660
        O0OO000O00000OOO0 .ExpiryType =O0OO000O00000OOO0 .fBAS [23 ]#line:1661
        O0OO000O00000OOO0 .UnderlyingType =O0OO000O00000OOO0 .fBAS [24 ]#line:1662
        O0OO000O00000OOO0 .MarketCloseGroup =O0OO000O00000OOO0 .fBAS [25 ]#line:1663
        O0OO000O00000OOO0 .EndSession =O0OO000O00000OOO0 .fBAS [26 ]#line:1664
        O0OO000O00000OOO0 .MktType =O0OO000O00000OOO0 .fBAS [27 ]#line:1665
        if len (O0OO000O00000OOO0 .fBAS [28 ])==0 or O0OO000O00000OOO0 .fBAS [28 ]is None or O0OO000O00000OOO0 .fBAS [28 ].isspace ():#line:1666
            O0OO000O00000OOO0 .SettleMth =""#line:1667
        else :#line:1668
            O0OO000O00000OOO0 .SettleMth =O0OO000O00000OOO0 .fBAS [28 ].split (".")[1 ]#line:1669
        O0OO000O00000OOO0 .CallPutType =""#line:1671
        if len (O0OO000O00000OOO0 .fBAS [28 ])==0 or O0OO000O00000OOO0 .fBAS [28 ]is None or O0OO000O00000OOO0 .fBAS [28 ].isspace ():#line:1672
            O0OO000O00000OOO0 .CallPutType =""#line:1673
        if "C"in O0OO000O00000OOO0 .fBAS [28 ]:#line:1674
            O0OO000O00000OOO0 .CallPutType ="C"#line:1675
        if "P"in O0OO000O00000OOO0 .fBAS [28 ]:#line:1676
            O0OO000O00000OOO0 .CallPutType ="P"#line:1677
        O0OO000O00000OOO0 .StrikeP =""#line:1679
        if len (O0OO000O00000OOO0 .fBAS [28 ])==0 or O0OO000O00000OOO0 .fBAS [28 ]is None or O0OO000O00000OOO0 .fBAS [28 ].isspace ():#line:1680
            O0OO000O00000OOO0 .StrikeP =""#line:1681
        if "C"in O0OO000O00000OOO0 .fBAS [28 ]:#line:1682
            O0OO000O00000OOO0 .StrikeP =O0OO000O00000OOO0 .fBAS [28 ].split (".")[1 ]#line:1683
        if "P"in O0OO000O00000OOO0 .fBAS [28 ]:#line:1684
            O0OO000O00000OOO0 .StrikeP =O0OO000O00000OOO0 .fBAS [28 ].split (".")[1 ]#line:1685
        O0OO000O00000OOO0 .PreTotalMatchQty =O0OO000O00000OOO0 .fBAS [29 ]#line:1687
        O0OO000O00000OOO0 .PreOpenInterest =O0OO000O00000OOO0 .fBAS [30 ]#line:1688
        O0OO000O00000OOO0 .PreTodayRefPrice =O0OO000O00000OOO0 .fBAS [31 ]#line:1689
        O0OO000O00000OOO0 .PreClosePrice =O0OO000O00000OOO0 .fBAS [32 ]#line:1690
        O0OO000O00000OOO0 .PreSettlePrice =O0OO000O00000OOO0 .fBAS [33 ]#line:1691
        O0OO000O00000OOO0 .TickSizeInfo =O0OO000O00000OOO0 .fBAS [36 ]#line:1693
        if O0OO000O00000OOO0 .fHasBAS :#line:1694
            O0OO000O00000OOO0 .DECIMAL_LOCATOR_Org =O0OO000O00000OOO0 .Get_IdxDgtOrg ()#line:1696
            if O0OO000O00000OOO0 .DECIMAL_LOCATOR_Org ==0 :#line:1697
                O0OO000O00000OOO0 .DECIMAL_LOCATOR_Dgt =1 #line:1698
            else :#line:1699
                O0OO000O00000OOO0 .DECIMAL_LOCATOR_Dgt =1 /Decimal ("1".ljust (O0OO000O00000OOO0 .DECIMAL_LOCATOR_Org +1 ,'0'))#line:1701
        if O0OO000O00000OOO0 .TopicTX !="":#line:1703
            O000O0OOOOOO00O00 =O0OO000O00000OOO0 .TopicTX .split ("/")#line:1704
            O000O0OOOOOO00O00 [len (O000O0OOOOOO00O00 )-2 ]=O0OO000O00000OOO0 .OrdProdID #line:1705
            O0OO000O00000OOO0 .TopicTX ="/".join (O000O0OOOOOO00O00 )#line:1706
            O000O0OOOOOO00O00 =O0OO000O00000OOO0 .Topic5Q .split ("/")#line:1707
            O000O0OOOOOO00O00 [len (O000O0OOOOOO00O00 )-2 ]=O0OO000O00000OOO0 .OrdProdID #line:1708
            O0OO000O00000OOO0 .Topic5Q ="/".join (O000O0OOOOOO00O00 )#line:1709
            O000O0OOOOOO00O00 =O0OO000O00000OOO0 .TopicHL .split ("/")#line:1710
            O000O0OOOOOO00O00 [len (O000O0OOOOOO00O00 )-2 ]=O0OO000O00000OOO0 .OrdProdID #line:1711
            O0OO000O00000OOO0 .TopicHL ="/".join (O000O0OOOOOO00O00 )#line:1712
            O000O0OOOOOO00O00 =O0OO000O00000OOO0 .Topic5QTOT .split ("/")#line:1713
            O000O0OOOOOO00O00 [len (O000O0OOOOOO00O00 )-2 ]=O0OO000O00000OOO0 .OrdProdID #line:1714
            O0OO000O00000OOO0 .Topic5QTOT ="/".join (O000O0OOOOOO00O00 )#line:1715
            O000O0OOOOOO00O00 =O0OO000O00000OOO0 .TopicBAS .split ("/")#line:1716
            O000O0OOOOOO00O00 [len (O000O0OOOOOO00O00 )-2 ]=O0OO000O00000OOO0 .OrdProdID #line:1717
            O0OO000O00000OOO0 .TopicBAS ="/".join (O000O0OOOOOO00O00 )#line:1718
    def Handle_BAS_ChangeMktType (OO000OO0O0OOOO0OO ,O0OOO0OOO00O00OO0 :str )->bool :#line:1720
        ""#line:1721
        try :#line:1722
            if OO000OO0O0OOOO0OO .fBAS is not None and len (OO000OO0O0OOOO0OO .fBAS )>28 :#line:1723
                O00OOOO00O0000000 =O0OOO0OOO00O00OO0 .split ("|")#line:1724
                if len (O00OOOO00O0000000 )>28 :#line:1725
                    if O00OOOO00O0000000 [27 ]!=OO000OO0O0OOOO0OO .fBAS [27 ]:#line:1726
                        OO000OO0O0OOOO0OO .Handle_BAS (O0OOO0OOO00O00OO0 )#line:1727
                        return True #line:1728
        except Exception as O0000O000O0OO0000 :#line:1729
            return False #line:1730
    def TransPrice2Dec (OOOO0O0O00O000O0O ,OO00O0O00O00OO00O :str )->decimal :#line:1733
        try :#line:1734
            O000OOOO00OO0O000 =Decimal (OO00O0O00O00OO00O )#line:1735
            O000OOOO00OO0O000 =O000OOOO00OO0O000 *OOOO0O0O00O000O0O .DECIMAL_LOCATOR_Dgt #line:1736
            return O000OOOO00OO0O000 #line:1737
        except Exception as OO0OOOOOO0OOOOO00 :#line:1738
            print (f"Not a Decimal{OO0OOOOOO0OOOOO00}")#line:1739
            return 0 #line:1740
    def TransPrice2Str (O0O0OOOO0O00OOOOO ,O0OO0OOO0OOO00O0O :str )->str :#line:1742
        if O0O0OOOO0O00OOOOO .DECIMAL_LOCATOR_Dgt ==1 :#line:1743
            return O0OO0OOO0OOO00O0O #line:1744
        if O0OO0OOO0OOO00O0O =="0":#line:1745
            return ""#line:1746
        if len (O0OO0OOO0OOO00O0O )<O0O0OOOO0O00OOOOO .DECIMAL_LOCATOR_Org :#line:1747
            return O0OO0OOO0OOO00O0O #line:1748
        if not O0OO0OOO0OOO00O0O or O0OO0OOO0OOO00O0O .isspace ():#line:1749
            return ""#line:1750
        try :#line:1751
            OOO0O0OO0O00O00OO =len (O0OO0OOO0OOO00O0O )#line:1752
            return O0OO0OOO0OOO00O0O [:OOO0O0OO0O00O00OO -O0O0OOOO0O00OOOOO .DECIMAL_LOCATOR_Org ]+'.'+O0OO0OOO0OOO00O0O [OOO0O0OO0O00O00OO -O0O0OOOO0O00OOOOO .DECIMAL_LOCATOR_Org :]#line:1753
        except Exception as O00OO0OOOOOO0OOO0 :#line:1754
            return ""#line:1755
    def TransToInt (OO0O000000OO0OOOO ,OO0O000OO00O0OOO0 :str )->int :#line:1757
        try :#line:1758
            return int (OO0O000OO00O0OOO0 )#line:1759
        except Exception as OO00O000OO0O0OOO0 :#line:1760
            pass #line:1762
        return 0 #line:1763
    def TransToDecimal (OOO0OOO0OO0O0OO0O ,OOOOOOOO000000O0O :str )->decimal :#line:1765
        try :#line:1766
            return Decimal (OOOOOOOO000000O0O )#line:1767
        except Exception as OOO00OOO0O0OOO00O :#line:1768
            print (f"Not a Decimal{OOO00OOO0O0OOO00O}")#line:1769
        return 0 #line:1770
    def __init__ (OO00O000OO00OOO0O ,topic :str ="")->None :#line:1773
        if topic !="":#line:1774
            OOOO00OOOOOO00O00 =topic .split ("/")#line:1775
            OOOO00OOOOOO00O00 [len (OOOO00OOOOOO00O00 )-1 ]="HL"#line:1776
            OO00O000OO00OOO0O .TopicHL ="/".join (OOOO00OOOOOO00O00 )#line:1777
            OOOO00OOOOOO00O00 [len (OOOO00OOOOOO00O00 )-1 ]="TX"#line:1778
            OO00O000OO00OOO0O .TopicTX ="/".join (OOOO00OOOOOO00O00 )#line:1779
            OOOO00OOOOOO00O00 [len (OOOO00OOOOOO00O00 )-1 ]="5Q"#line:1780
            OO00O000OO00OOO0O .Topic5Q ="/".join (OOOO00OOOOOO00O00 )#line:1781
            OOOO00OOOOOO00O00 [len (OOOO00OOOOOO00O00 )-1 ]="5QTOT"#line:1782
            OO00O000OO00OOO0O .Topic5QTOT ="/".join (OOOO00OOOOOO00O00 )#line:1783
            OOOO00OOOOOO00O00 [len (OOOO00OOOOOO00O00 )-1 ]="BAS"#line:1784
            OO00O000OO00OOO0O .TopicBAS ="/".join (OOOO00OOOOOO00O00 )#line:1785
    def __str__ (OO0O0O0OOO00OO0OO )->str :#line:1787
        return f"""OrdProdID:{OO0O0O0OOO00OO0OO.OrdProdID} RefPriceOrg:{OO0O0O0OOO00OO0OO.RefPriceOrg} LimitPrice_UpOrg:{OO0O0O0OOO00OO0OO.LimitPrice_UpOrg} LimitPrice_DownOrg:{OO0O0O0OOO00OO0OO.LimitPrice_DownOrg}"""+"""IdxDgtOrg:{self.IdxDgtOrg} ProdID:{self.ProdID} FutName:{self.FutName} StkNo:{self.StkNo} ValuePerUnitOrg:{self.ValuePerUnitOrg}"""+"""MktType:{self.MktType} SettleMth:{self.SettleMth} CallPutType:{self.CallPutType} StrikeP:{self.StrikeP} TickSizeInfo:{self.TickSizeInfo} """#line:1790
class TFutQtHL :#line:1791
    HasHL :bool =False #line:1793
    fHL =[]#line:1794
    TopicTX =""#line:1795
    Topic5Q =""#line:1796
    Topic5QTOT =""#line:1797
    TopicBAS =""#line:1798
    DECIMAL_LOCATOR_Org :int =0 #line:1800
    """價格欄位小數位數"""#line:1801
    DECIMAL_LOCATOR_Dgt :decimal =1 #line:1802
    """價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"""#line:1803
    Exchange :str =""#line:1804
    "市場別(TWS/TWF)"#line:1805
    Market :str =""#line:1806
    """商品別(FUT/OPT)"""#line:1807
    Symbol :str =""#line:1808
    """委託商品代碼(TXFA2)"""#line:1809
    TryMark_Deal :str =""#line:1810
    """成交試撮註記(試撮=1, 非試撮=0"""#line:1811
    TryMark :str =""#line:1812
    """試撮註記(試撮=1, 非試撮=0)"""#line:1813
    DealTime :str =""#line:1814
    """撮合時間(成交)(EX:173547.32700)"""#line:1815
    DealSn :str =""#line:1816
    """成交序號"""#line:1817
    def Get_DealSn (OOO0OOOOOOO0O00OO )->int :#line:1819
        return OOO0OOOOOOO0O00OO .TransToInt (OOO0OOOOOOO0O00OO .fHL [7 ])#line:1820
    Sn_5Q :str =""#line:1821
    """五檔序號"""#line:1822
    def Get_Sn_5Q (O0O0OOO0O0O0OOOO0 )->int :#line:1824
        return O0O0OOO0O0O0OOOO0 .TransToInt (O0O0OOO0O0O0OOOO0 .fHL [8 ])#line:1825
    DealPriceOrg :str =""#line:1826
    """成交價"""#line:1827
    def Get_DealPrice2Str (OO0000O00O000OOOO )->str :#line:1828
        return OO0000O00O000OOOO .TransPrice2Str (OO0000O00O000OOOO .fHL [9 ])#line:1829
    def Get_DealPrice2Dec (OOOOOOO0OO00O0O0O )->decimal :#line:1830
        return OOOOOOO0OO00O0O0O .TransPrice2Dec (OOOOOOO0OO00O0O0O .fHL [9 ])#line:1831
    fDealPrice :decimal =0 #line:1833
    """成交價"""#line:1834
    def DealPrice (O0O0O00O0000O0000 )->decimal :#line:1836
        return O0O0O00O0000O0000 .fDealPrice #line:1837
    DealQty :str =""#line:1838
    """成交單量"""#line:1839
    def Get_DealQty2Dec (OO0O0OO00OOOO0O0O )->decimal :#line:1841
        return OO0O0OO00OOOO0O0O .TransToDecimal (OO0O0OO00OOOO0O0O .fHL [10 ])#line:1842
    def Get_DealQty2Int (OO00O00OO00OOOO00 )->int :#line:1844
        return OO00O00OO00OOOO00 .TransToInt (OO00O00OO00OOOO00 .fHL [10 ])#line:1845
    HighPriceOrg :str =""#line:1846
    """當日最高價"""#line:1847
    def Get_HighPrice2Str (OOO000O000000O0OO )->str :#line:1849
        return OOO000O000000O0OO .TransPrice2Str (OOO000O000000O0OO .fHL [11 ])#line:1850
    def Get_HighPrice2Dec (OOO00O000OO0O0O0O )->decimal :#line:1852
        return OOO00O000OO0O0O0O .TransPrice2Dec (OOO00O000OO0O0O0O .fHL [11 ])#line:1853
    LowPriceOrg :str =""#line:1854
    """當日最低價"""#line:1855
    def Get_LowPrice2Str (OOOO0O0000OO0OO00 )->str :#line:1857
        return OOOO0O0000OO0OO00 .TransPrice2Str (OOOO0O0000OO0OO00 .fHL [12 ])#line:1858
    def Get_LowPrice2Dec (O0O0OO0O00O0OO0OO )->decimal :#line:1860
        return O0O0OO0O00O0OO0OO .TransPrice2Dec (O0O0OO0O00O0OO0OO .fHL [12 ])#line:1861
    TotAmt :str =""#line:1862
    """成交總額"""#line:1863
    TotQty :str =""#line:1864
    """成交總量"""#line:1865
    def Get_TotQty2Dec (OO00OOO0OO0OO00OO )->decimal :#line:1867
        return OO00OOO0OO0OO00OO .TransToDecimal (OO00OOO0OO0OO00OO .fHL [14 ])#line:1868
    def Get_TotQty2Int (OOO0O00OOO0O00OOO )->int :#line:1870
        return OOO0O00OOO0O00OOO .TransToInt (OOO0O00OOO0O00OOO .fHL [14 ])#line:1871
    FirstDerivedBuyPriceOrg :str #line:1873
    "衍生委託單第一檔買進價格"#line:1874
    def Get_FirstDerivedBuyPrice (O0000O0O00OOO0OO0 ):#line:1875
        return O0000O0O00OOO0OO0 .TransPrice2Str (O0000O0O00OOO0OO0 .fHL [35 ])#line:1876
    FirstDerivedBuyQty :str #line:1877
    "衍生委託單第一檔買進價格數量"#line:1878
    FirstDerivedSellPriceOrg :str #line:1879
    "衍生委託單第一檔賣出價格數量"#line:1880
    def Get_FirstDerivedSellPrice (OOO0OO0000O00O0OO ):#line:1881
        return OOO0OO0000O00O0OO .TransPrice2Str (OOO0OO0000O00O0OO .fHL [37 ])#line:1882
    FirstDerivedSellQty :str #line:1883
    "衍生委託單第一檔賣出價格數量"#line:1884
    OpenPriceOrg :str =""#line:1886
    """開盤價"""#line:1887
    def Get_OpenPrice2Str (OOO0OO00O0O00OO00 ):#line:1888
        return OOO0OO00O0O00OO00 .TransPrice2Str (OOO0OO00O0O00OO00 .fHL [39 ])#line:1889
    def Get_OpenPrice2Dec (O0OO0000OO0OOOO00 ):#line:1890
        return O0OO0000OO0OOOO00 .TransPrice2Dec (O0OO0000OO0OOOO00 .fHL [39 ])#line:1891
    def Get_OpenPrice2Str (O0O0O00O0O00OO000 )->str :#line:1893
        return O0O0O00O0O00OO000 .TransPrice2Str (O0O0O00O0O00OO000 .fHL [39 ])#line:1894
    def Get_OpenPrice2Dec (OO0000OO0OO00O0O0 )->decimal :#line:1896
        return OO0000OO0OO00O0O0 .TransPrice2Dec (OO0000OO0OO00O0O0 .fHL [39 ])#line:1897
    TryMark_5Q :str =""#line:1899
    "五檔試撮註記(試撮=1, 非試撮=0)"#line:1900
    ClosePrice :str =""#line:1901
    "收盤價"#line:1902
    def Get_ClosePrice (OO0OOO0O000OO0OOO ):#line:1903
        return OO0OOO0O000OO0OOO .TransPrice2Str (OO0OOO0O000OO0OOO .fHL [41 ])#line:1904
    SettlePrice :str =""#line:1905
    "結算價<"#line:1906
    def Get_SettlePrice (O0O00OOO0OOOO00OO ):#line:1907
        return O0O00OOO0OOOO00OO .TransPrice2Str (O0O00OOO0OOOO00OO .fHL [42 ])#line:1908
    OpenInterest :str =""#line:1909
    "未平倉合約數"#line:1910
    fAryB5Q_P =[15 ,17 ,19 ,21 ,23 ]#line:1914
    """買五檔價在字串中的位置"""#line:1915
    fAryB5Q_Q =[16 ,18 ,20 ,22 ,24 ]#line:1916
    """買五檔價在字串中的位置"""#line:1917
    fB5QCount :int =5 #line:1918
    """買5檔的檔數"""#line:1919
    def B5Q_POrg (OO00OO000OOOO0O00 ,O000O0O00O0OO0OOO :int )->str :#line:1921
        ""#line:1922
        if O000O0O00O0OO0OOO >OO00OO000OOOO0O00 .fB5QCount :#line:1923
            return ""#line:1924
        else :#line:1925
            return OO00OO000OOOO0O00 .fHL [OO00OO000OOOO0O00 .fAryB5Q_P [O000O0O00O0OO0OOO -1 ]]#line:1926
    def Get_B5Q_P2Dec (O00OO0O0OOO0O0000 ,O0000000O00OOOO00 :int )->decimal :#line:1928
        ""#line:1929
        if O0000000O00OOOO00 >O00OO0O0OOO0O0000 .fB5QCount :#line:1930
            return 0 #line:1931
        else :#line:1932
            return O00OO0O0OOO0O0000 .TransPrice2Dec (O00OO0O0OOO0O0000 .fHL [O00OO0O0OOO0O0000 .fAryB5Q_P [O0000000O00OOOO00 -1 ]])#line:1933
    def Get_B5Q_P2Str (O000OO0O00O00OO00 ,O00O00000OO0OO0OO :int )->str :#line:1935
        ""#line:1936
        if O00O00000OO0OO0OO >O000OO0O00O00OO00 .fB5QCount :#line:1937
            return ""#line:1938
        else :#line:1939
            return O000OO0O00O00OO00 .TransPrice2Str (O000OO0O00O00OO00 .fHL [O000OO0O00O00OO00 .fAryB5Q_P [O00O00000OO0OO0OO -1 ]])#line:1940
    def B5Q_QOrg (O0000O0O0000OOOOO ,OO0OOO0O0OO00OO0O :int )->str :#line:1942
        ""#line:1943
        if OO0OOO0O0OO00OO0O >O0000O0O0000OOOOO .fB5QCount :#line:1944
            return ""#line:1945
        else :#line:1946
            return O0000O0O0000OOOOO .fHL [O0000O0O0000OOOOO .fAryB5Q_Q [OO0OOO0O0OO00OO0O -1 ]]#line:1947
    def Get_B5Q_Q (O0OOO0000OO00OOOO ,OOO0000O00O0000OO :int )->int :#line:1949
        ""#line:1950
        if OOO0000O00O0000OO >O0OOO0000OO00OOOO .fB5QCount :#line:1951
            return 0 #line:1952
        else :#line:1953
            return O0OOO0000OO00OOOO .TransToInt (O0OOO0000OO00OOOO .fHL [O0OOO0000OO00OOOO .fAryB5Q_Q [OOO0000O00O0000OO -1 ]])#line:1954
    fAryS5Q_P =[25 ,27 ,29 ,31 ,33 ]#line:1958
    """買五檔價在字串中的位置"""#line:1959
    fAryS5Q_Q =[26 ,28 ,30 ,32 ,34 ]#line:1960
    """買五檔價在字串中的位置"""#line:1961
    fS5QCount :int =5 #line:1962
    """賣5檔的檔數"""#line:1963
    def S5Q_POrg (O0O0000O0000000O0 ,O0000000OOO00OOO0 :int )->str :#line:1965
        ""#line:1966
        if O0000000OOO00OOO0 >O0O0000O0000000O0 .fS5QCount :#line:1967
            return ""#line:1968
        else :#line:1969
            return O0O0000O0000000O0 .fHL [O0O0000O0000000O0 .fAryS5Q_P [O0000000OOO00OOO0 -1 ]]#line:1970
    def Get_S5Q_P2Dec (O00000O00O00OO0OO ,OO0OO00O00000OOO0 :int )->decimal :#line:1972
        ""#line:1973
        if OO0OO00O00000OOO0 >O00000O00O00OO0OO .fS5QCount :#line:1974
            return 0 #line:1975
        else :#line:1976
            return O00000O00O00OO0OO .TransPrice2Dec (O00000O00O00OO0OO .fHL [O00000O00O00OO0OO .fAryS5Q_P [OO0OO00O00000OOO0 -1 ]])#line:1977
    def Get_S5Q_P2Str (OOO00O0O0O0OO0O0O ,O0OO000OOOOOOOO00 :int )->str :#line:1979
        ""#line:1980
        if O0OO000OOOOOOOO00 >OOO00O0O0O0OO0O0O .fS5QCount :#line:1981
            return ""#line:1982
        else :#line:1983
            return OOO00O0O0O0OO0O0O .TransPrice2Str (OOO00O0O0O0OO0O0O .fHL [OOO00O0O0O0OO0O0O .fAryS5Q_P [O0OO000OOOOOOOO00 -1 ]])#line:1984
    def S5Q_QOrg (OO00O00OO0O000OO0 ,OOO000O00O00O000O :int )->str :#line:1986
        ""#line:1987
        if OOO000O00O00O000O >OO00O00OO0O000OO0 .fS5QCount :#line:1988
            return ""#line:1989
        else :#line:1990
            return OO00O00OO0O000OO0 .fHL [OO00O00OO0O000OO0 .fAryS5Q_Q [OOO000O00O00O000O -1 ]]#line:1991
    def Get_S5Q_Q (OOO00000O000OOOOO ,O0OO0O00O00O0OO0O :int )->int :#line:1993
        ""#line:1994
        if O0OO0O00O00O0OO0O >OOO00000O000OOOOO .fS5QCount :#line:1995
            return 0 #line:1996
        else :#line:1997
            return OOO00000O000OOOOO .TransToInt (OOO00000O000OOOOO .fHL [OOO00000O000OOOOO .fAryS5Q_Q [O0OO0O00O00O0OO0O -1 ]])#line:1998
    def Handle_HL (OO0000O0000OO0OOO ,OO0OO0OOOOO0O0OOO :str ):#line:2001
        OO0000O0000OO0OOO .fHL =OO0OO0OOOOO0O0OOO .split ('|')#line:2002
        OO0000O0000OO0OOO .HasHL =len (OO0000O0000OO0OOO .fHL )>0 #line:2003
        OO0000O0000OO0OOO .Exchange =OO0000O0000OO0OOO .fHL [0 ]#line:2004
        OO0000O0000OO0OOO .Market =OO0000O0000OO0OOO .fHL [1 ]#line:2005
        OO0000O0000OO0OOO .Symbol =OO0000O0000OO0OOO .fHL [3 ]#line:2006
        OO0000O0000OO0OOO .TryMark_Deal =OO0000O0000OO0OOO .fHL [4 ]#line:2007
        OO0000O0000OO0OOO .TryMark =OO0000O0000OO0OOO .fHL [5 ]#line:2008
        OO0000O0000OO0OOO .DealTime =OO0000O0000OO0OOO .fHL [6 ]#line:2009
        OO0000O0000OO0OOO .DealSn =OO0000O0000OO0OOO .fHL [7 ]#line:2010
        OO0000O0000OO0OOO .Sn_5Q =OO0000O0000OO0OOO .fHL [8 ]#line:2011
        OO0000O0000OO0OOO .DealPriceOrg =OO0000O0000OO0OOO .fHL [9 ]#line:2012
        OO0000O0000OO0OOO .DealQty =OO0000O0000OO0OOO .fHL [10 ]#line:2013
        OO0000O0000OO0OOO .HighPriceOrg =OO0000O0000OO0OOO .fHL [11 ]#line:2014
        OO0000O0000OO0OOO .LowPriceOrg =OO0000O0000OO0OOO .fHL [12 ]#line:2015
        OO0000O0000OO0OOO .TotAmt =OO0000O0000OO0OOO .fHL [13 ]#line:2016
        OO0000O0000OO0OOO .TotQty =OO0000O0000OO0OOO .fHL [14 ]#line:2017
        OO0000O0000OO0OOO .FirstDerivedBuyPriceOrg =OO0000O0000OO0OOO .fHL [35 ]#line:2018
        OO0000O0000OO0OOO .FirstDerivedBuyQty =OO0000O0000OO0OOO .fHL [36 ]#line:2019
        OO0000O0000OO0OOO .FirstDerivedSellPriceOrg =OO0000O0000OO0OOO .fHL [37 ]#line:2020
        OO0000O0000OO0OOO .FirstDerivedSellQty =OO0000O0000OO0OOO .fHL [38 ]#line:2021
        OO0000O0000OO0OOO .OpenPriceOrg =OO0000O0000OO0OOO .fHL [39 ]#line:2022
        OO0000O0000OO0OOO .TryMark_5Q =OO0000O0000OO0OOO .fHL [40 ]#line:2023
        OO0000O0000OO0OOO .ClosePrice =OO0000O0000OO0OOO .fHL [41 ]#line:2024
        OO0000O0000OO0OOO .SettlePrice =OO0000O0000OO0OOO .fHL [42 ]#line:2025
        OO0000O0000OO0OOO .OpenInterest =OO0000O0000OO0OOO .fHL [43 ]#line:2026
        if OO0000O0000OO0OOO .HasHL :#line:2027
            OO0000O0000OO0OOO .TopicTX =f"Quote/TWF/{OO0000O0000OO0OOO.Market}/{OO0000O0000OO0OOO.Symbol}/TX"#line:2028
            OO0000O0000OO0OOO .Topic5Q =f"Quote/TWF/{OO0000O0000OO0OOO.Market}/{OO0000O0000OO0OOO.Symbol}/5Q"#line:2029
            OO0000O0000OO0OOO .Topic5QTOT =f"Quote/TWF/{OO0000O0000OO0OOO.Market}/{OO0000O0000OO0OOO.Symbol}/5QTOT"#line:2030
            OO0000O0000OO0OOO .TopicBAS =f"Quote/TWF/{OO0000O0000OO0OOO.Market}/{OO0000O0000OO0OOO.Symbol}/BAS"#line:2031
        OO0000O0000OO0OOO .fDealPrice =OO0000O0000OO0OOO .TransPrice2Dec (OO0000O0000OO0OOO .DealPriceOrg )#line:2033
    def TransPrice2Dec (OOO00OOOO0OO000O0 ,OOO00O000O00OOOO0 :str )->decimal :#line:2036
        try :#line:2037
            OOOOOO00OO0OO00O0 =Decimal (OOO00O000O00OOOO0 )#line:2038
            OOOOOO00OO0OO00O0 =OOOOOO00OO0OO00O0 *OOO00OOOO0OO000O0 .DECIMAL_LOCATOR_Dgt #line:2039
            return OOOOOO00OO0OO00O0 #line:2040
        except Exception as O0O00OO00OO0OOO0O :#line:2041
            return 0 #line:2042
    def TransPrice2Str (O0000O0O0OO0OO0OO ,O0OO000O0O000OOO0 :str )->str :#line:2044
        if O0000O0O0OO0OO0OO .DECIMAL_LOCATOR_Dgt ==1 :#line:2045
            return O0OO000O0O000OOO0 #line:2046
        if O0OO000O0O000OOO0 =="0":#line:2047
            return ""#line:2048
        if len (O0OO000O0O000OOO0 )<O0000O0O0OO0OO0OO .DECIMAL_LOCATOR_Org :#line:2049
            return O0OO000O0O000OOO0 #line:2050
        if not O0OO000O0O000OOO0 or O0OO000O0O000OOO0 .isspace ():#line:2051
            return ""#line:2052
        try :#line:2053
            OOO00O000O0O0OOO0 =len (O0OO000O0O000OOO0 )#line:2054
            return O0OO000O0O000OOO0 [:OOO00O000O0O0OOO0 -O0000O0O0OO0OO0OO .DECIMAL_LOCATOR_Org ]+'.'+O0OO000O0O000OOO0 [OOO00O000O0O0OOO0 -O0000O0O0OO0OO0OO .DECIMAL_LOCATOR_Org :]#line:2055
        except Exception as O0OOO0OO00000OO00 :#line:2056
            return ""#line:2057
    def TransToInt (O0OO00OO0000000OO ,OO00O00O00OO000OO :str )->int :#line:2059
        try :#line:2060
            return int (OO00O00O00OO000OO )#line:2061
        except Exception as O000OOOO00OOO00OO :#line:2062
            pass #line:2064
        return 0 #line:2065
    def TransToDecimal (O0000O0O0OOO0000O ,OO0000OO00OOOO0O0 :str )->decimal :#line:2067
        try :#line:2068
            return Decimal (OO0000OO00OOOO0O0 )#line:2069
        except Exception as OO0O0OO0O000OO0OO :#line:2070
            print (f"Not a Decimal{OO0O0OO0O000OO0OO}")#line:2071
        return 0 #line:2072
    def __init__ (O000O0OOOOOOO0000 )->None :#line:2075
        pass #line:2076
    def __str__ (O00O00O0OOO0000OO )->str :#line:2078
        return f"""Market:{O00O00O0OOO0000OO.Market} Symbol:{O00O00O0OOO0000OO.Symbol} TryMark:{O00O00O0OOO0000OO.TryMark} DealTime:{O00O00O0OOO0000OO.DealTime} DealSn:{O00O00O0OOO0000OO.DealSn}"""+"""Sn_5Q:{self.Sn_5Q} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty} HighPriceOrg:{self.HighPriceOrg} LowPriceOrg:{self.LowPriceOrg}"""+"""TotQty:{self.TotQty} OpenPriceOrg:{self.OpenPriceOrg}"""#line:2081
class TFutQtTX :#line:2082
    DECIMAL_LOCATOR_Org :int =0 #line:2084
    """價格欄位小數位數"""#line:2085
    DECIMAL_LOCATOR_Dgt :decimal =1 #line:2086
    """價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"""#line:2087
    fTX =[]#line:2088
    SystemTime :str #line:2090
    """系統時間(Epoch & Unix Timestamp(us))"""#line:2091
    DataTime :str #line:2092
    """資料時間(交易所給的)(EX:173547.32700)"""#line:2093
    DealSn :str #line:2094
    """成交序號"""#line:2095
    TryMark :str #line:2096
    """試撮註記(試撮=1, 非試撮=0)"""#line:2097
    DealTime :str #line:2098
    """撮合時間(成交)(EX:173547.32700)"""#line:2099
    DealShowMark :str #line:2100
    """成交資料揭示項目註記(*結算價此欄為空)"""#line:2101
    def Get_SystemTime (OOOOOOO0O00000000 )->int :#line:2102
        return OOOOOOO0O00000000 .TransToInt (OOOOOOO0O00000000 .fTX [1 ])#line:2103
    def Get_DealSn (OO0O0O000000O0O0O )->int :#line:2105
        return OO0O0O000000O0O0O .TransToInt (OO0O0O000000O0O0O .fTX [3 ])#line:2106
    TotQty :str #line:2107
    """成交總量"""#line:2108
    def Get_TotQty2Dec (O0O0O00O00O0O00O0 )->decimal :#line:2110
        return O0O0O00O00O0O00O0 .TransToDecimal (O0O0O00O00O0O00O0 .fTX [7 ])#line:2111
    def Get_TotQty2Int (OOO0O00OO000OO00O )->int :#line:2113
        return OOO0O00OO000OO00O .TransToInt (OOO0O00OO000OO00O .fTX [7 ])#line:2114
    SumBuyDealCount :str #line:2115
    """累計買進成交筆數"""#line:2116
    def Get_SumBuyDealCount (O0000OO0000OOOO0O )->int :#line:2118
        return O0000OO0000OOOO0O .TransToInt (O0000OO0000OOOO0O .fTX [8 ])#line:2119
    SumSellDealCount :str #line:2120
    """累計賣出成交筆數"""#line:2121
    def Get_SumSellDealCount (OOOOOOO00OO0O0O0O )->int :#line:2123
        return OOOOOOO00OO0O0O0O .TransToInt (OOOOOOO00OO0O0O0O .fTX [9 ])#line:2124
    DealCount :str #line:2125
    """成交價量檔數"""#line:2126
    def Get_DealCount (O0O0OO0O0OO0OOO0O )->int :#line:2128
        return O0O0OO0O0OO0OOO0O .TransToInt (O0O0OO0O0OO0OOO0O .fTX [11 ])#line:2129
    DealPriceOrg :str #line:2130
    """成交價"""#line:2131
    def Get_DealPrice2Dec (O00OOOO00O000O000 )->decimal :#line:2133
        return O00OOOO00O000O000 .TransPrice2Dec (O00OOOO00O000O000 .fTX [12 ])#line:2134
    def Get_DealPrice2Str (O0OO0000O0OOO0OO0 )->str :#line:2136
        return O0OO0000O0OOO0OO0 .TransPrice2Str (O0OO0000O0OOO0OO0 .fTX [12 ])#line:2137
    DealQty :str #line:2139
    """成交單量"""#line:2140
    def Get_DealQty2Dec (O00O00OOOOO0O0OO0 )->decimal :#line:2142
        return O00O00OOOOO0O0OO0 .TransToDecimal (O00O00OOOOO0O0OO0 .fTX [13 ])#line:2143
    def Get_DealQty2Int (O0OOO000O0OOOO000 )->int :#line:2145
        return O0OOO000O0OOOO000 .TransToInt (O0OOO000O0OOOO000 .fTX [13 ])#line:2146
    def Get_DealQty2IdxVal (O000O0O00OO00OO0O ,OO0O00O0OO00000O0 :int )->int :#line:2147
        return O000O0O00OO00OO0O .TransToInt (O000O0O00OO00OO0O .fTX [13 +(OO0O00O0OO00000O0 *2 )])#line:2148
    fDealPrice :decimal =0 #line:2152
    "成交價"#line:2153
    HighPrice :decimal =0 #line:2154
    "當日最高價"#line:2155
    LowPrice :decimal =0 #line:2156
    "當日最低價"#line:2157
    def CalcHightLowPrice (O0OO0O0OOOO000O0O ):#line:2159
        ""#line:2160
        try :#line:2161
            O0OO0O0OOOO000O0O .fDealPrice =O0OO0O0OOOO000O0O .Get_DealPrice ()#line:2162
            O0OO0O0OOOO000O0O .HighPrice =math .Max (O0OO0O0OOOO000O0O .fDealPrice ,O0OO0O0OOOO000O0O .HighPrice )#line:2163
            O0OO0O0OOOO000O0O .LowPrice =O0OO0O0OOOO000O0O .fDealPrice if O0OO0O0OOOO000O0O .LowPrice ==0 else math .Min (O0OO0O0OOOO000O0O .fDealPrice ,O0OO0O0OOOO000O0O .LowPrice )#line:2165
        except Exception as OO0OO0O0O00OO00OO :#line:2166
            pass #line:2167
    def CalcHightLowPrice_None (O00O0OOOO0OO00O00 ):#line:2169
        pass #line:2170
    fPROC_CalcHightLowPrice :callable =None #line:2172
    "PROC_CalcHightLowPrice"#line:2173
    def SetData (OO0O0O00O000O000O ):#line:2176
        OO0O0O00O000O000O .SystemTime =OO0O0O00O000O000O .fTX [1 ]#line:2177
        OO0O0O00O000O000O .DataTime =OO0O0O00O000O000O .fTX [2 ]#line:2178
        OO0O0O00O000O000O .DealSn =OO0O0O00O000O000O .fTX [3 ]#line:2179
        OO0O0O00O000O000O .TryMark ="1"if OO0O0O00O000O000O .fTX [4 ]is None else OO0O0O00O000O000O .fTX [4 ]#line:2180
        OO0O0O00O000O000O .DealTime =OO0O0O00O000O000O .fTX [5 ]#line:2181
        OO0O0O00O000O000O .DealShowMark =OO0O0O00O000O000O .fTX [6 ]#line:2182
        OO0O0O00O000O000O .TotQty =OO0O0O00O000O000O .fTX [7 ]#line:2183
        OO0O0O00O000O000O .SumBuyDealCount =OO0O0O00O000O000O .fTX [8 ]#line:2184
        OO0O0O00O000O000O .SumSellDealCount =OO0O0O00O000O000O .fTX [9 ]#line:2185
        OO0O0O00O000O000O .DealCount =OO0O0O00O000O000O .fTX [11 ]#line:2186
        OO0O0O00O000O000O .DealPriceOrg =OO0O0O00O000O000O .fTX [12 ]#line:2187
        OO0O0O00O000O000O .DealQty =OO0O0O00O000O000O .fTX [13 ]#line:2188
    def Handle_TXRcv (OO0O0O0O0OOO0OO00 ,O00O0000OO00O0OOO :str ):#line:2190
        try :#line:2191
            OOOO0000O0OO0O0OO :int =0 #line:2192
            O0O00OO00000O0OOO :int =0 #line:2193
            O0OOO00O0OOOO0O00 =O00O0000OO00O0OOO .split ('|')#line:2194
            if O0OOO00O0OOOO0O00 [4 ]==TSolQuoteFutSet .TryMark_No :#line:2196
                OO0O0O0O0OOO0OO00 .fPROC_HandleData =OO0O0O0O0OOO0OO00 .HandleData #line:2197
                if OO0O0O0O0OOO0OO00 .fTX ==None :#line:2199
                    OO0O0O0O0OOO0OO00 .fTX =O0OOO00O0OOOO0O00 #line:2200
                    OO0O0O0O0OOO0OO00 .SetData ()#line:2201
                else :#line:2202
                    O0O00OO00000O0OOO =OO0O0O0O0OOO0OO00 .TransToInt (O0OOO00O0OOOO0O00 [3 ])#line:2203
                    OOOO0000O0OO0O0OO =OO0O0O0O0OOO0OO00 .Get_DealSn ()#line:2204
                    if O0O00OO00000O0OOO >OOOO0000O0OO0O0OO :#line:2205
                        OO0O0O0O0OOO0OO00 .fTX =O0OOO00O0OOOO0O00 #line:2206
                        OO0O0O0O0OOO0OO00 .SetData ()#line:2207
                OO0O0O0O0OOO0OO00 .fPROC_CalcHightLowPrice ()#line:2208
            else :#line:2209
                OO0O0O0O0OOO0OO00 .fPROC_HandleData =OO0O0O0O0OOO0OO00 .HandleData_TryMarket #line:2210
                OO0O0O0O0OOO0OO00 .fPROC_HandleData (O00O0000OO00O0OOO )#line:2211
        except Exception as O0OO0000O00O00OOO :#line:2213
            pass #line:2214
    def Handle_TX (OOO0OOOO0OOO0OOO0 ,OOOOO0O0O00O0OO0O :str ):#line:2216
        OOO0OOOO0OOO0OOO0 .fPROC_HandleData (OOOOO0O0O00O0OO0O )#line:2217
    def HandleData_TryMarket (OO0OO0OOO000O0O00 ,OO00O00O00O00OOO0 :str ):#line:2220
        ""#line:2221
        if OO00O00O00O00OOO0 .split ('|')[4 ]==TSolQuoteFutSet .TryMark_No :#line:2222
            OO0OO0OOO000O0O00 .fPROC_HandleData =OO0OO0OOO000O0O00 .HandleData #line:2223
            OO0OO0OOO000O0O00 .fPROC_HandleData (OO00O00O00O00OOO0 )#line:2224
        else :#line:2225
            OO0OO0OOO000O0O00 .fTX =OO00O00O00O00OOO0 .split ('|')#line:2226
            OO0OO0OOO000O0O00 .SetData ()#line:2227
    def HandleData (O0OO000OO0O0O0OOO ,O0O0O00O000OO0000 :str ):#line:2229
        ""#line:2230
        O0OO000OO0O0O0OOO .fTX =O0O0O00O000OO0000 .split ('|')#line:2231
        O0OO000OO0O0O0OOO .SetData ()#line:2232
        O0OO000OO0O0O0OOO .fPROC_CalcHightLowPrice ()#line:2233
    fPROC_HandleData :callable =None #line:2235
    "PROC_HandleData"#line:2236
    def TransPrice2Dec (O0OO00OOOO00OOOOO ,OOO00O00OOOOO0O0O :str )->decimal :#line:2240
        try :#line:2241
            O00O0OOOOOOOOOOOO =Decimal (OOO00O00OOOOO0O0O )#line:2242
            O00O0OOOOOOOOOOOO =O00O0OOOOOOOOOOOO *O0OO00OOOO00OOOOO .DECIMAL_LOCATOR_Dgt #line:2243
            return O00O0OOOOOOOOOOOO #line:2244
        except Exception as O0O0OO00O0OOO0OO0 :#line:2245
            return 0 #line:2246
    def TransPrice2Str (OOO0OOOO00OO000OO ,OO0OOO0OOO000OO00 :str )->str :#line:2248
        if OOO0OOOO00OO000OO .DECIMAL_LOCATOR_Dgt ==1 :#line:2249
            return OO0OOO0OOO000OO00 #line:2250
        if OO0OOO0OOO000OO00 =="0":#line:2251
            return ""#line:2252
        if len (OO0OOO0OOO000OO00 )<OOO0OOOO00OO000OO .DECIMAL_LOCATOR_Org :#line:2253
            return OO0OOO0OOO000OO00 #line:2254
        if not OO0OOO0OOO000OO00 or OO0OOO0OOO000OO00 .isspace ():#line:2255
            return ""#line:2256
        try :#line:2257
            OO0O0O0OO000OOOOO =len (OO0OOO0OOO000OO00 )#line:2258
            return OO0OOO0OOO000OO00 [:OO0O0O0OO000OOOOO -OOO0OOOO00OO000OO .DECIMAL_LOCATOR_Org ]+'.'+OO0OOO0OOO000OO00 [OO0O0O0OO000OOOOO -OOO0OOOO00OO000OO .DECIMAL_LOCATOR_Org :]#line:2259
        except Exception as O000O0OO0O0OOO0O0 :#line:2260
            return ""#line:2261
    def TransToInt (OO00000000OO0O00O ,OOOO0O0O0O0OO0000 :str )->int :#line:2263
        try :#line:2264
            return int (OOOO0O0O0O0OO0000 )#line:2265
        except Exception as O0OO000000OO000O0 :#line:2266
            pass #line:2268
        return 0 #line:2269
    def TransToDecimal (O000O000O0OOO0O0O ,O0OOOOO00O00O000O :str )->decimal :#line:2271
        try :#line:2272
            return Decimal (O0OOOOO00O00O000O )#line:2273
        except Exception as OO00OOOO0OOOOOO0O :#line:2274
            print (f"Not a Decimal{OO00OOOO0OOOOOO0O}")#line:2275
        return 0 #line:2276
    def __init__ (OO0O0OOOO000O000O ,O00O0O0OO0OOOO000 :bool )->None :#line:2279
        OO0O0OOOO000O000O .fPROC_CalcHightLowPrice =OO0O0OOOO000O000O .CalcHightLowPrice_None #line:2281
        if O00O0O0OO0OOOO000 :#line:2282
            OO0O0OOOO000O000O .fPROC_CalcHightLowPrice =OO0O0OOOO000O000O .CalcHightLowPrice #line:2283
        OO0O0OOOO000O000O .fPROC_HandleData =OO0O0OOOO000O000O .HandleData_TryMarket #line:2285
    def __str__ (O00O00000OOO00OOO ):#line:2287
        return f"""DataTime:{O00O00000OOO00OOO.DataTime} TryMark:{O00O00000OOO00OOO.TryMark} DealTime:{O00O00000OOO00OOO.DealTime} DealSn:{O00O00000OOO00OOO.DealSn}"""+"""TotQty:{self.TotQty} SumBuyDealCount:{self.SumBuyDealCount} SumSellDealCount:{self.SumSellDealCount}"""+"""DealCount:{self.DealCount} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty} fDealPrice:{self.fDealPrice}"""+"""HighPrice:{self.HighPrice} LowPrice:{self.LowPrice} \n"""#line:2291
class TFutQt5Q :#line:2292
    DECIMAL_LOCATOR_Org :int =0 #line:2294
    "價格欄位小數位數"#line:2295
    DECIMAL_LOCATOR_Dgt :decimal =1 #line:2296
    "價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"#line:2297
    f5Q =[]#line:2298
    SystemTime :str #line:2300
    """系統時間(Epoch & Unix Timestamp(us))"""#line:2301
    DataTime :str #line:2302
    "資料時間(交易所給的)(EX:173547.32700)"#line:2303
    Sn :str #line:2304
    "序號"#line:2305
    def Get_SystemTime (OO0O0OOO0O0OOO0OO )->int :#line:2306
        return OO0O0OOO0O0OOO0OO .TransToInt (OO0O0OOO0O0OOO0OO .f5Q [1 ])#line:2307
    def Get_Sn (OOOOO0OOO0OOOO000 )->int :#line:2308
        return OOOOO0OOO0OOOO000 .TransToInt (OOOOO0OOO0OOOO000 .f5Q [3 ])#line:2309
    TryMark :str #line:2310
    "試撮註記(試撮=1, 非試撮=0)"#line:2311
    FirstDerivedBuyPriceOrg :str #line:2313
    "衍生委託單第一檔買進價格"#line:2314
    def Get_FirstDerivedBuyPrice (O0O00OOO0OO0O00OO ):#line:2315
        return O0O00OOO0OO0O00OO .TransPrice2Dec (O0O00OOO0OO0O00OO .f5Q [25 ])#line:2316
    FirstDerivedBuyQty :str #line:2317
    "衍生委託單第一檔買進價格數量"#line:2318
    FirstDerivedSellPriceOrg :str #line:2319
    "衍生委託單第一檔賣出價格數量"#line:2320
    def Get_FirstDerivedSellPrice (O0O00OO0O000OO000 ):#line:2321
        return O0O00OO0O000OO000 .TransPrice2Str (O0O00OO0O000OO000 .f5Q [27 ])#line:2322
    FirstDerivedSellQty :str #line:2323
    "衍生委託單第一檔賣出價格數量"#line:2324
    def Handle_5Q (OOOOO000O0OOO0O00 ,O00O0O00OOO000OOO :str ):#line:2325
        OOOOO000O0OOO0O00 .fPROC_HandleData (O00O0O00OOO000OOO )#line:2326
    def HandleData_TryMarket (OOOO0OO00O0O0OOOO ,O000O0OOO0O0OOO0O :str ):#line:2329
        ""#line:2330
        if O000O0OOO0O0OOO0O .split ('|')[4 ]==TSolQuoteFutSet .TryMark_No :#line:2331
            OOOO0OO00O0O0OOOO .fPROC_HandleData =OOOO0OO00O0O0OOOO .HandleData #line:2332
            OOOO0OO00O0O0OOOO .fPROC_HandleData (O000O0OOO0O0OOO0O )#line:2333
        else :#line:2334
            OOOO0OO00O0O0OOOO .f5Q =O000O0OOO0O0OOO0O .split ('|')#line:2335
            OOOO0OO00O0O0OOOO .SetData ()#line:2336
    def HandleData (OO00O0O000O0O0000 ,OO0OO00OOO0000000 :str ):#line:2338
        ""#line:2339
        OO00O0O000O0O0000 .f5Q =OO0OO00OOO0000000 .split ('|')#line:2340
        OO00O0O000O0O0000 .SetData ()#line:2341
    def SetData (OOOOOOOO0O00OO0OO ):#line:2343
        OOOOOOOO0O00OO0OO .DataTime =OOOOOOOO0O00OO0OO .f5Q [2 ]#line:2344
        OOOOOOOO0O00OO0OO .Sn =OOOOOOOO0O00OO0OO .f5Q [3 ]#line:2345
        OOOOOOOO0O00OO0OO .TryMark ="1"if OOOOOOOO0O00OO0OO .f5Q is None else OOOOOOOO0O00OO0OO .f5Q [4 ]#line:2346
        OOOOOOOO0O00OO0OO .FirstDerivedBuyPriceOrg =OOOOOOOO0O00OO0OO .f5Q [25 ]#line:2347
        OOOOOOOO0O00OO0OO .FirstDerivedBuyQty =OOOOOOOO0O00OO0OO .f5Q [26 ]#line:2348
        OOOOOOOO0O00OO0OO .FirstDerivedSellPriceOrg =OOOOOOOO0O00OO0OO .f5Q [27 ]#line:2349
        OOOOOOOO0O00OO0OO .FirstDerivedSellQty =OOOOOOOO0O00OO0OO .f5Q [28 ]#line:2350
    fPROC_HandleData :callable =None #line:2352
    "PROC_HandleData"#line:2353
    fAryB5Q_P =[5 ,7 ,9 ,11 ,13 ]#line:2357
    "買五檔價在字串中的位置"#line:2358
    fAryB5Q_Q =[6 ,8 ,10 ,12 ,14 ]#line:2359
    "買五檔價在字串中的位置"#line:2360
    fB5QCount :int =5 #line:2361
    "買5檔的檔數"#line:2362
    def B5Q_POrg (O00O00OO00O00000O ,O0OOO000OO0000OOO :int )->str :#line:2364
        ""#line:2365
        if O0OOO000OO0000OOO >O00O00OO00O00000O .fB5QCount :#line:2366
            return ""#line:2367
        elif O00O00OO00O00000O .f5Q is None :#line:2368
            return ""#line:2369
        else :#line:2370
            return O00O00OO00O00000O .f5Q [O00O00OO00O00000O .fAryB5Q_P [O0OOO000OO0000OOO -1 ]]#line:2371
    def Get_B5Q_P2Dec (OO0OO0OOO00O0O000 ,OOOOOOO00O000000O :int )->decimal :#line:2373
        ""#line:2374
        if OOOOOOO00O000000O >OO0OO0OOO00O0O000 .fB5QCount :#line:2375
            return 0 #line:2376
        elif OO0OO0OOO00O0O000 .f5Q is None :#line:2377
            return 0 #line:2378
        else :#line:2379
            return OO0OO0OOO00O0O000 .TransPrice2Dec (OO0OO0OOO00O0O000 .f5Q [OO0OO0OOO00O0O000 .fAryB5Q_P [OOOOOOO00O000000O -1 ]])#line:2380
    def Get_B5Q_P2Str (O0OO000000O0OOO00 ,OO00O00O00OO0000O :int )->str :#line:2382
        ""#line:2383
        if OO00O00O00OO0000O >O0OO000000O0OOO00 .fB5QCount :#line:2384
            return ""#line:2385
        elif O0OO000000O0OOO00 .f5Q is None :#line:2386
            return ""#line:2387
        else :#line:2388
            return O0OO000000O0OOO00 .TransPrice2Str (O0OO000000O0OOO00 .f5Q [O0OO000000O0OOO00 .fAryB5Q_P [OO00O00O00OO0000O -1 ]])#line:2389
    def B5Q_QOrg (OO0O0O00000O0OO0O ,O0O0OO0000000000O :int )->str :#line:2391
        ""#line:2392
        if O0O0OO0000000000O >OO0O0O00000O0OO0O .fB5QCount :#line:2394
            return ""#line:2395
        elif OO0O0O00000O0OO0O .f5Q is None :#line:2396
            return ""#line:2397
        else :#line:2398
            return OO0O0O00000O0OO0O .f5Q [OO0O0O00000O0OO0O .fAryB5Q_Q [O0O0OO0000000000O -1 ]]#line:2399
    def Get_B5Q_Q (OO00OO0O00OOO0O00 ,OO00000O0O00000OO :int )->int :#line:2401
        ""#line:2402
        if OO00000O0O00000OO >OO00OO0O00OOO0O00 .fB5QCount :#line:2403
            return 0 #line:2404
        elif OO00OO0O00OOO0O00 .f5Q is None :#line:2405
            return 0 #line:2406
        else :#line:2407
            return OO00OO0O00OOO0O00 .TransToInt (OO00OO0O00OOO0O00 .f5Q [OO00OO0O00OOO0O00 .fAryB5Q_Q [OO00000O0O00000OO -1 ]])#line:2408
    fAryS5Q_P =[15 ,17 ,19 ,21 ,23 ]#line:2413
    "買五檔價在字串中的位置"#line:2414
    fAryS5Q_Q =[16 ,18 ,20 ,22 ,24 ]#line:2415
    "買五檔價在字串中的位置"#line:2416
    fS5QCount :int =5 #line:2417
    "賣5檔的檔數"#line:2418
    def S5Q_POrg (OOOO0O0OOOO0OOO00 ,O0OO0OO0O0O0000O0 :int )->str :#line:2420
        ""#line:2421
        if O0OO0OO0O0O0000O0 >OOOO0O0OOOO0OOO00 .fS5QCount :#line:2422
            return ""#line:2423
        elif OOOO0O0OOOO0OOO00 .f5Q is None :#line:2424
            return ""#line:2425
        else :#line:2426
            return OOOO0O0OOOO0OOO00 .f5Q [OOOO0O0OOOO0OOO00 .fAryS5Q_P [O0OO0OO0O0O0000O0 -1 ]]#line:2427
    def Get_S5Q_P2Dec (OOO0O0OO0O000O000 ,O0OO0O00OO0000O00 :int )->decimal :#line:2429
        ""#line:2430
        if O0OO0O00OO0000O00 >OOO0O0OO0O000O000 .fS5QCount :#line:2431
            return 0 #line:2432
        elif OOO0O0OO0O000O000 .f5Q is None :#line:2433
            return 0 #line:2434
        else :#line:2435
            return OOO0O0OO0O000O000 .TransPrice2Dec (OOO0O0OO0O000O000 .f5Q [OOO0O0OO0O000O000 .fAryS5Q_P [O0OO0O00OO0000O00 -1 ]])#line:2436
    def Get_S5Q_P2Str (O000O000OO0O0O0O0 ,OO0000O00O00O00OO :int )->str :#line:2438
        ""#line:2439
        if OO0000O00O00O00OO >O000O000OO0O0O0O0 .fS5QCount :#line:2440
            return ""#line:2441
        elif O000O000OO0O0O0O0 .f5Q is None :#line:2442
            return ""#line:2443
        else :#line:2444
            return O000O000OO0O0O0O0 .TransPrice2Str (O000O000OO0O0O0O0 .f5Q [O000O000OO0O0O0O0 .fAryS5Q_P [OO0000O00O00O00OO -1 ]])#line:2445
    def S5Q_QOrg (OO0OO0OO000OO0O0O ,O0000O0OOOOOOOOOO :int )->str :#line:2447
        ""#line:2448
        if O0000O0OOOOOOOOOO >OO0OO0OO000OO0O0O .fS5QCount :#line:2449
            return ""#line:2450
        elif OO0OO0OO000OO0O0O .f5Q is None :#line:2451
            return ""#line:2452
        else :#line:2453
            return OO0OO0OO000OO0O0O .f5Q [OO0OO0OO000OO0O0O .fAryS5Q_Q [O0000O0OOOOOOOOOO -1 ]]#line:2454
    def Get_S5Q_Q (OO000OOO0OOOOO0OO ,OO0OO00O0OOOOOO0O :int )->int :#line:2456
        ""#line:2457
        if OO0OO00O0OOOOOO0O >OO000OOO0OOOOO0OO .fS5QCount :#line:2458
            return 0 #line:2459
        elif OO000OOO0OOOOO0OO .f5Q is None :#line:2460
            return 0 #line:2461
        else :#line:2462
            return OO000OOO0OOOOO0OO .TransToInt (OO000OOO0OOOOO0OO .f5Q [OO000OOO0OOOOO0OO .fAryS5Q_Q [OO0OO00O0OOOOOO0O -1 ]])#line:2463
    def TransPrice2Dec (O000000OO000OO0O0 ,OOO0O0OOOOOOOO000 :str )->decimal :#line:2468
        try :#line:2469
            OO0O0O000OOO0O00O =Decimal (OOO0O0OOOOOOOO000 )#line:2470
            OO0O0O000OOO0O00O =OO0O0O000OOO0O00O *O000000OO000OO0O0 .DECIMAL_LOCATOR_Dgt #line:2471
            return OO0O0O000OOO0O00O #line:2472
        except Exception as OO0OOO00O00O00OO0 :#line:2473
            return 0 #line:2474
    def TransPrice2Str (OOOO00O0O0OOOOO0O ,O0OOOOOO0O00O0000 :str )->str :#line:2476
        if OOOO00O0O0OOOOO0O .DECIMAL_LOCATOR_Dgt ==1 :#line:2477
            return O0OOOOOO0O00O0000 #line:2478
        if O0OOOOOO0O00O0000 =="0":#line:2479
            return ""#line:2480
        if len (O0OOOOOO0O00O0000 )<OOOO00O0O0OOOOO0O .DECIMAL_LOCATOR_Org :#line:2481
            return O0OOOOOO0O00O0000 #line:2482
        if not O0OOOOOO0O00O0000 or O0OOOOOO0O00O0000 .isspace ():#line:2483
            return ""#line:2484
        try :#line:2485
            OO0O00OO0000OOO00 =len (O0OOOOOO0O00O0000 )#line:2486
            return O0OOOOOO0O00O0000 [:OO0O00OO0000OOO00 -OOOO00O0O0OOOOO0O .DECIMAL_LOCATOR_Org ]+'.'+O0OOOOOO0O00O0000 [OO0O00OO0000OOO00 -OOOO00O0O0OOOOO0O .DECIMAL_LOCATOR_Org :]#line:2487
        except Exception as OOO0O0OOO0O000OO0 :#line:2488
            return ""#line:2489
    def TransToInt (O00O0000OOOO00OO0 ,O0O000OO0O0OO00OO :str )->int :#line:2491
        try :#line:2492
            return int (O0O000OO0O0OO00OO )#line:2493
        except Exception as OOO0OO0OOO0000000 :#line:2494
            pass #line:2496
        return 0 #line:2497
    def TransToDecimal (O000OOO0000O0OO0O ,OO0O0OO0OO0O0OO00 :str )->decimal :#line:2499
        try :#line:2500
            return Decimal (OO0O0OO0OO0O0OO00 )#line:2501
        except Exception as OO0O0O000O000000O :#line:2502
            print (f"Not a Decimal{OO0O0O000O000000O}")#line:2503
        return 0 #line:2504
    def __init__ (O0OOO0OO000OO00OO )->None :#line:2507
        O0OOO0OO000OO00OO .fPROC_HandleData =O0OOO0OO000OO00OO .HandleData_TryMarket #line:2509
    def __str__ (OOO0O0OO00O0O0OOO ):#line:2511
        return f"""DataTime:{OOO0O0OO00O0O0OOO.DataTime} Sn:{OOO0O0OO00O0O0OOO.Sn} TryMark:{OOO0O0OO00O0O0OOO.TryMark} f5Q:{OOO0O0OO00O0O0OOO.f5Q}"""#line:2512
class TFutQt5QTOT :#line:2513
    f5QTOT =[]#line:2514
    DataTime :str #line:2516
    "資料時間(交易所給的)(EX:173547.32700)"#line:2517
    Sn :str #line:2518
    "序號"#line:2519
    def Get_Sn (O00OO0O000OO0O0O0 )->int :#line:2521
        return O00OO0O000OO0O0O0 .TransToInt (O00OO0O000OO0O0O0 .f5QTOT [3 ])#line:2522
    SumBuyOrderCount :str #line:2523
    "買進累計委託筆數"#line:2524
    def Get_SumBuyOrderCount (O0O0OOO0O0OO0O0O0 )->int :#line:2526
        return O0O0OOO0O0OO0O0O0 .TransToInt (O0O0OOO0O0OO0O0O0 .f5QTOT [4 ])#line:2527
    SumBuyOrderQty :str #line:2528
    "買進累計委託合約數"#line:2529
    def Get_SumBuyOrderQty (OO00OO00OO0OOO000 )->int :#line:2531
        return OO00OO00OO0OOO000 .TransToInt (OO00OO00OO0OOO000 .f5QTOT [5 ])#line:2532
    SumSellOrderCount :str #line:2533
    "賣出累計委託筆數"#line:2534
    def Get_SumSellOrderCount (OO0000OOOOOO00OO0 )->int :#line:2536
        return OO0000OOOOOO00OO0 .TransToInt (OO0000OOOOOO00OO0 .f5QTOT [6 ])#line:2537
    SumSellOrderQty :str #line:2538
    "賣出累計委託合約數"#line:2539
    def Get_SumSellOrderQty (O0O0OOOOOO00OOOOO )->int :#line:2541
        return O0O0OOOOOO00OOOOO .TransToInt (O0O0OOOOOO00OOOOO .f5QTOT [7 ])#line:2542
    def Handle_5QTOT (O000OO0O00OO0OOO0 ,O00O000O0OOO0O0OO :str ):#line:2544
        O000OO0O00OO0OOO0 .f5QTOT =O00O000O0OOO0O0OO .split ('|')#line:2545
        O000OO0O00OO0OOO0 .DataTime =O000OO0O00OO0OOO0 .f5QTOT [2 ]#line:2547
        O000OO0O00OO0OOO0 .Sn =O000OO0O00OO0OOO0 .f5QTOT [3 ]#line:2548
        O000OO0O00OO0OOO0 .SumBuyOrderCount =O000OO0O00OO0OOO0 .f5QTOT [4 ]#line:2549
        O000OO0O00OO0OOO0 .SumBuyOrderQty =O000OO0O00OO0OOO0 .f5QTOT [5 ]#line:2550
        O000OO0O00OO0OOO0 .SumSellOrderCount =O000OO0O00OO0OOO0 .f5QTOT [6 ]#line:2551
        O000OO0O00OO0OOO0 .SumSellOrderQty =O000OO0O00OO0OOO0 .f5QTOT [7 ]#line:2552
    def TransToInt (O00OO000O000OOO00 ,O00O0000OO0O0OOO0 :str )->int :#line:2555
        try :#line:2556
            return int (O00O0000OO0O0OOO0 )#line:2557
        except Exception as O0O0OO00OO0O0O00O :#line:2558
            return 0 #line:2559
    def TransToDecimal (O0OO000OO00OO0OO0 ,O00O0OO0OO0O00OOO :str )->decimal :#line:2561
        try :#line:2562
            return Decimal (O00O0OO0OO0O00OOO )#line:2563
        except Exception as O0OO0OOO00OOO0O00 :#line:2564
            return 0 #line:2565
    def __init__ (OOO0O00OOOO0000O0 )->None :#line:2568
        pass #line:2569
    def __str__ (O00000O00OO0OO0OO )->str :#line:2571
        return f"""DataTime:{O00000O00OO0OO0OO.DataTime} Sn:{O00000O00OO0OO0OO.Sn} SumBuyOrderCount:{O00000O00OO0OO0OO.SumBuyOrderCount} SumBuyOrderQty:{O00000O00OO0OO0OO.SumBuyOrderQty}"""+"""SumSellOrderCount:{self.SumSellOrderCount} SumSellOrderQty:{self.SumSellOrderQty}"""#line:2573
class TFutQtIDX :#line:2574
    fIsGotDgtVal :bool =False #line:2575
    fDECIMAL_LOCATOR_Org :int =0 #line:2576
    "指數小數位數"#line:2577
    fDECIMAL_LOCATOR_Dgt :decimal =1 #line:2578
    "指數小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"#line:2579
    fIdx =[]#line:2580
    DataTime :str #line:2583
    "資料時間(交易所給的)(EX:173547.32700)"#line:2584
    Sn :str #line:2585
    "序號"#line:2586
    def Get_Sn (OO0O00O0O0O000OOO )->int :#line:2588
        return OO0O00O0O0O000OOO .TransToInt (OO0O00O0O0O000OOO .fIdx [3 ])#line:2589
    TryMark :str #line:2590
    "試撮註記(試撮=1, 非試撮=0)"#line:2591
    DealTime :str #line:2592
    "指數編篡時間(EX:173547.32700)"#line:2593
    IdxDgtOrg :str #line:2594
    "指數小數位數"#line:2595
    def Get_IdxDgtOrg (OO00OOO0O000OOOO0 )->int :#line:2597
        return OO00OOO0O000OOOO0 .TransToInt (OO00OOO0O000OOOO0 .fIdx [7 ])#line:2598
    IdxValueOrg :str #line:2599
    "指數"#line:2600
    def Get_IdxValue2Dec (O0O000000OOOOO0OO )->decimal :#line:2602
        return O0O000000OOOOO0OO .TransPrice2Dec (O0O000000OOOOO0OO .fIdx [6 ])#line:2603
    def Get_IdxValue2Str (OO0O0O000OO000O0O )->str :#line:2605
        return OO0O0O000OO000O0O .TransPrice2Str (OO0O0O000OO000O0O .fIdx [6 ])#line:2606
    HighIdxValueOrg :str #line:2607
    "當日最高指數"#line:2608
    def Get_HighIdxValue2Dec (OOO0O0OO0OO0OOOOO )->decimal :#line:2610
        return OOO0O0OO0OO0OOOOO .TransPrice2Dec (OOO0O0OO0OO0OOOOO .fIdx [8 ])#line:2611
    def Get_HighIdxValue2Str (OO0OOO0O00O00000O )->str :#line:2613
        return OO0OOO0O00O00000O .TransPrice2Str (OO0OOO0O00O00000O .fIdx [8 ])#line:2614
    LowIdxValueOrg :str #line:2616
    "當日最低指數"#line:2617
    def Get_LowIdxValue2Dec (OOO00OO0O00OO0O0O )->decimal :#line:2619
        return OOO00OO0O00OO0O0O .TransPrice2Dec (OOO00OO0O00OO0O0O .fIdx [9 ])#line:2620
    def Get_LowIdxValue2Str (O0OOO000O0O00O000 )->str :#line:2622
        return O0OOO000O0O00O000 .TransPrice2Str (O0OOO000O0O00O000 .fIdx [9 ])#line:2623
    OpenIdxValueOrg :str #line:2625
    "開盤指數"#line:2626
    def Get_OpenIdxValue2Dec (O0OO000O00OO00OO0 )->decimal :#line:2628
        return O0OO000O00OO00OO0 .TransPrice2Dec (O0OO000O00OO00OO0 .fIdx [10 ])#line:2629
    def Get_OpenIdxValue2Str (OO000O000OO00000O )->str :#line:2631
        return OO000O000OO00000O .TransPrice2Str (OO000O000OO00000O .fIdx [10 ])#line:2632
    def Handle_IDX (OOO0OOOOOO00OO000 ,O000OOOO00O000OO0 :str ):#line:2635
        OOO0OOOOOO00OO000 .fIdx =O000OOOO00O000OO0 .split ('|')#line:2636
        OOO0OOOOOO00OO000 .DataTime =OOO0OOOOOO00OO000 .fIdx [2 ]#line:2638
        OOO0OOOOOO00OO000 .Sn =OOO0OOOOOO00OO000 .fIdx [3 ]#line:2639
        OOO0OOOOOO00OO000 .TryMark =OOO0OOOOOO00OO000 .fIdx [4 ]#line:2640
        OOO0OOOOOO00OO000 .DealTime =OOO0OOOOOO00OO000 .fIdx [5 ]#line:2641
        OOO0OOOOOO00OO000 .IdxValueOrg =OOO0OOOOOO00OO000 .fIdx [6 ]#line:2642
        OOO0OOOOOO00OO000 .IdxDgtOrg =OOO0OOOOOO00OO000 .fIdx [7 ]#line:2643
        OOO0OOOOOO00OO000 .HighIdxValueOrg =OOO0OOOOOO00OO000 .fIdx [8 ]#line:2644
        OOO0OOOOOO00OO000 .LowIdxValueOrg =OOO0OOOOOO00OO000 .fIdx [9 ]#line:2645
        OOO0OOOOOO00OO000 .OpenIdxValueOrg =OOO0OOOOOO00OO000 .fIdx [10 ]#line:2646
        if OOO0OOOOOO00OO000 .fIsGotDgtVal ==False :#line:2649
            OOO0OOOOOO00OO000 .fDECIMAL_LOCATOR_Org =OOO0OOOOOO00OO000 .Get_IdxDgtOrg ()#line:2651
            if OOO0OOOOOO00OO000 .fDECIMAL_LOCATOR_Org ==0 :#line:2652
                OOO0OOOOOO00OO000 .fDECIMAL_LOCATOR_Dgt =1 #line:2653
            else :#line:2654
                OOO0OOOOOO00OO000 .fDECIMAL_LOCATOR_Dgt =1 /Decimal ("1".ljust (OOO0OOOOOO00OO000 .fDECIMAL_LOCATOR_Dgt +1 ,'0'))#line:2656
            OOO0OOOOOO00OO000 .fIsGotDgtVal =True #line:2658
    def TransPrice2Dec (O000OO0OOOO0O0000 ,O0OOO0OOO00000OOO :str )->decimal :#line:2661
        try :#line:2662
            O0OOOO0O0OOOOOO0O =Decimal (O0OOO0OOO00000OOO )#line:2663
            O0OOOO0O0OOOOOO0O =O0OOOO0O0OOOOOO0O *O000OO0OOOO0O0000 .DECIMAL_LOCATOR_Dgt #line:2664
            return O0OOOO0O0OOOOOO0O #line:2665
        except Exception as OO0000OO000OO0OOO :#line:2666
            print (f"Not a Decimal{OO0000OO000OO0OOO}")#line:2667
            return 0 #line:2668
    def TransPrice2Str (O0O0000O0OOO0O00O ,O00OOO0O0OOO0OO00 :str )->str :#line:2670
        if O0O0000O0OOO0O00O .DECIMAL_LOCATOR_Dgt ==1 :#line:2671
            return O00OOO0O0OOO0OO00 #line:2672
        if O00OOO0O0OOO0OO00 =="0":#line:2673
            return ""#line:2674
        if len (O00OOO0O0OOO0OO00 )<O0O0000O0OOO0O00O .DECIMAL_LOCATOR_Org :#line:2675
            return O00OOO0O0OOO0OO00 #line:2676
        if not O00OOO0O0OOO0OO00 or O00OOO0O0OOO0OO00 .isspace ():#line:2677
            return ""#line:2678
        try :#line:2679
            O0O000O0OOOOO0OO0 =len (O00OOO0O0OOO0OO00 )#line:2680
            return O00OOO0O0OOO0OO00 [:O0O000O0OOOOO0OO0 -O0O0000O0OOO0O00O .DECIMAL_LOCATOR_Org ]+'.'+O00OOO0O0OOO0OO00 [O0O000O0OOOOO0OO0 -O0O0000O0OOO0O00O .DECIMAL_LOCATOR_Org :]#line:2681
        except Exception as OO0O0O0OO0OO0000O :#line:2682
            return ""#line:2683
    def TransToInt (O000O0OOOO00000O0 ,OOOO0OO0O0000OOO0 :str )->int :#line:2685
        try :#line:2686
            return int (OOOO0OO0O0000OOO0 )#line:2687
        except Exception as O000OO0O0OO00OOO0 :#line:2688
            pass #line:2690
        return 0 #line:2691
    def TransToDecimal (OO00OOOO0O0O0OO00 ,OO0O0O0O0O0O0O0OO :str )->decimal :#line:2693
        try :#line:2694
            return Decimal (OO0O0O0O0O0O0O0OO )#line:2695
        except Exception as O000O000OO00OO0O0 :#line:2696
            print (f"Not a Decimal{O000O000OO00OO0O0}")#line:2697
        return 0 #line:2698
    def __init__ (OOOOO000OO00O0O0O )->None :#line:2701
        pass #line:2702
    def __str__ (O0O0OOOOO00OO0OOO )->str :#line:2704
        return f"""DataTime:{O0O0OOOOO00OO0OOO.DataTime} Sn:{O0O0OOOOO00OO0OOO.Sn} TryMark:{O0O0OOOOO00OO0OOO.TryMark} DealTime:{O0O0OOOOO00OO0OOO.DealTime} IdxValueOrg:{O0O0OOOOO00OO0OOO.IdxValueOrg}"""+"""IdxDgtOrg:{self.IdxDgtOrg} HighIdxValueOrg:{self.HighIdxValueOrg} LowIdxValueOrg:{self.LowIdxValueOrg} OpenIdxValueOrg:{self.OpenIdxValueOrg}"""#line:2706
class TFutQuoteData :#line:2707
    SolIce =""#line:2708
    ProdKind :TFutProdKind =TFutProdKind .pkNone #line:2709
    BAS :TFutQtBase =None #line:2710
    HL :TFutQtHL =None #line:2711
    QtTX :TFutQtTX =None #line:2712
    Qt5Q :TFutQt5Q =None #line:2713
    Qt5QTOT :TFutQt5QTOT =None #line:2714
    QtIDX :TFutQtIDX =None #line:2715
    def __init__ (O0O000O00O0O0O000 ,O0O0O0000OOO0OO00 :TFutProdKind ,OO00O0OOOOO00OO0O :str ,O000O000O0O00O0OO :bool ):#line:2717
        ""#line:2718
        O0O000O00O0O0O000 .SolIce =OO00O0OOOOO00OO0O #line:2720
        O0O000O00O0O0O000 .ProdKind =O0O0O0000OOO0OO00 #line:2721
        O0O000O00O0O0O000 ._lock =Lock ()#line:2722
        O0O000O00O0O0O000 .UpdateBAS =True #line:2723
        O0O000O00O0O0O000 .UpdateHL =False #line:2724
        if O0O0O0000OOO0OO00 ==TFutProdKind .pkNormal :#line:2725
            O0O000O00O0O0O000 .BAS =TFutQtBase ()#line:2726
            O0O000O00O0O0O000 .HL =TFutQtHL ()#line:2727
            O0O000O00O0O0O000 .QtTX =TFutQtTX (O000O000O0O00O0OO )#line:2728
            O0O000O00O0O0O000 .Qt5Q =TFutQt5Q ()#line:2729
            O0O000O00O0O0O000 .Qt5QTOT =TFutQt5QTOT ()#line:2730
        elif O0O0O0000OOO0OO00 ==TFutProdKind .pkIndex :#line:2732
            O0O000O00O0O0O000 .QtIDX =TFutQtIDX ()#line:2733
    def SetDataInit (OOOO0OO0000000OO0 ,type :str =""):#line:2735
        ""#line:2736
        if OOOO0OO0000000OO0 .ProdKind ==TFutProdKind .pkNormal :#line:2737
            if type =="BAS"or type =="":#line:2738
                OOOO0OO0000000OO0 .HL .DECIMAL_LOCATOR_Dgt =OOOO0OO0000000OO0 .BAS .DECIMAL_LOCATOR_Dgt #line:2739
                OOOO0OO0000000OO0 .QtTX .DECIMAL_LOCATOR_Dgt =OOOO0OO0000000OO0 .BAS .DECIMAL_LOCATOR_Dgt #line:2740
                OOOO0OO0000000OO0 .Qt5Q .DECIMAL_LOCATOR_Dgt =OOOO0OO0000000OO0 .BAS .DECIMAL_LOCATOR_Dgt #line:2741
                OOOO0OO0000000OO0 .HL .DECIMAL_LOCATOR_Org =OOOO0OO0000000OO0 .BAS .DECIMAL_LOCATOR_Org #line:2743
                OOOO0OO0000000OO0 .QtTX .DECIMAL_LOCATOR_Org =OOOO0OO0000000OO0 .BAS .DECIMAL_LOCATOR_Org #line:2744
                OOOO0OO0000000OO0 .Qt5Q .DECIMAL_LOCATOR_Org =OOOO0OO0000000OO0 .BAS .DECIMAL_LOCATOR_Org #line:2745
            if type =="HL"or type =="":#line:2746
                OOOO0OO0000000OO0 .QtTX .HighPrice =OOOO0OO0000000OO0 .HL .Get_HighPrice2Dec ()#line:2747
                OOOO0OO0000000OO0 .QtTX .LowPrice =OOOO0OO0000000OO0 .HL .Get_LowPrice2Dec ()#line:2748
class TObjFutQuoteMap (UserDict ):#line:2750
    ""#line:2752
    DefProc_TX :callable =None #line:2756
    DefProc_5Q :callable =None #line:2757
    DefProc_Idx :callable =None #line:2758
    DefProc_5QTOT :callable =None #line:2759
    DefProc_BAS :callable =None #line:2760
    def __init__ (OO00OO0OOOOOO0O0O ,mapping =None ,**OO000O0O0O0O0OOOO ):#line:2761
        if mapping is not None :#line:2762
            mapping ={str (OOO00O0OO0000O000 ).upper ():OO00O00O0O000OOO0 for OOO00O0OO0000O000 ,OO00O00O0O000OOO0 in mapping .items ()}#line:2765
        else :#line:2766
            mapping ={}#line:2767
        if OO000O0O0O0O0OOOO :#line:2768
            mapping .update ({str (O0O000OO0000000O0 ).upper ():OOOOO000O0000OOOO for O0O000OO0000000O0 ,OOOOO000O0000OOOO in OO000O0O0O0O0OOOO .items ()})#line:2771
        OO00OO0OOOOOO0O0O .MapQtProc ={}#line:2773
        "各商品拆解行情proc(EX:TXF的TX與5Q, 行情拆解,是不同Proc)"#line:2774
        super ().__init__ (mapping )#line:2775
    def __setitem__ (O0000OOOOO00O00O0 ,OO0O0OO0O0O0O0000 ,O00O00O0OO00OOO00 ):#line:2777
        super ().__setitem__ (OO0O0OO0O0O0O0000 ,O00O00O0OO00OOO00 )#line:2778
    def AddRcvData (O0O0OO000OOOOOO0O ,O0O0OOOOO00000O0O :str ,OOOO0OOO0O000000O :str ,OOO0O0OOO0OO0OOOO :bool ):#line:2780
        ""#line:2784
        OOOO0OOO0OO0OOO0O =""#line:2785
        OO000OOO0OO0OO0OO :TFutQuoteData =None #line:2786
        try :#line:2787
            O0O000OO00OO00OO0 =json .loads (OOOO0OOO0O000000O )#line:2788
            if "status"in O0O000OO00OO00OO0 and len (O0O000OO00OO00OO0 ["status"])>0 :#line:2790
                if O0O000OO00OO00OO0 ["status"][0 ]=="error":#line:2791
                    OOOO0OOO0OO0OOO0O =f"[期][AddRcvData](aSolIce={O0O0OOOOO00000O0O}, aData={OOOO0OOO0O000000O})行情回補資料有誤!"#line:2792
                    return False ,OO000OOO0OO0OO0OO ,OOOO0OOO0OO0OOO0O #line:2793
            if "BAS"in O0O000OO00OO00OO0 and len (O0O000OO00OO00OO0 ["BAS"])==0 :#line:2794
                OOOO0OOO0OO0OOO0O =f"[期][AddRcvData](aSolIce={O0O0OOOOO00000O0O}, aData={OOOO0OOO0O000000O})沒有BAS資料!"#line:2795
                return False ,OO000OOO0OO0OO0OO ,OOOO0OOO0OO0OOO0O #line:2796
            if "HL"in O0O000OO00OO00OO0 and len (O0O000OO00OO00OO0 ["HL"])==0 :#line:2797
                OOOO0OOO0OO0OOO0O =f"[期][AddRcvData](aSolIce={O0O0OOOOO00000O0O}, aData={OOOO0OOO0O000000O})沒有HL資料!"#line:2798
                return False ,OO000OOO0OO0OO0OO ,OOOO0OOO0OO0OOO0O #line:2799
            if O0O0OO000OOOOOO0O .data .get (O0O0OOOOO00000O0O )is None :#line:2802
                OOOOO000OOO0O0000 =TFutQuoteData (TFutProdKind .pkNormal ,O0O0OOOOO00000O0O ,OOO0O0OOO0OO0OOOO )#line:2804
                OOOOO000OOO0O0000 .BAS .Handle_BAS (O0O000OO00OO00OO0 ["BAS"][0 ])#line:2805
                OOOOO000OOO0O0000 .HL .Handle_HL (O0O000OO00OO00OO0 ["HL"][0 ])#line:2806
                OOOOO000OOO0O0000 .SetDataInit ()#line:2807
                OO000OOO0OO0OO0OO =OOOOO000OOO0O0000 #line:2808
                O0O0OO000OOOOOO0O [O0O0OOOOO00000O0O ]=OOOOO000OOO0O0000 #line:2809
                return True ,OO000OOO0OO0OO0OO ,""#line:2810
            else :#line:2811
                OOOOO000OOO0O0000 :TFutQuoteData =O0O0OO000OOOOOO0O [O0O0OOOOO00000O0O ]#line:2812
                with OOOOO000OOO0O0000 ._lock :#line:2813
                    OOOOO000OOO0O0000 .BAS .Handle_BAS (O0O000OO00OO00OO0 ["BAS"][0 ])#line:2814
                    OOOOO000OOO0O0000 .HL .Handle_HL (O0O000OO00OO00OO0 ["HL"][0 ])#line:2815
                    OOOOO000OOO0O0000 .SetDataInit ()#line:2816
                    OO000OOO0OO0OO0OO =OOOOO000OOO0O0000 #line:2817
                return True ,OO000OOO0OO0OO0OO ,""#line:2818
        except Exception as OOO00OOO0O0000OOO :#line:2819
            OOOO0OOO0OO0OOO0O =f"[期][AddRcvData](aSolIce={O0O0OOOOO00000O0O}, aData={OOOO0OOO0O000000O}){OOO00OOO0O0000OOO}"#line:2820
        return False ,OO000OOO0OO0OO0OO ,OOOO0OOO0OO0OOO0O #line:2821
    def AddData (OO00000OO00OO0OOO ,OOO0O0OOO000O0000 :TFutProdKind ,O0OOOO00O00O00O00 :str ,O00OOOOOOO000OOOO :bool ,OOOOO0O0O00OO0OO0 :str ,OO0O000OO0O0O00OO :callable ):#line:2823
        ""#line:2826
        try :#line:2827
            if OO00000OO00OO0OOO .data .get (O0OOOO00O00O00O00 )is None :#line:2828
                O0O0OO0OO000O0O0O =TFutQuoteData (OOO0O0OOO000O0000 ,O0OOOO00O00O00O00 ,O00OOOOOOO000OOOO )#line:2829
                OO00000OO00OO0OOO [OOOOO0O0O00OO0OO0 ]=O0O0OO0OO000O0O0O #line:2830
                if OO00000OO00OO0OOO .MapQtProc .get (OOOOO0O0O00OO0OO0 )is None :#line:2832
                    OO00000OO00OO0OOO .MapQtProc [OOOOO0O0O00OO0OO0 ]=OO0O000OO0O0O00OO #line:2833
                return True #line:2835
            else :#line:2836
                return True #line:2837
        except Exception as OOOO00O0O00O00OO0 :#line:2838
            pass #line:2839
        return False #line:2840
    def AddDataBySolIce (O00O0000OOOO0O000 ,OO0O000OO0O0OOOOO :bool ,OO0OO000O0000000O :str ,OO000OO0OO0O00O0O ,O00OOOO000O0OOOOO :bool ,topic :str =""):#line:2842
        ""#line:2848
        O0O000O0O00O0O0OO =""#line:2849
        try :#line:2850
            OO0O0O0O0OO0OOO00 :TObjFutQuoteMap =TObjFutQuoteMap ()#line:2852
            if OO000OO0OO0O00O0O .get ("BAS")is not None :#line:2853
                for OOOOO00000OOO00OO in OO000OO0OO0O00O0O ["BAS"]:#line:2854
                    O00OOO000OO0O000O :TFutQtBase =TFutQtBase (topic )#line:2855
                    O00OOO000OO0O000O .Handle_BAS (OOOOO00000OOO00OO )#line:2856
                    if OO0O0O0O0OO0OOO00 .data .get (O00OOO000OO0O000O .OrdProdID )is None :#line:2857
                        O00OOOOOOO00OOOOO =TFutQuoteData (TFutProdKind .pkNormal ,O00OOO000OO0O000O .OrdProdID ,O00OOOO000O0OOOOO )#line:2858
                        O00OOOOOOO00OOOOO .BAS =O00OOO000OO0O000O #line:2859
                        O00OOOOOOO00OOOOO .UpdateHL =False #line:2860
                        O00OOOOOOO00OOOOO .SetDataInit ("BAS")#line:2861
                        OO0O0O0O0OO0OOO00 [O00OOO000OO0O000O .OrdProdID ]=O00OOOOOOO00OOOOO #line:2862
                    if topic !="":#line:2863
                        O0O0OO0O0OOOOOOO0 :OO000OOO0OO00O000 =O00OOOOOOO00OOOOO .BAS .TopicTX #line:2864
                        OOO0O0OO000O0O00O :OO000OOO0OO00O000 =O00OOOOOOO00OOOOO .BAS .Topic5Q #line:2865
                        OOO0O00O000O0OO00 :OO000OOO0OO00O000 =O00OOOOOOO00OOOOO .BAS .Topic5QTOT #line:2866
                        OO0O0O0O0OO00OOO0 :OO000OOO0OO00O000 =O00OOOOOOO00OOOOO .BAS .TopicBAS #line:2867
                        O00O0000OOOO0O000 [O0O0OO0O0OOOOOOO0 ]=O00OOOOOOO00OOOOO #line:2868
                        O00O0000OOOO0O000 [OOO0O0OO000O0O00O ]=O00OOOOOOO00OOOOO #line:2869
                        O00O0000OOOO0O000 [OOO0O00O000O0OO00 ]=O00OOOOOOO00OOOOO #line:2870
                        O00O0000OOOO0O000 [OO0O0O0O0OO00OOO0 ]=O00OOOOOOO00OOOOO #line:2871
                        if O00O0000OOOO0O000 .MapQtProc .get (O0O0OO0O0OOOOOOO0 )is None :#line:2872
                            O00O0000OOOO0O000 .MapQtProc [O0O0OO0O0OOOOOOO0 ]=O00O0000OOOO0O000 .DefProc_TX #line:2873
                        if O00O0000OOOO0O000 .MapQtProc .get (OOO0O0OO000O0O00O )is None :#line:2874
                            O00O0000OOOO0O000 .MapQtProc [OOO0O0OO000O0O00O ]=O00O0000OOOO0O000 .DefProc_5Q #line:2875
                        if O00O0000OOOO0O000 .MapQtProc .get (OOO0O00O000O0OO00 )is None :#line:2876
                            O00O0000OOOO0O000 .MapQtProc [OOO0O00O000O0OO00 ]=O00O0000OOOO0O000 .DefProc_5QTOT #line:2877
                        if O00O0000OOOO0O000 .MapQtProc .get (OO0O0O0O0OO00OOO0 )is None :#line:2878
                            O00O0000OOOO0O000 .MapQtProc [OO0O0O0O0OO00OOO0 ]=O00O0000OOOO0O000 .DefProc_BAS #line:2879
            if OO000OO0OO0O00O0O .get ("HL")is not None :#line:2882
                for OO000OOO0OO00O000 in OO000OO0OO0O00O0O ["HL"]:#line:2883
                    OOO0O0000O0OO0O00 =TFutQtHL ()#line:2884
                    OOO0O0000O0OO0O00 .Handle_HL (OO000OOO0OO00O000 )#line:2885
                    if OO0O0O0O0OO0OOO00 .data .get (OOO0O0000O0OO0O00 .Symbol ):#line:2886
                        O00OOOOOOO00OOOOO :TFutQuoteData =OO0O0O0O0OO0OOO00 [OOO0O0000O0OO0O00 .Symbol ]#line:2887
                        O00OOOOOOO00OOOOO .UpdateHL =True #line:2888
                        O00OOOOOOO00OOOOO .HL =OOO0O0000O0OO0O00 #line:2889
                        O00OOOOOOO00OOOOO .SetDataInit ()#line:2890
                    if topic =="":#line:2891
                        O0O0OO0O0OOOOOOO0 :OO000OOO0OO00O000 =OOO0O0000O0OO0O00 .TopicTX #line:2892
                        OOO0O0OO000O0O00O :OO000OOO0OO00O000 =OOO0O0000O0OO0O00 .Topic5Q #line:2893
                        OOO0O00O000O0OO00 :OO000OOO0OO00O000 =OOO0O0000O0OO0O00 .Topic5QTOT #line:2894
                        OO0O0O0O0OO00OOO0 :OO000OOO0OO00O000 =OOO0O0000O0OO0O00 .TopicBAS #line:2895
                        O00O0000OOOO0O000 [O0O0OO0O0OOOOOOO0 ]=O00OOOOOOO00OOOOO #line:2896
                        O00O0000OOOO0O000 [OOO0O0OO000O0O00O ]=O00OOOOOOO00OOOOO #line:2897
                        O00O0000OOOO0O000 [OOO0O00O000O0OO00 ]=O00OOOOOOO00OOOOO #line:2898
                        O00O0000OOOO0O000 [OO0O0O0O0OO00OOO0 ]=O00OOOOOOO00OOOOO #line:2899
                        if O00O0000OOOO0O000 .MapQtProc .get (O0O0OO0O0OOOOOOO0 )is None :#line:2900
                            O00O0000OOOO0O000 .MapQtProc [O0O0OO0O0OOOOOOO0 ]=O00O0000OOOO0O000 .DefProc_TX #line:2901
                        if O00O0000OOOO0O000 .MapQtProc .get (OOO0O0OO000O0O00O )is None :#line:2902
                            O00O0000OOOO0O000 .MapQtProc [OOO0O0OO000O0O00O ]=O00O0000OOOO0O000 .DefProc_5Q #line:2903
                        if O00O0000OOOO0O000 .MapQtProc .get (OOO0O00O000O0OO00 )is None :#line:2904
                            O00O0000OOOO0O000 .MapQtProc [OOO0O00O000O0OO00 ]=O00O0000OOOO0O000 .DefProc_5QTOT #line:2905
                        if O00O0000OOOO0O000 .MapQtProc .get (OO0O0O0O0OO00OOO0 )is None :#line:2906
                            O00O0000OOOO0O000 .MapQtProc [OO0O0O0O0OO00OOO0 ]=O00O0000OOOO0O000 .DefProc_BAS #line:2907
            return len (OO0O0O0O0OO0OOO00 )>0 ,OO0O0O0O0OO0OOO00 ,O0O000O0O00O0O0OO #line:2910
        except Exception as O00O0OOOO0OOOOOO0 :#line:2911
            O0O000O0O00O0O0OO =f"[期][AddDataBySolIce](aIsCat={OO0O000OO0O0OOOOO}, aSolIce={OO0OO000O0000000O}){O00O0OOOO0OOOOOO0}"#line:2912
        return False ,OO0O0O0O0OO0OOO00 ,O0O000O0O00O0O0OO #line:2913
    def GetItem_BySolIce (O0OO00000OOOOO0OO ,O000O0OO0000O0O00 :str ):#line:2916
        ""#line:2919
        O00OOO000OOO00OOO =""#line:2920
        O00O0OO000O0O0000 =None #line:2921
        try :#line:2922
            O0OO00OOO00O00000 =[]#line:2923
            for O0O0O0OOO0O000O00 ,O0O000000OO0O00OO in O0OO00000OOOOO0OO .items ():#line:2924
                O000O0O00O00OOOO0 :TFutQuoteData #line:2925
                O000O0O00O00OOOO0 =O0O000000OO0O00OO #line:2926
                if (O000O0O00O00OOOO0 .SolIce ==O000O0OO0000O0O00 ):#line:2927
                    O0OO00OOO00O00000 .append (O0O0O0OOO0O000O00 )#line:2928
            O00O0OO000O0O0000 =O0OO00OOO00O00000 #line:2929
            if O00O0OO000O0O0000 is None or len (O00O0OO000O0O0000 )==0 :#line:2930
                O00OOO000OOO00OOO =f"[期][GetItem_BySolIce](aSolIce={O000O0OO0000O0O00})商品已不存存!"#line:2931
                return False ,O00O0OO000O0O0000 ,O00OOO000OOO00OOO #line:2932
            else :#line:2933
                return True ,O00O0OO000O0O0000 ,""#line:2934
        except Exception as OOOO0OOO00OOO000O :#line:2935
            O00OOO000OOO00OOO =f"[期][GetItem_BySolIce](aSolIce={O000O0OO0000O0O00}){OOOO0OOO00OOO000O}"#line:2936
        return False ,O00O0OO000O0O0000 ,O00OOO000OOO00OOO #line:2937
    def GetItem_ByCategory (OOOOOO00000OO0OOO ,O00O0OO0OO00OO0OO :str ):#line:2939
        ""#line:2942
        O00OOOO0O000OOO00 :str =""#line:2943
        OO0OO00OO0OO000O0 =None #line:2944
        try :#line:2945
            OOO0O0O0OO00O0OOO =[]#line:2946
            for O0OOOOOOOO000O0OO ,OO0O00OO0OOOO0000 in OOOOOO00000OO0OOO .items ():#line:2947
                O000OO00OOO0OOOOO :TFutQuoteData =OO0O00OO0OOOO0000 #line:2948
                OOOOOO0O0O00OOO00 =O0OOOOOOOO000O0OO .split ('/')#line:2949
                if OOOOOO0O0O00OOO00 [2 ]==O00O0OO0OO00OO0OO :#line:2950
                    OOO0O0O0OO00O0OOO .append (O0OOOOOOOO000O0OO )#line:2951
            OO0OO00OO0OO000O0 =OOO0O0O0OO00O0OOO #line:2952
            if OO0OO00OO0OO000O0 is None or len (OO0OO00OO0OO000O0 )==0 :#line:2953
                O00OOOO0O000OOO00 =f"期][GetItem_ByCategory](aCat={O00O0OO0OO00OO0OO})商品已不存存!"#line:2954
                return False ,OO0OO00OO0OO000O0 ,O00OOOO0O000OOO00 #line:2955
            else :#line:2956
                return True ,OO0OO00OO0OO000O0 ,""#line:2957
        except Exception as O0O00O00O0OO00OO0 :#line:2958
            O00OOOO0O000OOO00 =f"[期][GetItem_ByCategory](aCat={O00O0OO0OO00OO0OO}){O0O00O00O0OO00OO0}"#line:2959
        return False ,OO0OO00OO0OO000O0 ,O00OOOO0O000OOO00 #line:2960
class TObjBaseFutMap (UserDict ):#line:2963
    ""#line:2965
    def __init__ (OOOOOO0OOO00O0O00 ,mapping =None ,**OOOO00O0OO000O000 ):#line:2968
        if mapping is not None :#line:2969
            mapping ={str (O0O00O00000OOOOOO ).upper ():OO00O0OOO0000O0O0 for O0O00O00000OOOOOO ,OO00O0OOO0000O0O0 in mapping .items ()}#line:2972
        else :#line:2973
            mapping ={}#line:2974
        if OOOO00O0OO000O000 :#line:2975
            mapping .update ({str (O0O0OOO0000000O00 ).upper ():O00OOO000OOO0O00O for O0O0OOO0000000O00 ,O00OOO000OOO0O00O in OOOO00O0OO000O000 .items ()})#line:2978
        OOOOOO0OOO00O0O00 .fSortMap ={}#line:2980
        "<ProdID, <交割月, TFutQtBase>>"#line:2981
        super ().__init__ (mapping )#line:2982
    def __setitem__ (O000O0O0OO00000OO ,OO00OOOOOOOO0OOO0 ,OOOOOOO00O00O0O0O ):#line:2984
        super ().__setitem__ (OO00OOOOOOOO0OOO0 ,OOOOOOO00O00O0O0O )#line:2985
    def AddItem_ByStkNo (O0O000O00O00O0O0O ,OO00O000OOOO00OO0 :TFutQtBase ):#line:2987
        try :#line:2988
            if O0O000O00O00O0O0O .fSortMap .get (OO00O000OOOO00OO0 .StkNo )is None :#line:2989
                OOOOO0O0000O00O0O ={OO00O000OOOO00OO0 .SettleMth :OO00O000OOOO00OO0 }#line:2990
                O0O000O00O00O0O0O .fSortMap [OO00O000OOOO00OO0 .StkNo ]=OOOOO0O0000O00O0O #line:2991
            else :#line:2992
                OOOO0O0O0OO000O00 =O0O000O00O00O0O0O .fSortMap [OO00O000OOOO00OO0 .StkNo ]#line:2993
                OOOO0O0O0OO000O00 [OO00O000OOOO00OO0 .SettleMth ]=OO00O000OOOO00OO0 #line:2994
                O000OOOO0OOOOO0OO =sorted (OOOO0O0O0OO000O00 .items ())#line:2995
                O0OOOOO0O000OO0OO =dict (O000OOOO0OOOOO0OO )#line:2996
                O0O000O00O00O0O0O .fSortMap [OO00O000OOOO00OO0 .StkNo ]=O0OOOOO0O000OO0OO #line:2997
        except Exception as OOO000OOOOOO0OOO0 :#line:2998
            pass #line:2999
    def AddItem_ByProdID (O0O00O000OO00O0O0 ,O00O0OO0O000O000O :TFutQtBase ):#line:3001
        try :#line:3002
            if O0O00O000OO00O0O0 .fSortMap .get (O00O0OO0O000O000O .ProdID )is None :#line:3003
                OO00O0OO000OO00O0 ={O00O0OO0O000O000O .SettleMth :O00O0OO0O000O000O }#line:3004
                O0O00O000OO00O0O0 .fSortMap [O00O0OO0O000O000O .ProdID ]=OO00O0OO000OO00O0 #line:3005
            else :#line:3006
                OOO0OOO00OO00O0OO =O0O00O000OO00O0O0 .fSortMap [O00O0OO0O000O000O .ProdID ]#line:3007
                OOO0OOO00OO00O0OO [O00O0OO0O000O000O .SettleMth ]=O00O0OO0O000O000O #line:3008
                OO00OOOOOO000000O =sorted (OOO0OOO00OO00O0OO .items ())#line:3009
                O00000OO00O000000 =dict (OO00OOOOOO000000O )#line:3010
                O0O00O000OO00O0O0 .fSortMap [O00O0OO0O000O000O .ProdID ]=O00000OO00O000000 #line:3011
        except Exception as O00O000OOOOO0000O :#line:3012
            pass #line:3013
    def ReAddAll (O0OOOO000OO0O00OO ):#line:3015
        if O0OOOO000OO0O00OO .fSortMap .keys ()is None :#line:3016
            return #line:3017
        for OOO00O0O00O0O0OO0 in O0OOOO000OO0O00OO .fSortMap .keys ():#line:3019
            O00O000OOO000OOO0 =TObjBaseFutList ()#line:3020
            [O00O000OOO000OOO0 .append (O0OOOO000OO0O00OO .fSortMap [OOO00O0O00O0O0OO0 ][O0O0OOO0O00O000OO ])for O0O0OOO0O00O000OO in O0OOOO000OO0O00OO .fSortMap [OOO00O0O00O0O0OO0 ]]#line:3021
            O0OOOO000OO0O00OO [OOO00O0O00O0O0OO0 ]=O00O000OOO000OOO0 #line:3022
class TObjBaseFutList (list ):#line:3024
    ""#line:3025
    pass #line:3026
class TObjFutComList (UserDict ):#line:3027
    ""#line:3029
    def __init__ (OOO0OO00O00OOO0OO ,mapping =None ,**OOOO0OOO0O000O000 ):#line:3031
        if mapping is not None :#line:3032
            mapping ={str (O00O00O0O00000OOO ).upper ():O0O0OO000OO000OOO for O00O00O0O00000OOO ,O0O0OO000OO000OOO in mapping .items ()}#line:3035
        else :#line:3036
            mapping ={}#line:3037
        if OOOO0OOO0O000O000 :#line:3038
            mapping .update ({str (O00OO0OOOO000OO0O ).upper ():O0O0OO0OOO0O0O0O0 for O00OO0OOOO000OO0O ,O0O0OO0OOO0O0O0O0 in OOOO0OOO0O000O000 .items ()})#line:3041
        super ().__init__ (mapping )#line:3042
    def __setitem__ (O0O00OOO0000OOOOO ,OO00OOO0O000OO00O ,OOOOOO0000OOOO00O ):#line:3044
        super ().__setitem__ (OO00OOO0O000OO00O ,OOOOOO0000OOOO00O )#line:3045
    def AddItem (O0O0OOOO00OOOOOO0 ,OO000O00000000000 :str ):#line:3047
        try :#line:3048
            OO00O00OO0OO0OOO0 =TFutCom ()#line:3049
            OO00O00OO0OO0OOO0 .SolIce =OO000O00000000000 #line:3050
            OO00O00OO0OO0OOO0 .Leg1_SolIce =OO000O00000000000 .split ('^')[0 ]#line:3051
            OO00O00OO0OO0OOO0 .Leg2_SolIce =OO00O00OO0OO0OOO0 .Leg1_SolIce [:len (OO00O00OO0OO0OOO0 .Leg1_SolIce )-2 ]+OO000O00000000000 .split ('^')[1 ]#line:3053
            O0O0OOOO00OOOOOO0 [OO000O00000000000 ]=OO00O00OO0OO0OOO0 #line:3054
            O0O0OOOO00OOOOOO0 .data =dict (sorted (O0O0OOOO00OOOOOO0 .data .items ()))#line:3055
        except Exception as O0OOO0O0OO0000000 :#line:3056
            pass #line:3057
class TFutCom :#line:3059
    SolIce :str #line:3060
    "CDFL2^C3"#line:3061
    Leg1_SolIce :str #line:3062
    "CDFL2"#line:3063
    Leg2_SolIce :str #line:3064
    "CDFC3"#line:3065
class TObjBaseOptMap (UserDict ):#line:3070
    ""#line:3072
    def __init__ (OO0O00O0O0000OOOO ,mapping =None ,**OO00O000OO0O0O000 ):#line:3074
        if mapping is not None :#line:3075
            mapping ={str (OO000OO0OO0000OOO ).upper ():OO0OO0000O0OO00O0 for OO000OO0OO0000OOO ,OO0OO0000O0OO00O0 in mapping .items ()}#line:3078
        else :#line:3079
            mapping ={}#line:3080
        if OO00O000OO0O0O000 :#line:3081
            mapping .update ({str (O0OO0O0OO000O000O ).upper ():OOOOO00000OOOOOO0 for O0OO0O0OO000O000O ,OOOOO00000OOOOOO0 in OO00O000OO0O0O000 .items ()})#line:3084
        super ().__init__ (mapping )#line:3085
    def __setitem__ (O0O0O0000O00OO0O0 ,OO00O0O0OOOO0OOO0 ,OO0O00OOO0O00O0O0 ):#line:3087
        super ().__setitem__ (OO00O0O0OOOO0OOO0 ,OO0O00OOO0O00O0O0 )#line:3088
    def AddItem_ByProdID (OO00O0OOO0O00OO0O ,OO0O0O0OO0O000O00 :TFutQtBase ):#line:3090
        try :#line:3091
            if OO00O0OOO0O00OO0O .data .get (OO0O0O0OO0O000O00 .ProdID )is None :#line:3092
                O0OOO00O0OO000OOO =TObjBaseOptMthList ()#line:3093
                O0OOO00O0OO000OOO .NewItem (OO0O0O0OO0O000O00 )#line:3094
                OO00O0OOO0O00OO0O [OO0O0O0OO0O000O00 .ProdID ]=O0OOO00O0OO000OOO #line:3095
            else :#line:3096
                O0OOO00O0OO000OOO :TObjBaseOptMthList =OO00O0OOO0O00OO0O [OO0O0O0OO0O000O00 .ProdID ]#line:3097
                O0OOO00O0OO000OOO .NewItem (OO0O0O0OO0O000O00 )#line:3098
        except Exception as OOO00O00O00OO000O :#line:3099
            pass #line:3100
class TObjBaseOptMthList (UserDict ):#line:3101
    ""#line:3103
    ProdName :str =""#line:3104
    def __init__ (O00O0O0O0O0OOO000 ,mapping =None ,**O00O00OO000O00O0O ):#line:3106
        if mapping is not None :#line:3107
            mapping ={str (O000OOO0O00OO00OO ).upper ():OO00O000OOO0OO00O for O000OOO0O00OO00OO ,OO00O000OOO0OO00O in mapping .items ()}#line:3110
        else :#line:3111
            mapping ={}#line:3112
        if O00O00OO000O00O0O :#line:3113
            mapping .update ({str (O000O00O00OOOO0O0 ).upper ():OOOO0OO0OOO0OO000 for O000O00O00OOOO0O0 ,OOOO0OO0OOO0OO000 in O00O00OO000O00O0O .items ()})#line:3116
        super ().__init__ (mapping )#line:3117
    def __setitem__ (O0000OOO0O00OOOO0 ,OOO0000OO0OO0OO0O ,O00OO000O000OO0OO ):#line:3119
        super ().__setitem__ (OOO0000OO0OO0OO0O ,O00OO000O000OO0OO )#line:3120
    def NewItem (O0O000OO0OO000O00 ,OOOO0OOO0OOOOOOO0 :TFutQtBase ):#line:3122
        OO00000O000O0000O =OOOO0OOO0OOOOOOO0 .SettleMth #line:3123
        if O0O000OO0OO000O00 .data .get (OO00000O000O0000O )is None :#line:3125
            O00OOOOOOO00OOO0O =OOOO0OOO0OOOOOOO0 .FutName #line:3126
            O0O00OO00O0000O0O =TObjBaseOptCallPutList ()#line:3127
            O0O00OO00O0000O0O .NewItem (OOOO0OOO0OOOOOOO0 )#line:3128
            O0O000OO0OO000O00 [OO00000O000O0000O ]=O0O00OO00O0000O0O #line:3129
        else :#line:3130
            O0O00OO00O0000O0O :TObjBaseOptCallPutList =O0O000OO0OO000O00 [OO00000O000O0000O ]#line:3131
            O0O00OO00O0000O0O .NewItem (OOOO0OOO0OOOOOOO0 )#line:3132
        OOOO00O0O0O000O00 =O0O000OO0OO000O00 .data #line:3134
        OOOOOOOOO0000OO00 =sorted (OOOO00O0O0O000O00 .items ())#line:3135
        OOOOO00OO0OO0O00O =dict (OOOOOOOOO0000OO00 )#line:3136
        O0O000OO0OO000O00 .data =OOOOO00OO0OO0O00O #line:3137
class TObjBaseOptCallPutList (UserDict ):#line:3138
    ""#line:3140
    def __init__ (OO00O00OO00000O00 ,mapping =None ,**OO00000O0O0OO0O00 ):#line:3142
        if mapping is not None :#line:3143
            mapping ={str (OO0000OO0O0O00000 ).upper ():OO0OO0O0O000O0000 for OO0000OO0O0O00000 ,OO0OO0O0O000O0000 in mapping .items ()}#line:3146
        else :#line:3147
            mapping ={}#line:3148
        if OO00000O0O0OO0O00 :#line:3149
            mapping .update ({str (OO0OO00OO0OO0OO0O ).upper ():OO000O0O00OOOO00O for OO0OO00OO0OO0OO0O ,OO000O0O00OOOO00O in OO00000O0O0OO0O00 .items ()})#line:3152
        super ().__init__ (mapping )#line:3153
    def __setitem__ (OO0OOOO0O0000O0OO ,OOO0OOOOO0O0O0OOO ,OOO00OO0OO00O00OO ):#line:3155
        super ().__setitem__ (OOO0OOOOO0O0O0OOO ,OOO00OO0OO00O00OO )#line:3156
    def NewItem (OOOOOO0O0O00OO00O ,OO0O0000000O0O0OO :TFutQtBase ):#line:3158
        O00O0O0OO00000000 =OO0O0000000O0O0OO .CallPutType #line:3159
        if OOOOOO0O0O00OO00O .data .get (O00O0O0OO00000000 )is None :#line:3161
            OOOO0O00O000OO000 =TObjBaseOptList ()#line:3162
            OOOO0O00O000OO000 .append (OO0O0000000O0O0OO )#line:3163
            OOOOOO0O0O00OO00O [O00O0O0OO00000000 ]=OOOO0O00O000OO000 #line:3164
        else :#line:3165
            OO00O00000O0O0000 :TObjBaseOptList =OOOOOO0O0O00OO00O [O00O0O0OO00000000 ]#line:3166
            OO00O00000O0O0000 .append (OO0O0000000O0O0OO )#line:3167
        O0O00O0000O000O0O =OOOOOO0O0O00OO00O .data #line:3169
        O0000O0OO0OO00000 =sorted (O0O00O0000O000O0O .items ())#line:3170
        OOO0OOO000OOO000O =dict (O0000O0OO0OO00000 )#line:3171
        OOOOOO0O0O00OO00O .data =OOO0OOO000OOO000O #line:3172
class TObjBaseOptList (list ):#line:3173
    ""#line:3174
    pass #line:3175
class TQryFutProdMap (UserDict ):#line:3179
    ""#line:3181
    def __init__ (OO000OOOO0O000OOO ,mapping =None ,**OOO0OOOO000O0O0OO ):#line:3183
        if mapping is not None :#line:3184
            mapping ={str (OOOOO0OO0OOO00OO0 ).upper ():O0OO0O0OOOOO0O0O0 for OOOOO0OO0OOO00OO0 ,O0OO0O0OOOOO0O0O0 in mapping .items ()}#line:3187
        else :#line:3188
            mapping ={}#line:3189
        if OOO0OOOO000O0O0OO :#line:3190
            mapping .update ({str (OOO0OOOOO0O000O0O ).upper ():O0O0OOOO000OO0O00 for OOO0OOOOO0O000O0O ,O0O0OOOO000OO0O00 in OOO0OOOO000O0O0OO .items ()})#line:3193
        super ().__init__ (mapping )#line:3194
    def __setitem__ (O00OOOOOO0O0000O0 ,OOO0OOOOOO0O000O0 ,O0OOO0OOOOO000OOO ):#line:3196
        super ().__setitem__ (OOO0OOOOOO0O000O0 ,O0OOO0OOOOO000OOO )#line:3197
class TQryFutProdRec :#line:3199
    tmpBase :TFutQtBase =None #line:3201
    tmpHL :TFutQtHL =None #line:3202
    def SetDataInit (OO0OO00OOOOO0OOO0 ):#line:3204
        OO0OO00OOOOO0OOO0 .tmpHL .DECIMAL_LOCATOR_Dgt =OO0OO00OOOOO0OOO0 .tmpBase .DECIMAL_LOCATOR_Dgt #line:3205
        OO0OO00OOOOO0OOO0 .tmpHL .DECIMAL_LOCATOR_Org =OO0OO00OOOOO0OOO0 .tmpBase .DECIMAL_LOCATOR_Org #line:3206
class TOvsFutQtDef :#line:3211
    DecimalMultiply :decimal =1 #line:3212
    "DecimalMultiply(一個契約含多少Shares)"#line:3213
    Price_Denominator :decimal =1 #line:3214
    "分母價格(為1者, 不是分子分母報價方式)"#line:3215
    def TransPrice2Dec (O0OOO000OO00OO00O ,OO00O0O000OO0O00O :str ):#line:3218
        try :#line:3219
            return Decimal (OO00O0O000OO0O00O )#line:3220
        except Exception as OOOO0O00O0O0O0OO0 :#line:3221
            return 0 #line:3222
    def TransPrice2Str (OO000O0OO000O0000 ,OO0O0O000OOOOO0OO :decimal ,aDg_tPrice :str =""):#line:3225
        if OO000O0OO000O0000 .Price_Denominator ==1 :#line:3226
            if OO000O0OO000O0000 .DecimalMultiply ==1 :#line:3227
                if aDg_tPrice is None or not aDg_tPrice or aDg_tPrice .isspace ():#line:3228
                    return str (OO0O0O000OOOOO0OO )#line:3229
                else :#line:3230
                    return aDg_tPrice .format (OO0O0O000OOOOO0OO )#line:3231
            if aDg_tPrice is None or not aDg_tPrice or aDg_tPrice .isspace ():#line:3232
                return "{:.8f}".format (OO0O0O000OOOOO0OO *OO000O0OO000O0000 .DecimalMultiply )#line:3233
            else :#line:3234
                return aDg_tPrice .format (OO0O0O000OOOOO0OO *OO000O0OO000O0000 .DecimalMultiply )#line:3235
        else :#line:3237
            O0000OO000000O0OO :decimal =math .trunc (OO0O0O000OOOOO0OO )#line:3239
            OO0OO0O00O0OOO0OO :decimal =OO0O0O000OOOOO0OO -O0000OO000000O0OO #line:3240
            if aDg_tPrice is None or not aDg_tPrice or aDg_tPrice .isspace ():#line:3241
                return "{0} {1:.8f}/{2}".format (O0000OO000000O0OO ,(OO0OO0O00O0OOO0OO *OO000O0OO000O0000 .Price_Denominator ),OO000O0OO000O0000 .Price_Denominator )#line:3242
            else :#line:3243
                return "{0} {1:.8f}/{2}".format (O0000OO000000O0OO ,aDg_tPrice .format (OO0OO0O00O0OOO0OO *OO000O0OO000O0000 .Price_Denominator ),OO000O0OO000O0000 .Price_Denominator )#line:3244
    def TransToInt (OOOOOO0OOOOO0OO00 ,O0O00OO00OOOO0OO0 :str ):#line:3246
        try :#line:3247
            return int (O0O00OO00OOOO0OO0 )#line:3248
        except Exception as O0O00OO0000OO0OOO :#line:3249
            return 0 #line:3250
    def TransToDecimal (O0OOO000000000000 ,O00000O0O000OO0O0 :str ):#line:3252
        try :#line:3253
            return Decimal (O00000O0O000OO0O0 )#line:3254
        except Exception as O000OOOOOOO0OO0O0 :#line:3255
            return 0 #line:3256
    def __init__ (OOOOOO00OOO0OOO00 )->None :#line:3259
        pass #line:3260
class TOvsFutQtBase (TOvsFutQtDef ):#line:3262
    fHasBAS :bool =False #line:3263
    fBAS =[]#line:3264
    SolICE :str #line:3266
    "元富行情代碼(NQ.202212)"#line:3267
    SysTime :str #line:3268
    "系統時間"#line:3269
    RefPriceOrg :str #line:3270
    "參考價"#line:3271
    def Get_RefPrice (O000O0000O0O000OO ):#line:3273
        return O000O0000O0O000OO .TransPrice2Dec (O000O0000O0O000OO .RefPriceOrg )#line:3274
    def GetDply_RefPrice (OO0OOOOO0O0OOOOO0 ,aDg_tPrice :str =""):#line:3276
        if (OO0OOOOO0O0OOOOO0 .fBAS ==None ):#line:3277
            return ""#line:3278
        O000000O000OO0O00 :decimal =0 #line:3279
        O000000O000OO0O00 =OO0OOOOO0O0OOOOO0 .TransPrice2Dec (OO0OOOOO0O0OOOOO0 .RefPriceOrg )#line:3280
        return OO0OOOOO0O0OOOOO0 .TransPrice2Str (O000000O000OO0O00 ,aDg_tPrice )#line:3281
    ProdID :str #line:3282
    "元富商品代碼 (EX:NQ)"#line:3283
    FutName :str #line:3284
    "商品中文名稱(EX:小型環球晶)"#line:3285
    OrdProdId :str #line:3286
    "元富商品委託代碼(EX:NQ)"#line:3287
    ICEProdId :str #line:3288
    "元富行情代碼(EX:NQ, 艾揚的為ICE開頭)"#line:3289
    MktStr :str #line:3290
    "元富市場別(FUT/OPT)"#line:3291
    Market :str #line:3292
    "元富市場別(4=FUT/5=OPT)"#line:3293
    BaseUnit :str #line:3294
    "基本跳動點(選擇權商品為TickSizeList, 如:0=0.05;5=0.25)"#line:3295
    def Get_BaseUnit (O0O0OO00O00000O0O ):#line:3297
        O00O0O00OO0OOOOO0 :decimal =1 #line:3298
        O00O0O00OO0OOOOO0 =O0O0OO00O00000O0O .TransToDecimal (O0O0OO00O00000O0O .BaseUnit )#line:3299
        if O00O0O00OO0OOOOO0 ==0 :#line:3300
            O00O0O00OO0OOOOO0 =1 #line:3301
        return O00O0O00OO0OOOOO0 #line:3302
    ValuePerUnitOrg :str #line:3304
    "每點價值"#line:3305
    def Get_ValuePerUnit (O000OO0O00000OOOO ):#line:3307
        return O000OO0O00000OOOO .TransToDecimal (O000OO0O00000OOOO .ValuePerUnitOrg )#line:3308
    DecimalMultiplyOrg :str #line:3309
    "DecimalMultiply(一個契約含多少Shares)"#line:3310
    def Get_DecimalMultiply (OO00OOOOO0OO00O0O ):#line:3312
        return OO00OOOOO0OO00O0O .TransToDecimal (OO00OOOOO0OO00O0O .DecimalMultiplyOrg )#line:3313
    Exchange :str #line:3314
    "元富交易所代碼"#line:3315
    ExchangeName :str #line:3316
    "元富商品代碼 (EX:NQ)"#line:3317
    Price_DenominatorOrg :str #line:3318
    "分母價格(為1者, 不是分子分母報價方式)"#line:3319
    def Get_Price_Denominator (O00000OO0000O0O0O ):#line:3321
        return O00000OO0000O0O0O .TransToDecimal (O00000OO0000O0O0O .Price_DenominatorOrg )#line:3322
    Display :str #line:3323
    "是否可交易(Y/N)"#line:3324
    SettleMth :str #line:3325
    "交割月"#line:3326
    CP :str #line:3327
    "C/P(非選擇權者為空字串)"#line:3328
    StrikeP :str #line:3329
    "履約價(非選擇權者為空字串)"#line:3330
    PreSettlePriceOrg :str #line:3331
    "昨日結算價"#line:3332
    def Get_PreSettlePrice (O00OO00O0O000OOOO ):#line:3334
        if O00OO00O0O000OOOO .fBAS is None :#line:3335
            return 0 #line:3336
        OOO00OOO000OOO0OO :decimal =0 #line:3337
        OOO00OOO000OOO0OO =O00OO00O0O000OOOO .TransPrice2Dec (O00OO00O0O000OOOO .PreSettlePriceOrg )#line:3338
        return OOO00OOO000OOO0OO #line:3339
    def GetDply_PreSettlePrice (O00OO0O0O00OOOOOO ,aDg_tPrice :str =""):#line:3341
        if O00OO0O0O00OOOOOO .fBAS ==None :#line:3342
            return ""#line:3343
        OO00O0000000O0O00 :decimal =0 #line:3344
        OO00O0000000O0O00 =O00OO0O0O00OOOOOO .TransPrice2Dec (O00OO0O0O00OOOOOO .PreSettlePriceOrg )#line:3345
        return O00OO0O0O00OOOOOO .TransPrice2Str (OO00O0000000O0O00 ,aDg_tPrice )#line:3346
    PreClosePriceOrg :str #line:3347
    def Get_PreClosePrice (OO00OO0O00O0O0O0O ):#line:3349
        if OO00OO0O00O0O0O0O .fBAS ==None :#line:3350
            return 0 #line:3351
        O00O0O000OO0OO0O0 :decimal =0 #line:3352
        O00O0O000OO0OO0O0 =OO00OO0O00O0O0O0O .TransPrice2Dec (OO00OO0O00O0O0O0O .PreClosePriceOrg )#line:3353
        return O00O0O000OO0OO0O0 #line:3354
    def GetDply_PreClosePrice (OO0O000OOO0O0O0OO ,aDg_tPrice :str =""):#line:3356
        if OO0O000OOO0O0O0OO .fBAS ==None :#line:3357
            return ""#line:3358
        O0O0O000O00OO00OO :decimal =0 #line:3359
        O0O0O000O00OO00OO =OO0O000OOO0O0O0OO .TransPrice2Str (OO0O000OOO0O0O0OO .PreClosePriceOrg )#line:3360
        return OO0O000OOO0O0O0OO .TransPrice2Str (O0O0O000O00OO00OO ,aDg_tPrice )#line:3361
    LastTxDate :str #line:3363
    "最後交易日"#line:3364
    TickSizeList :str #line:3365
    "TickSizeList(僅選擇權有值, 如:0=0.05;5=0.25)"#line:3366
    def Get_OptTickSizeList (O00O0O00OO00O0OO0 ):#line:3368
        ""#line:3370
        OO0000OOO0O00OOOO ={}#line:3372
        try :#line:3373
            if O00O0O00OO00O0OO0 .MktStr =="FUT":#line:3374
                return OO0000OOO0O00OOOO #line:3375
            if O00O0O00OO00O0OO0 .TickSizeList is None or not O00O0O00OO00O0OO0 .TickSizeList or O00O0O00OO00O0OO0 .TickSizeList .isspace :#line:3376
                return OO0000OOO0O00OOOO #line:3377
            O0000O0OOOOO0O00O =O00O0O00OO00O0OO0 .TickSizeList .split (';')#line:3380
            for OOO0OOO00000O0O00 in O0000O0OOOOO0O00O :#line:3381
                OO0000OOO0O00OOOO [Decimal (OOO0OOO00000O0O00 .split ('=')[0 ])]=Decimal (OOO0OOO00000O0O00 .split ('=')[1 ])#line:3383
            OO0000OOO0O00OOOO =dict (sorted (OO0000OOO0O00OOOO .items ()))#line:3384
        except Exception as OOO000OOO00OO0OO0 :#line:3385
            pass #line:3386
        return OO0000OOO0O00OOOO #line:3387
    def GetFavorStr (O00000OO00OOO0O0O )->str :#line:3389
        ""#line:3390
        return "|{0}|{1}|{2}|{3}|".format (O00000OO00OOO0O0O .Exchange ,O00000OO00OOO0O0O .ProdID ,O00000OO00OOO0O0O .SettleMth ,O00000OO00OOO0O0O .SolICE )#line:3391
    def Handle_BAS (O000O00O0OOOO0O0O ,O000OO00000OOO00O :str ):#line:3393
        O000O00O0OOOO0O0O .fBAS =O000OO00000OOO00O .split ('|')#line:3394
        O000O00O0OOOO0O0O .fHasBAS =len (O000O00O0OOOO0O0O .fBAS )>0 #line:3395
        O000O00O0OOOO0O0O .Set_Data ()#line:3396
        if O000O00O0OOOO0O0O .fHasBAS :#line:3397
            O000O00O0OOOO0O0O .DecimalMultiply =O000O00O0OOOO0O0O .Get_DecimalMultiply ()#line:3398
            O000O00O0OOOO0O0O .Price_Denominator =O000O00O0OOOO0O0O .Get_Price_Denominator ()#line:3399
    def Set_Data (OO0O0OO0OOO00OO0O ):#line:3401
        OO0O0OO0OOO00OO0O .SolICE =OO0O0OO0OOO00OO0O .fBAS [0 ]#line:3402
        OO0O0OO0OOO00OO0O .SysTime =OO0O0OO0OOO00OO0O .fBAS [1 ]#line:3403
        OO0O0OO0OOO00OO0O .RefPriceOrg =OO0O0OO0OOO00OO0O .fBAS [2 ]#line:3404
        OO0O0OO0OOO00OO0O .ProdID =OO0O0OO0OOO00OO0O .fBAS [3 ]#line:3405
        OO0O0OO0OOO00OO0O .FutName =OO0O0OO0OOO00OO0O .fBAS [4 ]#line:3406
        OO0O0OO0OOO00OO0O .OrdProdId =OO0O0OO0OOO00OO0O .fBAS [5 ]#line:3407
        OO0O0OO0OOO00OO0O .ICEProdId =OO0O0OO0OOO00OO0O .fBAS [6 ]#line:3408
        OO0O0OO0OOO00OO0O .MktStr =OO0O0OO0OOO00OO0O .fBAS [7 ]#line:3409
        OO0O0OO0OOO00OO0O .Market ="4"if OO0O0OO0OOO00OO0O .fBAS [7 ]=="FUT"else "5"#line:3410
        OO0O0OO0OOO00OO0O .BaseUnit =OO0O0OO0OOO00OO0O .fBAS [8 ]#line:3411
        OO0O0OO0OOO00OO0O .ValuePerUnitOrg =OO0O0OO0OOO00OO0O .fBAS [9 ]#line:3412
        OO0O0OO0OOO00OO0O .DecimalMultiplyOrg =OO0O0OO0OOO00OO0O .fBAS [10 ]#line:3413
        OO0O0OO0OOO00OO0O .Exchange =OO0O0OO0OOO00OO0O .fBAS [11 ]#line:3414
        OO0O0OO0OOO00OO0O .ExchangeName =OO0O0OO0OOO00OO0O .fBAS [12 ]#line:3415
        OO0O0OO0OOO00OO0O .Price_DenominatorOrg =OO0O0OO0OOO00OO0O .fBAS [13 ]#line:3416
        OO0O0OO0OOO00OO0O .Display =OO0O0OO0OOO00OO0O .fBAS [14 ]#line:3417
        OO0O0OO0OOO00OO0O .SettleMth =OO0O0OO0OOO00OO0O .fBAS [15 ]#line:3418
        OO0O0OO0OOO00OO0O .CP =OO0O0OO0OOO00OO0O .fBAS [16 ]#line:3419
        OO0O0OO0OOO00OO0O .StrikeP =OO0O0OO0OOO00OO0O .fBAS [17 ]#line:3420
        OO0O0OO0OOO00OO0O .PreSettlePriceOrg =OO0O0OO0OOO00OO0O .fBAS [18 ]#line:3421
        OO0O0OO0OOO00OO0O .PreClosePriceOrg =OO0O0OO0OOO00OO0O .fBAS [19 ]#line:3422
        OO0O0OO0OOO00OO0O .LastTxDate =OO0O0OO0OOO00OO0O .fBAS [20 ]#line:3423
        OO0O0OO0OOO00OO0O .TickSizeList =OO0O0OO0OOO00OO0O .fBAS [21 ]#line:3424
    def IsSameBAS (O0O0000O0O0O0OOOO ,O0O00O00O00OOOO00 :str ,O0OOOOOO0OO0OO0OO :str ):#line:3426
        return O0O00O00O00OOOO00 ==O0O0000O0O0O0OOOO .ProdID and O0O0000O0O0O0OOOO .SettleMth ==O0OOOOOO0OO0OO0OO #line:3427
class TOvsFutQtTX (TOvsFutQtDef ):#line:3428
    fTX =[]#line:3429
    SolICE :str #line:3432
    "元富行情代碼(NQ.202212)"#line:3433
    SysTime :str #line:3434
    "系統時間(EX:143211.693)"#line:3435
    DataTime :str #line:3436
    "資料時間(交易所給的)(EX:14:32:11.752025)"#line:3437
    QtSrc :str #line:3438
    "行情來源(EX:PATS.NQ/CQG.NQ)"#line:3439
    DealTime :str #line:3440
    "成交時間(EX:14:32:11.752025)"#line:3441
    DealShowMark :str #line:3442
    "成交資料揭示項目註記(0:請略過,1:成交行情,空字串:收盤/結算)"#line:3443
    TotQty :str #line:3444
    "成交總量"#line:3445
    def Get_TotQty2Dec (OO0OO000O0OO0OO0O ):#line:3447
        return OO0OO000O0OO0OO0O .TransToDecimal (OO0OO000O0OO0OO0O .TotQty )#line:3448
    def Get_TotQty2Int (O00O00OO00OOO00OO ):#line:3450
        return O00O00OO00OOO00OO .TransToInt (O00O00OO00OOO00OO .TotQty )#line:3451
    SumBuyDealCount :str #line:3452
    "累計買進成交筆數"#line:3453
    def Get_SumBuyDealCount (O00OO0O0OO0OO00O0 ):#line:3455
        return O00OO0O0OO0OO00O0 .TransToInt (O00OO0O0OO0OO00O0 .SumBuyDealCount )#line:3456
    SumSellDealCount :str #line:3457
    "累計賣出成交筆數"#line:3458
    def Get_SumSellDealCount (O0000OOOO0O0OOO00 ):#line:3460
        return O0000OOOO0O0OOO00 .TransToInt (O0000OOOO0O0OOO00 .SumSellDealCount )#line:3461
    DealCount :str #line:3462
    "成交價量檔數(目前海期都給1)"#line:3463
    def Get_DealCount (OO00000O0O0OO0OO0 ):#line:3465
        return OO00000O0O0OO0OO0 .TransToInt (OO00000O0O0OO0OO0 .DealCount )#line:3466
    DealPriceOrg :str #line:3467
    "成交價"#line:3468
    def Get_DealPrice (OOO0000OO0OOO00O0 ):#line:3470
        if OOO0000OO0OOO00O0 .fTX is None :#line:3471
            return 0 #line:3472
        O0O00OO00O0O00O00 :decimal =0 #line:3473
        O0O00OO00O0O00O00 =OOO0000OO0OOO00O0 .TransPrice2Dec (OOO0000OO0OOO00O0 .DealPriceOrg )#line:3474
        return O0O00OO00O0O00O00 #line:3475
    def GetDply_DealPrice (OO0OOO0O00OOOOOO0 ,aDg_tPrice :str =""):#line:3477
        if OO0OOO0O00OOOOOO0 .fTX ==None :#line:3478
            return ""#line:3479
        O00O0OO0OO0O00O00 :decimal =0 #line:3480
        O00O0OO0OO0O00O00 =OO0OOO0O00OOOOOO0 .TransPrice2Dec (OO0OOO0O00OOOOOO0 .DealPriceOrg )#line:3481
        return OO0OOO0O00OOOOOO0 .TransPrice2Str (O00O0OO0OO0O00O00 ,aDg_tPrice )#line:3482
    DealQty :str #line:3483
    "成交單量"#line:3484
    def Get_DealQty2Dec (O0O0OO0OOOOOOOO00 ):#line:3486
        return O0O0OO0OOOOOOOO00 .TransPrice2Dec (O0O0OO0OOOOOOOO00 .DealQty )#line:3487
    def GetDealQty2Int (OOOO0OO00OOO000OO ):#line:3489
        return OOOO0OO00OOO000OO .TransToInt (OOOO0OO00OOO000OO .DealQty )#line:3490
    DayHighOrg :str #line:3491
    "最高價"#line:3492
    def Get_DayHigh (O0OO000O0OO00OOO0 ):#line:3494
        if O0OO000O0OO00OOO0 .fTX is None :#line:3495
            return 0 #line:3496
        O000OOOO0O0OOO000 :decimal =0 #line:3497
        O000OOOO0O0OOO000 =O0OO000O0OO00OOO0 .TransPrice2Dec (O0OO000O0OO00OOO0 .DayHighOrg )#line:3498
        return O000OOOO0O0OOO000 #line:3499
    def GetDply_DayHigh (OOOO0O0OO0O000OO0 ,aDg_tPrice :str =""):#line:3501
        if OOOO0O0OO0O000OO0 .fTX ==None :#line:3502
            return ""#line:3503
        OO0O0OOOO00O0OOOO :decimal =0 #line:3504
        OO0O0OOOO00O0OOOO =OOOO0O0OO0O000OO0 .TransPrice2Dec (OOOO0O0OO0O000OO0 .DayHighOrg )#line:3505
        return OOOO0O0OO0O000OO0 .TransPrice2Str (OO0O0OOOO00O0OOOO ,aDg_tPrice )#line:3506
    DayLowOrg :str #line:3507
    "最低價"#line:3508
    def Get_DayLow (O0OOO000OOOO00O00 ):#line:3510
        if O0OOO000OOOO00O00 .fTX ==None :#line:3511
            return 0 #line:3512
        O0OO00000O0000OOO :decimal =0 #line:3513
        O0OO00000O0000OOO =O0OOO000OOOO00O00 .TransPrice2Dec (O0OOO000OOOO00O00 .DayLowOrg )#line:3514
        return O0OO00000O0000OOO #line:3515
    def GetDply_DayLow (O00OO0OO0O00000O0 ,aDg_tPrice :str =""):#line:3517
        if O00OO0OO0O00000O0 .fTX ==None :#line:3518
            return ""#line:3519
        OO0OO000OO000O0OO :decimal =0 #line:3520
        OO0OO000OO000O0OO =O00OO0OO0O00000O0 .TransPrice2Dec (O00OO0OO0O00000O0 .DayLowOrg )#line:3521
        return O00OO0OO0O00000O0 .TransPrice2Str (OO0OO000OO000O0OO ,aDg_tPrice )#line:3522
    OpenPriceOrg :str #line:3523
    "開盤價"#line:3524
    def Get_OpenPrice (OOOO0OO000O0O0OOO ):#line:3526
        if OOOO0OO000O0O0OOO .fTX ==None :#line:3527
            return 0 #line:3528
        OO00O00OOOOOO0OOO :decimal =0 #line:3529
        OO00O00OOOOOO0OOO =OOOO0OO000O0O0OOO .TransPrice2Dec (OOOO0OO000O0O0OOO .OpenPriceOrg )#line:3530
        return OO00O00OOOOOO0OOO #line:3531
    def GetDply_OpenPrice (O00O00O0O0O0OO000 ,aDg_tPrice :str =""):#line:3533
        if O00O00O0O0O0OO000 .fTX ==None :#line:3534
            return ""#line:3535
        OO0OO0OO000OOO00O :decimal =0 #line:3536
        OO0OO0OO000OOO00O =O00O00O0O0O0OO000 .TransPrice2Dec (O00O00O0O0O0OO000 .OpenPriceOrg )#line:3537
        return O00O00O0O0O0OO000 .TransPrice2Dec (OO0OO0OO000OOO00O ,aDg_tPrice )#line:3538
    ClosePriceOrg :str #line:3539
    "收盤價"#line:3540
    def Get_ClosePrice (OO000O0O0OOO000O0 ):#line:3542
        if OO000O0O0OOO000O0 .fTX ==None :#line:3543
            return 0 #line:3544
        OO000O0O000O0OOOO :decimal =0 #line:3545
        OO000O0O000O0OOOO =OO000O0O0OOO000O0 .TransPrice2Dec (OO000O0O0OOO000O0 .ClosePriceOrg )#line:3546
        return OO000O0O000O0OOOO #line:3547
    def GetDply_ClosePrice (O000OO00O000OOOOO ,aDg_tPrice :str =""):#line:3549
        if O000OO00O000OOOOO .fTX ==None :#line:3551
            return ""#line:3552
        O00OO0OO0OOOOOO0O :decimal =0 #line:3553
        O00OO0OO0OOOOOO0O =O000OO00O000OOOOO .TransPrice2Dec (O000OO00O000OOOOO .ClosePriceOrg )#line:3554
        return O000OO00O000OOOOO .TransPrice2Str (O00OO0OO0OOOOOO0O ,aDg_tPrice )#line:3555
    SettlePriceOrg :str #line:3557
    "結算價"#line:3558
    def Get_SettlePrice (OOOO0OO0O00O00000 ):#line:3560
        if OOOO0OO0O00O00000 .fTX ==None :#line:3561
            return 0 #line:3562
        O0OOOOO0000O00O00 :decimal =0 #line:3563
        O0OOOOO0000O00O00 =OOOO0OO0O00O00000 .TransPrice2Dec (OOOO0OO0O00O00000 .SettlePriceOrg )#line:3564
        return O0OOOOO0000O00O00 #line:3565
    def GetDply_SettlePrice (OO0O0OO000OOO0OOO ,aDg_tPrice :str =""):#line:3567
        if OO0O0OO000OOO0OOO .fTX ==None :#line:3568
            return ""#line:3569
        OOO0O0O0O0OO00OO0 :decimal =0 #line:3570
        OOO0O0O0O0OO00OO0 =OO0O0OO000OOO0OOO .TransPrice2Dec (OO0O0OO000OOO0OOO .SettlePriceOrg )#line:3571
        return OO0O0OO000OOO0OOO .TransPrice2Str (OOO0O0O0O0OO00OO0 ,aDg_tPrice )#line:3572
    fDealPrice :decimal =0 #line:3575
    "成交價"#line:3576
    HighPrice :decimal =0 #line:3577
    "當日最高價"#line:3578
    LowPrice :decimal =0 #line:3579
    "當日最低價"#line:3580
    def CalcHightLowPrice (OOOOOOOOOOOOO0000 ):#line:3582
        ""#line:3583
        try :#line:3584
            OOOOOOOOOOOOO0000 .fDealPrice =OOOOOOOOOOOOO0000 .Get_DealPrice ()#line:3585
            OOOOOOOOOOOOO0000 .HighPrice =math .Max (OOOOOOOOOOOOO0000 .fDealPrice ,OOOOOOOOOOOOO0000 .HighPrice )#line:3587
            if OOOOOOOOOOOOO0000 .LowPrice ==0 :#line:3588
                OOOOOOOOOOOOO0000 .LowPrice =OOOOOOOOOOOOO0000 .fDealPrice #line:3589
            else :#line:3590
                OOOOOOOOOOOOO0000 .LowPrice =min (OOOOOOOOOOOOO0000 .fDealPrice ,OOOOOOOOOOOOO0000 .LowPrice )#line:3591
        except Exception as O000OOOO0000O0O0O :#line:3592
            pass #line:3593
    def CalcHightLowPrice_None (O0OOO0O0OOOOOOO0O ):#line:3595
        pass #line:3596
    fPROC_CalcHightLowPrice :callable =None #line:3597
    "PROC_CalcHightLowPrice"#line:3598
    def Set_Data (O0O0000OO0OO0O000 ):#line:3601
        O0O0000OO0OO0O000 .SolICE =O0O0000OO0OO0O000 .fTX [0 ]#line:3602
        O0O0000OO0OO0O000 .SysTime =O0O0000OO0OO0O000 .fTX [1 ]#line:3603
        O0O0000OO0OO0O000 .DataTime =O0O0000OO0OO0O000 .fTX [2 ]#line:3604
        O0O0000OO0OO0O000 .QtSrc =O0O0000OO0OO0O000 .fTX [3 ]#line:3605
        O0O0000OO0OO0O000 .DealTime =O0O0000OO0OO0O000 .fTX [4 ]#line:3606
        O0O0000OO0OO0O000 .DealShowMark =O0O0000OO0OO0O000 .fTX [5 ]#line:3607
        O0O0000OO0OO0O000 .TotQty =O0O0000OO0OO0O000 .fTX [6 ]#line:3608
        O0O0000OO0OO0O000 .SumBuyDealCount =O0O0000OO0OO0O000 .fTX [7 ]#line:3609
        O0O0000OO0OO0O000 .SumSellDealCount =O0O0000OO0OO0O000 .fTX [8 ]#line:3610
        O0O0000OO0OO0O000 .DealCount =O0O0000OO0OO0O000 .fTX [9 ]#line:3611
        O0O0000OO0OO0O000 .DealPriceOrg =O0O0000OO0OO0O000 .fTX [10 ]#line:3612
        O0O0000OO0OO0O000 .DealQty =O0O0000OO0OO0O000 .fTX [11 ]#line:3613
        O0O0000OO0OO0O000 .DayHighOrg =O0O0000OO0OO0O000 .fTX [12 ]#line:3614
        O0O0000OO0OO0O000 .DayLowOrg =O0O0000OO0OO0O000 .fTX [13 ]#line:3615
        O0O0000OO0OO0O000 .OpenPriceOrg =O0O0000OO0OO0O000 .fTX [14 ]#line:3616
        O0O0000OO0OO0O000 .ClosePriceOrg =O0O0000OO0OO0O000 .fTX [15 ]#line:3617
        O0O0000OO0OO0O000 .SettlePriceOrg =O0O0000OO0OO0O000 .fTX [16 ]#line:3618
    def Handle_TX (OOOOOOO0O0OO0000O ,O00O00OOOO0OOOO0O :str ):#line:3620
        ""#line:3621
        OOOOOOO0O0OO0000O .fTX =O00O00OOOO0OOOO0O .split ('|')#line:3622
        OOOOOOO0O0OO0000O .Set_Data ()#line:3623
        OOOOOOO0O0OO0000O .fPROC_CalcHightLowPrice ()#line:3625
    def __init__ (OO0O000O000O00000 ,OOO000O0OOOO00OO0 :bool )->None :#line:3627
        OO0O000O000O00000 .fPROC_CalcHightLowPrice =OO0O000O000O00000 .CalcHightLowPrice_None #line:3629
        if OOO000O0OOOO00OO0 :#line:3630
            OO0O000O000O00000 .fPROC_CalcHightLowPrice =OO0O000O000O00000 .CalcHightLowPrice #line:3631
        super ().__init__ ()#line:3632
    def __str__ (O00000OOOOO0O0O00 )->str :#line:3634
        return f"""SolICE:{O00000OOOOO0O0O00.SolICE} SysTime:{O00000OOOOO0O0O00.SysTime} DataTime:{O00000OOOOO0O0O00.DataTime} QtSrc:{O00000OOOOO0O0O00.QtSrc} DealTime:{O00000OOOOO0O0O00.DealTime}"""+"""DealShowMark:{self.DealShowMark} TotQty:{self.TotQty} SumBuyDealCount:{self.SumBuyDealCount} SumSellDealCount:{self.SumSellDealCount}"""+"""DealCount:{self.DealCount} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty} DayHighOrg:{self.DayHighOrg}"""+"""DayLowOrg:{self.DayLowOrg} OpenPriceOrg:{self.OpenPriceOrg} ClosePriceOrg:{self.ClosePriceOrg} SettlePriceOrg:{self.SettlePriceOrg}"""+"""fDealPrice:{self.fDealPrice} HighPrice:{self.HighPrice} LowPrice:{self.LowPrice}"""#line:3639
class TOvsFutQt5Q (TOvsFutQtDef ):#line:3640
    f5Q =[]#line:3641
    SolICE :str #line:3643
    "元富行情代碼(NQ.202212)"#line:3644
    DataTime :str #line:3645
    "資料時間(交易所給的)(EX:14:32:19.676684)"#line:3646
    QtSrc :str #line:3647
    "行情來源(EX:PATS.NQ/CQG.NQ)"#line:3648
    fAryB5Q_P =[4 ,6 ,8 ,10 ,12 ,24 ,26 ,28 ,30 ,32 ]#line:3650
    "買五檔價在字串中的位置"#line:3651
    fAryB5Q_Q =[5 ,7 ,9 ,11 ,13 ,25 ,27 ,29 ,31 ,33 ]#line:3652
    "買五檔價在字串中的位置"#line:3653
    fB5QCount :int =10 #line:3654
    "買5檔的檔數"#line:3655
    def B5Q_POrg (OO0OOOO00000OOOO0 ,O0OO0000000OO00O0 :int ):#line:3657
        ""#line:3658
        if O0OO0000000OO00O0 >OO0OOOO00000OOOO0 .fB5QCount :#line:3659
            return ""#line:3660
        elif OO0OOOO00000OOOO0 .f5Q ==None :#line:3661
            return ""#line:3662
        else :#line:3663
            return OO0OOOO00000OOOO0 .f5Q [OO0OOOO00000OOOO0 .fAryB5Q_P [O0OO0000000OO00O0 -1 ]]#line:3664
    def Set_B5Q_P (OOO00O000OO00O00O ,O0OOOOOO0000OO000 :int ):#line:3666
        ""#line:3667
        if O0OOOOOO0000OO000 >OOO00O000OO00O00O .fB5QCount :#line:3668
            return 0 #line:3669
        elif OOO00O000OO00O00O .f5Q ==None :#line:3670
            return 0 #line:3671
        else :#line:3672
            return OOO00O000OO00O00O .TransPrice2Dec (OOO00O000OO00O00O .f5Q [OOO00O000OO00O00O .fAryB5Q_P [O0OOOOOO0000OO000 -1 ]])#line:3673
    def Get_B5Q_P (OOO0O00OO0OO0O000 ,O00O0O0OOOO00O0O0 :int ):#line:3675
        if OOO0O00OO0OO0O000 .f5Q ==None :#line:3676
            return 0 #line:3677
        O0000OO00000O0O00 :decimal =0 #line:3678
        O0000OO00000O0O00 =OOO0O00OO0OO0O000 .TransPrice2Dec (OOO0O00OO0OO0O000 .f5Q [OOO0O00OO0OO0O000 .fAryB5Q_P [O00O0O0OOOO00O0O0 -1 ]])#line:3679
        return O0000OO00000O0O00 #line:3680
    def GetDply_B5Q_P (OO0OOOOO0000O00O0 ,OO0OO00O0OOOOO000 :int ,aDg_tPrice :str =""):#line:3682
        if OO0OO00O0OOOOO000 >OO0OOOOO0000O00O0 .fB5QCount :#line:3683
            return ""#line:3684
        elif OO0OOOOO0000O00O0 .f5Q ==None :#line:3685
            return ""#line:3686
        else :#line:3687
            O0000OO0000OO000O :decimal =0 #line:3688
            O0000OO0000OO000O =OO0OOOOO0000O00O0 .TransPrice2Dec (OO0OOOOO0000O00O0 .f5Q [OO0OOOOO0000O00O0 .fAryB5Q_P [OO0OO00O0OOOOO000 -1 ]])#line:3689
            return OO0OOOOO0000O00O0 .TransPrice2Str (O0000OO0000OO000O ,aDg_tPrice )#line:3690
    def B5Q_QOrg (O0OOOO00O0O000O0O ,O0O00O00O0OOOO0OO :int ):#line:3692
        ""#line:3693
        if O0O00O00O0OOOO0OO >O0OOOO00O0O000O0O .fB5QCount :#line:3694
            return ""#line:3695
        elif O0OOOO00O0O000O0O .f5Q ==None :#line:3696
            return ""#line:3697
        else :#line:3698
            return O0OOOO00O0O000O0O .f5Q [O0OOOO00O0O000O0O .fAryB5Q_Q [O0O00O00O0OOOO0OO -1 ]]#line:3699
    def Set_B5Q_Q (O0OOO0OO00OO0OO0O ,O0OOOOO000OOO0O0O :int ):#line:3701
        ""#line:3702
        if O0OOOOO000OOO0O0O >O0OOO0OO00OO0OO0O .fB5QCount :#line:3704
            return 0 #line:3705
        elif O0OOO0OO00OO0OO0O .f5Q ==None :#line:3706
            return 0 #line:3707
        else :#line:3708
            return O0OOO0OO00OO0OO0O .TransToInt (O0OOO0OO00OO0OO0O .f5Q [O0OOO0OO00OO0OO0O .fAryB5Q_Q [O0OOOOO000OOO0O0O -1 ]])#line:3709
    def Get_B5Q_Q (O0OO0OO00OOO0O0OO ,OO0OOO000OO00O00O :int ):#line:3711
        OO00OOOO0OO0O0000 :int =0 #line:3713
        OO00OOOO0OO0O0000 =O0OO0OO00OOO0O0OO .Set_B5Q_Q (OO0OOO000OO00O00O )#line:3714
        return str (OO00OOOO0OO0O0000 )#line:3715
    fAryS5Q_P =[14 ,16 ,18 ,20 ,22 ,34 ,36 ,38 ,40 ,42 ]#line:3718
    "買五檔價在字串中的位置"#line:3719
    fAryS5Q_Q =[15 ,17 ,19 ,21 ,23 ,35 ,37 ,39 ,41 ,43 ]#line:3720
    "買五檔價在字串中的位置"#line:3721
    fS5QCount :int =10 #line:3722
    "賣5檔的檔數"#line:3723
    def S5Q_POrg (OOOO0000O0OO0OO00 ,OOOO00OOO00OOOO0O :int ):#line:3725
        ""#line:3726
        if OOOO00OOO00OOOO0O >OOOO0000O0OO0OO00 .fS5QCount :#line:3727
            return ""#line:3728
        elif OOOO0000O0OO0OO00 .f5Q ==None :#line:3729
            return ""#line:3730
        else :#line:3731
            return OOOO0000O0OO0OO00 .f5Q [OOOO0000O0OO0OO00 .fAryS5Q_P [OOOO00OOO00OOOO0O -1 ]]#line:3732
    def Set_S5Q_P (OO0000OO0O00OO00O ,O00OO0O000OO00O0O :int ):#line:3734
        ""#line:3735
        if O00OO0O000OO00O0O >OO0000OO0O00OO00O .fS5QCount :#line:3736
            return 0 #line:3737
        elif OO0000OO0O00OO00O .f5Q ==None :#line:3738
            return 0 #line:3739
        else :#line:3740
            return OO0000OO0O00OO00O .TransPrice2Dec (OO0000OO0O00OO00O .f5Q [OO0000OO0O00OO00O .fAryS5Q_P [O00OO0O000OO00O0O -1 ]])#line:3741
    def Get_S5Q_P (O0000O0O00OOOOO00 ,O0O000OO000OO0O0O :int ):#line:3743
        if O0000O0O00OOOOO00 .f5Q ==None :#line:3744
            return 0 #line:3745
        O0OO0O0OO0O00O00O :decimal =0 #line:3746
        O0OO0O0OO0O00O00O =O0000O0O00OOOOO00 .TransPrice2Dec (O0000O0O00OOOOO00 .f5Q [O0000O0O00OOOOO00 .fAryS5Q_P [O0O000OO000OO0O0O -1 ]])#line:3747
        return O0OO0O0OO0O00O00O #line:3748
    def GetDply_S5Q_P (OO0000O0O00000OO0 ,OOO00OO0OOOO0OO00 :int ,aDg_tPrice :str =""):#line:3750
        if OOO00OO0OOOO0OO00 >OO0000O0O00000OO0 .fS5QCount :#line:3751
            return ""#line:3752
        elif OO0000O0O00000OO0 .f5Q ==None :#line:3753
            return ""#line:3754
        else :#line:3755
            O00O000O00O0OOOOO :decimal =0 #line:3756
            O00O000O00O0OOOOO =OO0000O0O00000OO0 .TransPrice2Dec (OO0000O0O00000OO0 .f5Q [OO0000O0O00000OO0 .fAryS5Q_P [OOO00OO0OOOO0OO00 -1 ]])#line:3757
            return OO0000O0O00000OO0 .TransPrice2Str (O00O000O00O0OOOOO ,aDg_tPrice )#line:3758
    def S5Q_QOrg (OOO00O0O00O0O0000 ,O0OO00O00OOO0OOO0 :int ):#line:3760
        ""#line:3761
        if O0OO00O00OOO0OOO0 >OOO00O0O00O0O0000 .fS5QCount :#line:3762
            return ""#line:3763
        elif OOO00O0O00O0O0000 .f5Q ==None :#line:3764
            return ""#line:3765
        else :#line:3766
            return OOO00O0O00O0O0000 .f5Q [OOO00O0O00O0O0000 .fAryS5Q_Q [O0OO00O00OOO0OOO0 -1 ]]#line:3767
    def Set_S5Q_Q (OOOO0O00OOO0O0OO0 ,O0O00OO0O00O0OOOO :int ):#line:3769
        ""#line:3770
        if O0O00OO0O00O0OOOO >OOOO0O00OOO0O0OO0 .fS5QCount :#line:3771
            return 0 #line:3772
        elif OOOO0O00OOO0O0OO0 .f5Q ==None :#line:3773
            return 0 #line:3774
        else :#line:3775
            return OOOO0O00OOO0O0OO0 .TransToInt (OOOO0O00OOO0O0OO0 .f5Q [OOOO0O00OOO0O0OO0 .fAryS5Q_Q [O0O00OO0O00O0OOOO -1 ]])#line:3776
    def Get_S5Q_Q (OO000000O0O00OOO0 ,O0OO0OO0OO00O0OO0 :int ):#line:3778
        O0O0O0O00000OOOOO :int =0 #line:3779
        O0O0O0O00000OOOOO =OO000000O0O00OOO0 .Set_S5Q_Q (O0OO0OO0OO00O0OO0 )#line:3780
        return str (O0O0O0O00000OOOOO )#line:3781
    def Handle_5Q (OO00O0O0OO0OOOO0O ,OOOO000OO0OO0OOO0 :str ):#line:3784
        OO00O0O0OO0OOOO0O .f5Q =OOOO000OO0OO0OOO0 .split ('|')#line:3785
        OO00O0O0OO0OOOO0O .SetData ()#line:3786
    def SetData (OOOO00OO00O000O0O ):#line:3788
        OOOO00OO00O000O0O .SolICE =OOOO00OO00O000O0O .f5Q [0 ]#line:3789
        OOOO00OO00O000O0O .DataTime =OOOO00OO00O000O0O .f5Q [2 ]#line:3790
        OOOO00OO00O000O0O .QtSrc =OOOO00OO00O000O0O .f5Q [3 ]#line:3791
    def __init__ (O0O0000O0OOOO000O )->None :#line:3793
        pass #line:3794
    def __str__ (OOOOO00000O000OOO )->str :#line:3796
        return f"SolICE:{OOOOO00000O000OOO.SolICE} DataTime:{OOOOO00000O000OOO.DataTime} QtSrc:{OOOOO00000O000OOO.QtSrc} f5Q:{OOOOO00000O000OOO.f5Q}"#line:3797
class TOvsFutQuoteData :#line:3798
    SolIce :str =""#line:3799
    ProdKind :TOvsFutProdKind =TOvsFutProdKind .pkNone #line:3801
    BAS :TOvsFutQtBase =None #line:3803
    QtTX :TOvsFutQtTX =None #line:3804
    Qt5Q :TOvsFutQt5Q =None #line:3805
    def __init__ (OOOOOOOOOOO0OOOOO ,O0OOO00OO00O00O0O :TOvsFutProdKind ,OOOOOO00O00OO00O0 :str ,OO00OOOO0O0O00000 :bool ):#line:3807
        ""#line:3808
        OOOOOOOOOOO0OOOOO .SolIce =OOOOOO00O00OO00O0 #line:3809
        OOOOOOOOOOO0OOOOO .ProdKind =O0OOO00OO00O00O0O #line:3810
        OOOOOOOOOOO0OOOOO ._lock =Lock ()#line:3811
        if O0OOO00OO00O00O0O ==TOvsFutProdKind .pkNormal :#line:3812
            OOOOOOOOOOO0OOOOO .BAS =TOvsFutQtBase ()#line:3813
            OOOOOOOOOOO0OOOOO .QtTX =TOvsFutQtTX (OO00OOOO0O0O00000 )#line:3814
            OOOOOOOOOOO0OOOOO .Qt5Q =TOvsFutQt5Q ()#line:3815
        elif O0OOO00OO00O00O0O ==TOvsFutProdKind .pkIndex :#line:3816
            pass #line:3817
    def SetDataInit (OOO00O0O00OOOO000 ):#line:3819
        ""#line:3820
        if OOO00O0O00OOOO000 .ProdKind ==TOvsFutProdKind .pkNormal :#line:3821
            OOO00O0O00OOOO000 .QtTX .DecimalMultiply =OOO00O0O00OOOO000 .BAS .DecimalMultiply #line:3822
            OOO00O0O00OOOO000 .Qt5Q .DecimalMultiply =OOO00O0O00OOOO000 .BAS .DecimalMultiply #line:3823
            OOO00O0O00OOOO000 .QtTX .Price_Denominator =OOO00O0O00OOOO000 .BAS .Price_Denominator #line:3824
            OOO00O0O00OOOO000 .Qt5Q .Price_Denominator =OOO00O0O00OOOO000 .BAS .Price_Denominator #line:3825
class TMapOvsFutQuoteData (UserDict ):#line:3827
    ""#line:3828
    def __init__ (OO0O0OOOO00OOO00O ,mapping =None ,**O0OOOO000O0OOOO00 ):#line:3829
        if mapping is not None :#line:3830
            mapping ={str (OOO00O000O00OOO00 ).upper ():OOO00O0O0000O00O0 for OOO00O000O00OOO00 ,OOO00O0O0000O00O0 in mapping .items ()}#line:3833
        else :#line:3834
            mapping ={}#line:3835
        if O0OOOO000O0OOOO00 :#line:3836
            mapping .update ({str (O00OOOO0OOOOO0000 ).upper ():OO0OO000O0000OO0O for O00OOOO0OOOOO0000 ,OO0OO000O0000OO0O in O0OOOO000O0OOOO00 .items ()})#line:3839
        OO0O0OOOO00OOO00O .MapQtProc ={}#line:3840
        super ().__init__ (mapping )#line:3841
    def __setitem__ (OOOOOOO0O0OOO00O0 ,OO0OO0OO0OO0O0O00 ,O0OOOO000OOOO0O00 ):#line:3843
        super ().__setitem__ (OO0OO0OO0OO0O0O00 ,O0OOOO000OOOO0O00 )#line:3844
class TObjOvsFutQuoteMap (UserDict ):#line:3846
    DefProc_TX :callable =None #line:3848
    "成交行情解析proc"#line:3849
    DefProc_5Q :callable =None #line:3850
    "五檔行情解析proc"#line:3851
    def __init__ (OOOO00O0OOO000OO0 ,mapping =None ,**O000O0000O00OO00O ):#line:3853
        if mapping is not None :#line:3854
            mapping ={str (O00O0000OOOOOO0OO ).upper ():OO0000000O000O000 for O00O0000OOOOOO0OO ,OO0000000O000O000 in mapping .items ()}#line:3857
        else :#line:3858
            mapping ={}#line:3859
        if O000O0000O00OO00O :#line:3860
            mapping .update ({str (OOOO0000O00OOO0OO ).upper ():OO000O000O0O0O000 for OOOO0000O00OOO0OO ,OO000O000O0O0O000 in O000O0000O00OO00O .items ()})#line:3863
        OOOO00O0OOO000OO0 .MapQtProc ={}#line:3866
        "各商品拆解行情proc(EX:NQ的TX與5Q, 行情拆解,是不同Proc)"#line:3867
        super ().__init__ (mapping )#line:3868
    def __setitem__ (OO0000OOO0000O000 ,O0OO0O0O0OO000000 ,OO0OO000O00000O00 ):#line:3870
        super ().__setitem__ (O0OO0O0O0OO000000 ,OO0OO000O00000O00 )#line:3871
    def AddRcvData (O00O00O00OOOOO000 ,O00OO00O00O0O0OOO :str ,OO0OOO0OO0O0OO0O0 :str ,O000000OOOO00O000 :bool ):#line:3873
        ""#line:3877
        O0000OO000OOO0OOO =""#line:3879
        OO000O0O0OO00000O :TOvsFutQuoteData =None #line:3880
        try :#line:3881
            OO0O0OO0OO00O0OO0 =json .loads (OO0OOO0OO0O0OO0O0 )#line:3882
            if "status"in OO0O0OO0OO00O0OO0 and len (OO0O0OO0OO00O0OO0 ["status"])>0 :#line:3884
                if OO0O0OO0OO00O0OO0 ["status"][0 ]=="error":#line:3885
                    O0000OO000OOO0OOO =f"[海期][AddRcvData](aSolIce={O00OO00O00O0O0OOO}, aData={OO0OOO0OO0O0OO0O0})行情回補資料有誤!"#line:3886
                    return False ,OO000O0O0OO00000O ,O0000OO000OOO0OOO #line:3887
            if "BAS"in OO0O0OO0OO00O0OO0 and len (OO0O0OO0OO00O0OO0 ["BAS"])==0 :#line:3888
                O0000OO000OOO0OOO =f"[海期][AddRcvData](aSolIce={O00OO00O00O0O0OOO}, aData={OO0OOO0OO0O0OO0O0})沒有BAS資料!"#line:3889
                return False ,OO000O0O0OO00000O ,O0000OO000OOO0OOO #line:3890
            if O00O00O00OOOOO000 .data .get (O00OO00O00O0O0OOO )is None :#line:3893
                O0000O0000OOO00OO =TOvsFutQuoteData (TOvsFutProdKind .pkNormal ,O00OO00O00O0O0OOO ,O000000OOOO00O000 )#line:3895
                O0000O0000OOO00OO .BAS .Handle_BAS (OO0O0OO0OO00O0OO0 ["BAS"][0 ])#line:3896
                O0000O0000OOO00OO .SetDataInit ()#line:3898
                OO000O0O0OO00000O =O0000O0000OOO00OO #line:3899
                O00O00O00OOOOO000 [O00OO00O00O0O0OOO ]=O0000O0000OOO00OO #line:3900
                return True ,OO000O0O0OO00000O ,""#line:3901
            else :#line:3902
                O0000O0000OOO00OO :TOvsFutQuoteData =O00O00O00OOOOO000 [O00OO00O00O0O0OOO ]#line:3903
                with O0000O0000OOO00OO ._lock :#line:3904
                    O0000O0000OOO00OO .BAS .Handle_BAS (OO0O0OO0OO00O0OO0 ["BAS"][0 ])#line:3905
                    O0000O0000OOO00OO .SetDataInit ()#line:3907
                    OO000O0O0OO00000O =O0000O0000OOO00OO #line:3908
                return True ,OO000O0O0OO00000O ,""#line:3909
        except Exception as OOO0000OOO000OOOO :#line:3910
            O0000OO000OOO0OOO =f"[海期][AddRcvData](aSolIce={O00OO00O00O0O0OOO}, aData={OO0OOO0OO0O0OO0O0}){OOO0000OOO000OOOO}"#line:3911
        return False ,OO000O0O0OO00000O ,O0000OO000OOO0OOO #line:3912
    def AddData (O0OOOO0O000O0O0OO ,O0O0OOOO000OOO000 :TOvsFutProdKind ,O00OOOOOO0O00OOOO :str ,O0OO00OO00OO0OOOO :bool ,OO0OOO0O000OOOO00 :str ,O000OO0OOOOOOOOO0 :callable ):#line:3914
        ""#line:3918
        try :#line:3919
            if O0OOOO0O000O0O0OO .data .get (O00OOOOOO0O00OOOO )is None :#line:3920
                OOOOOOOO0O0OO0000 =TOvsFutQuoteData (O0O0OOOO000OOO000 ,O00OOOOOO0O00OOOO ,O0OO00OO00OO0OOOO )#line:3921
                O0OOOO0O000O0O0OO [OO0OOO0O000OOOO00 ]=OOOOOOOO0O0OO0000 #line:3922
                if O0OOOO0O000O0O0OO .MapQtProc .get (OO0OOO0O000OOOO00 )is None :#line:3924
                    O0OOOO0O000O0O0OO .MapQtProc [OO0OOO0O000OOOO00 ]=O000OO0OOOOOOOOO0 #line:3925
                return True #line:3927
            else :#line:3928
                return True #line:3929
        except Exception as O00OO0O00O00O000O :#line:3930
            pass #line:3931
        return False #line:3932
    def AddDataBySolIce (OO000O00OO0O0000O ,O0O00OOO000O000O0 :bool ,OO0O00O0OOOO0O0OO :str ,OOO0OOO00000OO0OO ,OO0O00O0O00OOO000 :bool ):#line:3934
        ""#line:3942
        OO000O0OOOO00OOOO =""#line:3943
        O00O000OO0O000000 :TOvsFutQuoteData =None #line:3944
        try :#line:3945
            O00O000OO0O000000 =TMapOvsFutQuoteData ()#line:3947
            for OOO00O0O0O0OOO0O0 in OOO0OOO00000OO0OO ["BAS"]:#line:3948
                OO0000OO0OOOOOO00 =TOvsFutQtBase ()#line:3949
                OO0000OO0OOOOOO00 .Handle_BAS (OOO00O0O0O0OOO0O0 )#line:3950
                if O00O000OO0O000000 .data .get (OO0000OO0OOOOOO00 .Symbol ):#line:3952
                    O0O0000O00O00OOOO =TOvsFutQuoteData (TOvsFutProdKind .pkNormal ,OO0000OO0OOOOOO00 .Symbol ,OO0O00O0O00OOO000 )#line:3953
                    O0O0000O00O00OOOO .BAS =OO0000OO0OOOOOO00 #line:3954
                    O0O0000O00O00OOOO .SetDataInit ()#line:3955
                    O00O0OOO000OOOOOO :OOO00O0O0O0OOO0O0 =O0O0000O00O00OOOO .BAS .TopicTX #line:3957
                    O0000OO0OOO000O00 :OOO00O0O0O0OOO0O0 =O0O0000O00O00OOOO .BAS .Topic5Q #line:3958
                    OO000O00OO0O0000O [O00O0OOO000OOOOOO ]=O0O0000O00O00OOOO #line:3960
                    OO000O00OO0O0000O [O0000OO0OOO000O00 ]=O0O0000O00O00OOOO #line:3961
                    if OO000O00OO0O0000O .MapQtProc .get (O00O0OOO000OOOOOO )is None :#line:3963
                        OO000O00OO0O0000O .MapQtProc [O00O0OOO000OOOOOO ]=OO000O00OO0O0000O .DefProc_TX #line:3964
                    if OO000O00OO0O0000O .MapQtProc .get (O0000OO0OOO000O00 )is None :#line:3965
                        OO000O00OO0O0000O .MapQtProc [O0000OO0OOO000O00 ]=OO000O00OO0O0000O .DefProc_5Q #line:3966
                    O00O000OO0O000000 .Add (OO0000OO0OOOOOO00 .Symbol ,O0O0000O00O00OOOO )#line:3968
            return len (O00O000OO0O000000 )>0 ,O00O000OO0O000000 ,OO000O0OOOO00OOOO #line:3969
        except Exception as O00O0O00OOOOOO0O0 :#line:3971
            OO000O0OOOO00OOOO =f"[海期][AddDataBySolIce](aIsCat={O0O00OOO000O000O0}, aSolIce={OO0O00O0OOOO0O0OO}){O00O0O00OOOOOO0O0}"#line:3972
        return False ,O00O000OO0O000000 ,OO000O0OOOO00OOOO #line:3973
    def GetItem_BySolIce (O00OO000O0O0OO00O ,O000O00O00O0OOOOO :str ):#line:3975
        ""#line:3978
        OOO00OOO000OO00O0 :str =""#line:3980
        O00O0OOOOO0OOOOO0 =None #line:3981
        try :#line:3982
            OO0OO00OOOO0OO000 =[]#line:3983
            for O00O00O0O0O0O000O ,OO0O000O0OOO0O000 in O00OO000O0O0OO00O .items ():#line:3984
                OO00O0OOOO0O00OOO :TOvsFutQuoteData =OO0O000O0OOO0O000 #line:3985
                if OO00O0OOOO0O00OOO .SolIce ==O000O00O00O0OOOOO :#line:3986
                    OO0OO00OOOO0OO000 .append (O00O00O0O0O0O000O )#line:3987
            O00O0OOOOO0OOOOO0 =OO0OO00OOOO0OO000 #line:3989
            if O00O0OOOOO0OOOOO0 is None or len (O00O0OOOOO0OOOOO0 )==0 :#line:3990
                OOO00OOO000OO00O0 =f"[海期][GetItem_BySolIce](aSolIce={O000O00O00O0OOOOO})商品已不存存!"#line:3991
                return False ,O00O0OOOOO0OOOOO0 ,OOO00OOO000OO00O0 #line:3992
            return True ,O00O0OOOOO0OOOOO0 ,OOO00OOO000OO00O0 #line:3993
        except Exception as O00OOO00O0O0O00OO :#line:3994
            OOO00OOO000OO00O0 =f"[海期][GetItem_BySolIce](aSolIce={O000O00O00O0OOOOO}){O00OOO00O0O0O00OO}"#line:3995
        return False ,O00O0OOOOO0OOOOO0 ,OOO00OOO000OO00O0 #line:3996
    def GetItem_ByExchange (OO0000OO00O000OOO ,O0O0000O0O0O0O00O :str ):#line:3997
        ""#line:3998
        OO0OO000OOO00OOO0 =""#line:3999
        O00OOOO000OO0O000 =None #line:4000
        try :#line:4001
            O0O0O0O00OOOO000O =[]#line:4002
            for O00OOO00O00OOO0O0 ,OO00OOO0O0O0OOO00 in OO0000OO00O000OOO .items ():#line:4003
                OO0O0000O00O0O0O0 :TOvsFutQuoteData =OO00OOO0O0O0OOO00 #line:4004
                if OO0O0000O00O0O0O0 .BAS .Exchange ==O0O0000O0O0O0O00O :#line:4005
                    O0O0O0O00OOOO000O .append (O00OOO00O00OOO0O0 )#line:4006
                O00OOOO000OO0O000 =O0O0O0O00OOOO000O #line:4007
            if O00OOOO000OO0O000 is None or len (O00OOOO000OO0O000 )==0 :#line:4008
                OO0OO000OOO00OOO0 =f"[海期][GetItem_ByExchange](aExchange={O0O0000O0O0O0O00O})商品已不存存!"#line:4009
                return False ,O00OOOO000OO0O000 ,OO0OO000OOO00OOO0 #line:4010
            return True ,O00OOOO000OO0O000 ,OO0OO000OOO00OOO0 #line:4012
        except Exception as OOOOOOOOO0O00O0OO :#line:4014
            OO0OO000OOO00OOO0 =f"[海期][GetItem_ByExchange](aExchange={O0O0000O0O0O0O00O}){OOOOOOOOO0O00O0OO}"#line:4015
        return False ,O00OOOO000OO0O000 ,OO0OO000OOO00OOO0 #line:4016
class TObjOvsFutProdMthMap (UserDict ):#line:4021
    ""#line:4023
    def __init__ (OOOOOO0O00000O0OO ,O0OOOO0OOO0000O0O :str ,O0O000OO00O0O0OO0 :str ):#line:4025
        OOOOOO0O00000O0OO .Exchange =O0OOOO0OOO0000O0O #line:4026
        OOOOOO0O00000O0OO .ExchangeName =O0O000OO00O0O0OO0 #line:4027
        OO0O0000O000OOOOO ={}#line:4028
        super ().__init__ (OO0O0000O000OOOOO )#line:4029
    def __setitem__ (O00OO0O0OOO00O0O0 ,OOO0OO0OOOO00OOO0 ,O000OO00O0000O000 ):#line:4031
        super ().__setitem__ (OOO0OO0OOOO00OOO0 ,O000OO00O0000O000 )#line:4032
    def AddItem (O0OO00O00OO000O00 ,OOO0O000OOOOO0OOO :TOvsFutQtBase ):#line:4034
        if O0OO00O00OO000O00 .data .get (OOO0O000OOOOO0OOO .ProdID )is None :#line:4035
            O00O0O0000O000O0O =TObjOvsFutMthList (OOO0O000OOOOO0OOO .ProdID ,OOO0O000OOOOO0OOO .FutName )#line:4036
            O00O0O0000O000O0O .AddItem (OOO0O000OOOOO0OOO )#line:4037
            O0OO00O00OO000O00 [OOO0O000OOOOO0OOO .ProdID ]=O00O0O0000O000O0O #line:4038
        else :#line:4039
            O00O0O0000O000O0O :TObjOvsFutMthList =O0OO00O00OO000O00 [OOO0O000OOOOO0OOO .ProdID ]#line:4040
            O00O0O0000O000O0O .AddItem (OOO0O000OOOOO0OOO )#line:4041
class TObjOvsFutMthList (UserDict ):#line:4043
    ""#line:4045
    def __init__ (O000O00000O00O000 ,OOO0OO0OO000O0000 :str ,OO0O00O0O00O00O0O :str ):#line:4047
        O000O00000O00O000 .ProdID =OOO0OO0OO000O0000 #line:4048
        O000O00000O00O000 .ProdName =OO0O00O0O00O00O0O #line:4049
        O0O00O0O00O00OO0O ={}#line:4050
        super ().__init__ (O0O00O0O00O00OO0O )#line:4051
    def __setitem__ (OO00O00O000OO00O0 ,O0OOOOOOOOO00OO0O ,O000OOOOO0OOOOOO0 ):#line:4053
        super ().__setitem__ (O0OOOOOOOOO00OO0O ,O000OOOOO0OOOOOO0 )#line:4054
    def AddItem (O0000OOOOOO0OO0O0 ,OO00000O00O000OOO :TOvsFutQtBase ):#line:4056
        if O0000OOOOOO0OO0O0 .data .get (OO00000O00O000OOO .SettleMth )is None :#line:4057
            O0000000OO0O000O0 :TObjOvsFutBasMap =TObjOvsFutBasMap (OO00000O00O000OOO .SettleMth )#line:4058
            O0000000OO0O000O0 .AddItem (OO00000O00O000OOO )#line:4059
            O0000OOOOOO0OO0O0 [OO00000O00O000OOO .SettleMth ]=O0000000OO0O000O0 #line:4060
        else :#line:4061
            O0000000OO0O000O0 :TObjOvsFutBasMap =O0000OOOOOO0OO0O0 [OO00000O00O000OOO .SettleMth ]#line:4062
            O0000000OO0O000O0 .AddItem (OO00000O00O000OOO )#line:4063
        O0000OOOOOO0OO0O0 .data =dict (sorted (O0000OOOOOO0OO0O0 .data .items ()))#line:4064
class TObjOvsFutBasMap (UserDict ):#line:4066
    ""#line:4067
    def __init__ (O0000O00OOO00O00O ,O0OOO00O0O0OO0O00 :str ):#line:4069
        O0000O00OOO00O00O .SettleMth =O0OOO00O0O0OO0O00 #line:4070
        O000O00OOOO0O0O0O ={}#line:4071
        super ().__init__ (O000O00OOOO0O0O0O )#line:4072
    def __setitem__ (OO0OOO0O00O00O0O0 ,OO0000000O0O000OO ,O0OOOO00000000000 ):#line:4074
        super ().__setitem__ (OO0000000O0O000OO ,O0OOOO00000000000 )#line:4075
    def AddItem (O0O0O000000O0OOOO ,OO000OOO00OO0OO0O :TOvsFutQtBase ):#line:4077
        if O0O0O000000O0OOOO .data .get (OO000OOO00OO0OO0O .SolICE )is None :#line:4078
            O0O0O000000O0OOOO [OO000OOO00OO0OO0O .SolICE ]=OO000OOO00OO0OO0O #line:4079
class TObjBaseOvsFutExchageTree (UserDict ):#line:4081
    ""#line:4083
    fProdMthList :TObjOvsFutProdMthMap =TObjOvsFutProdMthMap ("","")#line:4084
    "Key=ProdID, Values=可交易月份們"#line:4085
    fMapSolICE ={}#line:4087
    "Key=SolICE Dictionary<string, TOvsFutQtBase>()"#line:4088
    def __init__ (O00O0O0O0O00O0O0O ):#line:4090
        OO00OOOO00O000OOO ={}#line:4091
        super ().__init__ (OO00OOOO00O000OOO )#line:4092
    def __setitem__ (O0O000O00OOOO00OO ,OOO0O000OO00O00O0 ,OO0OOOOO00OOO0OO0 ):#line:4094
        super ().__setitem__ (OOO0O000OO00O00O0 ,OO0OOOOO00OOO0OO0 )#line:4095
    def AddItem (OO0O000000O0000O0 ,O0OO00O000OOO0O00 :TOvsFutQtBase ):#line:4097
        if OO0O000000O0000O0 .data .get (O0OO00O000OOO0O00 .Exchange )is None :#line:4098
            O0OO00O00OOOOOOO0 =TObjOvsFutProdMthMap (O0OO00O000OOO0O00 .Exchange ,O0OO00O000OOO0O00 .ExchangeName )#line:4100
            OO0O000000O0000O0 [O0OO00O000OOO0O00 .Exchange ]=O0OO00O00OOOOOOO0 #line:4101
        else :#line:4102
            O0OO00O00OOOOOOO0 :TObjOvsFutMthList =OO0O000000O0000O0 [O0OO00O000OOO0O00 .Exchange ]#line:4103
            O0OO00O00OOOOOOO0 .AddItem (O0OO00O000OOO0O00 )#line:4104
    def SetInit (OOO00000OO00OO00O ):#line:4106
        try :#line:4107
            for OOO000OO00000OO0O in OOO00000OO00OO00O .values ():#line:4109
                OO00OOOOOO0OOOO00 :TObjOvsFutProdMthMap #line:4110
                OO00OOOOOO0OOOO00 =OOO000OO00000OO0O #line:4111
                O00O00O0OO00O000O :TObjOvsFutMthList =next (iter (OO00OOOOOO0OOOO00 .values ()),None )#line:4114
                if O00O00O0OO00O000O .ProdID in OOO00000OO00OO00O .fProdMthList :#line:4116
                    continue #line:4117
                OOO00000OO00OO00O .fProdMthList [O00O00O0OO00O000O .ProdID ]=O00O00O0OO00O000O #line:4120
                for OOOO0OO0000O0O0O0 in O00O00O0OO00O000O .values ():#line:4122
                    for O0000OOO0OO00O0O0 in OOOO0OO0000O0O0O0 .values ():#line:4123
                        OOO00000OO00OO00O .fMapSolICE [O0000OOO0OO00O0O0 .SolICE ]=O0000OOO0OO00O0O0 #line:4124
        except Exception as O0OO0O0O0000O0OO0 :#line:4125
            pass #line:4126
    def GetItem_BySolICE (O0OO0O00OO000OOO0 ,OO0OO00O00000OO00 :str ):#line:4128
        ""#line:4130
        O0OO0OOO00OOO0OOO =None #line:4131
        try :#line:4132
            if O0OO0O00OO000OOO0 .fMapSolICE .get (OO0OO00O00000OO00 )is not None :#line:4133
                O0OO0OOO00OOO0OOO =O0OO0O00OO000OOO0 .fMapSolICE [OO0OO00O00000OO00 ]#line:4134
                return True ,O0OO0OOO00OOO0OOO #line:4135
        except Exception as OOOOOOO0000O0000O :#line:4136
            pass #line:4137
        return False ,O0OO0OOO00OOO0OOO #line:4138
    def IsExists (OOOOO000O0O000O00 ,OOO00O0OO0OOOO000 :str ,O00O00000OO0OOO00 :str ):#line:4140
        try :#line:4141
            if OOOOO000O0O000O00 .fProdMthList .get (OOO00O0OO0OOOO000 )is not None :#line:4142
                if O00O00000OO0OOO00 in OOOOO000O0O000O00 .fProdMthList [OOO00O0OO0OOOO000 ]:#line:4143
                    return True #line:4144
        except Exception as OO0O0O000OOO00OO0 :#line:4145
            pass #line:4146
        return False #line:4147
    def GetExchangeAndProdList (O00OO00O0OOOOO00O ):#line:4149
        ""#line:4152
        O0OOOOO0OO000O0OO ={}#line:4153
        OOOO0O00OO0O00000 ={}#line:4154
        try :#line:4155
            for O00O0O0O0OO0O0O0O in O00OO00O0OOOOO00O .values ():#line:4157
                O0OOOOO0OO000O0OO [O00O0O0O0OO0O0O0O .Exchange ]=O00O0O0O0OO0O0O0O .ExchangeName #line:4158
                for O00O00000O0O000OO in O00O0O0O0OO0O0O0O .Values :#line:4159
                    OOOO0O00OO0O00000 [O00O00000O0O000OO .ProdName ]=O00O00000O0O000OO #line:4160
            return True ,O0OOOOO0OO000O0OO ,OOOO0O00OO0O00000 #line:4161
        except Exception as OOOO00OO00OO0OOO0 :#line:4163
            pass #line:4164
        return False ,O0OOOOO0OO000O0OO ,OOOO0O00OO0O00000 #line:4165
class ITQtRcvEventData :#line:4168
    SolIce :str #line:4169
    IsOK :bool #line:4170
    tmpRcvKind :TOvsFutQtRcvKind #line:4171
    tmpQt :TOvsFutQuoteData #line:4172
class TQtRcvEventData (ITQtRcvEventData ):#line:4174
    def __init__ (O0OO00OO0O0O0OOO0 )->None :#line:4175
        O0OO00OO0O0O0OOO0 .SolIce =""#line:4176
        O0OO00OO0O0O0OOO0 .IsOK =False #line:4177
        O0OO00OO0O0O0OOO0 .tmpQt =None #line:4178
        super ().__init__ ()#line:4179
    def SetRcvBAS_Succ (OO000O000OOO0O0O0 ,O00000OOO00OO0000 :str ,OOOO0O0O00O0O00O0 :TOvsFutQuoteData ):#line:4181
        OO000O000OOO0O0O0 .IsOK =True #line:4182
        OO000O000OOO0O0O0 .SolIce =O00000OOO00OO0000 #line:4183
        OO000O000OOO0O0O0 .tmpRcvKind =TOvsFutQtRcvKind .pkQtRcv_BAS #line:4184
        OO000O000OOO0O0O0 .tmpQt =OOOO0O0O00O0O00O0 #line:4185
    def SetRcvBAS_Fail (O0OOO00OO0000OO0O ,O00OOO0O0OOO00O0O :str ):#line:4187
        O0OOO00OO0000OO0O .IsOK =False #line:4188
        O0OOO00OO0000OO0O .SolIce =O00OOO0O0OOO00O0O #line:4189
        O0OOO00OO0000OO0O .tmpRcvKind =TOvsFutQtRcvKind .pkQtRcv_BAS #line:4190
class ServiceEventHandler (ReconnectionListener ,ReconnectionAttemptListener ,ServiceInterruptionListener ):#line:4195
    def __init__ (O0O00000O000O0O0O ,O0OO00O0OOO00O0OO :callable )->None :#line:4196
        O0O00000O000O0O0O ._callbackInterrupt =O0OO00O0OOO00O0OO #line:4197
        super ().__init__ ()#line:4198
    def on_reconnected (OOOO00OO0O00O000O ,O00OOO000OO000000 :ServiceEvent ):#line:4200
        print ("\non_reconnected")#line:4201
        print (f"Error cause: {O00OOO000OO000000.get_cause()}")#line:4202
        print (f"Message: {O00OOO000OO000000.get_message()}")#line:4203
    def on_reconnecting (O0O0000O000OOOO0O ,O00O0O0O0OO00OO0O :"ServiceEvent"):#line:4205
        print ("\non_reconnecting")#line:4206
        print (f"Error cause: {O00O0O0O0OO00OO0O.get_cause()}")#line:4207
        print (f"Message: {O00O0O0O0OO00OO0O.get_message()}")#line:4208
    def on_service_interrupted (OOOOOOOOOO0O0OO00 ,OOOOOOOOOO000OO00 :"ServiceEvent"):#line:4210
        OOOOOOOOOO0O0OO00 ._callbackInterrupt (f"Error cause: {OOOOOOOOOO000OO00.get_cause()} Message: {OOOOOOOOOO000OO00.get_message()}")#line:4214
class TerminationNotificationHandler (TerminationNotificationListener ):#line:4216
    def __init__ (OOO00OOO0O0O0O0O0 ,OOO0O0O000O00O000 :callable )->None :#line:4217
        OOO00OOO0O0O0O0O0 ._callbackfunc =OOO0O0O000O00O000 #line:4218
        super ().__init__ ()#line:4219
    def on_termination (O0O00OOOO0O0O0OO0 ,O00OO0O00OOO0OOOO :'TerminationNotificationEvent'):#line:4220
        O0O00OOOO0O0O0OO0 ._callbackfunc (f"Error cause:{O00OO0O00OOO0OOOO.cause()} Message:{O00OO0O00OOO0OOOO.message}")#line:4222
class TCacheJobMap (UserDict ):#line:4224
    ""#line:4225
    _Lock =Lock ()#line:4226
    def __init__ (O0OO0O00OO0O0OOO0 ,mapping =None ,**O0OO000OOOO0OO00O ):#line:4227
        if mapping is not None :#line:4228
            mapping ={str (OOO00000O00OOO0OO ).upper ():O0000000O0O00OO00 for OOO00000O00OOO0OO ,O0000000O0O00OO00 in mapping .items ()}#line:4231
        else :#line:4232
            mapping ={}#line:4233
        if O0OO000OOOO0OO00O :#line:4234
            mapping .update ({str (O000O00O00OO0OO0O ).upper ():OO0O0O0OOO00OO0O0 for O000O00O00OO0OO0O ,OO0O0O0OOO00OO0O0 in O0OO000OOOO0OO00O .items ()})#line:4237
        super ().__init__ (mapping )#line:4238
    def __setitem__ (O0O0O00OO0OO0OOOO ,O0OO00O0OOO0OO0O0 ,OO000OOO0OO0000O0 ):#line:4240
        super ().__setitem__ (O0OO00O0OOO0OO0O0 ,OO000OOO0OO0000O0 )#line:4241
    def IsExists (OOO0000OO000O00OO ,O000O0O0000OOO0O0 )->bool :#line:4244
        with OOO0000OO000O00OO ._Lock :#line:4245
            if OOO0000OO000O00OO .data .get (O000O0O0000OOO0O0 )is None :#line:4246
                return False #line:4247
            else :#line:4248
                return True #line:4249
    def AddRcvData (OOOO00000OO00000O ,O00000OO000O0000O :'InboundMessage')->bool :#line:4251
        with OOOO00000OO00000O ._Lock :#line:4253
            if OOOO00000OO00000O .data .get (O00000OO000O0000O .get_cache_request_id ())is None :#line:4254
                return False #line:4255
            else :#line:4256
                OOOO00000OO00000O .data [O00000OO000O0000O .get_cache_request_id ()]=O00000OO000O0000O #line:4257
                return True #line:4258
    def DeleteJob (O0O0OO0O000O0O000 ,O0OOOOOOOOOO0O000 )->bool :#line:4260
        ""#line:4261
        OOO0O00OOO0OO00OO =None #line:4262
        with O0O0OO0O000O0O000 ._Lock :#line:4263
            if O0O0OO0O000O0O000 .data .get (O0OOOOOOOOOO0O000 )is None :#line:4264
                return False ,None #line:4265
            else :#line:4266
                OOO0O00OOO0OO00OO =O0O0OO0O000O0O000 .data .pop (O0OOOOOOOOOO0O000 )#line:4267
                return True ,OOO0O00OOO0OO00OO #line:4268
class TCacheJob :#line:4270
    def __init__ (OO0O00OO0OO0O0O0O )->None :#line:4272
        OO0O00OO0OO0O0O0O .RequestID :int =0 #line:4273
        OO0O00OO0OO0O0O0O .prod :str =""#line:4274
        OO0O00OO0OO0O0O0O .oneProd :bool =True #line:4275
        OO0O00OO0OO0O0O0O .TopicBAS :str =""#line:4276
        OO0O00OO0OO0O0O0O .TopicHL :str =""#line:4277
        OO0O00OO0OO0O0O0O .TopicTX :str =""#line:4278
        OO0O00OO0OO0O0O0O .HandleProc :callable =None #line:4279
        OO0O00OO0OO0O0O0O .CacheData :dict ={}#line:4280
        OO0O00OO0OO0O0O0O .Params :dict ={}#line:4281
        OO0O00OO0OO0O0O0O .fTotCnt =10 #line:4283
        OO0O00OO0OO0O0O0O .fCurCnt =0 #line:4284
    def ReSet (OOOOOO000OOO0OOO0 )->bool :#line:4286
        ""#line:4287
        OO0O00OO0OOO00O00 =""#line:4288
        if OOOOOO000OOO0OOO0 .fCurCnt >=OOOOOO000OOO0OOO0 .fTotCnt :#line:4289
            OO0O00OO0OOO00O00 =f"已超過總執行次數:{OOOOOO000OOO0OOO0.fTotCnt}"#line:4290
            return False ,OO0O00OO0OOO00O00 #line:4291
        OOOOOO000OOO0OOO0 .fCurCnt +=1 #line:4293
        return True ,""#line:4296
class SolAPI :#line:4299
    __OOOOOO00000OO00OO ='solacelink.json'#line:4301
    __OOO0O00OOOOO0O0O0 ='solaceProperties'#line:4303
    __O0O00O0O0OO0O00OO =os .path .join (dirname (__file__ ),__OOOOOO00000OO00OO )#line:4305
    _fPrdSnapshotMap :TMapPrdSnapshot =TMapPrdSnapshot ()#line:4309
    _fPrdOvsMap :TMapPrdOvs =TMapPrdOvs ()#line:4310
    _fMapQuoteSTK :TObjStkQuoteMap =TObjStkQuoteMap ()#line:4312
    _fMapQuoteFUT :TObjFutQuoteMap =TObjFutQuoteMap ()#line:4313
    _fMapQuoteOvsFUT :TObjOvsFutQuoteMap =TObjOvsFutQuoteMap ()#line:4314
    def __init__ (O00000OO0000O000O ,__O0OO000OOO0O0OOO0 :MarketDataMart ,O0OO00OOO0000OO00 :str ,aRcvUseList :bool =False ,loglv =logging .INFO ,conlv =logging .INFO ):#line:4316
        ""#line:4317
        O00000OO0000O000O .__OOOO00000000O00OO =None #line:4320
        O00000OO0000O000O .__O0000O0OO0OO00O00 =None #line:4321
        O00000OO0000O000O .__O0O0O0000OO0O0O00 =None #line:4322
        O00000OO0000O000O .__O0OO000O000OO000O =None #line:4323
        O00000OO0000O000O .__OOOOOO000000O0O00 =aRcvUseList #line:4324
        O00000OO0000O000O .__O0OO000OOO0O0OOO0 :MarketDataMart =__O0OO000OOO0O0OOO0 #line:4325
        O00000OO0000O000O ._pypath =O0OO00OOO0000OO00 #line:4326
        O00000OO0000O000O ._is_connected =False #line:4327
        O00000OO0000O000O ._lock =Lock ()#line:4328
        O00000OO0000O000O ._lockQtTX_Stk =Lock ()#line:4329
        O00000OO0000O000O ._lockQtTX_Fut =Lock ()#line:4330
        O00000OO0000O000O ._lockQtIDX_Stk =Lock ()#line:4331
        O00000OO0000O000O ._lockQtIDX_Fut =Lock ()#line:4332
        O00000OO0000O000O ._fMapQuoteSTK .DefProc_TX =O00000OO0000O000O .__OOO0OOO000O0O0OOO #line:4335
        O00000OO0000O000O ._fMapQuoteSTK .DefProc_5Q =O00000OO0000O000O .__OO00OOOOO0000O00O #line:4336
        O00000OO0000O000O ._fMapQuoteSTK .DefProc_Idx =O00000OO0000O000O .__OO0000OO0O00000OO #line:4337
        O00000OO0000O000O .__OO00O00OOOO000O0O =O00000OO0000O000O .__O0O0O0OO0OOO00000 #line:4338
        O00000OO0000O000O .__O0O00OOOO0000OO0O =O00000OO0000O000O .__OOOO00OOO000000O0 #line:4339
        O00000OO0000O000O .__O00OOOO0OOO000O0O =O00000OO0000O000O .__OOO0O0OOO00O0OO0O #line:4340
        O00000OO0000O000O .__O0O0O00OOOO00OOOO =O00000OO0000O000O .__OO000O00000O0000O #line:4341
        O00000OO0000O000O .__O000OO00O0O000OO0 =O00000OO0000O000O .__O00O0OOO0000OO000 #line:4342
        O00000OO0000O000O ._fMapCacheJob =TCacheJobMap ()#line:4345
        O00000OO0000O000O ._last_ReqID =0 #line:4346
        O00000OO0000O000O ._lock_ReqID =Lock ()#line:4347
        O00000OO0000O000O ._fMapQuoteFUT .DefProc_TX =O00000OO0000O000O .__OO000000000O000OO #line:4348
        O00000OO0000O000O ._fMapQuoteFUT .DefProc_5Q =O00000OO0000O000O .__O0O000O000O0OOOOO #line:4349
        O00000OO0000O000O ._fMapQuoteFUT .DefProc_5QTOT =O00000OO0000O000O .__O0OO0OO0O0O0O0O00 #line:4350
        O00000OO0000O000O ._fMapQuoteFUT .DefProc_BAS =O00000OO0000O000O .__O0OO0O0O00OOOOOOO #line:4351
        O00000OO0000O000O .__OOOO0000OO000OO0O =O00000OO0000O000O .__OOO00O0O0O00OOO0O #line:4352
        O00000OO0000O000O .__O00O00OOO00O0O000 =O00000OO0000O000O .__OOO0O0O00OO0OO000 #line:4353
        O00000OO0000O000O .__OOO0OOOOOO000OO00 =O00000OO0000O000O .__OOO0OOO000O000OOO #line:4354
        O00000OO0000O000O .__O0O00O0OO0OO0O0OO =O00000OO0000O000O .__O00000O0O0O00OOOO #line:4355
        O00000OO0000O000O .__O0O0O0OO0O00OOOO0 =O00000OO0000O000O .__O000000O0000O0OOO #line:4356
        O00000OO0000O000O .__OOO0OO000OO0OO000 =O00000OO0000O000O .__O0OO0O00O00O00O00 #line:4357
        O00000OO0000O000O ._fMapQuoteOvsFUT .DefProc_TX =O00000OO0000O000O .__OO0OOO0OO0OO0OO00 #line:4359
        O00000OO0000O000O ._fMapQuoteOvsFUT .DefProc_5Q =O00000OO0000O000O .__O0OO00000OOO0OO00 #line:4360
        O00000OO0000O000O .__OO0O0O0OO00O0OO0O =O00000OO0000O000O .__O0O0000OOOO00OO00 #line:4361
        O00000OO0000O000O .__OOOO0O0O000OO0000 =O00000OO0000O000O .__O000O000000O00OO0 #line:4362
        O00000OO0000O000O .__O0OO0O0O0O00O0000 =O00000OO0000O000O .__O00O00O00O0OO0O00 #line:4363
        O00000OO0000O000O ._message_service :MessagingService #line:4365
        O00000OO0000O000O ._message_receiver :DirectMessageReceiver #line:4366
        O00000OO0000O000O ._message_requester :RequestReplyMessagePublisher #line:4368
        O00000OO0000O000O ._loglv =loglv #line:4369
        O00000OO0000O000O ._conlv =conlv #line:4370
        O00000OO0000O000O ._log =SolaceLog (O00000OO0000O000O ._pypath ,loglv ,conlv )#line:4371
        O00000OO0000O000O ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"pypath:{O0OO00OOO0000OO00}, aRcvUseList:{aRcvUseList}, loglv:{loglv} conlv:{conlv}")#line:4372
        O00000OO0000O000O ._reply_timeout =120000 #line:4378
        O00000OO0000O000O ._vRcvTopic_Stk ="Quote_TWS_RECOVER"#line:4379
        "證券回補TOPIC"#line:4380
        O00000OO0000O000O ._vRcvTopic_Stk_Req ="Quote_TWS_REQ"#line:4381
        "收到證券回補TOPIC"#line:4382
        O00000OO0000O000O ._vRcvTopic_Fut ="Quote_TWF_RECOVER"#line:4383
        "期貨回補TOPIC"#line:4384
        O00000OO0000O000O ._vRcvTopic_Fut_Req ="Quote_TWF_REQ"#line:4385
        "收到期貨回補TOPIC"#line:4386
        O00000OO0000O000O ._vRcvTopic_OvsFut ="QuoteOvs_RECOVER"#line:4387
        "海期貨回補TOPIC"#line:4388
        O00000OO0000O000O ._vRcvTopic_OvsFut_Req ="QuoteOvs_REQ"#line:4389
        "收到海期貨回補TOPIC"#line:4390
        O00000OO0000O000O ._vExchange =""#line:4391
        O00000OO0000O000O .__OO0OOO0O0OOOO0O0O ="Idx"#line:4392
        O00000OO0000O000O ._vQuote_FUT ="Quote/TWF/"#line:4393
        O00000OO0000O000O ._vQuote_STK ="Quote/TWS/"#line:4394
        O00000OO0000O000O ._vQuote_OvsFUT ="QuoteOvs/"#line:4395
        O00000OO0000O000O ._vQuote_BAS ="/BAS"#line:4396
        O00000OO0000O000O ._vQuote_HL ="/HL"#line:4397
    def GetRequestID (OO0O0OO0O00O00OOO ):#line:4399
        try :#line:4400
            with OO0O0OO0O00O00OOO ._lock_ReqID :#line:4401
                OO00O0000000O0000 =int (datetime .now ().strftime ("%y%m%d%H%M%S%f"))#line:4402
                if OO00O0000000O0000 <=OO0O0OO0O00O00OOO ._last_ReqID :#line:4403
                    OO00O0000000O0000 =OO0O0OO0O00O00OOO ._last_ReqID +1 #line:4404
                OO0O0OO0O00O00OOO ._last_ReqID =OO00O0000000O0000 #line:4405
                return OO00O0000000O0000 #line:4406
        except Exception as OOO0O0OO00000O0OO :#line:4407
            OO0O0OO0O00O00OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Error GetRequestID: {OOO0O0OO00000O0OO}")#line:4408
    def __O0O000OOO00O000OO ():#line:4410
        try :#line:4411
            with open (SolAPI .__O0O00O0O0OO0O00OO ,'r')as OOOO00OO0O0O0OOOO :#line:4412
                OOOOOO0O000000OOO =OOOO00OO0O0O0OOOO .read ()#line:4413
            return json .loads (OOOOOO0O000000OOO )#line:4415
        except Exception as O000O0OOOO0OO0O00 :#line:4416
            raise Exception (f"Unable to read JSON in file: {SolAPI.__external_file_full_path}. Exception: {O000O0OOOO0OO0O00}")#line:4417
    def __OOOO00O000OO0000O (OO0OOOOOOO0O0OOOO :dict ):#line:4419
        if SolAPI .__OOO0O00OOOOO0O0O0 not in OO0OOOOOOO0O0OOOO :#line:4420
            print (f'Solbroker details in [{SolAPI.__properties_from_external_file_name}] is unavailable, unable to find KEY: [{SolAPI.__solbroker_properties_key}]. Refer README...')#line:4421
        O0OO0O0OOOOOOOO00 =OO0OOOOOOO0O0OOOO [SolAPI .__OOO0O00OOOOO0O0O0 ]#line:4423
        return O0OO0O0OOOOOOOO00 #line:4425
    __OO00O00OOOO000O0O :callable =None #line:4430
    __OOOO0000OO000OO0O :callable =None #line:4431
    __OO0O0O0OO00O0OO0O :callable =None #line:4432
    def __OOO000O00OOOO00O0 (OOOO0OOOOO0OOO00O ,O0O00O0O0O0OOOOOO :STKxFUT ,O0000O0OO0OO0OOO0 ):#line:4434
        ""#line:4436
        if O0O00O0O0O0OOOOOO ==STKxFUT .STK :#line:4437
            if OOOO0OOOOO0OOO00O .__OO00O00OOOO000O0O ==None :#line:4438
                return #line:4439
            OO0O000OO0000000O :TObjStkQuoteMap =O0000O0OO0OO0OOO0 #line:4440
            OOOO0OOOOO0OOO00O .__OO00O00OOOO000O0O ("STK",True ,OO0O000OO0000000O )#line:4441
        elif O0O00O0O0O0OOOOOO ==STKxFUT .FUT :#line:4442
            if OOOO0OOOOO0OOO00O .__OOOO0000OO000OO0O ==None :#line:4443
                return #line:4444
            OO0O000OO0000000O :TObjFutQuoteMap =O0000O0OO0OO0OOO0 #line:4445
            OOOO0OOOOO0OOO00O .__OOOO0000OO000OO0O ("FUT",True ,OO0O000OO0000000O )#line:4446
        elif O0O00O0O0O0OOOOOO ==STKxFUT .OVSFUT :#line:4447
            if OOOO0OOOOO0OOO00O .__OO0O0O0OO00O0OO0O ==None :#line:4448
                return #line:4449
            OO0O000OO0000000O :TQtRcvEventData =O0000O0OO0OO0OOO0 #line:4450
            if OO0O000OO0000000O .IsOK :#line:4451
                OOOO0OOOOO0OOO00O .__OO0O0O0OO00O0OO0O (OOOO0OOOOO0OOO00O ,OO0O000OO0000000O .SolIce ,OO0O000OO0000000O .IsOK ,OO0O000OO0000000O .tmpRcvKind ,OO0O000OO0000000O .tmpQt )#line:4453
            else :#line:4454
                OOOO0OOOOO0OOO00O .__OO0O0O0OO00O0OO0O (OOOO0OOOOO0OOO00O ,OO0O000OO0000000O .SolIce ,OO0O000OO0000000O .IsOK ,OO0O000OO0000000O .tmpRcvKind ,None )#line:4456
    def __O0000O0O0000OOO00 (OOO0OO00OO0OOO000 ,O00OO0OOO0OOOOOO0 :STKxFUT ,O00O0OOO0OO00000O :str ):#line:4458
        if O00OO0OOO0OOOOOO0 ==STKxFUT .STK :#line:4459
            if OOO0OO00OO0OOO000 .__OO00O00OOOO000O0O ==None :#line:4460
                return #line:4461
            OOO0OO00OO0OOO000 .__OO00O00OOOO000O0O (O00O0OOO0OO00000O ,False ,None )#line:4462
        elif O00OO0OOO0OOOOOO0 ==STKxFUT .FUT :#line:4463
            if OOO0OO00OO0OOO000 .__OOOO0000OO000OO0O ==None :#line:4464
                return #line:4465
            OOO0OO00OO0OOO000 .__OOOO0000OO000OO0O (O00O0OOO0OO00000O ,False ,None )#line:4466
        elif O00OO0OOO0OOOOOO0 ==STKxFUT .OVSFUT :#line:4467
            if OOO0OO00OO0OOO000 .__OO0O0O0OO00O0OO0O ==None :#line:4468
                return #line:4469
            pass #line:4470
    __O0O00OOOO0000OO0O :callable =None #line:4473
    def Set_OnQtIdxRcvEventSTK (O0OO000000O000OO0 ,OO00O0O00OOO0O0O0 :callable ):#line:4475
        O0OO000000O000OO0 .__O0O00OOOO0000OO0O =OO00O0O00OOO0O0O0 #line:4476
    def __OOOOO000OO0O0O00O (O0OOO00O0OOOOOO0O ,OOO00OOOO000000O0 :TObjStkQuoteMap ):#line:4478
        if O0OOO00O0OOOOOO0O .__O0O00OOOO0000OO0O ==None :#line:4479
            return #line:4480
        O0OOO00O0OOOOOO0O .__O0O00OOOO0000OO0O ("STKIdx",True ,OOO00OOOO000000O0 )#line:4481
    def __O0O00O0O0OO000O00 (OO00O00O00OO0O00O ,OOOO00OO0O0O0O0O0 :str ):#line:4483
        if OO00O00O00OO0O00O .OnQtIdxRcvEvent ==None :#line:4484
            return #line:4485
        OO00O00O00OO0O00O .OnQtIdxRcvEvent (OO00O00O00OO0O00O ,OOOO00OO0O0O0O0O0 ,False ,None )#line:4486
    __O00OOOO0OOO000O0O :callable =None #line:4490
    """QtTXEventHandler"""#line:4491
    def Set_OnQtTXEventSTK (OOO000000OO0O0OO0 ,O0O0O0O0O0OOOO00O :callable ):#line:4493
        OOO000000OO0O0OO0 .__O00OOOO0OOO000O0O =O0O0O0O0O0OOOO00O #line:4494
    def __O0OO0OO0O00O0O00O (O000O0O00000OO0OO ,O0OO0OOO00000000O :str ,OO0O0000OOOO00OO0 :TStkQtTX ):#line:4496
        if O000O0O00000OO0OO .__O00OOOO0OOO000O0O ==None :#line:4497
            return #line:4498
        O000O0O00000OO0OO .__O00OOOO0OOO000O0O (O0OO0OOO00000000O ,OO0O0000OOOO00OO0 )#line:4499
    def __OOO00O0O0O00OOO0O (O0OOO000000000O0O ,O0O0OOO000OOOO000 :str ,OOOO0O0O00OOOOOO0 :bool ,OO0O00OO000O0OO0O :TObjFutQuoteMap ):#line:4501
        ""#line:4502
        if OOOO0O0O00OOOOOO0 ==False :#line:4504
            O0OOO000000000O0O ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[期貨行情回補]{O0O0OOO000OOOO000}回補失敗!")#line:4505
            return #line:4506
        try :#line:4507
            for O0OO000O00O0000O0 ,O0O0O0OO000O000OO in OO0O00OO000O0OO0O .items ():#line:4508
                O0O00O0OOOO0OOO00 :TFutQuoteData =O0O0O0OO000O000OO #line:4509
                O00000OO0O00O0OO0 =O0O00O0OOOO0OOO00 .BAS .OrdProdID #line:4510
                if O0OOO000000000O0O ._fPrdSnapshotMap .NewItemFut (O00000OO0O00O0OO0 ,O0O00O0OOOO0OOO00 ):#line:4511
                    OO0000OOO00O0000O :ProductSnapshot =O0OOO000000000O0O ._fPrdSnapshotMap [O00000OO0O00O0OO0 ]#line:4513
                    if O0O00O0OOOO0OOO00 .UpdateBAS :#line:4514
                        O0OOO000000000O0O .__O0OO000OOO0O0OOO0 .Fire_OnUpdateBasic (OO0000OOO00O0000O .BasicData )#line:4515
                        O0O00O0OOOO0OOO00 .UpdateBAS =False #line:4516
                    if O0O00O0OOOO0OOO00 .UpdateHL :#line:4517
                        OO0000OOO00O0000O .TickData =ProductTick_Fut (O0O00O0OOOO0OOO00 )#line:4518
                        O0OOO000000000O0O .__O0OO000OOO0O0OOO0 .Fire_OnUpdateLastSnapshot (O0OOO000000000O0O ._fPrdSnapshotMap [O00000OO0O00O0OO0 ])#line:4519
                        O0O00O0OOOO0OOO00 .UpdateHL =False #line:4520
        except Exception as OOOOOOOO00OO00000 :#line:4525
            O0OOO000000000O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteFutApi_OnQtRcvEvent]aMsg={O0O0OOO000OOOO000}, aIsOK={OOOO0O0O00OOOOOO0}, ex:{OOOOOOOO00OO00000}")#line:4526
    def __OOO0O0O00OO0OO000 (OOO0O00O00000OOO0 ,OO0OO0O0OO0O0OOOO :str ,OOOOOO00O000OOO00 :TFutQtTX ):#line:4528
        ""#line:4529
        try :#line:4530
            O0O000O00O0OOOOO0 :ProductSnapshot =None #line:4531
            OOOOO0O0O000O00O0 ,O0O000O00O0OOOOO0 =OOO0O00O00000OOO0 ._fPrdSnapshotMap .GetItem (OO0OO0O0OO0O0OOOO )#line:4533
            if OOOOO0O0O000O00O0 :#line:4534
                OOO0OOOO0OOOO0OOO :ProductTick_Fut =O0O000O00O0OOOOO0 .TickData #line:4536
                if OOO0OOOO0OOOO0OOO .Upt_TX (OOOOOO00O000OOO00 ):#line:4538
                    OOO0O00O00000OOO0 .__O0OO000OOO0O0OOO0 .Fire_OnMatch (OOO0O00O00000OOO0 ._fPrdSnapshotMap [OO0OO0O0OO0O0OOOO ].TickData )#line:4539
        except Exception as OO000000OOO0O0O0O :#line:4541
            OOO0O00O00000OOO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteFutApi_OnQtTXEvent]ProdID={OO0OO0O0OO0O0OOOO}, ex:{OO000000OOO0O0O0O}")#line:4542
    def __OOO0OOO000O000OOO (OOO0OOOO0O00O0O0O ,O00OO0O0O00O00O0O :str ,O00O0OOOOOO0O0000 :TFutQt5Q ):#line:4544
        ""#line:4545
        try :#line:4546
            O0O0O0OO0O0O0000O :ProductSnapshot =None #line:4547
            OO0OO00O0O00OOO00 ,O0O0O0OO0O0O0000O =OOO0OOOO0O00O0O0O ._fPrdSnapshotMap .GetItem (O00OO0O0O00O00O0O )#line:4549
            if OO0OO00O0O00OOO00 :#line:4550
                O0O0O00000O00OOO0 :ProductTick_Fut =O0O0O0OO0O0O0000O .TickData #line:4551
                if O0O0O00000O00OOO0 .Upt_5Q (O00O0OOOOOO0O0000 ):#line:4553
                    OOO0OOOO0O00O0O0O .__O0OO000OOO0O0OOO0 .Fire_OnOrderBook (OOO0OOOO0O00O0O0O ._fPrdSnapshotMap [O00OO0O0O00O00O0O ].TickData )#line:4554
        except Exception as O00OOOOOO00O00000 :#line:4556
         OOO0OOOO0O00O0O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteFutApi_OnQt5QEvent]ProdID={O00OO0O0O00O00O0O}, ex:{O00OOOOOO00O00000}")#line:4557
    def __O00000O0O0O00OOOO (OOOOOOOOO0O0O0OO0 ,O0000000O00O00000 :str ,OOOOOO00O00O0000O :TFutQt5QTOT ):#line:4559
        ""#line:4560
        try :#line:4561
            O0O0O000O0O0O00O0 :ProductSnapshot =None #line:4562
            O00O0000OOO0OOO00 ,O0O0O000O0O0O00O0 =OOOOOOOOO0O0O0OO0 ._fPrdSnapshotMap .GetItem (O0000000O00O00000 )#line:4564
            if O00O0000OOO0OOO00 :#line:4565
                O0O00O0O0000000O0 :ProductTick_Fut =O0O0O000O0O0O00O0 .TickData #line:4566
                if O0O00O0O0000000O0 .Upt_5QTOT (OOOOOO00O00O0000O ):#line:4568
                    OOOOOOOOO0O0O0OO0 .__O0OO000OOO0O0OOO0 .Fire_OnUpdateTotalOrderQty (OOOOOOOOO0O0O0OO0 ._fPrdSnapshotMap [O0000000O00O00000 ].TickData )#line:4569
        except Exception as O0OO0OO000000000O :#line:4571
            OOOOOOOOO0O0O0OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteFutApi_OnQt5QTOTEvent]ProdID={O0000000O00O00000}, ex:{O0OO0OO000000000O}")#line:4572
    def __O000000O0000O0OOO (O00OO0OOO0OOO0O00 ,OOOOO0O00OO0OOOO0 :str ,O00OO0O00OOO0O00O :TFutQtIDX ):#line:4573
        try :#line:4574
            pass #line:4575
        except Exception as O00O0000000O0O0OO :#line:4581
            O00OO0OOO0OOO0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteFutApi_OnQtIDXEvent]ProdID={OOOOO0O00OO0OOOO0}, ex:{O00O0000000O0O0OO}")#line:4582
    def __O0OO0O00O00O00O00 (OO0O00OOOOO0O0OO0 ,OOO0O0O000OO000OO :str ,OO0O00OO0000O0O00 :TFutQtBase ):#line:4583
        ""#line:4584
        try :#line:4585
            pass #line:4586
        except Exception as OOOOOOO0OO0000O00 :#line:4603
            pass #line:4604
    def __O0O0000OOOO00OO00 (OO0O00OOOOO0OOO00 ,OOO0O0OOO0OO0OO0O :ITQtRcvEventData ):#line:4606
        if OOO0O0OOO0OO0OO0O ==None :#line:4607
            OO0O00OOOOO0OOO00 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[海期行情回補] 回補失敗!")#line:4608
            return #line:4609
        if OOO0O0OOO0OO0OO0O .IsOK ==False :#line:4610
            OO0O00OOOOO0OOO00 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[海期行情回補]{OOO0O0OOO0OO0OO0O.SolIce}回補失敗!")#line:4611
            return #line:4612
        try :#line:4613
            if OO0O00OOOOO0OOO00 ._fPrdOvsMap .NewItem (OOO0O0OOO0OO0OO0O .QtMap ):#line:4614
                OO0O00OOOOO0OOO00 .__O0OO000OOO0O0OOO0 .Fire_OnUpdateOvsBasic (OOO0O0OOO0OO0OO0O .QtMap )#line:4615
        except Exception as OO0OOOO00O00O00O0 :#line:4617
            OO0O00OOOOO0OOO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteOvsFutAPI_OnQtRcvEvent]aSolIce={OOO0O0OOO0OO0OO0O.SolIce}, aIsOK={OOO0O0OOO0OO0OO0O.IsOK}, ex:{OO0OOOO00O00O00O0}")#line:4618
    def __O000O000000O00OO0 (OO0OO00O000OO00O0 ,O00OO00O0000O0O00 :str ,O0000O0OO0O00OOO0 :TOvsFutQtTX ):#line:4619
        try :#line:4620
            OO0O0O00OOO00O0O0 :TOvsFutQuoteData =None #line:4621
            OO00O000OO00O00O0 ,OO0O0O00OOO00O0O0 =OO0OO00O000OO00O0 ._fPrdOvsMap .GetItem (O00OO00O0000O0O00 )#line:4623
            if OO00O000OO00O00O0 :#line:4624
                OO0O0O00OOO00O0O0 .QtTX =O0000O0OO0O00OOO0 #line:4625
                OO0OO00O000OO00O0 .__O0OO000OOO0O0OOO0 .Fire_OnUpdateOvsMatch (OO0O0O00OOO00O0O0 )#line:4626
        except Exception as O0O00OOO0OO00OOOO :#line:4627
            OO0OO00O000OO00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteOvsFutAPI_OnQtTXEvent]ProdID={O00OO00O0000O0O00}, ex:{O0O00OOO0OO00OOOO}")#line:4628
    def __O00O00O00O0OO0O00 (OOO00OOOO00OO0000 ,O00O0OO0OOO0O00O0 :str ,O0OOOOOO00000O0O0 :TOvsFutQt5Q ):#line:4629
        try :#line:4630
            O0OO00000O00000OO :TOvsFutQuoteData =None #line:4631
            O000OOOO0000O0OOO ,O0OO00000O00000OO =OOO00OOOO00OO0000 ._fPrdOvsMap .GetItem (O00O0OO0OOO0O00O0 )#line:4633
            if O000OOOO0000O0OOO :#line:4634
                O0OO00000O00000OO .Qt5Q =O0OOOOOO00000O0O0 #line:4635
                OOO00OOOO00OO0000 .__O0OO000OOO0O0OOO0 .Fire_OnUpdateOvsOrderBook (O0OO00000O00000OO )#line:4636
        except Exception as OOOO00OO0O00O0OO0 :#line:4637
            OOO00OOOO00OO0000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteStkAPI_OnQt5QEvent]ProdID={O00O0OO0OOO0O00O0}, ex:{OOOO00OO0O00O0OO0}")#line:4638
    __O00O00OOO00O0O000 :callable =None #line:4642
    def Set_OnQtTXEventFUT (O0OO00OOOO00O000O ,O000O0OO000OOO0OO :callable ):#line:4644
        O0OO00OOOO00O000O .__O00O00OOO00O0O000 =O000O0OO000OOO0OO #line:4645
    def __O00O0000O000OO000 (OO00OOO0O00O0OOOO ,O0O000OO00OOO0O00 :str ,O0OO0000000O0O0O0 :TFutQtTX ):#line:4647
        if OO00OOO0O00O0OOOO .__O00O00OOO00O0O000 ==None :#line:4648
            return #line:4649
        OO00OOO0O00O0OOOO .__O00O00OOO00O0O000 (O0O000OO00OOO0O00 ,O0OO0000000O0O0O0 )#line:4651
    __OOOO0O0O000OO0000 :callable =None #line:4654
    def Set_OnQtTXEventOvsFUT (OOO0000OO00OO000O ,O0OOOOO00O0O000OO :callable ):#line:4656
        OOO0000OO00OO000O .__OOOO0O0O000OO0000 =O0OOOOO00O0O000OO #line:4657
    def __O0OO0O0OOOO0000O0 (O00O000O000O0O0OO ,OOOO0OOO00OO000OO :str ,O0000O000O0O0OO0O :TOvsFutQtTX ):#line:4659
        if O00O000O000O0O0OO .__OOOO0O0O000OO0000 ==None :#line:4660
            return #line:4661
        O00O000O000O0O0OO .__OOOO0O0O000OO0000 (OOOO0OOO00OO000OO ,O0000O000O0O0OO0O )#line:4662
    __O0O0O00OOOO00OOOO :callable =None #line:4666
    """Qt5QEventHandler"""#line:4667
    def Set_OnQt5QEventSTK (O0O0OOOOO0OOOOO00 ,OO00O0OOOO0000O0O :callable ):#line:4669
        O0O0OOOOO0OOOOO00 .__O0O0O00OOOO00OOOO =OO00O0OOOO0000O0O #line:4670
    def __OOO0OOO0O000O0O00 (OO0O00OOOOOOO000O ,O0OO00OOOOO0O000O :str ,O00OO000000000OO0 :TStkQt5Q ):#line:4672
        if OO0O00OOOOOOO000O .__O0O0O00OOOO00OOOO ==None :#line:4673
            return #line:4674
        OO0O00OOOOOOO000O .__O0O0O00OOOO00OOOO (O0OO00OOOOO0O000O ,O00OO000000000OO0 )#line:4675
    __OOO0OOOOOO000OO00 :callable =None #line:4678
    def Set_OnQt5QEventFUT (OO0OOO0O0OO000O0O ,OOOOO0O0O0OO0O00O :callable ):#line:4680
        OO0OOO0O0OO000O0O .__OOO0OOOOOO000OO00 =OOOOO0O0O0OO0O00O #line:4681
    def __OO000OOO0O00OO000 (OOO00OO00O0OO0O00 ,O0OOO0000000OO000 :str ,O0OO000OOO00O00OO :TFutQt5Q ):#line:4683
        if OOO00OO00O0OO0O00 .__OOO0OOOOOO000OO00 ==None :#line:4684
            return #line:4685
        OOO00OO00O0OO0O00 .__OOO0OOOOOO000OO00 (O0OOO0000000OO000 ,O0OO000OOO00O00OO )#line:4687
    __O0OO0O0O0O00O0000 :callable =None #line:4690
    def Set_OnQt5QEventOvsFUT (O00O0OO00OO0OO00O ,OO00OOO00O0OOO00O :callable ):#line:4692
        O00O0OO00OO0OO00O .__O0OO0O0O0O00O0000 =OO00OOO00O0OOO00O #line:4693
    def __O0000O0O0O0OO0000 (OO000O0OOO0000OO0 ,O00OO00OO0OO00O00 :str ,O00OO0OO0O0000O0O :TOvsFutQt5Q ):#line:4695
        if OO000O0OOO0000OO0 .__O0OO0O0O0O00O0000 ==None :#line:4696
            return #line:4697
        OO000O0OOO0000OO0 .__O0OO0O0O0O00O0000 (OO000O0OOO0000OO0 ,O00OO00OO0OO00O00 ,O00OO0OO0O0000O0O )#line:4698
    __O0O00O0OO0OO0O0OO :callable =None #line:4701
    def Set_OnQt5QTOTEventFUT (O0O0OO0O00O0OOO00 ,OO0OOO0OO000OOO00 :callable ):#line:4703
        O0O0OO0O00O0OOO00 .__O0O00O0OO0OO0O0OO =OO0OOO0OO000OOO00 #line:4704
    def __O0O00OOOOOOOO0OO0 (O000O000O000000OO ,O0OO00O0OO0OOOOO0 :str ,OO0OO00OOOO000000 :TFutQt5QTOT ):#line:4706
        if O000O000O000000OO .__O0O00O0OO0OO0O0OO ==None :#line:4707
            return #line:4708
        O000O000O000000OO .__O0O00O0OO0OO0O0OO (O0OO00O0OO0OOOOO0 ,OO0OO00OOOO000000 )#line:4709
    __OOO0OO000OO0OO000 :callable =None #line:4712
    def Set_OnChangeMktStuEventFUT (OO0O0OOOO0O0O00O0 ,OOO00O0000OO0O0O0 :callable ):#line:4714
        OO0O0OOOO0O0O00O0 .__OOO0OO000OO0OO000 =OOO00O0000OO0O0O0 #line:4715
    def __OOOOOOO000000O000 (OOO00000000OO00OO ,OO0O00OOO00OOO000 :str ,O0OO00OOOO0O000O0 :TFutQtBase ):#line:4717
        if OOO00000000OO00OO .__OOO0OO000OO0OO000 ==None :#line:4718
            return #line:4719
        OOO00000000OO00OO .__OOO0OO000OO0OO000 (OO0O00OOO00OOO000 ,O0OO00OOOO0O000O0 )#line:4720
    __O000OO00O0O000OO0 :callable =None #line:4723
    def Set_OnQtIDXEventSTK (OO0OO000O0OOO0000 ,OOO0O000O00O0O0O0 :callable ):#line:4725
        OO0OO000O0OOO0000 .__O000OO00O0O000OO0 =OOO0O000O00O0O0O0 #line:4726
    def __OO00O0OOOO0O000OO (OOO000O0O000O0000 ,OO0OOO0OO0000000O :str ,OOOOO00O000O0O0OO :TStkQtIDX ):#line:4728
        if OOO000O0O000O0000 .__O000OO00O0O000OO0 ==None :#line:4729
            return #line:4730
        OOO000O0O000O0000 .__O000OO00O0O000OO0 (OO0OOO0OO0000000O ,OOOOO00O000O0O0OO )#line:4731
    __O0O0O0OO0O00OOOO0 :callable =None #line:4732
    def Set_OnQtIDXEventFUT (OOOOO0OOOO0O00O00 ,O0O00OO000O0O0OOO :callable ):#line:4734
        OOOOO0OOOO0O00O00 .__O0O0O0OO0O00OOOO0 =O0O00OO000O0O0OOO #line:4735
    def __O0OO0OOO0OO000O0O (OO00000000OO00OO0 ,OOO0O0OOOOO00O000 :str ,O0000OO00000000OO :TFutQtIDX ):#line:4737
        if OO00000000OO00OO0 .__O0O0O0OO0O00OOOO0 ==None :#line:4738
            return #line:4739
        OO00000000OO00OO0 .__O0O0O0OO0O00OOOO0 (OOO0O0OOOOO00O000 ,O0000OO00000000OO )#line:4740
    __O000OOOOO0OOO0O0O :callable =None #line:4743
    """OtherMessageEventHandler"""#line:4744
    def Set_OnOtherMessageEvent (O0O00O00000OO0OOO ,OO0OOOOOO00O0000O :callable ):#line:4746
        O0O00O00000OO0OOO .__O000OOOOO0OOO0O0O =OO0OOOOOO00O0000O #line:4747
    def __OOOO0O0O0O00000O0 (OO0000O000OOO00O0 ,OO0000OOO00OO0O00 :str ):#line:4749
        if OO0000O000OOO00O0 .__O000OOOOO0OOO0O0O ==None :#line:4750
            return #line:4751
        OO0000O000OOO00O0 .__O000OOOOO0OOO0O0O (OO0000OOO00OO0O00 )#line:4752
    __OO0O0OO0O0OO0OOOO :callable =None #line:4755
    """LogEventHandler"""#line:4756
    __O0OO0O0O000O00O0O :callable =None #line:4757
    __OO0OOOOO0000O0OO0 :callable =None #line:4758
    def Set_OnLogEvent (O0O00OO00O0O00OOO ,OOOO0OO0O0O0OOO0O :callable ):#line:4760
        O0O00OO00O0O00OOO .__OO0O0OO0O0OO0OOOO =OOOO0OO0O0O0OOO0O #line:4761
    def __OOO000O0OOO0O00O0 (O00OOO000OOO0000O ,OOO0OO0000O0OO0O0 :str ):#line:4763
        if O00OOO000OOO0000O .__OO0O0OO0O0OO0OOOO ==None :#line:4764
            return #line:4765
        O00OOO000OOO0000O .__OO0O0OO0O0OO0OOOO (OOO0OO0000O0OO0O0 )#line:4766
    def Set_OnInterruptEvent (OO00OO0OO0OOOO0O0 ,OOOOO0OO00O000000 :callable ):#line:4769
        OO00OO0OO0OOOO0O0 .__O0OO0O0O000O00O0O =OOOOO0OO00O000000 #line:4770
    def __O0OO000O00OOOOO00 (OO0000OO000OO000O ,OO0O0O00OOO00O0OO :str ):#line:4772
        if OO0000OO000OO000O .__O0OO0O0O000O00O0O ==None :#line:4773
            return #line:4774
        OO0000OO000OO000O .__O0OO0O0O000O00O0O (OO0O0O00OOO00O0OO )#line:4775
    def Set_OnTerminationEvent (O00OOO0OOO0OOOO0O ,OO0OOOOO000OO0000 :callable ):#line:4777
        O00OOO0OOO0OOOO0O .__OO0OOOOO0000O0OO0 =OO0OOOOO000OO0000 #line:4778
    def __O0O0OO0OO0O0O0OO0 (OOO0OOOOOO00OOOO0 ,O00OOOOOO0O0OOO0O :str ):#line:4780
        if OOO0OOOOOO00OOOO0 .__OO0OOOOO0000O0OO0 ==None :#line:4781
            return #line:4782
        OOO0OOOOOO00OOOO0 .__OO0OOOOO0000O0OO0 (O00OOOOOO0O0OOO0O )#line:4783
    def __O0O0OOO0OOO0O000O (O00OOO00O0O0OOOOO ,O0O0O00O0O0OO0OOO :TSolClientConnData )->RCode :#line:4786
        try :#line:4787
            if O00OOO00O0O0OOOOO ._is_connected :#line:4788
                return RCode .OK #line:4789
            if O00OOO00O0O0OOOOO ._log ._run ==False :#line:4790
                O00OOO00O0O0OOOOO ._log =SolaceLog (O00OOO00O0O0OOOOO ._pypath ,O00OOO00O0O0OOOOO ._loglv ,O00OOO00O0O0OOOOO ._conlve )#line:4791
            O00OOO00O0O0OOOOO ._log .Add (arg1 =SolLogType .Info ,arg2 ="DoSolaceConn")#line:4792
            O00OOO00O0O0OOOOO .__OOOO00OOO000O0000 ()#line:4793
            O00OOO00O0O0OOOOO ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"host:{O0O0O00O0O0OO0OOO.Host} vpn:{O0O0O00O0O0OO0OOO.MessageVPN} username:{O0O0O00O0O0OO0OOO.Username} pwd:{O0O0O00O0O0OO0OOO.Password} cmplv:{O0O0O00O0O0OO0OOO.CompressLevel}")#line:4794
            O0O0OO0O000OO0OO0 :dict ={}#line:4795
            O0O0OO0O000OO0OO0 ["solace.messaging.transport.host"]=O0O0O00O0O0OO0OOO .Host #line:4796
            O0O0OO0O000OO0OO0 ["solace.messaging.service.vpn-name"]=O0O0O00O0O0OO0OOO .MessageVPN #line:4797
            O0O0OO0O000OO0OO0 ["solace.messaging.authentication.basic.username"]=O0O0O00O0O0OO0OOO .Username #line:4798
            O0O0OO0O000OO0OO0 ["solace.messaging.authentication.basic.password"]=O0O0O00O0O0OO0OOO .Password #line:4799
            O0O0OO0O000OO0OO0 ["solace.messaging.transport.compression-level"]=O0O0O00O0O0OO0OOO .CompressLevel #line:4800
            O0O0OO0O000OO0OO0 ['solace.messaging.transport.connection-retries']=3 #line:4802
            O0O0OO0O000OO0OO0 ['solace.messaging.transport.connection.retries-per-host']=4 #line:4803
            O0O0OO0O000OO0OO0 ['solace.messaging.transport.connection-attempts-timeout']=30000 #line:4804
            O0O0OO0O000OO0OO0 ['solace.messaging.transport.reconnection-attempts']=10 #line:4806
            O0O0OO0O000OO0OO0 ['solace.messaging.transport.reconnection-attempts-wait-interval']=1000 #line:4807
            O00OOO00O0O0OOOOO ._cacheReqOutListener =CacheReqOutListener (O00OOO00O0O0OOOOO ,O00OOO00O0O0OOOOO .__OOOO00000000O00OO ,O00OOO00O0O0OOOOO ._log )#line:4810
            O00OOO00O0O0OOOOO ._message_service =MessagingService .builder ().from_properties (O0O0OO0O000OO0OO0 ).build ()#line:4811
            O00OOO00O0O0OOOOO ._message_service .connect ()#line:4812
            O00OOO00O0O0OOOOO ._service_handler =ServiceEventHandler (O00OOO00O0O0OOOOO .__O0OO000O00OOOOO00 )#line:4813
            O00OOO00O0O0OOOOO ._message_service .add_service_interruption_listener (O00OOO00O0O0OOOOO ._service_handler )#line:4814
            O00OOO00O0O0OOOOO ._termination_handler =TerminationNotificationHandler (O00OOO00O0O0OOOOO .__O0O0OO0OO0O0O0OO0 )#line:4815
            O00OOO00O0O0OOOOO ._message_receiver =O00OOO00O0O0OOOOO ._message_service .create_direct_message_receiver_builder ().build ()#line:4817
            O00OOO00O0O0OOOOO ._message_receiver .start ()#line:4818
            O00OOO00O0O0OOOOO ._message_receiver .receive_async (O00OOO00O0O0OOOOO .__OOOO00000000O00OO )#line:4819
            O00OOO00O0O0OOOOO ._message_receiver .set_termination_notification_listener (O00OOO00O0O0OOOOO ._termination_handler )#line:4820
            O00OOO00O0O0OOOOO ._direct_publish_service =O00OOO00O0O0OOOOO ._message_service .create_direct_message_publisher_builder ().build ()#line:4822
            O00OOO00O0O0OOOOO ._message_requester =O00OOO00O0O0OOOOO ._message_service .request_reply ().create_request_reply_message_publisher_builder ().build ().start ()#line:4824
            O00OOO00O0O0OOOOO ._is_connected =O00OOO00O0O0OOOOO ._message_service .is_connected #line:4825
            if O00OOO00O0O0OOOOO ._is_connected :#line:4827
                return RCode .OK #line:4828
            else :#line:4829
                return RCode .FAIL #line:4830
        except Exception as OO0O000OO0O00OOO0 :#line:4831
            O00OOO00O0O0OOOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSolaceConn error: {OO0O000OO0O00OOO0}")#line:4833
            return RCode .FAIL #line:4834
    def Connect (O000O0OOO0OOO0OOO ,O000000OO00000O00 :str ,OO0OO0OO000OOO000 :str ,OOO0O0OO00O0OOOOO :str ,O0OOO000OO000O00O :str ,aCompressLevel :int =0 ):#line:4836
        O0OOOO0O0O000O0O0 :TSolClientConnData =TSolClientConnData ()#line:4837
        O0OOOO0O0O000O0O0 .Host =O000000OO00000O00 #line:4838
        O0OOOO0O0O000O0O0 .MessageVPN =OO0OO0OO000OOO000 #line:4839
        O0OOOO0O0O000O0O0 .Username =OOO0O0OO00O0OOOOO #line:4840
        O0OOOO0O0O000O0O0 .Password =O0OOO000OO000O00O #line:4841
        O0OOOO0O0O000O0O0 .CompressLevel =aCompressLevel #line:4842
        return O000O0OOO0OOO0OOO .__O0O0OOO0OOO0O000O (O0OOOO0O0O000O0O0 )#line:4844
    def DisConnect (O0OO0000OOO0000OO )->RCode :#line:4846
        if O0OO0000OOO0000OO ._is_connected :#line:4848
            O00OO0O000O0O0O0O =time .time ()#line:4849
            while (True ):#line:4850
                O0O000OO0OO0O00OO =O0OO0000OOO0000OO .__O0O0O0000OO0O0O00 ._queue .empty ()#line:4851
                OO0O0O00O00O0OO00 =O0OO0000OOO0000OO .__O0OO000O000OO000O ._queue .empty ()#line:4852
                if O0O000OO0OO0O00OO and OO0O0O00O00O0OO00 :#line:4853
                    sleep (2 )#line:4854
                    with O0OO0000OOO0000OO ._lock :#line:4855
                        if hasattr (O0OO0000OOO0000OO ,'_message_service')and O0OO0000OOO0000OO ._is_connected :#line:4856
                            O0OO0000OOO0000OO ._message_receiver .terminate ()#line:4857
                            O0OO0000OOO0000OO ._message_requester .terminate ()#line:4858
                            O0OO0000OOO0000OO ._message_service .disconnect ()#line:4859
                        O0OO0000OOO0000OO ._is_connected =False #line:4860
                    break #line:4861
                O00O0O0OO000OO00O =time .time ()#line:4862
                O0OO000OO0O0O0O0O =O00O0O0OO000OO00O -O00OO0O000O0O0O0O #line:4863
                if O0OO000OO0O0O0O0O >30 :#line:4864
                    with O0OO0000OOO0000OO ._lock :#line:4865
                        if hasattr (O0OO0000OOO0000OO ,'_message_service')and O0OO0000OOO0000OO ._is_connected :#line:4866
                            O0OO0000OOO0000OO ._message_receiver .terminate ()#line:4867
                            O0OO0000OOO0000OO ._message_requester .terminate ()#line:4868
                            O0OO0000OOO0000OO ._message_service .disconnect ()#line:4869
                        O0OO0000OOO0000OO ._is_connected =False #line:4870
                    break #line:4871
        O0OO0000OOO0000OO .__OOOO0O0OOO00OO0O0 ()#line:4873
        if O0OO0000OOO0000OO ._log ._run :#line:4874
            O0OO0000OOO0000OO ._log .Wrtie_log (SolLogType .Info ,"DisConnect")#line:4875
            O0OO0000OOO0000OO ._log ._run =False #line:4876
        return RCode .OK #line:4877
    def __OOOO0000OO0000O0O (O00OO0O0OOO0000OO ,OOO0O0000O00OOOOO ):#line:4881
        ""#line:4882
        OO00O0OO00OO0O0OO :str =""#line:4883
        try :#line:4884
            if isinstance (OOO0O0000O00OOOOO ,int ):#line:4886
                O0O0OO00OO0O0O0O0 :int =OOO0O0000O00OOOOO #line:4887
                O00OOOOO00O00O000 =O00OO0O0OOO0000OO ._fMapCacheJob .get (O0O0OO00OO0O0O0O0 )#line:4888
                if O00OOOOO00O00O000 is None :#line:4889
                    O00OO0O0OOO0000OO .__OOO000O0OOO0O00O0 (f"[handle cache job data 回補結束]reqID={OOO0O0000O00OOOOO}")#line:4890
                    O00OO0O0OOO0000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[handle cache job data 回補結束]reqID={OOO0O0000O00OOOOO}")#line:4891
                else :#line:4892
                    O000O000OOOOO00O0 ,O00OO0O0O00O0OO00 =O00OO0O0OOO0000OO ._fMapCacheJob .DeleteJob (O0O0OO00OO0O0O0O0 )#line:4893
                    if O000O000OOOOO00O0 :#line:4894
                        O00OO0O0O00O0OO00 .HandleProc (O00OO0O0O00O0OO00 )#line:4895
                return #line:4896
            OOOOOOO000O00OO00 =OOO0O0000O00OOOOO .get_cache_status ()#line:4898
            OO00O0OO00OO0O0OO =OOO0O0000O00OOOOO .get_payload_as_bytes ().decode ('utf-8')#line:4899
            if len (OO00O0OO00OO0O0OO )==0 :#line:4900
                return #line:4901
            OO0OO000O0O00O00O :str =OOO0O0000O00OOOOO .get_destination_name ()#line:4902
            if OOOOOOO000O00OO00 .value ==OOOOOOO000O00OO00 .CACHED .value :#line:4904
                O00OO0O0O00O0OO00 :TCacheJob =O00OO0O0OOO0000OO ._fMapCacheJob [OOO0O0000O00OOOOO .get_cache_request_id ()]#line:4905
                if O00OO0O0O00O0OO00 is not None :#line:4906
                    if O00OO0O0O00O0OO00 .oneProd :#line:4907
                        O00O0O0O000O00OO0 =OO0OO000O0O00O00O .split ("/")#line:4908
                        if OO0OO000O0O00O00O .endswith (O00OO0O0OOO0000OO ._vQuote_BAS ):#line:4909
                            O00OO0O0O00O0OO00 .TopicBAS =OO0OO000O0O00O00O #line:4910
                            O00O0O0O000O00OO0 [len (O00O0O0O000O00OO0 )-1 ]="HL"#line:4911
                            O00OO0O0O00O0OO00 .TopicHL ="/".join (O00O0O0O000O00OO0 )#line:4912
                            O00O0O0O000O00OO0 [len (O00O0O0O000O00OO0 )-1 ]="TX"#line:4913
                            O00OO0O0O00O0OO00 .TopicTX ="/".join (O00O0O0O000O00OO0 )#line:4914
                            O00OO0O0O00O0OO00 .CacheData [OO0OO000O0O00O00O ]=OOO0O0000O00OOOOO #line:4915
                            O00OO0O0OOO0000OO ._fMapCacheJob [OOO0O0000O00OOOOO .get_cache_request_id ()]=O00OO0O0O00O0OO00 #line:4916
                            if O00OO0O0O00O0OO00 .CacheData .get (O00OO0O0O00O0OO00 .TopicHL )is None :#line:4918
                                OO00O00000O000O0O =TCacheJob ()#line:4919
                                OO00O00000O000O0O .prod =O00O0O0O000O00OO0 [len (O00O0O0O000O00OO0 )-2 ]#line:4920
                                OO00O00000O000O0O .TopicBAS =O00OO0O0O00O0OO00 .TopicBAS #line:4921
                                OO00O00000O000O0O .TopicHL =O00OO0O0O00O0OO00 .TopicHL #line:4922
                                OO00O00000O000O0O .TopicTX =O00OO0O0O00O0OO00 .TopicTX #line:4923
                                OO00O00000O000O0O .RequestID =O00OO0O0OOO0000OO .GetRequestID ()#line:4924
                                if OO0OO000O0O00O00O .startswith (O00OO0O0OOO0000OO ._vQuote_STK ):#line:4925
                                    OO00O00000O000O0O .HandleProc =O00OO0O0OOO0000OO .__O0O0O0OOO0O0O000O #line:4926
                                elif OO0OO000O0O00O00O .startswith (O00OO0O0OOO0000OO ._vQuote_FUT ):#line:4927
                                    OO00O00000O000O0O .HandleProc =O00OO0O0OOO0000OO .__OO0OO0OO0O0O0O0O0 #line:4928
                                O00OO0O0OOO0000OO ._fMapCacheJob [OO00O00000O000O0O .RequestID ]=OO00O00000O000O0O #line:4929
                                O00OO0O0OOO0000OO .__O0O0O0OOOO0OOOOO0 (OO00O00000O000O0O .RequestID ,OO00O00000O000O0O .TopicHL )#line:4930
                        elif OO0OO000O0O00O00O .endswith (O00OO0O0OOO0000OO ._vQuote_HL ):#line:4931
                            O00OO0O0O00O0OO00 .CacheData [OO0OO000O0O00O00O ]=OOO0O0000O00OOOOO #line:4932
                            O00OO0O0OOO0000OO ._fMapCacheJob [OOO0O0000O00OOOOO .get_cache_request_id ()]=O00OO0O0O00O0OO00 #line:4933
                        O00OO0O0OOO0000OO .__OOOO00000000O00OO .Add (OOO0O0000O00OOOOO .get_cache_request_id ())#line:4934
                    else :#line:4935
                        O00O0O0O000O00OO0 :list =OO0OO000O0O00O00O .split ('/')#line:4936
                        OOO00000000O00OO0 =O00O0O0O000O00OO0 [len (O00O0O0O000O00OO0 )-2 ]#line:4937
                        if OO0OO000O0O00O00O .endswith (O00OO0O0OOO0000OO ._vQuote_BAS ):#line:4938
                            O00OOOOO00O00O000 =TCacheJob ()#line:4939
                            O00OOOOO00O00O000 .prod =OOO00000000O00OO0 #line:4940
                            O00OOOOO00O00O000 .TopicBAS =OO0OO000O0O00O00O #line:4942
                            O00OOOOO00O00O000 .RequestID =O00OO0O0OOO0000OO .GetRequestID ()#line:4943
                            if OO0OO000O0O00O00O .startswith (O00OO0O0OOO0000OO ._vQuote_STK ):#line:4944
                                O00OOOOO00O00O000 .HandleProc =O00OO0O0OOO0000OO .__OOOO00O0OOOOO0OOO #line:4945
                            elif OO0OO000O0O00O00O .startswith (O00OO0O0OOO0000OO ._vQuote_FUT ):#line:4946
                                O00OOOOO00O00O000 .HandleProc =O00OO0O0OOO0000OO .__O0000O0O0O0OO0000 #line:4947
                            O00OOOOO00O00O000 .CacheData [OO0OO000O0O00O00O ]=OOO0O0000O00OOOOO #line:4948
                            O00OO0O0OOO0000OO ._fMapCacheJob [O00OOOOO00O00O000 .RequestID ]=O00OOOOO00O00O000 #line:4949
                            O00OO0O0OOO0000OO .__OOOO00000000O00OO .Add (O00OOOOO00O00O000 .RequestID )#line:4950
                        elif OO0OO000O0O00O00O .endswith (O00OO0O0OOO0000OO ._vQuote_HL ):#line:4951
                            O00OOOOO00O00O000 =TCacheJob ()#line:4952
                            O00OOOOO00O00O000 .prod =OOO00000000O00OO0 #line:4953
                            O00O0O0O000O00OO0 [len (O00O0O0O000O00OO0 )-1 ]="TX"#line:4955
                            O00OOOOO00O00O000 .TopicTX ="/".join (O00O0O0O000O00OO0 )#line:4956
                            O00OOOOO00O00O000 .TopicHL =OO0OO000O0O00O00O #line:4957
                            O00OOOOO00O00O000 .RequestID =O00OO0O0OOO0000OO .GetRequestID ()#line:4958
                            if OO0OO000O0O00O00O .startswith (O00OO0O0OOO0000OO ._vQuote_STK ):#line:4959
                                O00OOOOO00O00O000 .HandleProc =O00OO0O0OOO0000OO .__O0O0O0OOO0O0O000O #line:4960
                            elif OO0OO000O0O00O00O .startswith (O00OO0O0OOO0000OO ._vQuote_FUT ):#line:4961
                                O00OOOOO00O00O000 .HandleProc =O00OO0O0OOO0000OO .__OO0OO0OO0O0O0O0O0 #line:4962
                            O00OOOOO00O00O000 .CacheData [OO0OO000O0O00O00O ]=OOO0O0000O00OOOOO #line:4963
                            O00OO0O0OOO0000OO ._fMapCacheJob [O00OOOOO00O00O000 .RequestID ]=O00OOOOO00O00O000 #line:4964
                            O00OO0O0OOO0000OO .__OOOO00000000O00OO .Add (O00OOOOO00O00O000 .RequestID )#line:4965
                else :#line:4966
                    O00OO0O0OOO0000OO .__OOO000O0OOO0O00O0 (f"[cache job is none]dest={OO0OO000O0O00O00O}")#line:4967
                    O00OO0O0OOO0000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[cache job is none]dest={OO0OO000O0O00O00O}")#line:4968
                return #line:4969
            if OO0OO000O0O00O00O .startswith (O00OO0O0OOO0000OO ._vQuote_STK ):#line:4971
                OOOOOOOOOOO0OOO0O =O00OO0O0OOO0000OO ._fMapQuoteSTK .get (OO0OO000O0O00O00O )#line:4972
                if OOOOOOOOOOO0OOO0O :#line:4973
                    O00OO0O0OOO0000OO ._fMapQuoteSTK .MapQtProc [OO0OO000O0O00O00O ](OOOOOOOOOOO0OOO0O ,OO00O0OO00OO0O0OO ,OOO0O0000O00OOOOO )#line:4974
            elif OO0OO000O0O00O00O .startswith (O00OO0O0OOO0000OO ._vQuote_FUT ):#line:4975
                OOOOOOOOOOO0OOO0O =O00OO0O0OOO0000OO ._fMapQuoteFUT .get (OO0OO000O0O00O00O )#line:4976
                if OOOOOOOOOOO0OOO0O :#line:4977
                    O00OO0O0OOO0000OO ._fMapQuoteFUT .MapQtProc [OO0OO000O0O00O00O ](OOOOOOOOOOO0OOO0O ,OO00O0OO00OO0O0OO ,OOO0O0000O00OOOOO )#line:4978
            elif OO0OO000O0O00O00O .startswith (O00OO0O0OOO0000OO ._vQuote_OvsFUT ):#line:4979
                OOOOOOOOOOO0OOO0O =O00OO0O0OOO0000OO ._fMapQuoteOvsFUT .get (OO0OO000O0O00O00O )#line:4980
                if OOOOOOOOOOO0OOO0O :#line:4981
                    O00OO0O0OOO0000OO ._fMapQuoteOvsFUT .MapQtProc [OO0OO000O0O00O00O ](OOOOOOOOOOO0OOO0O ,OO00O0OO00OO0O0OO ,OOO0O0000O00OOOOO )#line:4982
        except Exception as OOO0O00O0O0000000 :#line:4983
            if isinstance (OOO0O0000O00OOOOO ,int ):#line:4984
                O00OO0O0OOO0000OO .__OOO000O0OOO0O00O0 (f"[證][Solace_ReceiveSolaceTopic]aTopic={OOO0O0000O00OOOOO}, except={OOO0O00O0O0000000}")#line:4986
                O00OO0O0OOO0000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[證][Solace_ReceiveSolaceTopic]aTopic={OOO0O0000O00OOOOO}, except={OOO0O00O0O0000000}")#line:4988
            else :#line:4989
                O00OO0O0OOO0000OO .__OOO000O0OOO0O00O0 (f"[證][Solace_ReceiveSolaceTopic]aTopic={OOO0O0000O00OOOOO.get_destination_name()}, aData={OO00O0OO00OO0O0OO}, except={OOO0O00O0O0000000}")#line:4991
                O00OO0O0OOO0000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[證][Solace_ReceiveSolaceTopic]aTopic={OOO0O0000O00OOOOO.get_destination_name()}, aData={OO00O0OO00OO0O0OO}, except={OOO0O00O0O0000000}")#line:4993
    def __OOO0OOO000O0O0OOO (OOOOOOO0OO00O0OOO ,OOO0OO0O00OOO0OOO :TStkQuoteData ,O00OOO0OOO0O0O0OO :str ,O00OO0OOOO000OOOO :'InboundMessage'):#line:4995
        ""#line:4996
        try :#line:4998
            with OOO0OO0O00OOO0OOO ._lock :#line:4999
                OOO0OO0O00OOO0OOO .QtTX .Handle_TX (O00OOO0OOO0O0O0OO )#line:5001
            OOOOOOO0OO00O0OOO .__O0OO0OO0O00O0O00O (OOO0OO0O00OOO0OOO .SolIce ,OOO0OO0O00OOO0OOO .QtTX )#line:5004
        except Exception as OOOO0O0OOOOO0O000 :#line:5005
            OOOOOOO0OO00O0OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_TXSTK:{OOOO0O0OOOOO0O000}")#line:5007
    def __OO000000000O000OO (OOOO00OO00000O0O0 ,OO0O0OOOOO0OOOOO0 :TFutQuoteData ,O0000O000O00OO0O0 :str ,OOOO0000O000OOO0O :'InboundMessage'):#line:5009
        ""#line:5010
        try :#line:5011
            with OO0O0OOOOO0OOOOO0 ._lock :#line:5012
                OO0O0OOOOO0OOOOO0 .QtTX .Handle_TX (O0000O000O00OO0O0 )#line:5014
            OOOO00OO00000O0O0 .__O00O0000O000OO000 (OO0O0OOOOO0OOOOO0 .SolIce ,OO0O0OOOOO0OOOOO0 .QtTX )#line:5017
        except Exception as O000O00O000O00OOO :#line:5018
            OOOO00OO00000O0O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_TXFUT:{O000O00O000O00OOO}")#line:5020
    def __OO0OOO0OO0OO0OO00 (O0OOOO0OOOOOO00O0 ,O0O000O0OO0OO0OOO :TOvsFutQuoteData ,OOO0OOO0OOO000O0O :str ,OO0O0O00O00OOOOOO :'InboundMessage'):#line:5022
        ""#line:5023
        try :#line:5024
            with O0O000O0OO0OO0OOO ._lock :#line:5025
                O0O000O0OO0OO0OOO .QtTX .Handle_TX (OOO0OOO0OOO000O0O )#line:5026
            O0OOOO0OOOOOO00O0 .__O0OO0O0OOOO0000O0 (O0O000O0OO0OO0OOO .SolIce ,O0O000O0OO0OO0OOO .QtTX )#line:5028
        except Exception as O00O0OOO00O00O000 :#line:5029
            O0OOOO0OOOOOO00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_TXOvsFUT:{O00O0OOO00O00O000}")#line:5031
    def __OO00OOOOO0000O00O (O0000OO0O00OO00OO ,OO00O0OOO0OO0O000 :TStkQuoteData ,OO0OOO0OO00O00OOO :str ,OOOOO000O00OO00O0 :'InboundMessage'):#line:5033
        ""#line:5034
        try :#line:5035
            with OO00O0OOO0OO0O000 ._lock :#line:5036
                OO00O0OOO0OO0O000 .Qt5Q .Handle_5Q (OO0OOO0OO00O00OOO )#line:5037
            O0000OO0O00OO00OO .__OOO0OOO0O000O0O00 (OO00O0OOO0OO0O000 .SolIce ,OO00O0OOO0OO0O000 .Qt5Q )#line:5038
        except Exception as OO0O000OO0OO00000 :#line:5039
            O0000OO0O00OO00OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_5QSTK:{OO0O000OO0OO00000}")#line:5041
    def __O0O000O000O0OOOOO (OO0OOO000O000000O ,O0O0O00OO0O00OO00 :TFutQuoteData ,O0000O0O0O0OO0000 :str ,OOO0O000O00OO00OO :'InboundMessage'):#line:5043
        ""#line:5044
        try :#line:5045
            with O0O0O00OO0O00OO00 ._lock :#line:5046
                O0O0O00OO0O00OO00 .Qt5Q .Handle_5Q (O0000O0O0O0OO0000 )#line:5047
            OO0OOO000O000000O .__OO000OOO0O00OO000 (O0O0O00OO0O00OO00 .SolIce ,O0O0O00OO0O00OO00 .Qt5Q )#line:5048
        except Exception as OO0OO00000OO0OOO0 :#line:5049
            OO0OOO000O000000O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_5QFUT:{OO0OO00000OO0OOO0}")#line:5051
    def __O0OO00000OOO0OO00 (OOO0O0O00OOOO0000 ,OO00OOOO0OO0OO000 :TOvsFutQuoteData ,O0OO000OOO000O000 :str ,O00OOOOO000OO0OO0 :'InboundMessage'):#line:5053
        try :#line:5054
            with OO00OOOO0OO0OO000 ._lock :#line:5055
                OO00OOOO0OO0OO000 .Qt5Q .Handle_5Q (O0OO000OOO000O000 )#line:5056
            OOO0O0O00OOOO0000 .__O0000O0O0O0OO0000 (OO00OOOO0OO0OO000 .SolIce ,OO00OOOO0OO0OO000 .Qt5Q )#line:5057
        except Exception as O00OO00O0O000O0OO :#line:5058
            OOO0O0O00OOOO0000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_5QOvsFUT:{O00OO00O0O000O0OO}")#line:5060
    def __OO0000OO0O00000OO (OOO0OO00OOO0O0O00 ,O0O00OO00OOO0OO0O :TStkQuoteData ,O0O00O00O0OO0O00O :str ,OO0OO0O0OOO0O00OO :'InboundMessage'):#line:5062
        ""#line:5063
        try :#line:5064
            with O0O00OO00OOO0OO0O ._lock :#line:5065
                O0O00OO00OOO0OO0O .QtIDX .Handle_IDX (O0O00O00O0OO0O00O )#line:5067
            OOO0OO00OOO0O0O00 .__OO00O0OOOO0O000OO (O0O00OO00OOO0OO0O .SolIce ,O0O00OO00OOO0OO0O .QtIDX )#line:5070
        except Exception as OOO0OOOO0O0O00O00 :#line:5071
            OOO0OO00OOO0O0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_IDXSTK:{OOO0OOOO0O0O00O00}")#line:5073
    def __OO00OO0OOO0OOOO00 (OO0O0O0O000O0OOO0 ,O0OOOOO0O000O0O00 :TFutQuoteData ,OO00OOOO0000000O0 :str ,OO00000000000OO0O :'InboundMessage'):#line:5075
        ""#line:5076
        try :#line:5077
            with O0OOOOO0O000O0O00 ._lock :#line:5078
                O0OOOOO0O000O0O00 .QtIDX .Handle_IDX (OO00OOOO0000000O0 )#line:5079
            OO0O0O0O000O0OOO0 .__O0OO0OOO0OO000O0O (O0OOOOO0O000O0O00 .SolIce ,O0OOOOO0O000O0O00 .QtIDX )#line:5080
        except Exception as O0O0OO00O0O00O000 :#line:5081
            OO0O0O0O000O0OOO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_IDXFUT:{O0O0OO00O0O00O000}")#line:5083
    def __O0OO0OO0O0O0O0O00 (O0O0OO00OO0000OOO ,OOOO00OOO0O0O00O0 :TFutQuoteData ,O0O0O0O00OO0O0O0O :str ,O0OOOOOOO00OOOOOO :'InboundMessage'):#line:5085
        ""#line:5086
        try :#line:5087
            with OOOO00OOO0O0O00O0 ._lock :#line:5088
                OOOO00OOO0O0O00O0 .Qt5QTOT .Handle_5QTOT (O0O0O0O00OO0O0O0O )#line:5089
            O0O0OO00OO0000OOO .__O0O00OOOOOOOO0OO0 (OOOO00OOO0O0O00O0 .SolIce ,OOOO00OOO0O0O00O0 .Qt5QTOT )#line:5090
        except Exception as OO00O0OOO00O0OO00 :#line:5091
            O0O0OO00OO0000OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_5QTOT:{OO00O0OOO00O0OO00}")#line:5093
    def __O0OO0O0O00OOOOOOO (OOOO000OO0OO000OO ,OOOOO0O0O0O0O0O0O :TFutQuoteData ,OO0OOOOOOO0000000 :str ,O0O00000O0OOOOO00 :'InboundMessage'):#line:5095
        ""#line:5096
        try :#line:5097
            O000O00O0OOO0OOOO :bool =False #line:5098
            with OOOOO0O0O0O0O0O0O ._lock :#line:5099
                O000O00O0OOO0OOOO =OOOOO0O0O0O0O0O0O .BAS .Handle_BAS_ChangeMktType (OO0OOOOOOO0000000 )#line:5100
            if O000O00O0OOO0OOOO :#line:5101
                OOOO000OO0OO000OO .__OOOOOOO000000O000 (OOOOO0O0O0O0O0O0O .SolIce ,OOOOO0O0O0O0O0O0O .BAS )#line:5102
        except Exception as O0OOOO0OOOO0OO0O0 :#line:5103
            OOOO000OO0OO000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_BAS:{O0OOOO0OOOO0OO0O0}")#line:5105
    def __OO0000O00O0O0OOOO (OO0O0OO0O0OOO0OOO ,O0OOO0O0OO000OO0O :str ,O0000OOO0O0O0O000 :bool ):#line:5109
        ""#line:5110
        try :#line:5111
            OO0000OOOO00OO000 =f"Quote/TWS/*/*/{O0OOO0O0OO000OO0O}/RECOVER"#line:5112
            OO0O00O0OO00O0000 ,O0O00OO0OOO0O00O0 =OO0O0OO0O0OOO0OOO .__O0OO0OO0OO00OOOO0 (OO0O0OO0O0OOO0OOO ._vRcvTopic_Stk ,OO0000OOOO00OO000 ,'utf-8',OO0O0OO0O0OOO0OOO ._vRcvTopic_Stk_Req )#line:5114
            if OO0O00O0OO00O0000 :#line:5116
                OO0OO0O0OO0OOO00O =json .loads (O0O00OO0OOO0O00O0 )#line:5117
                if "status"in OO0OO0O0OO0OOO00O and len (OO0OO0O0OO0OOO00O ["status"])>0 :#line:5118
                    if OO0OO0O0OO0OOO00O ["status"][0 ]=="error":#line:5119
                        OO0O0OO0O0OOO0OOO .__OOO000O0OOO0O00O0 (f"[證][DoSubQuoteSTK取個一般上市上櫃股票商品檔](aData={O0O00OO0OOO0O00O0})行情回補資料有誤!")#line:5121
                        return RCode .FAIL #line:5122
                if "BAS"in OO0OO0O0OO0OOO00O and len (OO0OO0O0OO0OOO00O ["BAS"])==0 :#line:5123
                    OO0O0OO0O0OOO0OOO .__OOO000O0OOO0O00O0 (f"[證][DoSubQuoteSTK取個一般上市上櫃股票商品檔](aData={O0O00OO0OOO0O00O0})沒有BAS資料!")#line:5125
                    return RCode .FAIL #line:5126
                if "HL"in OO0OO0O0OO0OOO00O and len (OO0OO0O0OO0OOO00O ["HL"])==0 :#line:5127
                    OO0O0OO0O0OOO0OOO .__OOO000O0OOO0O00O0 (f"[證][DoSubQuoteSTK取個一般上市上櫃股票商品檔](aData={O0O00OO0OOO0O00O0})沒有HL資料!")#line:5129
                    return RCode .FAIL #line:5130
            if OO0O00O0OO00O0000 and O0O00OO0OOO0O00O0 !="":#line:5132
                OOO0O00O0000O00OO =OO0OO0O0OO0OOO00O ["HL"][0 ].split ('|')[1 ]#line:5133
                if OOO0O00O0000O00OO ==OO0O0OO0O0OOO0OOO .__OO0OOO0O0OOOO0O0O :#line:5134
                    O0O00O0OOOOO00OO0 =OO0O0OO0O0OOO0OOO .__O0OO0O0OO00O0OO0O (False ,O0OOO0O0OO000OO0O ,O0000OOO0O0O0O000 ,OO0OO0O0OO0OOO00O )#line:5135
                else :#line:5136
                    O0O00O0OOOOO00OO0 =OO0O0OO0O0OOO0OOO .__OO0O0OO0OOOO0O0O0 (False ,O0OOO0O0OO000OO0O ,O0000OOO0O0O0O000 ,OO0OO0O0OO0OOO00O )#line:5137
                return O0O00O0OOOOO00OO0 #line:5138
            else :#line:5139
                return RCode .FAIL #line:5140
        except Exception as OO0OOO00O0000O00O :#line:5141
            OO0O0OO0O0OOO0OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteSTK:{OO0OOO00O0000O00O}")#line:5142
            OO0O0OO0O0OOO0OOO .__OOO000O0OOO0O00O0 (f"[證][DoSubQuoteSTK]{O0OOO0O0OO000OO0O}新增紀錄失敗!({OO0OOO00O0000O00O})")#line:5143
            OO0OO000OOO00O0OO =threading .Thread (target =OO0O0OO0O0OOO0OOO .__O0000O0O0000OOO00 ,args =(STKxFUT .STK ,O0OOO0O0OO000OO0O ))#line:5145
            OO0OO000OOO00O0OO .start ()#line:5146
            return RCode .FAIL #line:5147
    def __OO000OO0OO0OOOOOO (OOO00O00OOO0O00O0 ,OOOO0000OOOO0O00O :str ,O000000O00OOOO00O :bool ):#line:5149
        ""#line:5150
        try :#line:5151
            O0OOO000OO0OO0O0O =TCacheJob ()#line:5152
            O0OOO000OO0OO0O0O .prod =OOOO0000OOOO0O00O #line:5153
            O0OOO000OO0OO0O0O .TopicBAS =f"Quote/TWS/*/*/{OOOO0000OOOO0O00O}/BAS"#line:5154
            O0OOO000OO0OO0O0O .RequestID =OOO00O00OOO0O00O0 .GetRequestID ()#line:5155
            O0OOO000OO0OO0O0O .HandleProc =OOO00O00OOO0O00O0 .__OOOO00O0OOOOO0OOO #line:5156
            OOO00O00OOO0O00O0 ._fMapCacheJob [O0OOO000OO0OO0O0O .RequestID ]=O0OOO000OO0OO0O0O #line:5157
            OOO00O00OOO0O00O0 .__O0O0O0OOOO0OOOOO0 (O0OOO000OO0OO0O0O .RequestID ,O0OOO000OO0OO0O0O .TopicBAS )#line:5158
            return RCode .OK #line:5159
        except Exception as O00OO00000OOOOO00 :#line:5160
            OOO00O00OOO0O00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteSTK:{O00OO00000OOOOO00}")#line:5161
            OOO00O00OOO0O00O0 .__OOO000O0OOO0O00O0 (f"[證][DoSubQuoteSTK]{OOOO0000OOOO0O00O}新增紀錄失敗!({O00OO00000OOOOO00})")#line:5162
            OO0O000O000O00O00 =threading .Thread (target =OOO00O00OOO0O00O0 .__O0000O0O0000OOO00 ,args =(STKxFUT .STK ,OOOO0000OOOO0O00O ))#line:5164
            OO0O000O000O00O00 .start ()#line:5165
            return RCode .FAIL #line:5166
    def __OOO0O0OOO0O0O0OO0 (O0OO0OOO0OOO00O00 ,OO0O0OO0OO0000O0O :str ,O000OOOO00000OOO0 :bool ):#line:5168
        ""#line:5169
        try :#line:5170
            O0O00000O0O00O0O0 =f"Quote/TWS/{OO0O0OO0OO0000O0O}/*/*/RECOVER"#line:5171
            OO00000OOOO00OOO0 ,O0000O0O00OOO0OOO =O0OO0OOO0OOO00O00 .__O0OO0OO0OO00OOOO0 (O0OO0OOO0OOO00O00 ._vRcvTopic_Stk ,O0O00000O0O00O0O0 ,'utf-8',O0OO0OOO0OOO00O00 ._vRcvTopic_Stk_Req )#line:5172
            if OO00000OOOO00OOO0 and O0000O0O00OOO0OOO !="":#line:5174
                OOO00O000OO0000O0 =json .loads (O0000O0O00OOO0OOO )#line:5176
                if "status"in OOO00O000OO0000O0 and len (OOO00O000OO0000O0 ["status"])>0 :#line:5177
                    if OOO00O000OO0000O0 ["status"][0 ]=="error":#line:5178
                        OO0OOO0OOO000O0OO =f"[證][DoSubQuoteByCategory](aCat={OO0O0OO0OO0000O0O}, sResData={O0000O0O00OOO0OOO})行情回補資料有誤!"#line:5179
                        O0OO0OOO0OOO00O00 .__OOO000O0OOO0O00O0 (OO0OOO0OOO000O0OO )#line:5180
                        return False #line:5181
                if "BAS"in OOO00O000OO0000O0 and len (OOO00O000OO0000O0 ["BAS"])==0 :#line:5182
                    OO0OOO0OOO000O0OO =f"[證][DoSubQuoteByCategory](aCat={OO0O0OO0OO0000O0O}, sResData={O0000O0O00OOO0OOO})沒有BAS資料!"#line:5183
                    O0OO0OOO0OOO00O00 .__OOO000O0OOO0O00O0 (OO0OOO0OOO000O0OO )#line:5184
                    return False #line:5185
                if "HL"in OOO00O000OO0000O0 and len (OOO00O000OO0000O0 ["HL"])==0 :#line:5186
                    OO0OOO0OOO000O0OO =f"[證][DoSubQuoteByCategory](aCat={OO0O0OO0OO0000O0O}, sResData={O0000O0O00OOO0OOO})沒有HL資料!"#line:5187
                    O0OO0OOO0OOO00O00 .__OOO000O0OOO0O00O0 (OO0OOO0OOO000O0OO )#line:5188
                    return False #line:5189
                if OO0O0OO0OO0000O0O ==O0OO0OOO0OOO00O00 .__OO0OOO0O0OOOO0O0O :#line:5191
                    O0OO0OOO0OOO00O00 .__O0OO0O0OO00O0OO0O (True ,OO0O0OO0OO0000O0O ,O000OOOO00000OOO0 ,OOO00O000OO0000O0 )#line:5192
                else :#line:5193
                    O0OO0OOO0OOO00O00 .__OO0O0OO0OOOO0O0O0 (True ,OO0O0OO0OO0000O0O ,O000OOOO00000OOO0 ,OOO00O000OO0000O0 )#line:5194
                return True #line:5195
        except Exception as OO0OOOO0OOOOO0O0O :#line:5196
            O0OO0OOO0OOO00O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteByCategorySTK:{OO0OOOO0OOOOO0O0O}")#line:5197
            O0OO0OOO0OOO00O00 .__OOO000O0OOO0O00O0 (f"[證][DoSubQuoteByCategorySTK]{OO0O0OO0OO0000O0O}新增紀錄失敗!({OO0OOOO0OOOOO0O0O})")#line:5198
        OOOO000O00000OO00 =threading .Thread (target =O0OO0OOO0OOO00O00 .__O0000O0O0000OOO00 ,args =(STKxFUT .STK ,OO0O0OO0OO0000O0O ))#line:5201
        OOOO000O00000OO00 .start ()#line:5202
    def __O0O000OO0O0OO000O (O0OO0OO0OOOOO0OO0 ,OOO0OO000O0OO0000 :str ,O0O00OOOO0OO0O0OO :bool ):#line:5204
        ""#line:5205
        try :#line:5206
            O00OOOOO0OOOO0O00 =TCacheJob ()#line:5207
            O00OOOOO0OOOO0O00 .TopicBAS =f"Quote/TWS/{OOO0OO000O0OO0000}/*/*/BAS"#line:5208
            O00OOOOO0OOOO0O00 .oneProd =False #line:5209
            O00OOOOO0OOOO0O00 .RequestID =O0OO0OO0OOOOO0OO0 .GetRequestID ()#line:5210
            O00OOOOO0OOOO0O00 .HandleProc =O0OO0OO0OOOOO0OO0 .__OOOO00O0OOOOO0OOO #line:5211
            O00OOOOO0OOOO0O00 .Params ["Category"]="SubQuoteByCategory_BAS"#line:5212
            O0OO0OO0OOOOO0OO0 ._fMapCacheJob [O00OOOOO0OOOO0O00 .RequestID ]=O00OOOOO0OOOO0O00 #line:5213
            O0OO0OO0OOOOO0OO0 .__O0O0O0OOOO0OOOOO0 (O00OOOOO0OOOO0O00 .RequestID ,O00OOOOO0OOOO0O00 .TopicBAS )#line:5214
            return RCode .OK #line:5215
        except Exception as OO00O0000OO000OOO :#line:5216
            O0OO0OO0OOOOO0OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteByCategorySTK:{OO00O0000OO000OOO}")#line:5217
            O0OO0OO0OOOOO0OO0 .__OOO000O0OOO0O00O0 (f"[證][DoSubQuoteByCategorySTK]{OOO0OO000O0OO0000}新增紀錄失敗!({OO00O0000OO000OOO})")#line:5218
        O0OOOO0000O00O000 =threading .Thread (target =O0OO0OO0OOOOO0OO0 .__O0000O0O0000OOO00 ,args =(STKxFUT .STK ,OOO0OO000O0OO0000 ))#line:5221
        O0OOOO0000O00O000 .start ()#line:5222
    def __OOOO0OOOOOOO0OOOO (O0OOO0000O00O00O0 ,O0OO00O00000OO0O0 :str ,OO0OOOO00000OOO00 :bool ):#line:5224
        ""#line:5227
        try :#line:5228
            OOO0000O0O000OO00 =TCacheJob ()#line:5229
            OOO0000O0O000OO00 .prod =O0OO00O00000OO0O0 #line:5230
            OOO0000O0O000OO00 .TopicBAS =f"Quote/TWF/*/{O0OO00O00000OO0O0}/BAS"#line:5231
            OOO0000O0O000OO00 .RequestID =O0OOO0000O00O00O0 .GetRequestID ()#line:5232
            OOO0000O0O000OO00 .HandleProc =O0OOO0000O00O00O0 .__O0000O0O0O0OO0000 #line:5233
            O0OOO0000O00O00O0 ._fMapCacheJob [OOO0000O0O000OO00 .RequestID ]=OOO0000O0O000OO00 #line:5234
            O0OOO0000O00O00O0 .__O0O0O0OOOO0OOOOO0 (OOO0000O0O000OO00 .RequestID ,OOO0000O0O000OO00 .TopicBAS )#line:5235
            return RCode .OK #line:5236
        except Exception as OO00O0O0OO0000000 :#line:5237
            O0OOO0000O00O00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteFUT:{OO00O0O0OO0000000}")#line:5238
            O0OOO0000O00O00O0 .__OOO000O0OOO0O00O0 (f"[期][DoSubQuoteFUT]{O0OO00O00000OO0O0}新增紀錄失敗!({OO00O0O0OO0000000})")#line:5239
            OOO000O00O0O00000 =threading .Thread (target =O0OOO0000O00O00O0 .__O0000O0O0000OOO00 ,args =(STKxFUT .FUT ,O0OO00O00000OO0O0 ))#line:5240
            OOO000O00O0O00000 .start ()#line:5241
            return RCode .FAIL #line:5242
    def __OO0O00OOOO00000O0 (OO000OO000OO00O00 ,O0O0O0OO0OOO0O0OO :str ,OO0OOO0OO0OOO00O0 :bool ):#line:5244
        ""#line:5247
        try :#line:5248
            OO0O0OO00O0O0OO00 :str =f"Quote/TWF/*/{O0O0O0OO0OOO0O0OO}/RECOVER"#line:5249
            O0OO000OOOO00OOO0 ,OOOO0O00OOO0O0OOO =OO000OO000OO00O00 .__O0OO0OO0OO00OOOO0 (OO000OO000OO00O00 ._vRcvTopic_Fut ,OO0O0OO00O0O0OO00 ,'utf-8',OO000OO000OO00O00 ._vRcvTopic_Fut_Req )#line:5251
            if O0OO000OOOO00OOO0 and OOOO0O00OOO0O0OOO !="":#line:5253
                O00OO0O0O0OOOO00O =json .loads (OOOO0O00OOO0O0OOO )#line:5254
                if "status"in O00OO0O0O0OOOO00O and len (O00OO0O0O0OOOO00O ["status"])>0 :#line:5255
                    if O00OO0O0O0OOOO00O ["status"][0 ]=="error":#line:5256
                        OO000OO000OO00O00 .__OOO000O0OOO0O00O0 (f"[期][DoSubQuoteFUT](aSolIce={O0O0O0OO0OOO0O0OO}, aData={OOOO0O00OOO0O0OOO})行情回補資料有誤!")#line:5257
                        return RCode .FAIL #line:5258
                if "BAS"in O00OO0O0O0OOOO00O and len (O00OO0O0O0OOOO00O ["BAS"])==0 :#line:5259
                    OO000OO000OO00O00 .__OOO000O0OOO0O00O0 (f"[期][DoSubQuoteFUT](aSolIce={O0O0O0OO0OOO0O0OO},aData={OOOO0O00OOO0O0OOO})沒有BAS資料!")#line:5260
                    return RCode .FAIL #line:5261
                if "HL"in O00OO0O0O0OOOO00O and len (O00OO0O0O0OOOO00O ["HL"])==0 :#line:5262
                    OO000OO000OO00O00 .__OOO000O0OOO0O00O0 (f"[期][DoSubQuoteFUT](aSolIce={O0O0O0OO0OOO0O0OO},aData={OOOO0O00OOO0O0OOO})沒有HL資料!")#line:5263
                    return RCode .FAIL #line:5264
                OO0O0OOOO00000O0O =OO000OO000OO00O00 .__O0O000OOOOOO00O00 (False ,O0O0O0OO0OOO0O0OO ,OO0OOO0OO0OOO00O0 ,O00OO0O0O0OOOO00O )#line:5267
                return OO0O0OOOO00000O0O #line:5268
            else :#line:5269
                return RCode .FAIL #line:5270
        except Exception as O0OO00OOO00O000O0 :#line:5271
            OO000OO000OO00O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteFUT:{O0OO00OOO00O000O0}")#line:5272
            OO000OO000OO00O00 .__OOO000O0OOO0O00O0 (f"[期][DoSubQuoteFUT]{O0O0O0OO0OOO0O0OO}新增紀錄失敗!({O0OO00OOO00O000O0})")#line:5273
            O0OOOOO0O0O000OO0 =threading .Thread (target =OO000OO000OO00O00 .__O0000O0O0000OOO00 ,args =(STKxFUT .FUT ,O0O0O0OO0OOO0O0OO ))#line:5274
            O0OOOOO0O0O000OO0 .start ()#line:5275
            return RCode .FAIL #line:5276
    def __O0000O00OOOOOOO0O (O0OO0OO0O0O0O000O ,O000OO00O0OO0OOOO :str ,O00O00O0OO000000O :bool ):#line:5277
        try :#line:5278
            OOOOO0OO00000OO00 :bool =False #line:5279
            O00O00OO0O00O00O0 :str =f"Quote/TWF/{O000OO00O0OO0OOOO}/*/RECOVER"#line:5280
            OOOOOOOO000O0O0O0 :str =""#line:5281
            OOOOO0OO00000OO00 ,OOOOOOOO000O0O0O0 =O0OO0OO0O0O0O000O .__O0OO0OO0OO00OOOO0 (O0OO0OO0O0O0O000O ._vRcvTopic_Fut ,O00O00OO0O00O00O0 ,'utf-8',O0OO0OO0O0O0O000O ._vRcvTopic_Fut_Req )#line:5283
            if OOOOO0OO00000OO00 :#line:5285
                O0000O0O00O0OOOO0 =json .loads (OOOOOOOO000O0O0O0 )#line:5286
                if "status"in O0000O0O00O0OOOO0 and len (O0000O0O00O0OOOO0 ["status"])>0 :#line:5289
                    if O0000O0O00O0OOOO0 ["status"][0 ]=="error":#line:5290
                        O0OO0OO0O0O0O000O .__OOO000O0OOO0O00O0 (f"[期][DoSubQuoteByCategory](aCat={O000OO00O0OO0OOOO}, aData={OOOOOOOO000O0O0O0})行情回補資料有誤!")#line:5291
                        return #line:5292
                if "BAS"in O0000O0O00O0OOOO0 and len (O0000O0O00O0OOOO0 ["BAS"])==0 :#line:5293
                    O0OO0OO0O0O0O000O .__OOO000O0OOO0O00O0 (f"[期][DoSubQuoteByCategory](aCat={O000OO00O0OO0OOOO}, aData={OOOOOOOO000O0O0O0})沒有BAS資料!")#line:5294
                    return #line:5295
                if "HL"in O0000O0O00O0OOOO0 and len (O0000O0O00O0OOOO0 ["HL"])==0 :#line:5296
                    O0OO0OO0O0O0O000O .__OOO000O0OOO0O00O0 (f"[期][DoSubQuoteByCategory](aCat={O000OO00O0OO0OOOO}, aData={OOOOOOOO000O0O0O0})沒有HL資料!")#line:5297
                    return #line:5298
                O0OO0OO0O0O0O000O .__O0O000OOOOOO00O00 (True ,O000OO00O0OO0OOOO ,O00O00O0OO000000O ,O0000O0O00O0OOOO0 )#line:5301
                return #line:5302
        except Exception as O0OO00O00OO0OOO00 :#line:5303
            pass #line:5304
        O000OOOOO0OOOOOOO =threading .Thread (target =O0OO0OO0O0O0O000O .__O0000O0O0000OOO00 ,args =(STKxFUT .FUT ,f"[期]新增分類紀錄失敗{O000OO00O0OO0OOOO}"))#line:5306
        O000OOOOO0OOOOOOO .start ()#line:5307
    def __O0O0O0OOO000O0OOO (O0OO000OOO00O0O0O ,OOOOOOOOO0O0O00OO :str ,O0O00O0000O0OOOO0 :bool ):#line:5309
        ""#line:5310
        try :#line:5311
            O0OOO000000OOO0O0 =TCacheJob ()#line:5312
            O0OOO000000OOO0O0 .TopicBAS =f"Quote/TWF/{OOOOOOOOO0O0O00OO}/*/BAS"#line:5313
            O0OOO000000OOO0O0 .oneProd =False #line:5314
            O0OOO000000OOO0O0 .RequestID =O0OO000OOO00O0O0O .GetRequestID ()#line:5315
            O0OOO000000OOO0O0 .HandleProc =O0OO000OOO00O0O0O .__OOOO00O0OOOOO0OOO #line:5316
            O0OOO000000OOO0O0 .Params ["Category"]="SubQuoteByCategory_BAS"#line:5317
            O0OO000OOO00O0O0O ._fMapCacheJob [O0OOO000000OOO0O0 .RequestID ]=O0OOO000000OOO0O0 #line:5318
            O0OO000OOO00O0O0O .__O0O0O0OOOO0OOOOO0 (O0OOO000000OOO0O0 .RequestID ,O0OOO000000OOO0O0 .TopicBAS )#line:5319
            return RCode .OK #line:5320
        except Exception as OOOO00O00000OOO0O :#line:5321
            O0OO000OOO00O0O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteByCategoryFUT:{OOOO00O00000OOO0O}")#line:5322
            O0OO000OOO00O0O0O .__OOO000O0OOO0O00O0 (f"[證][DoSubQuoteByCategoryFUT]{OOOOOOOOO0O0O00OO}新增紀錄失敗!({OOOO00O00000OOO0O})")#line:5323
        O0OOO0000OOOO000O =threading .Thread (target =O0OO000OOO00O0O0O .__O0000O0O0000OOO00 ,args =(STKxFUT .FUT ,f"[期]新增分類紀錄失敗{OOOOOOOOO0O0O00OO}"))#line:5325
        O0OOO0000OOOO000O .start ()#line:5326
    def __O00OO00O000O00OO0 (O000O0OO0OOO00OO0 ,OO0OO00O0OO00OO0O :str ,O0OOOO00OOOO0OO00 :bool ):#line:5328
        try :#line:5329
            O000000OOOO0O0OOO :bool =False #line:5330
            OO00O00OO0OOOO0OO =f"QuoteOvs/*/*/{OO0OO00O0OO00OO0O}/RECOVER"#line:5332
            O000000OOOO0O0OOO ,O00O00OO00OO000O0 =O000O0OO0OOO00OO0 .__O0OO0OO0OO00OOOO0 (O000O0OO0OOO00OO0 ._vRcvTopic_OvsFut ,OO00O00OO0OOOO0OO ,'big5',O000O0OO0OOO00OO0 ._vRcvTopic_OvsFut_Req )#line:5333
            if O000000OOOO0O0OOO :#line:5335
                OOOOO00O00OO0OOOO =json .loads (O00O00OO00OO000O0 )#line:5336
                if "status"in OOOOO00O00OO0OOOO and len (OOOOO00O00OO0OOOO ["status"])>0 :#line:5337
                    if OOOOO00O00OO0OOOO ["status"][0 ]=="error":#line:5338
                         O000O0OO0OOO00OO0 .__OOO000O0OOO0O00O0 (f"[海期][DoSubQuoteOvsFUT](aSolIce={OO0OO00O0OO00OO0O}, aData={O00O00OO00OO000O0})行情回補資料有誤!")#line:5339
                         return RCode .FAIL #line:5340
                    if "BAS"in OOOOO00O00OO0OOOO and len (OOOOO00O00OO0OOOO ["BAS"])==0 :#line:5341
                        O000O0OO0OOO00OO0 .__OOO000O0OOO0O00O0 (f"[海期][DoSubQuoteOvsFUT](aSolIce={OO0OO00O0OO00OO0O}, aData={O00O00OO00OO000O0})沒有BAS資料!")#line:5342
                        return RCode .FAIL #line:5343
                O0OO00OOO0O0O00O0 =O000O0OO0OOO00OO0 .__O0O0OO0OOO0OOO0O0 (False ,OO0OO00O0OO00OO0O ,O0OOOO00OOOO0OO00 ,OOOOO00O00OO0OOOO )#line:5346
                return O0OO00OOO0O0O00O0 #line:5348
            else :#line:5349
                return RCode .FAIL #line:5350
        except Exception as O00000O00O00O0000 :#line:5351
            O000O0OO0OOO00OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteOvsFUT: {O00000O00O00O0000}")#line:5353
            O0OO0O000O0O000O0 =TQtRcvEventData ()#line:5355
            O0OO0O000O0O000O0 .SetRcvBAS_Fail (OO0OO00O0OO00OO0O )#line:5356
            O000O0OO0OOO00OO0 .__O0000O0OO0OO00O00 .Add (arg1 =STKxFUT .OVSFUT ,arg2 =O0OO0O000O0O000O0 )#line:5357
            return RCode .FAIL #line:5358
    def __OOOO00O0OO00000O0 (OOOOO000O000OO0OO ,OO0OOO00OOOO00O00 :bool ,aExchange :str ="*"):#line:5360
        ""#line:5364
        try :#line:5365
            OOO0000OO00O0O0OO :bool =False #line:5366
            O00O00O00000OO000 :str =f"QuoteOvs/{aExchange}/FUT/*/RECOVER"#line:5367
            OOOOO0000O00O00O0 :str =""#line:5368
            OOO0000OO00O0O0OO ,OOOOO0000O00O00O0 =OOOOO000O000OO0OO .__O0OO0OO0OO00OOOO0 (OOOOO000O000OO0OO ._vRcvTopic_OvsFut ,O00O00O00000OO000 ,'big5',OOOOO000O000OO0OO ._vRcvTopic_OvsFut_Req )#line:5369
            if OOO0000OO00O0O0OO :#line:5371
                OOO0OOO0O0OO0OO00 =json .loads (OOOOO0000O00O00O0 )#line:5372
                if "status"in OOO0OOO0O0OO0OO00 and len (OOO0OOO0O0OO0OO00 ["status"])>0 :#line:5374
                    if OOO0OOO0O0OO0OO00 ["status"][0 ]=="error":#line:5375
                        OOOOO000O000OO0OO .__OOO000O0OOO0O00O0 (f"[海期][DoSubQuoteByCategory](aSolIce={aExchange}, aData={OOOOO0000O00O00O0})行情回補資料有誤!")#line:5376
                        return RCode .FAIL #line:5377
                    if "BAS"in OOO0OOO0O0OO0OO00 and len (OOO0OOO0O0OO0OO00 ["BAS"])==0 :#line:5378
                        OOOOO000O000OO0OO .__OOO000O0OOO0O00O0 (f"[海期][DoSubQuoteByCategory](aSolIce={aExchange}, aData={OOOOO0000O00O00O0})沒有BAS資料!")#line:5379
                        return RCode .FAIL #line:5380
                OO00O0OO000O0OOO0 =OOOOO000O000OO0OO .__O0O0OO0OOO0OOO0O0 (False ,aExchange ,OO0OOO00OOOO00O00 ,OOO0OOO0O0OO0OO00 )#line:5384
                return OO00O0OO000O0OOO0 #line:5385
            else :#line:5386
                return RCode .FAIL #line:5387
        except Exception as OOOO0OOOO00OO0OOO :#line:5388
            OOOOO000O000OO0OO .__OOO000O0OOO0O00O0 (f"[海期][DoSubQuoteByCategoryOvsFUT] 新增分類紀錄失敗!")#line:5389
            return RCode .FAIL #line:5390
    def __O0O0O00OOOOO0O000 (O000OO0O000OO00O0 ,O000O000OOOOOOOO0 :str ):#line:5392
        ""#line:5395
        OOO00OOOOO0OOOO00 :str =""#line:5397
        try :#line:5398
            OOO0000000O00OO0O :list =[]#line:5399
            O0OOO0000O0OOOO00 ,OOO0000000O00OO0O ,OOO00OOOOO0OOOO00 =O000OO0O000OO00O0 ._fMapQuoteOvsFUT .GetItem_ByExchange (O000O000OOOOOOOO0 )#line:5400
            if O0OOO0000O0OOOO00 ==False :#line:5401
                return False ,OOO00OOOOO0OOOO00 #line:5402
            for O00OO00O000O0O0OO in OOO0000000O00OO0O :#line:5403
                O000OO0O000OO00O0 .__O0OO000O000OO000O .Add (arg1 =STKxFUT .FUT ,arg2 =O00OO00O000O0O0OO )#line:5404
            return True ,""#line:5405
        except Exception as OO00O0O0000O00OO0 :#line:5407
            OOO00OOOOO0OOOO00 =f"[海期][DoUnSubQuoteByCategory](aExchange={O000O000OOOOOOOO0}){OO00O0O0000O00OO0}"#line:5408
        return False ,OOO00OOOOO0OOOO00 #line:5409
    def __OO0O0OO0OOOO0O0O0 (OO0O0OOOO000OO0OO ,O0000O0O0000OOO00 :bool ,O0000O0OO00O0O0O0 :str ,OOOOOO000O00OO0OO :bool ,OOO000000O0OO00O0 ,topic :str =""):#line:5411
        ""#line:5412
        try :#line:5413
            O000O0000OOOOO0O0 :TObjStkQuoteMap =None #line:5414
            O0O0OOOOOO0O0O0OO :str =""#line:5415
            O00000OO00OOOO000 ,O000O0000OOOOO0O0 ,O0O0OOOOOO0O0O0OO =OO0O0OOOO000OO0OO ._fMapQuoteSTK .AddDataBySolIce (O0000O0O0000OOO00 ,O0000O0OO00O0O0O0 ,OOO000000O0OO00O0 ,OOOOOO000O00OO0OO ,topic )#line:5416
            if O00000OO00OOOO000 :#line:5417
                OO0O0OOOO000OO0OO .__O0000O0OO0OO00O00 .Add (arg1 =STKxFUT .STK ,arg2 =O000O0000OOOOO0O0 )#line:5418
                for O000OOO0OO0OOOO0O ,O0O0OOOO00O0OO0OO in O000O0000OOOOO0O0 .items ():#line:5421
                    O0O000000O0OO0OOO :TStkQuoteData =O0O0OOOO00O0OO0OO #line:5422
                    if topic =="":#line:5423
                        OO0O0OOOO000OO0OO .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .STK ,arg2 =O0O000000O0OO0OOO .HL .TopicTX )#line:5424
                        OO0O0OOOO000OO0OO .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .STK ,arg2 =O0O000000O0OO0OOO .HL .Topic5Q )#line:5425
                    else :#line:5426
                        OO0O0OOOO000OO0OO .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .STK ,arg2 =O0O000000O0OO0OOO .BAS .TopicTX )#line:5427
                        OO0O0OOOO000OO0OO .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .STK ,arg2 =O0O000000O0OO0OOO .BAS .Topic5Q )#line:5428
                return RCode .OK #line:5429
            else :#line:5430
                OO0O0OOOO000OO0OO .__OOO000O0OOO0O00O0 (f"[證][DoSubQuote_RTonlySTK]({O0000O0O0000OOO00},{O0000O0OO00O0O0O0})回補失敗!({O0O0OOOOOO0O0O0OO})")#line:5431
                return RCode .FAIL #line:5432
        except Exception as OOOOOO000000OOO0O :#line:5434
            OO0O0OOOO000OO0OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuote_RTonlySTK: {OOOOOO000000OOO0O}")#line:5436
            return RCode .FAIL #line:5437
    def __O0O000OOOOOO00O00 (OO000O0OO0OOOO00O ,O0OOOO000OOO00000 :bool ,OO00000O0O0O000O0 :str ,O00OOO0O0O0OO000O :bool ,O00O0O0000O0OO000 ,topic :str =""):#line:5439
        ""#line:5442
        try :#line:5443
            OOOO0000OO0OOO0OO :TObjFutQuoteMap =None #line:5444
            OO00OOOO000O000O0 :str =""#line:5445
            O0OOOOO00O00OO000 ,OOOO0000OO0OOO0OO ,OO00OOOO000O000O0 =OO000O0OO0OOOO00O ._fMapQuoteFUT .AddDataBySolIce (O0OOOO000OOO00000 ,OO00000O0O0O000O0 ,O00O0O0000O0OO000 ,O00OOO0O0O0OO000O ,topic )#line:5446
            if O0OOOOO00O00OO000 :#line:5447
                OO000O0OO0OOOO00O .__O0000O0OO0OO00O00 .Add (arg1 =STKxFUT .FUT ,arg2 =OOOO0000OO0OOO0OO )#line:5448
                for OO000O0O0OOOO00OO ,O000O00O000OOOO00 in OOOO0000OO0OOO0OO .items ():#line:5451
                    OOO0000O0OOOOO000 :TFutQuoteData =O000O00O000OOOO00 #line:5452
                    if topic =="":#line:5453
                        OO000O0OO0OOOO00O .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .FUT ,arg2 =OOO0000O0OOOOO000 .HL .TopicTX )#line:5454
                        OO000O0OO0OOOO00O .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .FUT ,arg2 =OOO0000O0OOOOO000 .HL .Topic5Q )#line:5455
                        OO000O0OO0OOOO00O .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .FUT ,arg2 =OOO0000O0OOOOO000 .HL .Topic5QTOT )#line:5456
                        OO000O0OO0OOOO00O .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .FUT ,arg2 =OOO0000O0OOOOO000 .HL .TopicBAS )#line:5457
                    else :#line:5458
                        OO000O0OO0OOOO00O .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .FUT ,arg2 =OOO0000O0OOOOO000 .BAS .TopicTX )#line:5459
                        OO000O0OO0OOOO00O .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .FUT ,arg2 =OOO0000O0OOOOO000 .BAS .Topic5Q )#line:5460
                        OO000O0OO0OOOO00O .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .FUT ,arg2 =OOO0000O0OOOOO000 .BAS .Topic5QTOT )#line:5461
                        OO000O0OO0OOOO00O .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .FUT ,arg2 =OOO0000O0OOOOO000 .BAS .TopicBAS )#line:5462
                return RCode .OK #line:5463
            else :#line:5464
                OO000O0OO0OOOO00O .__OOO000O0OOO0O00O0 (f"[期][DoSubQuote_RTonlyFUT]{OO00000O0O0O000O0}新增紀錄失敗!({OO00OOOO000O000O0})")#line:5465
                return RCode .FAIL #line:5466
        except Exception as O0OOOOO000OOOOOO0 :#line:5468
            OO000O0OO0OOOO00O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuote_RTonlyFUT: {O0OOOOO000OOOOOO0}")#line:5470
            return RCode .FAIL #line:5471
    def __O0O0OO0OOO0OOO0O0 (O0OO00O000OO0O000 ,O0OOOOOOO0OOO0OOO :bool ,OOOO00OOOOO000000 :str ,O0OO0O0000O0O0O00 :bool ,OO0O0OOOO0000O000 ):#line:5473
        ""#line:5475
        try :#line:5476
            O0OOOOO0000OO00O0 :TMapOvsFutQuoteData =None #line:5477
            O0O0000OO0O00000O :str =""#line:5478
            O0O000OOOO00O00O0 ,O0OOOOO0000OO00O0 ,O0O0000OO0O00000O =O0OO00O000OO0O000 ._fMapQuoteOvsFUT .AddDataBySolIce (O0OOOOOOO0OOO0OOO ,OOOO00OOOOO000000 ,OO0O0OOOO0000O000 ,O0OO0O0000O0O0O00 )#line:5479
            if O0O000OOOO00O00O0 :#line:5480
                O0O0OO000OO00OO00 =TQtRcvEventData ()#line:5482
                O0O0OO000OO00OO00 .SetRcvBAS_Succ ("",O0OOOOO0000OO00O0 )#line:5483
                O0OO00O000OO0O000 .__O0000O0OO0OO00O00 .Add (arg1 =STKxFUT .OVSFUT ,arg2 =O0O0OO000OO00OO00 )#line:5484
                for O00O00OOO0OO0O0O0 ,O0O00OO0OOO0OOOO0 in O0OOOOO0000OO00O0 .items ():#line:5487
                    O000OO0OO0O00OO0O :TOvsFutQuoteData =O0O00OO0OOO0OOOO0 #line:5488
                    O0OO00O000OO0O000 .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .OVSFUT ,arg2 =O000OO0OO0O00OO0O .HL .TopicTX )#line:5489
                    O0OO00O000OO0O000 .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .OVSFUT ,arg2 =O000OO0OO0O00OO0O .HL .Topic5Q )#line:5490
                return RCode .OK #line:5491
            else :#line:5492
                O0OO00O000OO0O000 .__OOO000O0OOO0O00O0 (f"[海期][DoSubQuote_RTonlyOvsFUT]{OOOO00OOOOO000000}新增紀錄失敗!({O0O0000OO0O00000O})")#line:5493
                return RCode .FAIL #line:5494
        except Exception as O0OO0OOO00O0OOO0O :#line:5495
            O0OO00O000OO0O000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuote_RTonlyOvsFUT: {O0OO0OOO00O0OOO0O}")#line:5496
            return RCode .FAIL #line:5497
    def __OOOO0000O00000O00 (O00O0O00OOO00O000 ,OO00OO0000OOOOO0O :str ,OOO0000O0OOO000OO :bool ):#line:5501
        ""#line:5504
        try :#line:5505
            O0O0OO000O000000O =False #line:5506
            OO0O00O00O0O0O00O =f"Quote/TWS/*/*/{OO00OO0000OOOOO0O}/RECOVER"#line:5507
            OO00O00OO0O0O00OO =""#line:5508
            O0O0OO000O000000O ,OO00O00OO0O0O00OO =O00O0O00OOO00O000 .__O0OO0OO0OO00OOOO0 (O00O0O00OOO00O000 ._vRcvTopic_Stk ,OO0O00O00O0O0O00O ,'utf-8',O00O0O00OOO00O000 ._vRcvTopic_Stk_Req )#line:5510
            if O0O0OO000O000000O :#line:5511
                OOOO0000O00OOOO00 =json .loads (OO00O00OO0O0O00OO )#line:5512
            if O0O0OO000O000000O and OO00O00OO0O0O00OO !="":#line:5513
                O00O00OOO00O0O000 :TStkQuoteData =None #line:5514
                O00OOO00OO0O00OO0 :str #line:5515
                O0O0O0O0OOOO0O0O0 ,O00O00OOO00O0O000 ,O00OOO00OO0O00OO0 =O00O0O00OOO00O000 ._fMapQuoteSTK .AddRcvData (TStkProdKind .pkIndex ,OO00OO0000OOOOO0O ,OO00O00OO0O0O00OO ,OOO0000O0OOO000OO )#line:5517
                if O0O0O0O0OOOO0O0O0 :#line:5518
                    O00O0O00OOO00O000 .__O0000O0OO0OO00O00 .Add (arg1 =STKxFUT .STK ,arg2 =O00O00OOO00O0O000 )#line:5520
                    O00O0O00OOO00O000 .__O0OO0O0OO00O0OO0O (O00O00OOO00O0O000 .HL .Market ,O00O00OOO00O0O000 .HL .StkKind ,OO00OO0000OOOOO0O ,OOOO0000O00OOOO00 )#line:5522
                    return #line:5523
                else :#line:5524
                    O00O0O00OOO00O000 .__OOO000O0OOO0O00O0 (f"[證][DoSubIdxQuoteSTK]{OO00OO0000OOOOO0O}新增紀錄失敗!")#line:5526
        except Exception as OO000000O000O0OO0 :#line:5528
            O00O0O00OOO00O000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubIdxQuoteSTK:{OO000000O000O0OO0}")#line:5529
        O00OOO00OOOOOOOOO =threading .Thread (target =O00O0O00OOO00O000 .__O0O00O0O0OO000O00 ,args =OO00OO0000OOOOO0O )#line:5531
        O00OOO00OOOOOOOOO .start ()#line:5532
    def __OO0O0000OOOO0O0OO (O00OOOOO000O00000 ,OOOOOO00O0O000OO0 :str ,OOO00OOOOOO0OO000 :bool ):#line:5534
        ""#line:5537
        try :#line:5538
            O0OOO00O000000OO0 :str =f"Quote/TWF/IDX/{OOOOOO00O0O000OO0}/MR"#line:5540
            if O00OOOOO000O00000 ._fMapQuoteFUT .AddData (TFutProdKind .pkIndex ,OOOOOO00O0O000OO0 ,OOO00OOOOOO0OO000 ,O0OOO00O000000OO0 ,O00OOOOO000O00000 .__OO00OO0OOO0OOOO00 ):#line:5541
                O00OOOOO000O00000 .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .FUT ,arg2 =O0OOO00O000000OO0 )#line:5542
            else :#line:5543
                O00OOOOO000O00000 .__OOO000O0OOO0O00O0 (f"[期][DoSubIdxQuote_RTonly]{OOOOOO00O0O000OO0}新增紀錄失敗!")#line:5545
        except Exception as O0O000OOO0O0O00O0 :#line:5546
            O00OOOOO000O00000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubIdxQuoteFUT:{O0O000OOO0O0O00O0}")#line:5547
    def __O0OO0O0OO00O0OO0O (OOOOO00O000O00000 ,OOO0OO00OO000OO00 :bool ,O0OO00O0O00OO0OOO :str ,OOO00000OO0O0OO0O :bool ,OOOOO000O0OO00OOO ):#line:5549
        ""#line:5553
        try :#line:5554
            O0OOO0O0OO0OOO00O :TObjStkQuoteMap =None #line:5555
            O00OO0O000OO0OOOO :str =""#line:5556
            O00O00000O0O0OO0O ,O0OOO0O0OO0OOO00O ,O00OO0O000OO0OOOO =OOOOO00O000O00000 ._fMapQuoteSTK .AddIdxDataBySolIce (OOO0OO00OO000OO00 ,O0OO00O0O00OO0OOO ,OOOOO000O0OO00OOO ,OOO00000OO0O0OO0O )#line:5557
            if O00O00000O0O0OO0O :#line:5559
                OOOOO00O000O00000 .__OOOOO000OO0O0O00O (O0OOO0O0OO0OOO00O )#line:5561
                for OO0O0O0O0O0OOO0O0 ,OO0OOO000OOOOOO00 in O0OOO0O0OO0OOO00O .items ():#line:5565
                    OO0O00O00O0O0O0OO :TStkQuoteData =OO0OOO000OOOOOO00 #line:5566
                    OOOOO00O000O00000 .__O0O0O0000OO0O0O00 .Add (arg1 =STKxFUT .STK ,arg2 =OO0O00O00O0O0O0OO .HL .TopicTX )#line:5567
                return RCode .OK #line:5568
            else :#line:5569
                OOOOO00O000O00000 .__OOO000O0OOO0O00O0 (f"[證][HandleRecover_Idx]({OOO0OO00OO000OO00},{O0OO00O0O00OO0OOO})新增紀錄失敗!({O00OO0O000OO0OOOO})")#line:5570
                return RCode .FAIL #line:5571
        except Exception as O0OO000OO00OOOO0O :#line:5572
            OOOOO00O000O00000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubIdxQuote_RTonlySTK:{O0OO000OO00OOOO0O}")#line:5574
            return RCode .FAIL #line:5575
    def __O0O0O0OOOO0OOOOO0 (O0O0O00OOOO0O0O0O ,O000OO0OOOOOOO0O0 ,OOO00000O0OO0O000 :str ):#line:5578
        OOO000O0OOOOOOO00 =CachedMessageSubscriptionRequest .as_available ("dc01",TopicSubscription .of (OOO00000O0OO0O000 ),60000 )#line:5579
        O0O0O00OOOO0O0O0O ._message_receiver .request_cached (OOO000O0OOOOOOO00 ,O000OO0OOOOOOO0O0 ,O0O0O00OOOO0O0O0O ._cacheReqOutListener )#line:5580
    def callcache (OO00O000O00O0O0O0 ,O0O0O0OO0O0O000O0 ,OOOOOOOOOO00OOOO0 :str ):#line:5582
        OO00O000O00O0O0O0 .__O0O0O0OOOO0OOOOO0 (O0O0O0OO0O0O000O0 ,OOOOOOOOOO00OOOO0 )#line:5583
    def __OOOO00O0OOOOO0OOO (OOOOOOO0000OO00O0 ,OO000OO0OO000O000 :TCacheJob ):#line:5585
        ""#line:5586
        try :#line:5587
            O0OOO0000O0O0000O :dict ={}#line:5588
            for O0O0OO00OO00OO00O ,OO0O000O00OOOO000 in OO000OO0OO000O000 .CacheData .items ():#line:5589
                O0O0OOO0O0OO0OO0O :'InboundMessage'=OO0O000O00OOOO000 #line:5590
                O000O000O00OOO000 =O0O0OOO0O0OO0OO0O .get_destination_name ()#line:5591
                O0O0O0O000OOOOO0O =O0O0OOO0O0OO0OO0O .get_payload_as_bytes ().decode ('utf-8')#line:5592
                OOOOO00O000O0OO00 :str =""#line:5593
                if O000O000O00OOO000 .endswith (OOOOOOO0000OO00O0 ._vQuote_BAS ):#line:5594
                    O0OOO0000O0O0000O ["BAS"]=[O0O0O0O000OOOOO0O ]#line:5595
                    OOOOO00O000O0OO00 =O000O000O00OOO000 #line:5596
                elif O000O000O00OOO000 .endswith (OOOOOOO0000OO00O0 ._vQuote_HL ):#line:5597
                    O0OOO0000O0O0000O ["HL"]=[O0O0O0O000OOOOO0O ]#line:5598
            OOOOOOO0000OO00O0 .__OO0O0OO0OOOO0O0O0 (False ,OO000OO0OO000O000 .prod ,True ,O0OOO0000O0O0000O ,OOOOO00O000O0OO00 )#line:5600
        except Exception as OO0OO00O0O00O0OO0 :#line:5602
            OOOOOOO0000OO00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_CacheJob_StkBAS Error:{OO0OO00O0O00O0OO0}")#line:5603
    def __O0O0O0OOO0O0O000O (O00O00000OOO0000O ,O0O0000OO0OOOO0OO :TCacheJob ):#line:5605
        try :#line:5607
            OOOOO00O0O0O000O0 :'InboundMessage'=O0O0000OO0OOOO0OO .CacheData [O0O0000OO0OOOO0OO .TopicHL ]#line:5608
            O0O00O000OOO0OO0O =OOOOO00O0O0O000O0 .get_payload_as_bytes ().decode ('utf-8')#line:5609
            if O00O00000OOO0000O ._fMapQuoteSTK .get (O0O0000OO0OOOO0OO .TopicTX )is not None :#line:5610
                O000O00OOOOOO0O00 :TObjStkQuoteMap =TObjStkQuoteMap ()#line:5611
                OOO00O00OOO0O0O0O :TStkQuoteData =O00O00000OOO0000O ._fMapQuoteSTK [O0O0000OO0OOOO0OO .TopicTX ]#line:5612
                OOO00O00OOO0O0O0O .UpdateHL =True #line:5613
                OOO00O00OOO0O0O0O .HL .Handle_HL (O0O00O000OOO0OO0O )#line:5614
                OOO00O00OOO0O0O0O .QtTX .HighPrice =OOO00O00OOO0O0O0O .HL .Get_HighPrice ()#line:5616
                OOO00O00OOO0O0O0O .QtTX .LowPrice =OOO00O00OOO0O0O0O .HL .Get_LowPrice ()#line:5617
                OOO00O00OOO0O0O0O .QtTX .HL_Sn_5Q =OOO00O00OOO0O0O0O .HL .Get_Sn_5Q ()#line:5619
                OOO00O00OOO0O0O0O .QtTX .HL_TotAmt =OOO00O00OOO0O0O0O .HL .Get_TotAmt2Int ()#line:5621
                O000O00OOOOOO0O00 [O0O0000OO0OOOO0OO .prod ]=OOO00O00OOO0O0O0O #line:5622
                O00O00000OOO0000O .__O0000O0OO0OO00O00 .Add (arg1 =STKxFUT .STK ,arg2 =O000O00OOOOOO0O00 )#line:5624
            else :#line:5625
                O0000O0OOOO0O00O0 =TCacheJob ()#line:5626
                O0000O0OOOO0O00O0 .prod =O0O0000OO0OOOO0OO .prod #line:5627
                O0000O0OOOO0O00O0 .TopicBAS =O0O0000OO0OOOO0OO .TopicBAS #line:5628
                O0000O0OOOO0O00O0 .TopicHL =O0O0000OO0OOOO0OO .TopicHL #line:5629
                O0000O0OOOO0O00O0 .TopicTX =O0O0000OO0OOOO0OO .TopicTX #line:5630
                O0000O0OOOO0O00O0 .RequestID =O00O00000OOO0000O .GetRequestID ()#line:5631
                O0000O0OOOO0O00O0 .HandleProc =O00O00000OOO0000O .__O0O0O0OOO0O0O000O #line:5632
                O00O00000OOO0000O ._fMapCacheJob [O0000O0OOOO0O00O0 .RequestID ]=O0000O0OOOO0O00O0 #line:5633
                O00O00000OOO0000O .__O0O0O0OOOO0OOOOO0 (O0000O0OOOO0O00O0 .RequestID ,O0000O0OOOO0O00O0 .TopicHL )#line:5634
        except Exception as O00OO00OOO00OO0O0 :#line:5635
            O00O00000OOO0000O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"__Handle_RTQuote_STK_HL:{O00OO00OOO00OO0O0}")#line:5636
    def __O0000O0O0O0OO0000 (O0OOOOOOO00000OOO ,OO000OO0O0OOO00OO :TCacheJob ):#line:5638
        ""#line:5639
        try :#line:5640
            O0O0O00O00000O00O :dict ={}#line:5641
            for O0O00OOO00O0OOO0O ,O000O0OOOO000OO0O in OO000OO0O0OOO00OO .CacheData .items ():#line:5642
                OOOO0000O00OOO000 :'InboundMessage'=O000O0OOOO000OO0O #line:5643
                OO00O0000OOO0O000 =OOOO0000O00OOO000 .get_destination_name ()#line:5644
                O0OO0OOO0OO00OOOO =OOOO0000O00OOO000 .get_payload_as_bytes ().decode ('utf-8')#line:5645
                O0000OOO0OO0OOOO0 :str =""#line:5646
                if OO00O0000OOO0O000 .endswith (O0OOOOOOO00000OOO ._vQuote_BAS ):#line:5647
                    O0O0O00O00000O00O ["BAS"]=[O0OO0OOO0OO00OOOO ]#line:5648
                    O0000OOO0OO0OOOO0 =OO00O0000OOO0O000 #line:5649
                elif OO00O0000OOO0O000 .endswith (O0OOOOOOO00000OOO ._vQuote_HL ):#line:5650
                    O0O0O00O00000O00O ["HL"]=[O0OO0OOO0OO00OOOO ]#line:5651
            O0OOOOOOO00000OOO .__O0O000OOOOOO00O00 (False ,OO000OO0O0OOO00OO .prod ,True ,O0O0O00O00000O00O ,O0000OOO0OO0OOOO0 )#line:5653
        except Exception as O00OOO0000OOOOO00 :#line:5655
            O0OOOOOOO00000OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_CacheJob_FutBAS Error:{O00OOO0000OOOOO00}")#line:5656
    def __OO0OO0OO0O0O0O0O0 (O000O0O0OO0OO0OOO ,OOOO00OO0OOOOOO0O :TCacheJob ):#line:5658
        try :#line:5660
            OOO0O00O0000O0OO0 :'InboundMessage'=OOOO00OO0OOOOOO0O .CacheData [OOOO00OO0OOOOOO0O .TopicHL ]#line:5661
            O000OO00000O00O00 =OOO0O00O0000O0OO0 .get_payload_as_bytes ().decode ('utf-8')#line:5662
            if O000O0O0OO0OO0OOO ._fMapQuoteFUT .get (OOOO00OO0OOOOOO0O .TopicTX )is not None :#line:5663
                O0OO0O0O000O0000O :TObjFutQuoteMap =TObjFutQuoteMap ()#line:5664
                O0000O0000O0OO00O :TFutQuoteData =O000O0O0OO0OO0OOO ._fMapQuoteFUT [OOOO00OO0OOOOOO0O .TopicTX ]#line:5665
                O0000O0000O0OO00O .UpdateHL =True #line:5666
                O0000O0000O0OO00O .HL .Handle_HL (O000OO00000O00O00 )#line:5667
                O0000O0000O0OO00O .QtTX .HighPrice =O0000O0000O0OO00O .HL .Get_HighPrice2Dec ()#line:5668
                O0000O0000O0OO00O .QtTX .LowPrice =O0000O0000O0OO00O .HL .Get_LowPrice2Dec ()#line:5669
                O0OO0O0O000O0000O [OOOO00OO0OOOOOO0O .prod ]=O0000O0000O0OO00O #line:5670
                O000O0O0OO0OO0OOO .__O0000O0OO0OO00O00 .Add (arg1 =STKxFUT .FUT ,arg2 =O0OO0O0O000O0000O )#line:5672
            else :#line:5673
                O0O0O0O0O000OOO00 ,O0O0O0O0000000O0O =OOOO00OO0OOOOOO0O .ReSet ()#line:5674
                if O0O0O0O0O000OOO00 :#line:5676
                    OO00OO0O0000OO0O0 =TCacheJob ()#line:5677
                    OO00OO0O0000OO0O0 .prod =OOOO00OO0OOOOOO0O .prod #line:5678
                    OO00OO0O0000OO0O0 .TopicBAS =OOOO00OO0OOOOOO0O .TopicBAS #line:5679
                    OO00OO0O0000OO0O0 .TopicHL =OOOO00OO0OOOOOO0O .TopicHL #line:5680
                    OO00OO0O0000OO0O0 .TopicTX =OOOO00OO0OOOOOO0O .TopicTX #line:5681
                    OO00OO0O0000OO0O0 .fCurCnt =OOOO00OO0OOOOOO0O .fCurCnt #line:5682
                    OO00OO0O0000OO0O0 .RequestID =O000O0O0OO0OO0OOO .GetRequestID ()#line:5683
                    OO00OO0O0000OO0O0 .HandleProc =O000O0O0OO0OO0OOO .__OO0OO0OO0O0O0O0O0 #line:5684
                    O000O0O0OO0OO0OOO ._fMapCacheJob [OO00OO0O0000OO0O0 .RequestID ]=OO00OO0O0000OO0O0 #line:5685
                    O000O0O0OO0OO0OOO .__O0O0O0OOOO0OOOOO0 (OO00OO0O0000OO0O0 .RequestID ,OO00OO0O0000OO0O0 .TopicHL )#line:5686
        except Exception as OOO0O00OO0O0O0O0O :#line:5687
            O000O0O0OO0OO0OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"__Handle_RTQuote_FUT_HL:{OOO0O00OO0O0O0O0O}")#line:5688
    def __OO0000OOO00O0O0OO (OOOO00O0O0O0O0O0O ,OOO0OOO0O0O00O00O :STKxFUT ,OO000OOOOO000O0OO :str ):#line:5690
        try :#line:5691
            with OOOO00O0O0O0O0O0O ._lock :#line:5692
                OOOO00O0O0O0O0O0O ._message_receiver .add_subscription (TopicSubscription .of (OO000OOOOO000O0OO ))#line:5693
        except Exception as O0OOO00O0O0OOOO0O :#line:5694
            OOOO00O0O0O0O0O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"SolaceSubTopic:{OO000OOOOO000O0OO}, {O0OOO00O0O0OOOO0O}")#line:5696
    def __OOOO0000000O0O0O0 (OO00O0O00O00OOOO0 ,O0O0O0O0OOOOOOO00 :str ):#line:5698
        ""#line:5701
        OOOOO00O0000OO000 :str =""#line:5702
        try :#line:5703
            O0O00OOOO0OOOO00O =[]#line:5704
            OOOOOOOOOO000O0OO :bool #line:5705
            OOOOOOOOOO000O0OO ,O0O00OOOO0OOOO00O ,OOOOO00O0000OO000 =OO00O0O00O00OOOO0 ._fMapQuoteSTK .GetItem_BySolIce (O0O0O0O0OOOOOOO00 )#line:5707
            if OOOOOOOOOO000O0OO ==False :#line:5708
                return False ,OOOOO00O0000OO000 #line:5709
            for OO00O00O0000O00O0 in O0O00OOOO0OOOO00O :#line:5710
                OO00O0O00O00OOOO0 .__O0OO000O000OO000O .Add (arg1 =STKxFUT .STK ,arg2 =OO00O00O0000O00O0 )#line:5711
            return True ,""#line:5712
        except Exception as OOOO00000OOO000O0 :#line:5713
            OO00O0O00O00OOOO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoUnSubTopicSTK:{OOOO00000OOO000O0}")#line:5714
            return False ,f"[證][DoUnSubTopicSTK](aSolICE={O0O0O0O0OOOOOOO00}){OOOO00000OOO000O0}"#line:5715
    def __OOO00OO0000O000OO (OO0O0OOOOOO00O0O0 ,OOO00OO0OOOO0O000 :str ):#line:5716
        ""#line:5718
        OO0O000O00O0O00OO :str =""#line:5719
        try :#line:5720
            O0O0O000O000OOOOO =[]#line:5721
            O0OO00OO0OO0OO000 ,O0O0O000O000OOOOO ,OO0O000O00O0O00OO =OO0O0OOOOOO00O0O0 ._fMapQuoteSTK .GetItem_ByCategory (OOO00OO0OOOO0O000 )#line:5722
            if O0OO00OO0OO0OO000 ==False :#line:5723
                return RCode .FAIL ,OO0O000O00O0O00OO #line:5724
            for O00O0O0OOO00O0000 in O0O0O000O000OOOOO :#line:5726
                OO0O0OOOOOO00O0O0 .__O0OO000O000OO000O .Add (arg1 =STKxFUT .STK ,arg2 =O00O0O0OOO00O0000 )#line:5727
            return RCode .OK ,""#line:5728
        except Exception as O00OO00O0O0000O00 :#line:5729
            OO0O000O00O0O00OO =f"[證][DoUnSubTopicByCategory](aCat={OOO00OO0OOOO0O000}){O00OO00O0O0000O00}"#line:5730
        return RCode .FAIL ,OO0O000O00O0O00OO #line:5731
    def __OO0OOO0O0O0OO00O0 (O00O0O000O00O00OO ,O0O0O00000O0OO0O0 :str ):#line:5733
        ""#line:5736
        OOO0O000O0O0OO00O :str =""#line:5737
        try :#line:5738
            OOO0O00000OOO0OO0 =[]#line:5739
            O0O0000O00O000O0O :bool #line:5740
            O0O0000O00O000O0O ,OOO0O00000OOO0OO0 ,OOO0O000O0O0OO00O =O00O0O000O00O00OO ._fMapQuoteFUT .GetItem_BySolIce (O0O0O00000O0OO0O0 )#line:5742
            if O0O0000O00O000O0O ==False :#line:5743
                return False ,OOO0O000O0O0OO00O #line:5744
            for O0OOOOOO0OOO0OO0O in OOO0O00000OOO0OO0 :#line:5745
                O00O0O000O00O00OO .__O0OO000O000OO000O .Add (arg1 =STKxFUT .FUT ,arg2 =O0OOOOOO0OOO0OO0O )#line:5746
            return True ,""#line:5747
        except Exception as O00000O0OOOO0000O :#line:5748
            O00O0O000O00O00OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoUnSubTopicFUT:{O00000O0OOOO0000O}")#line:5749
            return False ,f"[期][DoUnSubTopicSTK](aSolICE={O0O0O00000O0OO0O0}){O00000O0OOOO0000O}"#line:5750
    def __OOO0O0OOOO000OOOO (O0O0OOOO0OOO0OO0O ,O0O0O0O0O0OOOO0OO :str ):#line:5753
        ""#line:5754
        O000OOOOOOOO0000O :str =""#line:5755
        try :#line:5756
            OOO0000OOO0O0O00O =[]#line:5757
            O000OO0000000OOOO ,OOO0000OOO0O0O00O ,O000OOOOOOOO0000O =O0O0OOOO0OOO0OO0O ._fMapQuoteFUT .GetItem_ByCategory (O0O0O0O0O0OOOO0OO )#line:5758
            if O000OO0000000OOOO ==False :#line:5759
                return RCode .FAIL ,O000OOOOOOOO0000O #line:5760
            for OOOO00OO000OO0000 in OOO0000OOO0O0O00O :#line:5761
                O0O0OOOO0OOO0OO0O .__O0OO000O000OO000O .Add (arg1 =STKxFUT .FUT ,arg2 =OOOO00OO000OO0000 )#line:5762
            return RCode .OK ,""#line:5763
        except Exception as OOO00OO00O00O0O0O :#line:5765
            O000OOOOOOOO0000O =f"[期][DoUnSubTopicByCategoryFUT](aCat={O0O0O0O0O0OOOO0OO}){OOO00OO00O00O0O0O}"#line:5766
        return RCode .FAIL ,O000OOOOOOOO0000O #line:5767
    def __O00O0O0OOOOOOO0O0 (OOOO0OO0000OOOO00 ,O00OO00O0O0000O0O :str ):#line:5770
        ""#line:5772
        OOOOOOO0O0O000O0O =""#line:5773
        try :#line:5774
            O000OO0O00O0O0O0O =[]#line:5775
            O00O0O0OO0OOO00O0 ,O000OO0O00O0O0O0O ,O0OOOO000OO0O0O00 =OOOO0OO0000OOOO00 ._fMapQuoteOvsFUT .GetItem_BySolIce (O00OO00O0O0000O0O )#line:5777
            if O00O0O0OO0OOO00O0 ==False :#line:5778
                return False ,O0OOOO000OO0O0O00 #line:5779
            for O0OO00OO0000O0O0O in O000OO0O00O0O0O0O :#line:5780
                OOOO0OO0000OOOO00 .__O0OO000O000OO000O .Add (arg1 =STKxFUT .OVSFUT ,arg2 =O0OO00OO0000O0O0O )#line:5782
            return True ,""#line:5783
        except Exception as O0O000OOOOO00OO00 :#line:5784
            OOOO0OO0000OOOO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoUnSubTopicOvsFUT:{O0O000OOOOO00OO00}")#line:5786
            OOOOOOO0O0O000O0O =f"[證][DoUnSubTopic](aSolICE={O00OO00O0O0000O0O}){O0O000OOOOO00OO00}"#line:5787
            return False ,OOOOOOO0O0O000O0O #line:5788
    def __O0OO00O00O00OOOO0 (OO0O00OOOO0OO0O00 ,O0O0OO000000OO000 :STKxFUT ,OOOO00000O0OOOO0O :str ):#line:5790
        try :#line:5791
            with OO0O00OOOO0OO0O00 ._lock :#line:5792
                OO0O00OOOO0OO0O00 ._message_receiver .remove_subscription (TopicSubscription .of (OOOO00000O0OOOO0O ))#line:5794
        except Exception as OO0O00OOOO00OOO0O :#line:5795
            OO0O00OOOO0OO0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"SolaceUnSubTopic:{OOOO00000O0OOOO0O}, {OO0O00OOOO00OOO0O}")#line:5797
    def __OOOO00OOO000O0000 (OO0OO00OO00OOO0O0 ):#line:5799
        if OO0OO00OO00OOO0O0 .__OOOO00000000O00OO is None or OO0OO00OO00OOO0O0 .__OOOO00000000O00OO ._run ==False :#line:5800
            OO0OO00OO00OOO0O0 .__OOOO00000000O00OO =TSolaceMessageThreadClass ("Trd_HandleQuote",OO0OO00OO00OOO0O0 ._log ,OO0OO00OO00OOO0O0 .__OOOO0000OO0000O0O )#line:5802
        if OO0OO00OO00OOO0O0 .__O0000O0OO0OO00O00 is None or OO0OO00OO00OOO0O0 .__O0000O0OO0OO00O00 ._run ==False :#line:5804
            OO0OO00OO00OOO0O0 .__O0000O0OO0OO00O00 =TMyWorkItemThreadClass ("Trd_HandleRcvQuote",OO0OO00OO00OOO0O0 ._log ,OO0OO00OO00OOO0O0 .__OOO000O00OOOO00O0 )#line:5806
        if OO0OO00OO00OOO0O0 .__O0O0O0000OO0O0O00 is None or OO0OO00OO00OOO0O0 .__O0O0O0000OO0O0O00 ._run ==False :#line:5808
            OO0OO00OO00OOO0O0 .__O0O0O0000OO0O0O00 =TMyWorkItemThreadClass ("Trd_SolaceSubTopic",OO0OO00OO00OOO0O0 ._log ,OO0OO00OO00OOO0O0 .__OO0000OOO00O0O0OO )#line:5810
        if OO0OO00OO00OOO0O0 .__O0OO000O000OO000O is None or OO0OO00OO00OOO0O0 .__O0OO000O000OO000O ._run ==False :#line:5812
            OO0OO00OO00OOO0O0 .__O0OO000O000OO000O =TMyWorkItemThreadClass ("Trd_SolaceUnSubTopic",OO0OO00OO00OOO0O0 ._log ,OO0OO00OO00OOO0O0 .__O0OO00O00O00OOOO0 )#line:5814
    def __OOOO0O0OOO00OO0O0 (OO00000000O0OO00O ):#line:5816
        with OO00000000O0OO00O ._lock :#line:5817
            OO00000000O0OO00O .__OOOO00000000O00OO ._run =False #line:5819
            OO00000000O0OO00O .__O0000O0OO0OO00O00 ._run =False #line:5821
            OO00000000O0OO00O .__O0O0O0000OO0O0O00 ._run =False #line:5823
            OO00000000O0OO00O .__O0OO000O000OO000O ._run =False #line:5825
    def QryProdID_NormalStock (OO0OOOO0O000000O0 ):#line:5828
        ""#line:5831
        O0OO00000OOOOOO00 =None #line:5832
        try :#line:5833
            OO00OO000OOOO0OOO =False #line:5834
            OOO00O0O0O0OO0000 ="Quote/TWS/S/TSE/*/RECOVER"#line:5835
            OO00000000OO0000O =""#line:5836
            OO00OO000OOOO0OOO ,OO00000000OO0000O =OO0OOOO0O000000O0 .__O0OO0OO0OO00OOOO0 (OO0OOOO0O000000O0 ._vRcvTopic_Stk ,OOO00O0O0O0OO0000 ,'utf-8',OO0OOOO0O000000O0 ._vRcvTopic_Stk_Req )#line:5838
            if OO00OO000OOOO0OOO :#line:5839
                O00O0OOOO0000OO00 =json .loads (OO00000000OO0000O )#line:5840
                if "status"in O00O0OOOO0000OO00 and len (O00O0OOOO0000OO00 ["status"])>0 :#line:5843
                    if O00O0OOOO0000OO00 ["status"][0 ]=="error":#line:5844
                        OO0OOOO0O000000O0 .__OOO000O0OOO0O00O0 (f"[證][取個一般上市上櫃股票商品檔](aData={OO00000000OO0000O})行情回補資料有誤!")#line:5846
                        return RCode .FAIL ,O0OO00000OOOOOO00 #line:5847
                if "BAS"in O00O0OOOO0000OO00 and len (O00O0OOOO0000OO00 ["BAS"])==0 :#line:5848
                    OO0OOOO0O000000O0 .__OOO000O0OOO0O00O0 (f"[證][取個一般上市上櫃股票商品檔](aData={OO00000000OO0000O})沒有BAS資料!")#line:5850
                    return RCode .FAIL ,O0OO00000OOOOOO00 #line:5851
                if "HL"in O00O0OOOO0000OO00 and len (O00O0OOOO0000OO00 ["HL"])==0 :#line:5852
                    OO0OOOO0O000000O0 .__OOO000O0OOO0O00O0 (f"[證][取個一般上市上櫃股票商品檔](aData={OO00000000OO0000O})沒有HL資料!")#line:5854
                    return RCode .FAIL ,O0OO00000OOOOOO00 #line:5855
                O0OO00000OOOOOO00 =TQryStkProdMap ()#line:5858
                for OOOO00O0OO0O0OO0O in O00O0OOOO0000OO00 ["BAS"]:#line:5859
                    try :#line:5860
                        O0OO00000000OOOO0 =TStkQtBase ()#line:5861
                        O0OO00000000OOOO0 .Handle_BAS (OOOO00O0OO0O0OO0O )#line:5862
                        if O0OO00000OOOOOO00 .data .get (O0OO00000000OOOO0 .StkNo )is None :#line:5864
                            OO0O0OO0OO0OOO000 =TQryStkProdRec ()#line:5865
                            OO0O0OO0OO0OOO000 .tmpBase =O0OO00000000OOOO0 #line:5866
                            O0OO00000OOOOOO00 [O0OO00000000OOOO0 .StkNo ]=OO0O0OO0OO0OOO000 #line:5867
                    except Exception as O0000000O0O0OOO00 :#line:5868
                        OO0OOOO0O000000O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProdID_NormalStock(BAS):{O0000000O0O0OOO00}")#line:5870
                for OOOO00O0OO0O0OO0O in O00O0OOOO0000OO00 ["HL"]:#line:5872
                    try :#line:5873
                        O0OO00000000OOOO0 =TStkQtHL ()#line:5874
                        O0OO00000000OOOO0 .Handle_HL (OOOO00O0OO0O0OO0O )#line:5875
                        OO00O00O0000000OO :TQryStkProdRec =None #line:5877
                        OO00O00O0000000OO =next ((O0O00OOOOO0OOO00O for O0O00OOOOO0OOO00O in O0OO00000OOOOOO00 .values ()if O0O00OOOOO0OOO00O .tmpBase .StkNo ==O0OO00000000OOOO0 .Symbol ),None )#line:5879
                        if OO00O00O0000000OO is not None :#line:5880
                            OO00O00O0000000OO .tmpHL =O0OO00000000OOOO0 #line:5881
                            OO00O00O0000000OO .SetDataInit ()#line:5882
                    except Exception as O0000000O0O0OOO00 :#line:5883
                        OO0OOOO0O000000O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProdID_NormalStock(HL):{O0000000O0O0OOO00}")#line:5885
                return RCode .OK ,O0OO00000OOOOOO00 #line:5887
        except Exception as O0000000O0O0OOO00 :#line:5888
            OO0OOOO0O000000O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[證][QryProdID_NormalStock]取個一般上市上櫃股票商品檔失敗!({O0000000O0O0OOO00})")#line:5890
        return RCode .FAIL ,None #line:5892
    def QryProdID_FutStk_FirstMth (OO0O00O000OO000OO ):#line:5894
        ""#line:5896
        OOO0OO000O0OO000O :TQryFutProdMap =None #line:5897
        try :#line:5898
            OOOOOO00O00000OOO :bool =False #line:5899
            OO00O0OOO0O00O000 :OO00000OOOOOO0O00 ="Quote/TWF/FUT/*/RECOVER"#line:5900
            O0OO000OO00OOOO00 :OO00000OOOOOO0O00 =""#line:5901
            OOOOOO00O00000OOO ,O0OO000OO00OOOO00 =OO0O00O000OO000OO .__O0OO0OO0OO00OOOO0 (OO0O00O000OO000OO ._vRcvTopic_Fut ,OO00O0OOO0O00O000 ,'utf-8',OO0O00O000OO000OO ._vRcvTopic_Fut_Req )#line:5904
            if OOOOOO00O00000OOO and O0OO000OO00OOOO00 !="":#line:5906
                OO0000OOOOOOO000O =json .loads (O0OO000OO00OOOO00 )#line:5907
                if "status"in OO0000OOOOOOO000O and len (OO0000OOOOOOO000O ["status"])>0 :#line:5909
                    if OO0000OOOOOOO000O ["status"][0 ]=="error":#line:5910
                        OO0O00O000OO000OO .__OOO000O0OOO0O00O0 (f"[期][QryProdID_FutStk_FirstMth](aData={O0OO000OO00OOOO00})行情回補資料有誤!")#line:5912
                        return False ,OOO0OO000O0OO000O #line:5913
                if "BAS"in OO0000OOOOOOO000O and len (OO0000OOOOOOO000O ["BAS"])==0 :#line:5914
                    OO0O00O000OO000OO .__OOO000O0OOO0O00O0 (f"[期][QryProdID_FutStk_FirstMth](aData={O0OO000OO00OOOO00})沒有BAS資料!")#line:5916
                    return False ,OOO0OO000O0OO000O #line:5917
                if "HL"in OO0000OOOOOOO000O and len (OO0000OOOOOOO000O ["HL"])==0 :#line:5918
                    OO0O00O000OO000OO .__OOO000O0OOO0O00O0 (f"[期][QryProdID_FutStk_FirstMth](aData={O0OO000OO00OOOO00})沒有HL資料!")#line:5920
                    return False ,OOO0OO000O0OO000O #line:5921
                OOO0OO000O0OO000O =TQryFutProdMap ()#line:5925
                for OO00000OOOOOO0O00 in OO0000OOOOOOO000O ["BAS"]:#line:5926
                    try :#line:5927
                        O0000O000O0O00O00 :TFutQtBase =TFutQtBase ()#line:5928
                        O0000O000O0O00O00 .Handle_BAS (OO00000OOOOOO0O00 )#line:5929
                        if O0000O000O0O00O00 .StkNo .isspace ()==False and len (O0000O000O0O00O00 .StkNo )>0 :#line:5930
                            if OOO0OO000O0OO000O .data .get (O0000O000O0O00O00 .StkNo )is None :#line:5931
                                O0OOOO0OOOOO00O00 :TQryFutProdRec =TQryFutProdRec ()#line:5932
                                O0OOOO0OOOOO00O00 .tmpBase =O0000O000O0O00O00 #line:5933
                                OOO0OO000O0OO000O [O0000O000O0O00O00 .ProdID ]=O0OOOO0OOOOO00O00 #line:5934
                            elif (int (O0000O000O0O00O00 .SettleMth )<int (OOO0OO000O0OO000O [O0000O000O0O00O00 .ProdID ].tmpBase .SettleMth )):#line:5935
                                OOO0OO000O0OO000O [O0000O000O0O00O00 .ProdID ].tmpBase =O0000O000O0O00O00 #line:5936
                    except Exception as OOOO000OO000OO0O0 :#line:5937
                        OO0O00O000OO000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProdID_FutStk_FirstMth(BAS):{OOOO000OO000OO0O0}")#line:5939
                for OO00000OOOOOO0O00 in OO0000OOOOOOO000O ["HL"]:#line:5942
                    try :#line:5943
                        O0000O000O0O00O00 :TFutQtHL =TFutQtHL ()#line:5944
                        O0000O000O0O00O00 .Handle_HL (OO00000OOOOOO0O00 )#line:5945
                        O0OOOO00OO0O0OO00 :TQryStkProdRec =None #line:5946
                        O0OOOO00OO0O0OO00 =next ((OOO0O0OO00O0OO0O0 for OOO0O0OO00O0OO0O0 in OOO0OO000O0OO000O .values ()if OOO0O0OO00O0OO0O0 .tmpBase .OrdProdID ==O0000O000O0O00O00 .Symbol ),None )#line:5948
                        if O0OOOO00OO0O0OO00 is not None :#line:5949
                            O0OOOO00OO0O0OO00 .tmpHL =O0000O000O0O00O00 #line:5950
                            O0OOOO00OO0O0OO00 .SetDataInit ()#line:5951
                    except Exception as OOOO000OO000OO0O0 :#line:5952
                        OO0O00O000OO000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProdID_FutStk_FirstMth(HL):{OOOO000OO000OO0O0}")#line:5954
                return True ,OOO0OO000O0OO000O #line:5956
        except Exception as OOOO000OO000OO0O0 :#line:5957
            OO0O00O000OO000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProdID_FutStk_FirstMth:{OOOO000OO000OO0O0}")#line:5959
            OO0O00O000OO000OO .__OOO000O0OOO0O00O0 (f"[期][QryProdID_FutStk_FirstMth]取個期貨商品檔(近1月)失敗!({OOOO000OO000OO0O0})")#line:5961
        return False ,None #line:5962
    def QryProd_Fut (OO0OOO0O0O00OO0O0 ,OOO0O00OO00O0OO0O :bool ,O000O0O0OO0O0OO0O :bool ,OO0OOO00O0OO0000O :bool ):#line:5964
        ""#line:5970
        O0OO000000O0O000O :TObjBaseFutMap =None #line:5971
        try :#line:5972
            OO00000OO0O00OOOO :OO0OOO000O0O00O0O ="Quote/TWF/FUT/*/RECOVER"#line:5973
            OOO0O0000O0000OO0 :OO0OOO000O0O00O0O =""#line:5974
            OOO0OOO0OOO0O0OOO ,OOO0O0000O0000OO0 =OO0OOO0O0O00OO0O0 .__O0OO0OO0OO00OOOO0 (OO0OOO0O0O00OO0O0 ._vRcvTopic_Fut ,OO00000OO0O00OOOO ,'utf-8',OO0OOO0O0O00OO0O0 ._vRcvTopic_Fut_Req )#line:5976
            if OOO0OOO0OOO0O0OOO and OOO0O0000O0000OO0 !="":#line:5978
                O00OOO0O000O00OOO =json .loads (OOO0O0000O0000OO0 )#line:5979
                if "status"in O00OOO0O000O00OOO and len (O00OOO0O000O00OOO ["status"])>0 :#line:5982
                    if O00OOO0O000O00OOO ["status"][0 ]=="error":#line:5983
                        OO0OOO0O0O00OO0O0 .__OOO000O0OOO0O00O0 (f"[期][QryProdID_Fut](aData={OOO0O0000O0000OO0})行情回補資料有誤!")#line:5985
                        return RCode .FAIL ,O0OO000000O0O000O #line:5986
                if "BAS"in O00OOO0O000O00OOO and len (O00OOO0O000O00OOO ["BAS"])==0 :#line:5987
                    OO0OOO0O0O00OO0O0 .__OOO000O0OOO0O00O0 (f"[期][QryProdID_Fut](aData={OOO0O0000O0000OO0})沒有BAS資料!")#line:5989
                    return RCode .FAIL ,O0OO000000O0O000O #line:5990
                if "HL"in O00OOO0O000O00OOO and len (O00OOO0O000O00OOO ["HL"])==0 :#line:5991
                    OO0OOO0O0O00OO0O0 .__OOO000O0OOO0O00O0 (f"[期][QryProdID_Fut](aData={OOO0O0000O0000OO0})沒有HL資料!")#line:5993
                    return RCode .FAIL ,O0OO000000O0O000O #line:5994
                O0OO000000O0O000O :TObjBaseFutMap =TObjBaseFutMap ()#line:5998
                for OO0OOO000O0O00O0O in O00OOO0O000O00OOO ["BAS"]:#line:5999
                    try :#line:6000
                        OOOOOO0OO0O00O000 :TFutQtBase =TFutQtBase ()#line:6001
                        OOOOOO0OO0O00O000 .Handle_BAS (OO0OOO000O0O00O0O )#line:6002
                        if OOOOOO0OO0O00O000 .StkNo .isspace ()==False and len (OOOOOO0OO0O00O000 .StkNo )>0 :#line:6004
                            if O000O0O0OO0O0OO0O :#line:6005
                                if OO0OOO00O0OO0000O ==False and OOOOOO0OO0O00O000 .FutName .startswith ("小型"):#line:6007
                                    pass #line:6008
                                else :#line:6009
                                    O0OO000000O0O000O .AddItem_ByProdID (OOOOOO0OO0O00O000 )#line:6010
                        elif OOO0O00OO00O0OO0O :#line:6011
                            O0OO000000O0O000O .AddItem_ByProdID (OOOOOO0OO0O00O000 )#line:6012
                    except Exception as OOO0O0O000O0O0OO0 :#line:6013
                        OO0OOO0O0O00OO0O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Fut(BAS):{OOO0O0O000O0O0OO0}")#line:6015
                O0OO000000O0O000O .ReAddAll ()#line:6017
                return RCode .OK ,O0OO000000O0O000O #line:6020
        except Exception as OOO0O0O000O0O0OO0 :#line:6021
            OO0OOO0O0O00OO0O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Fut:{OOO0O0O000O0O0OO0}")#line:6022
            OO0OOO0O0O00OO0O0 .__OOO000O0OOO0O00O0 (f"[期][QryProdID_Fut]取期貨商品檔(不含選擇權)失敗!({OOO0O0O000O0O0OO0})")#line:6023
        return RCode .FAIL ,O0OO000000O0O000O #line:6024
    def QryProd_FutCom (O000OO0OO0OO00000 ):#line:6026
        ""#line:6027
        O0O00O0OOOO0OOOO0 :TObjFutComList =None #line:6028
        try :#line:6029
            O0OOO0OO0O0O0OOOO :str ="Quote/TWF/SPD/*/SYMBOL"#line:6030
            OOO0000OO0OO0O0OO :str =""#line:6031
            OO0OO00OOOOOO0O0O ,OOO0000OO0OO0O0OO =O000OO0OO0OO00000 .__O0OO0OO0OO00OOOO0 (O000OO0OO0OO00000 ._vRcvTopic_Fut ,O0OOO0OO0O0O0OOOO ,'utf-8',O000OO0OO0OO00000 ._vRcvTopic_Fut_Req )#line:6033
            if OO0OO00OOOOOO0O0O :#line:6035
                OO0O0OOOO0OOOO00O =json .loads (OOO0000OO0OO0O0OO )#line:6036
                if "status"in OO0O0OOOO0OOOO00O and len (OO0O0OOOO0OOOO00O ["status"])>0 :#line:6038
                    if OO0O0OOOO0OOOO00O ["status"][0 ]=="error":#line:6039
                        O000OO0OO0OO00000 .__OOO000O0OOO0O00O0 (f"[期][QryProd_FutCom](aData={OOO0000OO0OO0O0OO})行情回補資料有誤!")#line:6041
                        return False ,O0O00O0OOOO0OOOO0 #line:6042
                if "SYMBOL"in OO0O0OOOO0OOOO00O and len (OO0O0OOOO0OOOO00O ["SYMBOL"])==0 :#line:6043
                    O000OO0OO0OO00000 .__OOO000O0OOO0O00O0 (f"[期][QryProd_FutCom](aData={OOO0000OO0OO0O0OO})沒有SYMBOL資料!")#line:6045
                    return False ,O0O00O0OOOO0OOOO0 #line:6046
                O0O00O0OOOO0OOOO0 :TObjFutComList =TObjFutComList ()#line:6049
                O00000OOO000O0OOO =OO0O0OOOO0OOOO00O ["SYMBOL"][0 ].split ('|')#line:6050
                for OOOOO00O0O0OOOOO0 in O00000OOO000O0OOO :#line:6051
                    O0O00O0OOOO0OOOO0 .AddItem (OOOOO00O0O0OOOOO0 )#line:6052
                return True ,O0O00O0OOOO0OOOO0 #line:6054
        except Exception as OO000000OOO0OO00O :#line:6055
            O000OO0OO0OO00000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_FutCom:{OO000000OOO0OO00O}")#line:6056
            O000OO0OO0OO00000 .__OOO000O0OOO0O00O0 (f"[期][QryProd_FutCom]取複式期貨商品檔失敗!({OO000000OOO0OO00O})")#line:6057
        return False ,O0O00O0OOOO0OOOO0 #line:6058
    def QryProd_FutCom2 (O0OOOO00OO0O0000O ):#line:6060
        ""#line:6062
        OO0O00OO000O0O0OO :TObjFutComList =None #line:6063
        try :#line:6064
            O000OOO00OO00OO0O :TObjBaseFutMap =None #line:6065
            O00OOOO0OOOOOOOO0 ,O000OOO00OO00OO0O =O0OOOO00OO0O0000O .QryProd_Fut (True ,True ,True )#line:6066
            if O00OOOO0OOOOOOOO0 ==False :#line:6067
                O0OOOO00OO0O0000O .__OOO000O0OOO0O00O0 ("[QryProd_FutCom2]載入期貨單式商品失敗!")#line:6068
                return RCode .FAIL ,OO0O00OO000O0O0OO #line:6069
            OO0O00OO000O0O0OO :TObjFutComList =TObjFutComList ()#line:6070
            OOO00O00OOO00OO00 ,O0O0OOO0OO0O00OOO =0 ,0 #line:6072
            OOOO00O0O000OO00O =[O0O00000OO0OOOOOO for O0O00000OO0OOOOOO in O000OOO00OO00OO0O .keys ()if not O0O00000OO0OOOOOO .startswith ("MX")or O0O00000OO0OOOOOO =="MXF"]#line:6074
            for OO0O000000000O00O in OOOO00O0O000OO00O :#line:6076
                OO000OO00OO0O0OO0 =O000OOO00OO00OO0O [OO0O000000000O00O ]#line:6077
                if len (OO000OO00OO0O0OO0 )<=1 :#line:6078
                    continue #line:6079
                for OOO00O00OOO00OO00 in range (len (OO000OO00OO0O0OO0 )):#line:6080
                    for O0O0OOO0OO0O00OOO in range (OOO00O00OOO00OO00 +1 ,len (OO000OO00OO0O0OO0 )):#line:6081
                        OO00O00OOOO00OO00 =OO000OO00OO0O0OO0 [OOO00O00OOO00OO00 ]#line:6082
                        OO0OO0O000OO0OO00 =OO000OO00OO0O0OO0 [O0O0OOO0OO0O00OOO ]#line:6083
                        OO0O00OO000O0O0OO .AddItem ("{}^{}".format (OO00O00OOOO00OO00 .OrdProdID ,OO0OO0O000OO0OO00 .OrdProdID [3 :5 ]))#line:6085
            O0O0OOO0O00O0000O =O000OOO00OO00OO0O ["MXF"]#line:6088
            O0OO0OO0O000O0O00 =[OOOO00O0O0OOOO0OO for OOOO00O0O0OOOO0OO in O000OOO00OO00OO0O .keys ()if OOOO00O0O0OOOO0OO .startswith ("MX")and OOOO00O0O0OOOO0OO !="MXF"]#line:6090
            for OOO00O00OOO00OO00 in range (len (O0OO0OO0O000O0O00 )):#line:6091
                O0O0O0O00OOOOOOO0 =O000OOO00OO00OO0O [O0OO0OO0O000O0O00 [OOO00O00OOO00OO00 ]][0 ]#line:6092
                for O0O0OOO0OO0O00OOO in range (OOO00O00OOO00OO00 +1 ,len (O0OO0OO0O000O0O00 )):#line:6094
                    OOOOO000OOO00O00O =O000OOO00OO00OO0O [O0OO0OO0O000O0O00 [O0O0OOO0OO0O00OOO ]][0 ]#line:6095
                    if O0O0O0O00OOOOOOO0 .SettleMth ==OOOOO000OOO00O00O .SettleMth :#line:6096
                        if ord (O0O0O0O00OOOOOOO0 .OrdProdID [2 ])<ord (OOOOO000OOO00O00O .OrdProdID [2 ]):#line:6098
                            OO0O00OO000O0O0OO .AddItem ("{}^{}".format (O0O0O0O00OOOOOOO0 .OrdProdID ,OOOOO000OOO00O00O .OrdProdID ))#line:6100
                        else :#line:6101
                            OO0O00OO000O0O0OO .AddItem ("{}^{}".format (OOOOO000OOO00O00O .OrdProdID ,O0O0O0O00OOOOOOO0 .OrdProdID ))#line:6104
                    else :#line:6105
                        if int (O0O0O0O00OOOOOOO0 .SettleMth )<int (OOOOO000OOO00O00O .SettleMth ):#line:6106
                            OO0O00OO000O0O0OO .AddItem ("{}^{}".format (O0O0O0O00OOOOOOO0 .OrdProdID ,OOOOO000OOO00O00O .OrdProdID ))#line:6108
                        else :#line:6109
                            OO0O00OO000O0O0OO .AddItem ("{}^{}".format (OOOOO000OOO00O00O .OrdProdID ,O0O0O0O00OOOOOOO0 .OrdProdID ))#line:6112
                if O0O0O0O00OOOOOOO0 .SettleMth ==O0O0OOO0O00O0000O [0 ].SettleMth :#line:6115
                    if O0O0O0O00OOOOOOO0 .ProdID =="MX1"or O0O0O0O00OOOOOOO0 .ProdID =="MX2":#line:6116
                        for OO00OOO0OOOOO00O0 in O0O0OOO0O00O0000O :#line:6117
                            OO0O00OO000O0O0OO .AddItem ("{}^{}".format (O0O0O0O00OOOOOOO0 .OrdProdID ,OO00OOO0OOOOO00O0 .OrdProdID ))#line:6119
                    else :#line:6120
                        for OO00OOO0OOOOO00O0 in O0O0OOO0O00O0000O :#line:6121
                            OO0O00OO000O0O0OO .AddItem ("{}^{}".format (OO00OOO0OOOOO00O0 .OrdProdID ,O0O0O0O00OOOOOOO0 .OrdProdID ))#line:6123
                else :#line:6124
                    if int (O0O0O0O00OOOOOOO0 .SettleMth )<int (O0O0OOO0O00O0000O [0 ].SettleMth ):#line:6125
                        for OO00OOO0OOOOO00O0 in O0O0OOO0O00O0000O :#line:6126
                            OO0O00OO000O0O0OO .AddItem ("{}^{}".format (O0O0O0O00OOOOOOO0 .OrdProdID ,OO00OOO0OOOOO00O0 .OrdProdID ))#line:6128
                    else :#line:6129
                        for OO00OOO0OOOOO00O0 in O0O0OOO0O00O0000O :#line:6130
                            OO0O00OO000O0O0OO .AddItem ("{}^{}".format (OO00OOO0OOOOO00O0 .OrdProdID ,O0O0O0O00OOOOOOO0 .OrdProdID ))#line:6132
            return RCode .OK ,OO0O00OO000O0O0OO #line:6134
        except Exception as O0O0OOOOO0O0OOO00 :#line:6135
            O0OOOO00OO0O0000O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_FutCom2:{O0O0OOOOO0O0OOO00}")#line:6136
            O0OOOO00OO0O0000O .__OOO000O0OOO0O00O0 (f"[期][QryProd_FutCom2]取複式期貨商品檔失敗!({O0O0OOOOO0O0OOO00})")#line:6137
        return RCode .FAIL ,OO0O00OO000O0O0OO #line:6138
    def QryProd_Opt (O0OO0000O0000OO00 ,OOO0O00OOOO0O00O0 :bool ,OOO0OO0OO00OO0000 :bool ,OOO0000OOO0000O0O :bool ):#line:6140
        ""#line:6145
        OOOOO0OOO0OO000OO :TObjBaseOptMap =None #line:6146
        try :#line:6147
            O000O0O0OO0OOOO00 :OO0O0O00O00000OO0 ="Quote/TWF/OPT/*/RECOVER"#line:6148
            O0O0000O0OOOOOOOO :OO0O0O00O00000OO0 =""#line:6149
            OOOO0OOO00O0O0OO0 ,O0O0000O0OOOOOOOO =O0OO0000O0000OO00 .__O0OO0OO0OO00OOOO0 (O0OO0000O0000OO00 ._vRcvTopic_Fut ,O000O0O0OO0OOOO00 ,'utf-8',O0OO0000O0000OO00 ._vRcvTopic_Fut_Req )#line:6151
            if OOOO0OOO00O0O0OO0 :#line:6153
                OOOO0OOO0OO00OOO0 =json .loads (O0O0000O0OOOOOOOO )#line:6154
                if "status"in OOOO0OOO0OO00OOO0 and len (OOOO0OOO0OO00OOO0 ["status"])>0 :#line:6156
                    if OOOO0OOO0OO00OOO0 ["status"][0 ]=="error":#line:6157
                        O0OO0000O0000OO00 .__OOO000O0OOO0O00O0 (f"[期][QryProd_Opt](aData={O0O0000O0OOOOOOOO})行情回補資料有誤!")#line:6159
                        return RCode .FAIL ,OOOOO0OOO0OO000OO #line:6160
                if "BAS"in OOOO0OOO0OO00OOO0 and len (OOOO0OOO0OO00OOO0 ["BAS"])==0 :#line:6161
                    O0OO0000O0000OO00 .__OOO000O0OOO0O00O0 (f"[期][QryProd_Opt](aData={O0O0000O0OOOOOOOO})沒有BAS資料!")#line:6163
                    return RCode .FAIL ,OOOOO0OOO0OO000OO #line:6164
                if "HL"in OOOO0OOO0OO00OOO0 and len (OOOO0OOO0OO00OOO0 ["HL"])==0 :#line:6165
                    O0OO0000O0000OO00 .__OOO000O0OOO0O00O0 (f"[期][QryProd_Opt](aData={O0O0000O0OOOOOOOO})沒有HL資料!")#line:6167
                    return RCode .FAIL ,OOOOO0OOO0OO000OO #line:6168
                OOOOO0OOO0OO000OO =TObjBaseOptMap ()#line:6171
                for OO0O0O00O00000OO0 in OOOO0OOO0OO00OOO0 ["BAS"]:#line:6172
                    try :#line:6173
                        OO00O00O00OOOO000 :TFutQtBase =TFutQtBase ()#line:6174
                        OO00O00O00OOOO000 .Handle_BAS (OO0O0O00O00000OO0 )#line:6175
                        if OO00O00O00OOOO000 .StkNo .isspace ()==False and len (OO00O00O00OOOO000 .StkNo )>0 :#line:6177
                            if OOO0OO0OO00OO0000 :#line:6178
                                if OOO0000OOO0000O0O ==False and OO00O00O00OOOO000 .FutName .startswith ("小型"):#line:6180
                                    pass #line:6181
                                else :#line:6182
                                    OOOOO0OOO0OO000OO .AddItem_ByProdID (OO00O00O00OOOO000 )#line:6183
                        elif OOO0O00OOOO0O00O0 :#line:6184
                            OOOOO0OOO0OO000OO .AddItem_ByProdID (OO00O00O00OOOO000 )#line:6185
                    except Exception as O0O000OO0OO0000O0 :#line:6186
                        O0OO0000O0000OO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Opt:{O0O000OO0OO0000O0}")#line:6188
                return RCode .OK ,OOOOO0OOO0OO000OO #line:6191
        except Exception as O0O000OO0OO0000O0 :#line:6192
            O0OO0000O0000OO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Opt:{O0O000OO0OO0000O0}")#line:6193
            O0OO0000O0000OO00 .__OOO000O0OOO0O00O0 (f"[期][QryProd_Opt]取個選擇權商品檔失敗!({O0O000OO0OO0000O0})")#line:6194
        return RCode .FAIL ,OOOOO0OOO0OO000OO #line:6195
    def QryProd_OvsFut (OO000O000O0OO0O0O ):#line:6197
        ""#line:6200
        O0000OO0OOOOOO000 :TObjOvsFutProdMthMap =None #line:6201
        try :#line:6202
            O0O00O00O00000O00 =False #line:6203
            OO00O0O0O0O0000O0 ="QuoteOvs/*/FUT/*/RECOVER"#line:6204
            O0OO0O00OOO00O0OO =""#line:6205
            O0O00O00O00000O00 ,O0OO0O00OOO00O0OO =OO000O000O0OO0O0O .__O0OO0OO0OO00OOOO0 (OO000O000O0OO0O0O ._vRcvTopic_OvsFut ,OO00O0O0O0O0000O0 ,'big5',OO000O000O0OO0O0O ._vRcvTopic_OvsFut_Req )#line:6207
            if O0O00O00O00000O00 :#line:6208
                OOO0OOO00O000000O =json .loads (O0OO0O00OOO00O0OO )#line:6209
                if "status"in OOO0OOO00O000000O and len (OOO0OOO00O000000O ["status"])>0 :#line:6211
                    if OOO0OOO00O000000O ["status"][0 ]=="error":#line:6212
                        OO000O000O0OO0O0O .__OOO000O0OOO0O00O0 (f"[海期][QryProd_OvsFut](aData={O0OO0O00OOO00O0OO})行情回補資料有誤!")#line:6214
                        return False ,O0000OO0OOOOOO000 #line:6215
                if "BAS"in OOO0OOO00O000000O and len (OOO0OOO00O000000O ["BAS"])==0 :#line:6216
                    OO000O000O0OO0O0O .__OOO000O0OOO0O00O0 (f"[海期][QryProd_OvsFut](aData={O0OO0O00OOO00O0OO})沒有BAS資料!")#line:6218
                    return False ,O0000OO0OOOOOO000 #line:6219
                O0000OO0OOOOOO000 =TObjOvsFutProdMthMap ("","")#line:6222
                for OOOO0OO00O000O0OO in OOO0OOO00O000000O ["BAS"]:#line:6223
                    try :#line:6224
                        O000OO000OO0OOO0O =TOvsFutQtBase ()#line:6225
                        O000OO000OO0OOO0O .Handle_BAS (OOOO0OO00O000O0OO )#line:6226
                        O0000OO0OOOOOO000 .AddItem (O000OO000OO0OOO0O )#line:6228
                    except Exception as O00OOOOO0OO000000 :#line:6229
                        OO000O000O0OO0O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_OvsFut: {O00OOOOO0OO000000}")#line:6231
                return True ,O0000OO0OOOOOO000 #line:6233
        except Exception as O00OOOOO0OO000000 :#line:6234
            OO000O000O0OO0O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_OvsFut:{O00OOOOO0OO000000}")#line:6235
            OO000O000O0OO0O0O .__OOO000O0OOO0O00O0 (f"[海期][QryProd_OvsFut]取期貨商品檔(不含選擇權)失敗!({O00OOOOO0OO000000})")#line:6236
        return False ,O0000OO0OOOOOO000 #line:6237
    def QryProd_OvsOpt (O0O000O0O00OOOOOO ):#line:6239
        ""#line:6241
        O00OO000O0OOO000O :None #line:6242
        try :#line:6243
            O00000OOOO00O0OOO :bool =False #line:6244
            O00O0OOO0OO0O0OOO ="QuoteOvs/*/OPT/*/RECOVER"#line:6245
            O00O0O00OO0OO0000 =""#line:6246
            O00000OOOO00O0OOO ,O00O0O00OO0OO0000 =O0O000O0O00OOOOOO .__O0OO0OO0OO00OOOO0 (O0O000O0O00OOOOOO ._vRcvTopic_OvsFut ,O00O0OOO0OO0O0OOO ,'big5',O0O000O0O00OOOOOO ._vRcvTopic_OvsFut_Req )#line:6248
            if O00000OOOO00O0OOO :#line:6249
                OO00O00O0OOOOOOO0 =json .loads (O00O0O00OO0OO0000 )#line:6250
                if "status"in OO00O00O0OOOOOOO0 and len (OO00O00O0OOOOOOO0 ["status"])>0 :#line:6252
                    if OO00O00O0OOOOOOO0 ["status"][0 ]=="error":#line:6253
                        O0O000O0O00OOOOOO .__OOO000O0OOO0O00O0 (f"[海期][QryProd_OvsOpt](aData={O00O0O00OO0OO0000})行情回補資料有誤!")#line:6255
                        return False ,O00OO000O0OOO000O #line:6256
                if "BAS"in OO00O00O0OOOOOOO0 and len (OO00O00O0OOOOOOO0 ["BAS"])==0 :#line:6257
                    O0O000O0O00OOOOOO .__OOO000O0OOO0O00O0 (f"[海期][QryProd_OvsOpt](aData={O00O0O00OO0OO0000})沒有BAS資料!")#line:6259
                    return False ,O00OO000O0OOO000O #line:6260
                O00OO000O0OOO000O =TObjOvsFutProdMthMap ("","")#line:6263
                for O00OOO0O0000OOO0O in OO00O00O0OOOOOOO0 ["BAS"]:#line:6264
                    try :#line:6265
                        O0000OOOO0O0OOO0O =TOvsFutQtBase ()#line:6266
                        O0000OOOO0O0OOO0O .Handle_BAS (O00OOO0O0000OOO0O )#line:6267
                        O00OO000O0OOO000O .AddItem (O0000OOOO0O0OOO0O )#line:6268
                    except Exception as O0000OOO0OOOOOO0O :#line:6269
                        O0O000O0O00OOOOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_OvsOpt: {O0000OOO0OOOOOO0O}")#line:6271
                return True ,O00OO000O0OOO000O #line:6273
        except Exception as O0000OOO0OOOOOO0O :#line:6274
            O0O000O0O00OOOOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_OvsOpt:{O0000OOO0OOOOOO0O}")#line:6275
            O0O000O0O00OOOOOO .__OOO000O0OOO0O00O0 (f"[海期][QryProd_OptOvs]取選擇權商品檔失敗!({O0000OOO0OOOOOO0O})")#line:6276
        return False ,O00OO000O0OOO000O #line:6277
    def QryProd_Fut_ByExchangeTree (O00O0OOO00OO00O00 ,OOOOOO0O00O0OO000 :bool ):#line:6279
        ""#line:6282
        O0O00OO00OO00000O :TObjBaseOvsFutExchageTree =None #line:6283
        try :#line:6284
            OOOO0OOO0OOOOOO00 :bool =False #line:6285
            OOOO00000O0O000O0 ="QuoteOvs/*/FUT/*/RECOVER"#line:6286
            O0O00000000OOO00O =""#line:6287
            OOOO0OOO0OOOOOO00 ,O0O00000000OOO00O =O00O0OOO00OO00O00 .__O0OO0OO0OO00OOOO0 (O00O0OOO00OO00O00 ._vRcvTopic_OvsFut ,OOOO00000O0O000O0 ,'big5',O00O0OOO00OO00O00 ._vRcvTopic_OvsFut_Req )#line:6289
            if OOOO0OOO0OOOOOO00 :#line:6290
                OOOO000O00000OOO0 =json .loads (O0O00000000OOO00O )#line:6291
                if "status"in OOOO000O00000OOO0 and len (OOOO000O00000OOO0 ["status"])>0 :#line:6293
                    if OOOO000O00000OOO0 ["status"][0 ]=="error":#line:6294
                        O00O0OOO00OO00O00 .__OOO000O0OOO0O00O0 (f"[海期][QryProd_OvsFut](aData={O0O00000000OOO00O})行情回補資料有誤!")#line:6296
                        return False ,O0O00OO00OO00000O #line:6297
                if "BAS"in OOOO000O00000OOO0 and len (OOOO000O00000OOO0 ["BAS"])==0 :#line:6298
                    O00O0OOO00OO00O00 .__OOO000O0OOO0O00O0 (f"[海期][QryProd_OvsFut](aData={O0O00000000OOO00O})沒有BAS資料!")#line:6300
                    return False ,O0O00OO00OO00000O #line:6301
                O0O00OO00OO00000O =TObjBaseOvsFutExchageTree ()#line:6304
                for OO0000000OO0OOO00 in OOOO000O00000OOO0 ["BAS"]:#line:6305
                    try :#line:6306
                        O0O00O0O0O0O0OOOO =TOvsFutQtBase ()#line:6307
                        O0O00O0O0O0O0OOOO .Handle_BAS (OO0000000OO0OOO00 )#line:6308
                        if O0O00O0O0O0O0OOOO .Market =="4":#line:6309
                            if OOOOOO0O00O0OO000 ==False or (OOOOOO0O00O0OO000 and O0O00O0O0O0O0OOOO .Display =="Y"):#line:6311
                                O0O00OO00OO00000O .AddItem (O0O00O0O0O0O0OOOO )#line:6312
                    except Exception as OO0O00O0O00OOOO00 :#line:6313
                        O00O0OOO00OO00O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Fut_ByExchangeTree: {OO0O00O0O00OOOO00}")#line:6315
                O0O00OO00OO00000O .SetInit ()#line:6316
                return True ,O0O00OO00OO00000O #line:6319
        except Exception as OO0O00O0O00OOOO00 :#line:6320
            O00O0OOO00OO00O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Fut_ByExchangeTree:{OO0O00O0O00OOOO00}")#line:6322
            O00O0OOO00OO00O00 .__OOO000O0OOO0O00O0 (f"[海期][QryProdID_Fut]取期貨商品檔(不含選擇權)失敗!({OO0O00O0O00OOOO00})")#line:6323
        return False ,O0O00OO00OO00000O #line:6324
    def __OO00000000O0OOOOO (OO0O00000OOO0OO00 ,O00OOO0000000O0OO :str ,O0000O0OO00OO000O :str ):#line:6328
        try :#line:6329
            with OO0O00000OOO0OO00 ._lock :#line:6330
                O00OO000O0O000O0O =OO0O00000OOO0OO00 ._direct_publish_service .start_async ()#line:6331
                O00OO000O0O000O0O .result ()#line:6332
                OO0O0000O0O000000 ='utf-8'#line:6333
                OO0O000O00O00OO00 =bytearray (f'{O0000O0OO00OO000O}',OO0O0000O0O000000 )#line:6334
                O000OOOOOO0O00OO0 :OutboundMessage =OO0O00000OOO0OO00 ._message_service .message_builder ().build (OO0O000O00O00OO00 )#line:6335
                OO0O00000OOO0OO00 ._direct_publish_service .publish (O00OOO0000000O0OO ,O000OOOOOO0O00OO0 )#line:6336
        except Exception as OO0OO0O00O000OO0O :#line:6338
            OO0O00000OOO0OO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"SendMessage:{OO0OO0O00O000OO0O}")#line:6339
    def __O0OO0OO0OO00OOOO0 (OO00OOOOOO0O0000O ,OOO00000OO0OOOO00 :str ,O0OO000O0000OOO0O :str ,OOOOO0O0OOO00O0O0 :str ,O0000O00OO0O0O0O0 :str ):#line:6343
        ""#line:6346
        O0000000000000O0O =""#line:6347
        O000OOOOO0O00OO0O =bytearray (f'{O0OO000O0000OOO0O}',OOOOO0O0OOO00O0O0 )#line:6353
        OO0OOO0OOOOOO0O0O :OutboundMessage =OO00OOOOOO0O0000O ._message_service .message_builder ().build (payload =O000OOOOO0O00OO0O )#line:6354
        try :#line:6356
            with OO00OOOOOO0O0000O ._lock :#line:6357
                O0OOOOOO0O000OOOO =OO00OOOOOO0O0000O ._message_requester .publish_await_response (request_message =OO0OOO0OOOOOO0O0O ,request_destination =Topic .of (OOO00000OO0OOOO00 ),reply_timeout =OO00OOOOOO0O0000O ._reply_timeout )#line:6361
                OO0000OO0O0OOOO0O =O0OOOOOO0O000OOOO .get_payload_as_bytes ().decode (OOOOO0O0OOO00O0O0 )#line:6362
                return True ,OO0000OO0O0OOOO0O #line:6363
        except Exception as O0000O00OO00O00O0 :#line:6364
            OO00OOOOOO0O0000O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"send_request exception! topic={OOO00000OO0OOOO00}, msg={O0OO000O0000OOO0O}, exception={O0000O00OO00O00O0}")#line:6366
            OO0000OO0O0OOOO0O =""#line:6367
        return False ,OO0000OO0O0OOOO0O #line:6369
    def Subscribe (OOOOOO00OOO000000 ,O000OO0OO0OOO000O :str ,OO0O0O00OO0OO00O0 :str )->RCode :#line:6373
        ""#line:6376
        OOOOOO00OOO000000 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[Subscribe]exchange={O000OO0OO0OOO000O}, symbol={OO0O0O00OO0OO00O0}")#line:6377
        if EXCHANGE .TWF ==O000OO0OO0OOO000O :#line:6380
            O00O000OO0OOO00OO =OOOOOO00OOO000000 .__OOOO0OOOOOOO0OOOO (OO0O0O00OO0OO00O0 ,True )#line:6381
        elif EXCHANGE .TWS ==O000OO0OO0OOO000O :#line:6383
            O00O000OO0OOO00OO =OOOOOO00OOO000000 .__OO000OO0OO0OOOOOO (OO0O0O00OO0OO00O0 ,True )#line:6384
        return O00O000OO0OOO00OO #line:6386
    def OvsSubscribe (OOO0O0O00OOO0O00O ,OOOOO0000OO0OO0O0 :str ):#line:6387
        ""#line:6388
        return OOO0O0O00OOO0O00O .__O00OO00O000O00OO0 (OOOOO0000OO0OO0O0 ,True )#line:6389
    def OvsSubscribeWithCategory (O00000OOO00000O00 ,aMrt :str ="FUT",aExchange :str ="*"):#line:6391
        ""#line:6392
        if aMrt =="FUT":#line:6393
            return O00000OOO00000O00 .__OOOO00O0OO00000O0 (True ,aExchange )#line:6394
        else :#line:6395
            O00000OOO00000O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"OvsSubscribeWithCategory aMrt:{aMrt}")#line:6396
            return RCode .FAIL #line:6397
    def Unsubscribe (O0000O0O000O0OO0O ,O00000000OO00OO00 :str ,OO0O00O0O0OO0O0O0 :str )->RCode :#line:6399
        ""#line:6402
        O0000O0O000O0OO0O ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[Unsubscribe]exchange={O00000000OO00OO00}, symbol={OO0O00O0O0OO0O0O0}")#line:6403
        OOO00OOOO0OOO0OO0 :str =""#line:6405
        if EXCHANGE .TWF ==O00000000OO00OO00 :#line:6407
            O0OOOO000O0OOO0OO ,OOO00OOOO0OOO0OO0 =O0000O0O000O0OO0O .__OO0OOO0O0O0OO00O0 (OO0O00O0O0OO0O0O0 )#line:6408
            if O0OOOO000O0OOO0OO ==False :#line:6409
                OO00O0OO0OOOOO0OO =SystemEvent (RCode .SUBSCRIPTION_FAIL ,OOO00OOOO0OOO0OO0 )#line:6410
                O0000O0O000O0OO0O .__O0OO000OOO0O0OOO0 .Fire_OnSystemEvent (OO00O0OO0OOOOO0OO )#line:6411
                return RCode .FAIL #line:6412
        elif EXCHANGE .TWS ==O00000000OO00OO00 :#line:6414
            O0OOOO000O0OOO0OO ,OOO00OOOO0OOO0OO0 =O0000O0O000O0OO0O .__OOOO0000000O0O0O0 (OO0O00O0O0OO0O0O0 )#line:6415
            if O0OOOO000O0OOO0OO ==False :#line:6416
                OO00O0OO0OOOOO0OO =SystemEvent (RCode .SUBSCRIPTION_FAIL ,OOO00OOOO0OOO0OO0 )#line:6417
                O0000O0O000O0OO0O .__O0OO000OOO0O0OOO0 .Fire_OnSystemEvent (OO00O0OO0OOOOO0OO )#line:6418
                return RCode .FAIL #line:6419
        return RCode .OK #line:6421
    def OvsUnSubscribe (O0OOO000000OOOOOO ,OO0000OOO0OO0OO0O :str )->bool :#line:6422
        ""#line:6423
        OO000O000O000O0OO :str =""#line:6425
        O0OOO0O00O0O0OO0O ,OO000O000O000O0OO =O0OOO000000OOOOOO .__O00O0O0OOOOOOO0O0 (OO0000OOO0OO0OO0O )#line:6426
        if O0OOO0O00O0O0OO0O :#line:6427
            O0OOO000000OOOOOO ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[OvsUnSubscribe]aSymbol={OO0000OOO0OO0OO0O}")#line:6428
            return RCode .OK #line:6429
        else :#line:6430
            O0OOO000000OOOOOO ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[OvsUnSubscribe]aSymbol={OO0000OOO0OO0OO0O}, sErrMsg={OO000O000O000O0OO}")#line:6431
            return RCode .FAIL #line:6432
    def SubscribeWithCategory (O00000OOOO0OO000O ,O00O00OOO0O00O0O0 :str ,O0OOOOO00OOO0O0OO :str )->RCode :#line:6433
        O00000OOOO0OO000O ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[SubscribeWithCategory]exchange={O00O00OOO0O00O0O0}, subscriptionCategory={O0OOOOO00OOO0O0OO}")#line:6434
        if EXCHANGE .TWF ==O00O00OOO0O00O0O0 :#line:6436
            OOOOOOO000000O0O0 =threading .Thread (target =O00000OOOO0OO000O .__O0O0O0OOO000O0OOO ,args =(O0OOOOO00OOO0O0OO ,True ))#line:6438
            OOOOOOO000000O0O0 .start ()#line:6439
        elif EXCHANGE .TWS ==O00O00OOO0O00O0O0 :#line:6441
            OOOOOOO000000O0O0 =threading .Thread (target =O00000OOOO0OO000O .__O0O000OO0O0OO000O ,args =(O0OOOOO00OOO0O0OO ,True ))#line:6443
            OOOOOOO000000O0O0 .start ()#line:6444
        return RCode .OK #line:6445
    def UnsubscribeWithCategory (O000OO00O0OOOOO00 ,O00O0O00O00O0OOOO :str ,O00O0OOOOO0O00OOO :str )->RCode :#line:6447
        ""#line:6449
        O000000O0O00O0O0O :str =""#line:6450
        if EXCHANGE .TWF ==O00O0O00O00O0OOOO :#line:6452
            OO00O000O00O00O00 ,O000000O0O00O0O0O =O000OO00O0OOOOO00 .__OOO0O0OOOO000OOOO (O00O0OOOOO0O00OOO )#line:6453
            if OO00O000O00O00O00 ==RCode .FAIL :#line:6454
                return RCode .FAIL ,O000000O0O00O0O0O #line:6455
        elif EXCHANGE .TWS ==O00O0O00O00O0OOOO :#line:6457
            OO00O000O00O00O00 ,O000000O0O00O0O0O =O000OO00O0OOOOO00 .__OOO00OO0000O000OO (O00O0OOOOO0O00OOO )#line:6458
            if OO00O000O00O00O00 ==RCode .FAIL :#line:6459
                return RCode .FAIL ,O000000O0O00O0O0O #line:6460
        return RCode .OK ,O000000O0O00O0O0O #line:6461
    def OvsUnSubscribeWithCategory (OO00000000OO00O0O ,aMrt :str ="FUT",aExchange :str ="*"):#line:6462
        O0O0O00O0OO0OOO00 :str =""#line:6463
        if aMrt =="FUT":#line:6464
            O0000OOO00000OOO0 ,O0O0O00O0OO0OOO00 =OO00000000OO00O0O .__O0O0O00OOOOO0O000 (aExchange )#line:6465
            if O0000OOO00000OOO0 :#line:6466
                return RCode .OK ,""#line:6467
            else :#line:6468
                return RCode .FAIL ,O0O0O00O0OO0OOO00 #line:6469
        else :#line:6470
            return RCode .FAIL ,"Mart is not 'FUT'"#line:6471
    def __O0O0O0OO0OOO00000 (O00000OO000OOO000 ,OOOO0OO0OOO0OO0OO :str ,O00OOO0O0OOOO0000 :bool ,O0000OOO0OO000O00 :TObjStkQuoteMap ):#line:6474
        ""#line:6475
        if O00OOO0O0OOOO0000 ==False :#line:6476
            O00000OO000OOO000 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[證券行情回補]回補失敗!({OOOO0OO0OOO0OO0OO})")#line:6477
            return #line:6478
        try :#line:6479
            for OOO00OO0OOO0O0000 ,OO0000O0O000OOOOO in O0000OOO0OO000O00 .items ():#line:6480
                O00O0OOOO00OO00O0 :TStkQuoteData =OO0000O0O000OOOOO #line:6481
                O00OOO0000OO00O00 =O00O0OOOO00OO00O0 .BAS .StkNo #line:6482
                if O00000OO000OOO000 ._fPrdSnapshotMap .NewItemStk (O00OOO0000OO00O00 ,O00O0OOOO00OO00O0 ):#line:6483
                    O000OOOOOO00OOOOO :ProductSnapshot =O00000OO000OOO000 ._fPrdSnapshotMap [O00OOO0000OO00O00 ]#line:6485
                    if O00O0OOOO00OO00O0 .UpdateBAS :#line:6486
                        O00000OO000OOO000 .__O0OO000OOO0O0OOO0 .Fire_OnUpdateBasic (O000OOOOOO00OOOOO .BasicData )#line:6487
                        O00O0OOOO00OO00O0 .UpdateBAS =False #line:6488
                    if O00O0OOOO00OO00O0 .UpdateHL :#line:6489
                        O000OOOOOO00OOOOO .TickData =ProductTick_Stk (O00O0OOOO00OO00O0 )#line:6490
                        O00000OO000OOO000 .__O0OO000OOO0O0OOO0 .Fire_OnUpdateLastSnapshot (O00000OO000OOO000 ._fPrdSnapshotMap [O00OOO0000OO00O00 ])#line:6491
                        O00O0OOOO00OO00O0 .UpdateHL =False #line:6492
        except Exception as O00OO0OO0O00OO0OO :#line:6498
            O00000OO000OOO000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteStkAPI_OnQtRcvEvent]aMsg={OOOO0OO0OOO0OO0OO}, aIsOK={O00OOO0O0OOOO0000}, ex:{O00OO0OO0O00OO0OO}")#line:6499
    def __OOOO00OOO000000O0 (O00O0000OO0O000O0 ,OO0OO00O0O0O0O0O0 :str ,OO0O0O0O0O0O00O0O :str ,OOO000O0OOO0O000O :TObjStkQuoteMap ):#line:6501
        ""#line:6502
        if OO0O0O0O0O0O00O0O ==False :#line:6503
            O00O0000OO0O000O0 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[證券行情回補(指數)]{OO0OO00O0O0O0O0O0}回補失敗!")#line:6504
            return #line:6505
        try :#line:6506
            for OOO0O0OO000OO0OO0 ,OO0OOO0O000O00O0O in OOO000O0OOO0O000O .items ():#line:6507
                OO0O00OOOOOO0OO0O :TStkQuoteData =OO0OOO0O000O00O0O #line:6508
                O00O0O0O0O00000O0 =OO0O00OOOOOO0OO0O .BAS .StkNo #line:6509
                if O00O0000OO0O000O0 ._fPrdSnapshotMap .NewItemStk (O00O0O0O0O00000O0 ,OO0O00OOOOOO0OO0O ):#line:6510
                    if O00O0000OO0O000O0 .__OOOOOO000000O0O00 ==False :#line:6511
                        O00O00000O0O0O0O0 :ProductSnapshot =O00O0000OO0O000O0 ._fPrdSnapshotMap [O00O0O0O0O00000O0 ]#line:6512
                        O00O0000OO0O000O0 .__O0OO000OOO0O0OOO0 .Fire_OnUpdateBasic (O00O00000O0O0O0O0 .BasicData )#line:6513
                        O00O0000OO0O000O0 .__O0OO000OOO0O0OOO0 .Fire_OnUpdateLastSnapshot (O00O0000OO0O000O0 ._fPrdSnapshotMap [O00O0O0O0O00000O0 ])#line:6514
            if O00O0000OO0O000O0 .__OOOOOO000000O0O00 :#line:6515
                if len (O00O0000OO0O000O0 ._fPrdSnapshotMap )>0 :#line:6516
                    OOOO0OO00O0O00OO0 =list (O00O0000OO0O000O0 ._fPrdSnapshotMap .values ())#line:6517
                    O00O0000OO0O000O0 .__O0OO000OOO0O0OOO0 .Fire_OnUpdateProductBasicList (OOOO0OO00O0O00OO0 )#line:6518
        except Exception as OO0OOOO0000OOO00O :#line:6519
            O00O0000OO0O000O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteStkAPI_OnQtIdxRcvEvent]aMsg={OO0OO00O0O0O0O0O0}, aIsOK={OO0O0O0O0O0O00O0O}, ex:{OO0OOOO0000OOO00O}")#line:6520
    def __OOO0O0OOO00O0OO0O (O000OOOO00000OO0O ,OOOOOOOO0O0OO00O0 :str ,OO0O000000O0OO00O :TStkQtTX ):#line:6522
        ""#line:6523
        try :#line:6524
            OOOO0O0OOOOOOO0O0 :ProductSnapshot =None #line:6525
            OO000O0OO0OOOOO0O ,OOOO0O0OOOOOOO0O0 =O000OOOO00000OO0O ._fPrdSnapshotMap .GetItem (OOOOOOOO0O0OO00O0 )#line:6527
            if OO000O0OO0OOOOO0O :#line:6529
                O0000OO00OOO00O00 :ProductTick_Stk =OOOO0O0OOOOOOO0O0 .TickData #line:6530
                OO000O0OO0OOOOO0O ,OO000OOOOOOOO00O0 =O0000OO00OOO00O00 .Upt_TX (OO0O000000O0OO00O )#line:6531
                if OO000O0OO0OOOOO0O :#line:6532
                    O000OOOO00000OO0O .__O0OO000OOO0O0OOO0 .Fire_OnMatch (O000OOOO00000OO0O ._fPrdSnapshotMap [OOOOOOOO0O0OO00O0 ].TickData )#line:6533
                else :#line:6535
                    O000OOOO00000OO0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"STK_TXEvent Error:{OO000OOOOOOOO00O0} aSolIce:{OOOOOOOO0O0OO00O0} tmpQtTx:{OO0O000000O0OO00O}")#line:6536
        except Exception as O0O0O0O000000OO00 :#line:6537
            O000OOOO00000OO0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[STK_TXEvent]ProdID={OOOOOOOO0O0OO00O0}, ex:{O0O0O0O000000OO00}")#line:6538
    def __OO000O00000O0000O (OO00O0O00OOOO0OO0 ,O0OOOOOOO00O0OO0O :str ,OOOOOO0O0OO00OOOO :TStkQt5Q ):#line:6539
        ""#line:6540
        try :#line:6541
            OO0O0OOO0O0000OOO :ProductSnapshot =None #line:6542
            O0O0000OO0OO000O0 ,OO0O0OOO0O0000OOO =OO00O0O00OOOO0OO0 ._fPrdSnapshotMap .GetItem (O0OOOOOOO00O0OO0O )#line:6543
            if O0O0000OO0OO000O0 :#line:6544
                O00OOO0OOO0OO0O0O :ProductTick_Stk =OO0O0OOO0O0000OOO .TickData #line:6545
                O0O0000OO0OO000O0 ,OOO00OO0OO000OOO0 =O00OOO0OOO0OO0O0O .Upt_5Q (OOOOOO0O0OO00OOOO )#line:6547
                if O0O0000OO0OO000O0 :#line:6548
                    OO00O0O00OOOO0OO0 .__O0OO000OOO0O0OOO0 .Fire_OnOrderBook (OO00O0O00OOOO0OO0 ._fPrdSnapshotMap [O0OOOOOOO00O0OO0O ].TickData )#line:6549
                else :#line:6551
                    OO00O0O00OOOO0OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"STK_5QEvent Error:{OOO00OO0OO000OOO0} aSolIce={O0OOOOOOO00O0OO0O} tmpQt5Q:{OOOOOO0O0OO00OOOO}")#line:6552
        except Exception as OO0O000000O0OOO0O :#line:6553
            OO00O0O00OOOO0OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[STK_5QEvent]ProdID={O0OOOOOOO00O0OO0O}, ex:{OO0O000000O0OOO0O}")#line:6554
    def __O00O0OOO0000OO000 (O000O000OO0000O0O ,OO00O0O0O0O0000OO :str ,OOO00O0O0OOO00OOO :TStkQtIDX ):#line:6555
        ""#line:6556
        try :#line:6557
            O000OO0O0O00OO0OO :ProductSnapshot =None #line:6558
            OO0OO0OOOOO000O0O ,O000OO0O0O00OO0OO =O000O000OO0000O0O ._fPrdSnapshotMap .GetItem (OO00O0O0O0O0000OO )#line:6560
            if OO0OO0OOOOO000O0O :#line:6561
                OO0O0000000000O00 :ProductTick_Stk =O000OO0O0O00OO0OO .TickData #line:6562
                OO0OO0OOOOO000O0O ,OO00OOOOOO000O000 =OO0O0000000000O00 .Upt_IDX (OOO00O0O0OOO00OOO )#line:6564
                if OO0OO0OOOOO000O0O :#line:6565
                    O000O000OO0000O0O .__O0OO000OOO0O0OOO0 .Fire_OnMatch (O000O000OO0000O0O ._fPrdSnapshotMap [OO00O0O0O0O0000OO ].TickData )#line:6566
                else :#line:6568
                    O000O000OO0000O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"STK_IDXEvent Error:{OO00OOOOOO000O000} aSolIce:{OO00O0O0O0O0000OO} tmpQtIDX:{OOO00O0O0OOO00OOO}")#line:6569
        except Exception as OOOO0O00OO000OOOO :#line:6570
            O000O000OO0000O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteStkAPI_OnQtIDXEvent]ProdID={OO00O0O0O0O0000OO}, ex:{OOOO0O00OO000OOOO}")#line:6571
class SolAPIHH (SolAPI ):#line:6577
    def __init__ (OOOO0O0OOO0O0OOOO ,__OOO0OOOO0O0O000O0 :MarketDataMart ,O00OO00OO00O000O0 :str ,loglv =logging .INFO ,conlv =logging .INFO ):#line:6578
        super ().__init__ (__OOO0OOOO0O0O000O0 ,O00OO00OO00O000O0 ,False ,loglv ,conlv )#line:6579
    def Logon (O000000O000O00O00 ,O000OO0O00OOOOOOO :str ,OOOO0O00O00OO0OOO :str ,O00OO000O00O0O000 :str ,aCompressLevel :int =5 )->RCode :#line:6581
        ""#line:6587
        if aCompressLevel <1 :#line:6588
            return RCode .FAIL #line:6589
        return O000000O000O00O00 .Connect (O000OO0O00OOOOOOO +":55003","api",OOOO0O00O00OO0OOO ,O00OO000O00O0O000 ,aCompressLevel )#line:6591
class TSolaceMessageThreadClass (MessageHandler ):#line:6597
    ""#line:6598
    def __init__ (OO00OOOOO0O0OO000 ,O0O0OO00OOOO00000 :str ,O0OOOO0000OO00O00 :logging .Logger ,OOO0000O0O00O0O0O ):#line:6601
        OO00OOOOO0O0OO000 ._name =O0O0OO00OOOO00000 #line:6602
        OO00OOOOO0O0OO000 ._msgHandler =OOO0000O0O00O0O0O #line:6603
        OO00OOOOO0O0OO000 ._lock =Lock ()#line:6604
        OO00OOOOO0O0OO000 ._log =O0OOOO0000OO00O00 #line:6605
        OO00OOOOO0O0OO000 ._list =[]#line:6606
        OO00OOOOO0O0OO000 ._run =True #line:6607
        OO00OOOOO0O0OO000 .thrd =threading .Thread (target =OO00OOOOO0O0OO000 .OnThread ,name =OO00OOOOO0O0OO000 ._name )#line:6608
        OO00OOOOO0O0OO000 .thrd .start ()#line:6609
    def OnThread (OOOO0OO0OOOOO0O00 ):#line:6611
        O00000O0OO00O0OO0 =[]#line:6612
        OO0O000000OOOO0O0 ,O0O0000O0O000O0OO ,O000O0O0O0000000O =0 ,0 ,0 #line:6613
        while OOOO0OO0OOOOO0O00 ._run :#line:6614
            try :#line:6616
                with OOOO0OO0OOOOO0O00 ._lock :#line:6617
                    O00000O0OO00O0OO0 =OOOO0OO0OOOOO0O00 ._list .copy ()#line:6618
                    OO0O000000OOOO0O0 =len (O00000O0OO00O0OO0 )#line:6619
                    if (len (OOOO0OO0OOOOO0O00 ._list )>3000 )and OO0O000000OOOO0O0 ==O0O0000O0O000O0OO :#line:6620
                        OOOO0OO0OOOOO0O00 ._list =[]#line:6621
                for O000O0O0O0000000O in range (O0O0000O0O000O0OO ,OO0O000000OOOO0O0 ):#line:6623
                    OOOO0OO0OOOOO0O00 ._msgHandler (O00000O0OO00O0OO0 [O000O0O0O0000000O ])#line:6624
                O0O0000O0O000O0OO =OO0O000000OOOO0O0 #line:6626
            except Exception as O0O000O0O00O00O00 :#line:6627
                OOOO0OO0OOOOO0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"TSolaceMessageThreadClass __Handle_RTQuote_Main exception! exception={O0O000O0O00O00O00}")#line:6629
            finally :#line:6630
                sleep (0.001 )#line:6631
    def Add (OO0OO00O000OOOO0O ,O00O0000000OOOO0O ):#line:6633
        with OO0OO00O000OOOO0O ._lock :#line:6634
            OO0OO00O000OOOO0O ._list .append (O00O0000000OOOO0O )#line:6635
    def on_message (O00O000OOO0O0OO0O ,O000OO00O00OOO000 ):#line:6637
        ""#line:6638
        O00O000OOO0O0OO0O .Add (O000OO00O00OOO000 )#line:6639
class TMyWorkItemThreadClass :#line:6644
    def __init__ (O0O00000OO00OO000 ,O00OOOO0OO0OOOOO0 :str ,OOOO0000OO00OO0O0 :logging .Logger ,O0O0OOOOO00O0OO00 ):#line:6645
        O0O00000OO00OO000 ._name =O00OOOO0OO0OOOOO0 #line:6646
        O0O00000OO00OO000 ._msgHandler =O0O0OOOOO00O0OO00 #line:6647
        O0O00000OO00OO000 ._lock =Lock ()#line:6648
        O0O00000OO00OO000 ._log =OOOO0000OO00OO0O0 #line:6649
        O0O00000OO00OO000 ._run =True #line:6650
        O0O00000OO00OO000 ._queue =queue .Queue ()#line:6651
        O0000OOOO00O0OOOO =threading .Thread (target =O0O00000OO00OO000 .OnThread ,name =O0O00000OO00OO000 ._name )#line:6652
        O0000OOOO00O0OOOO .start ()#line:6653
    def OnThread (OO0O0O00OO0OOOOO0 ):#line:6655
        while OO0O0O00OO0OOOOO0 ._run :#line:6656
            try :#line:6658
                with OO0O0O00OO0OOOOO0 ._lock :#line:6659
                    while not OO0O0O00OO0OOOOO0 ._queue .empty ():#line:6660
                        O000O00OOO000OOO0 =OO0O0O00OO0OOOOO0 ._queue .get ()#line:6661
                        OO0O0O00OO0OOOOO0 ._msgHandler (O000O00OOO000OOO0 ["arg1"],O000O00OOO000OOO0 ["arg2"])#line:6663
            except Exception as OOOOOOOO00OO00O0O :#line:6665
                OO0O0O00OO0OOOOO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"TMyWorkItemThreadClass send_msg exception! exception={OOOOOOOO00OO00O0O}")#line:6666
            finally :#line:6667
                sleep (0.001 )#line:6668
    def Add (OOOO000OO0OOOO0O0 ,**O0O0O000OOOOO0O00 ):#line:6670
        with OOOO000OO0OOOO0O0 ._lock :#line:6671
            OOOO000OO0OOOO0O0 ._queue .put (O0O0O000OOOOO0O00 )#line:6672
class CacheReqOutListener (CacheRequestOutcomeListener ):#line:6674
    def __init__ (OO0000O0O00O000O0 ,OOOO0O00O00OOOO0O ,OOOO00OO0OO00OOO0 :TSolaceMessageThreadClass ,O0O00000OO0OO0000 :SolaceLog )->None :#line:6675
        OO0000O0O00O000O0 ._solapi =OOOO0O00O00OOOO0O #line:6676
        OO0000O0O00O000O0 ._thrdMag :TSolaceMessageThreadClass =OOOO00OO0OO00OOO0 #line:6677
        OO0000O0O00O000O0 ._log :SolaceLog =O0O00000OO0OO0000 #line:6678
    def on_completion (O000OO0OO000O0O00 ,OO00O0OO0O0O00000 :CacheRequestOutcome ,OO000000OO00OO0O0 :int ,O00OOOO0OO0O0OO00 :Exception ):#line:6679
        if OO00O0OO0O0O00000 ==CacheRequestOutcome .FAILED :#line:6681
            O000OO0OO000O0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"cache completion fail: result:{OO00O0OO0O0O00000} id:{OO000000OO00OO0O0} exception:{O00OOOO0OO0O0OO00}")#line:6682
            OO00OOO0OO0O0OOO0 :TCacheJob =O000OO0OO000O0O00 ._solapi ._fMapCacheJob [OO000000OO00OO0O0 ]#line:6683
        elif OO00O0OO0O0O00000 ==CacheRequestOutcome .OK :#line:6686
            O000OO0OO000O0O00 ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"cache completion OK: result:{OO00O0OO0O0O00000} id:{OO000000OO00OO0O0} exception:{O00OOOO0OO0O0OO00}")#line:6687
            if O000OO0OO000O0O00 ._solapi ._fMapCacheJob .get (OO000000OO00OO0O0 ):#line:6688
                OO00OOO0OO0O0OOO0 :TCacheJob =O000OO0OO000O0O00 ._solapi ._fMapCacheJob [OO000000OO00OO0O0 ]#line:6689
                OO0O0OOOOO0O0O000 =OO00OOO0OO0O0OOO0 .Params .get ("Category")#line:6690
                if (OO0O0OOOOO0O0O000 =="SubQuoteByCategory_BAS"):#line:6693
                    OO0OOOO000000OO0O =TCacheJob ()#line:6695
                    OO00000O0OO0OOOOO =OO00OOO0OO0O0OOO0 .TopicBAS .split ("/")#line:6696
                    if OO00OOO0OO0O0OOO0 .TopicBAS .startswith ("Quote/TWS/"):#line:6697
                        OO00000O0OO0OOOOO [len (OO00000O0OO0OOOOO )-1 ]="HL"#line:6698
                        OO00000O0OO0OOOOO [len (OO00000O0OO0OOOOO )-2 ]="*"#line:6699
                        OO00000O0OO0OOOOO [len (OO00000O0OO0OOOOO )-3 ]="*"#line:6700
                        OO0OOOO000000OO0O .TopicHL ="/".join (OO00000O0OO0OOOOO )#line:6701
                    elif OO00OOO0OO0O0OOO0 .TopicBAS .startswith ("Quote/TWF/"):#line:6702
                        OO00000O0OO0OOOOO [len (OO00000O0OO0OOOOO )-1 ]="HL"#line:6703
                        OO00000O0OO0OOOOO [len (OO00000O0OO0OOOOO )-2 ]="*"#line:6704
                        OO0OOOO000000OO0O .TopicHL ="/".join (OO00000O0OO0OOOOO )#line:6705
                    OO0OOOO000000OO0O .oneProd =False #line:6706
                    OO0OOOO000000OO0O .RequestID =O000OO0OO000O0O00 ._solapi .GetRequestID ()#line:6707
                    OO0OOOO000000OO0O .Params ["Category"]="SubQuoteByCategory_HL"#line:6708
                    O000OO0OO000O0O00 ._solapi ._fMapCacheJob [OO0OOOO000000OO0O .RequestID ]=OO0OOOO000000OO0O #line:6709
                    O000OO0OO000O0O00 ._solapi .callcache (OO0OOOO000000OO0O .RequestID ,OO0OOOO000000OO0O .TopicHL )#line:6711
