import socket  
import datetime  
import time
import hashlib

class Helper:
    @classmethod
    def getClientInfo(cls) -> str:
        ## getting the hostname by socket.gethostname() method
        hostname = socket.gethostname()
        ## getting the IP address using socket.gethostbyname() method
        ip_address = socket.gethostbyname(hostname)
        return f'{hostname}[{ip_address}]'

    @classmethod
    def formatExchangeTime(cls, time: str) -> str:
        if not time:
            return ''
        time = time.zfill(9)
        ts = datetime.datetime.strptime(time, '%H%M%S%f')
        return ts.strftime("%H:%M:%S.%f")

    @classmethod
    def currentMilliTime():
        return round(time.time() * 1000)

    @classmethod
    def get_md5(cls, msg: str):
        return hashlib.md5(msg.encode('utf-8')).hexdigest()