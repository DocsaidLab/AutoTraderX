# -*- coding: utf-8 -*-
from .sorapi_c import *
from .utility import Map

class SorTable():
    def __init__(self, sorApiC, table):
        self.__SorApiC = sorApiC
        self.__Table = table
        self.__Props = self.__SorApiC.CSorTable_Properties(table)
        self.__RecordCount = self.__SorApiC.CSorTable_RecordsCount(table)
        self.RecordData = []
        self.FieldName2Index = {}
        self.FieldIndex2Name = {}
        self.FieldDisplay = {}
        self.FieldDescription = {}
        self.__initFields()
    def __initFields(self):
        fields = self.__SorApiC.CSorTable_Fields(self.__Table)
        fieldsCount = self.__SorApiC.CSorFields_Count(fields)
        for index in range(fieldsCount):
            field = self.__SorApiC.CSorFields_IndexField(fields, index)
            fldProps = self.__SorApiC.CSorField_Properties(field)
            fldName = self.__SorApiC.CSorProperties_Name(fldProps)
            self.FieldName2Index[fldName] = index
            self.FieldIndex2Name[index] = fldName
            self.FieldDisplay[fldName] = self.__SorApiC.CSorProperties_DisplayText(fldProps)
            self.FieldDescription[fldName] = self.__SorApiC.CSorProperties_Description(fldProps)
        #把資料讀出來
        for recIdx in range(self.__RecordCount):
            rec = []
            for fldIdx in range(fieldsCount):
                field = self.__SorApiC.CSorFields_IndexField(fields, fldIdx)
                rec.append(self.__SorApiC.CSorTable_RecordField(self.__Table, recIdx, field))
            self.RecordData.append('\x01'.join(rec))    #以\x01 分隔
        #print (self.GetName())
        #print (self.FieldName2Index)
    def GetName(self):
        return self.__SorApiC.CSorProperties_Name(self.__Props)
    def GetDisplay(self):
        return self.__SorApiC.CSorProperties_DisplayText(self.__Props)
    def GetID(self):
        return self.__SorApiC.CSorProperties_Get(self.__Props, 'ID')
    def GetProperty(self, key):
        return self.__SorApiC.CSorProperties_Get(self.__Props, key)
    def GetRecordsCount(self):
        return self.__RecordCount
    def GetFieldCount(self):
        return len(self.FieldName2Index)
    def GetFieldIndex(self, fieldName):
        if fieldName in self.FieldName2Index:
            return self.FieldName2Index[fieldName]
        return None
    def GetFieldMap(self, flds):
        res = Map()
        assert len(self.FieldIndex2Name) == len(flds), '欄位數量不匹配'
        for index in range(len(flds)):
            res.Set(self.FieldIndex2Name[index], flds[index])
        return res

class SorTableMgr():
    def __init__(self, sorApiC):
        self.__SorApiC = sorApiC
        self.__SingleKeyTables = {}
        self.DoubleKeyTables_ = {}
    def Parse(self, sorTaskResult):
        tableCount = self.__SorApiC.CSorTaskResult_TableCount(sorTaskResult)
        #print ('tableCount:' + str(tableCount))
        for index in range(tableCount):
            table = self.__SorApiC.CSorTaskResult_IndexTable(sorTaskResult, index)
            sorTable = SorTable(self.__SorApiC, table)
            tableName = sorTable.GetName()
            if ":" in tableName:
                # REQ or ORD or RPT or DDS
                tableType = tableName[:3]
                # TwsNew or TwsChg
                tableName = tableName[4:]
                self.DoubleKeyTables_[tableType, tableName] = sorTable
            else:
                self.__SingleKeyTables[tableName] = sorTable
        #print (self.Tables_)
        '''
        for tableKey in self.Tables_:
            print (tableKey)
            print (self.GetDisplay(self.GetProperty(self.GetTable(tableKey[0], tableKey[1]))))
        '''
        #print (self.GetDisplay(self.GetProperty(self.GetTable('REQ', 'TwsNew'))))
    def GetTable(self, tableType, tableName):
        if (tableType, tableName) in self.DoubleKeyTables_:
            return self.DoubleKeyTables_[tableType, tableName]
        return None
    def GetSingleTable(self, tableName):
        if (tableName) in self.__SingleKeyTables:
            return self.__SingleKeyTables[tableName]
        return None
