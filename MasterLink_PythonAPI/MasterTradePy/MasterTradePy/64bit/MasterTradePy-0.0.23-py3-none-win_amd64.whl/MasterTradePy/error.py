from MasterTradePy.constant import RCode

class MTPYError(Exception):
    def __init__(self, code: RCode, message):
        formated_mes = "{}:{}".format(code, message)
        super().__init__(formated_mes)
        self.code = code
        self.message = message
        
    def __str__(self):
        return "{}:{}".format(self.code, self.message)

