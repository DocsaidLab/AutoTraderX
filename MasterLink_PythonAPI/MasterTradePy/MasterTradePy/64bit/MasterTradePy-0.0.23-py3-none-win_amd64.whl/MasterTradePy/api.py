import typing
from .pySsoSorApi.pySorApi.sorapi import *
from .pySsoSorApi.pySorApi.sorAccs import *
from .pySsoSorApi.pySorApi.sortablemgr import *
from .pySsoSorApi.pySorApi.utility import *
from . import pySsoSorApi

from MasterTradePy.model import *
from MasterTradePy.multiple import MultipleMeta
from MasterTradePy.constant import *
from MasterTradePy.utils import log
from MasterTradePy.helper import Helper
from MasterTradePy.soclient import SolClient, ServiceEventHandler, TradeMessageHandler
from MasterTradePy.error import MTPYError
from solace.messaging.errors.pubsubplus_client_error import PubSubTimeoutError
from solace.messaging.receiver.message_receiver import MessageHandler, InboundMessage
from threading import Lock
from time import sleep
from decimal import Decimal
            
class MasterTradeAPI(metaclass=MultipleMeta):      
    def __init__(self, trader: MarketTrader):
        self._client: SolClient = None
        self._clientRevAnn: SolClient = None
        self._subscriptions: set = set()
        self._trader = trader
        self.is_connected = False
        
        self.config = Config()
        self.callbacks = Map()
        self.tradeAccs = Accs()
        self.tradingAcc = None
        self.accMap = dict()
        self.orderReportDict: typing.Dict[str, ReportOrder] = dict()
        self.callbacks.Set('OnSorConnectEvent', self.OnSorConnect)
        self.callbacks.Set('OnSorApReadyAck', self.OnSorApReady)
        self.callbacks.Set('OnSorRequestAck', self.OnSorRequestAck)
        self.callbacks.Set('OnSorTaskResult', self.OnSorTaskResult)
        self.callbacks.Set('OnSorReport', self.OnSorReport)
        self.sso_sorapi = pySsoSorApi.SsoSorApi(self.callbacks)
        self.sorapi = None
        self.accounts = []
        self.__querySeqID = 0
        self.__qidmap: typing.Dict[str, RequestType] = dict()
        self.__prodmap: typing.Dict[str, str] = dict()
        self.__accmap: typing.Dict[str, str] = dict()
        self.__basic: typing.Dict[str, Basic] = dict()
        self.__inventory: typing.Dict[str, Inventory] = dict()
        self.__inventory_s: typing.Dict[str, Inventory] = dict()
        self.__secInvQty: typing.Dict[str, SecInvQty] = dict()
        self.__crQtyAndDbQty: typing.Dict[str, CrQtyAndDbQty] = dict()
        
        
    def SetConnectionHost(self, host):
        self.config.SOL_SESSION_HOST = host
    
    def Connect(self, ssoUrl: str, sysid: str, username: str, password: str):
        self.sorapi = self.sso_sorapi.create_connection(ssoUrl, sysid, username, password)
        log_star = ''.rjust(len(password), '*')
        try:
            self.sorapi.WaitConnect()
        except:                   
            log.error(f"MasterTradeAPI Connect error: username={username}, password={log_star}, config={self.config}")
        return RCode.USER_NOT_VERIFIED
    
    def disClient(self):
        self.__fWorkThr_RecMsg._run = False
        self._client.disconnect()
        self.__fWorkThr_RecMsg_RevAnn._run = False
        self._client_RevAnn.disconnect()    

    def Login(self, username: str, password: str, is_sim: bool, is_force: bool, is_event: bool) -> RCode:
        if is_event:
            is_sim = True
            username = username + "VA"
            print(f"連線競賽ID:{username}")

        rc = RCode.FAIL
        self.username = username
        self.password = password
        hash_password = Helper.get_md5(password)
        user_login = UserLogin(username, hash_password, Config.USER_SOURCE_TYPE, RequestType.TradeQPI, is_sim, is_event)
        self._client = SolClient(username, self.config)
        self.__fWorkThr_RecMsg = TSolMsgThrdClass("Trd_HandleQuote", log, self.__Handle_Reveice_Msg)
        self._client.create_connection(self.__fWorkThr_RecMsg, ServiceEventHandler(self._trader))
        self._client.add_subscription(self.config.SYSANNTWS)      

        #Announcement
        self._client_RevAnn = SolClient("Recover_ANN"+self.config.SOL_SESSION_HOST, self.config, "Recover_ANN")
        self.__fWorkThr_RecMsg_RevAnn = TSolMsgThrdClass("Trd_HandleQuote_RevAnn", log, self.__Handle_Reveice_Msg)        

        log_star = ''.rjust(len(self.password), '*')
        try:
            response = self._client.send_request(self.config.USER_AUTH_TOPIC, user_login.to_json())
        except PubSubTimeoutError as e:
            log.error(f"MasterTradeAPI Auth error: username={username}, password={log_star}, config={self.config}")
            self._trader.OnSystemEvent(SystemEvent(RCode.REQUEST_TIMEOUT, e))
            return RCode.REQUEST_TIMEOUT

        j = json.loads(response)
        login_reply = UserLoginReply(**j)
        
        ann:str = ''
        if 'announcement' in response:
            ann = j['announcement']
        if not(ann == None or ann.isspace() or len(ann) == 0):
            self._trader.OnAnnouncementEvent(ann)#公告

        if login_reply.result:
            #回補公告
            self._client_RevAnn.create_connection(self.__fWorkThr_RecMsg_RevAnn, ServiceEventHandler(self._trader))
            self._client_RevAnn.request_cached_only("dc01", self.config.SYSANNTWS, 60000, self._client_RevAnn.GetRequestID())

            auth_count = 0
            for login_reply_account in login_reply.list:
                self.accounts.append(login_reply_account['account'])
                statusCode = login_reply_account['statusCode']
                if is_sim or is_event:
                    if statusCode == AccountStatus.Verified or statusCode == AccountStatus.Approved or AccountStatus.NotVerified:
                        auth_count += 1
                else:
                    if statusCode == AccountStatus.Approved:
                        auth_count += 1         
            if auth_count > 0 and auth_count < len(login_reply.list):
                if is_force:
                    if is_event:
                        notice = u"連線競賽主機!!!\n"
                        print(notice)
                        log.info(f'Connect to trading host:{login_reply.host}, username={self.username}, password={log_star}')
                        self.sorapi = pySsoSorApi.SorApi(self.callbacks)
                        self.sorapi.Connect(login_reply.host, login_reply.sysId, username, login_reply.password)
                    elif is_sim:
                        notice = u"連線測試主機!!!\n"
                        print(notice)
                        log.info(f'Connect to trading host:{login_reply.host}, username={self.username}, password={log_star}')
                        self.sorapi = pySsoSorApi.SorApi(self.callbacks)
                        self.sorapi.Connect(login_reply.host, login_reply.sysId, username, login_reply.password)
                    else:
                        notice = u"證券帳號已部分驗證，連線正式主機!!!\n"
                        print(notice)
                        log.info(f'Connect to trading host:{login_reply.ssoUrl}, username={self.username}, password={log_star}')
                        self.sorapi = self.sso_sorapi.create_connection(login_reply.ssoUrl, self.username, hash_password)
                    try:
                        self.sorapi.WaitConnect()
                    except:                   
                        log.error(f"MasterTradeAPI Connect error: host={login_reply.ssoUrl}, username={username}, password={log_star}")
                    return RCode.PART_USER_VERIFIED
                else:
                    notice = u"證券帳號已部分驗證，請完成所有帳號驗證\n"
                    print(notice)
                    return RCode.USER_NOT_VERIFIED
            elif auth_count == len(login_reply.list):
                if is_event:
                    notice = u"連線競賽主機!!!\n"
                    print(notice)
                    log.info(f'Connect to trading host:{login_reply.host}, username={username}, password={log_star}')
                    self.sorapi = pySsoSorApi.SorApi(self.callbacks)
                    self.sorapi.Connect(login_reply.host, login_reply.sysId, username, login_reply.password)
                elif is_sim:
                    notice = u"連線測試主機!!!\n"
                    print(notice)
                    log.info(f'Connect to trading host:{login_reply.host}, username={username}, password={log_star}')
                    self.sorapi = pySsoSorApi.SorApi(self.callbacks)
                    self.sorapi.Connect(login_reply.host, login_reply.sysId, username, login_reply.password)
                else:
                    notice = u"證券帳號已驗證，連線正式主機!!!\n"
                    print(notice)
                    log.info(f'Connect to trading host:{login_reply.ssoUrl}, username={self.username}, password={log_star}')
                    self.sorapi = self.sso_sorapi.create_connection(login_reply.ssoUrl, self.username, hash_password)
                try:
                    self.sorapi.WaitConnect()
                except:                   
                    log.error(f"MasterTradeAPI Connect error: host={login_reply.ssoUrl}, username={username}, password={log_star}")
                return RCode.OK
            else:
                if is_sim or is_event:
                    notice = u"證券帳號未驗證，連線至驗證下單主機\n"
                    print(notice)
                else:
                    notice = u"證券帳號未驗證\n"
                    print(notice)
                    return RCode.USER_NOT_VERIFIED
            
                log.info(f'Connect to trading host:{login_reply.host}, username={self.username}, password={log_star}')
                self.sorapi = pySsoSorApi.SorApi(self.callbacks)
                self.sorapi.Connect(login_reply.host, login_reply.sysId, self.username, self.password)
                try:
                    self.sorapi.WaitConnect()
                except:                   
                    log.error(f"MasterTradeAPI Connect error: host={login_reply.host}, username={username}, password={log_star}")
                return RCode.USER_NOT_VERIFIED
        else:
            notice = login_reply.message
            print(notice)
            return RCode.FAIL
    
    def QryRepAll(self,  tradingAccount: str):
        """查詢所有委託"""
        if len(tradingAccount) < 7:
                tradingAccount = tradingAccount.zfill(7)
        bNoData = True
        for key, rep in self.orderReportDict.items():
            if rep.order.tradingAccount == tradingAccount:            
                bNoData = False
                self._trader.OnReport(rep)
        if bNoData:
            print(f"帳號:{tradingAccount} 無委託資料")        

    def QryRepDeal(self, tradingAccount: str):
        """查詢成交回報"""
        if len(tradingAccount) < 7:
                tradingAccount = tradingAccount.zfill(7)
        bNoData = True
        for key, rep in self.orderReportDict.items():
            if rep.order.tableName == "RPT:TwsDeal" and rep.order.tradingAccount == tradingAccount:
                bNoData = False
                self._trader.OnReport(rep)
        if bNoData:
            print(f"帳號:{tradingAccount} 無成交資料")

    def QrySecInvQty_Rayin(self, tradingAccount: str, symbol:str) -> str:
        """或有券源"""
        if len(tradingAccount) < 7:
                tradingAccount = tradingAccount.zfill(7)
        acc = self.__getTradingAccount(tradingAccount)
        if acc:
            sParmAcNo = 'acno={0}-{1}'.format(acc.BrkNo(), acc.IvacNo())
            sTaskID = 'RayDisp.KL.sor.ivac'
            sDetail = 'ScDetail={0}'.format(symbol)
            sParms = [sParmAcNo, sDetail, 'table=TwsSecInv']
            self.__querySeqID += 1
            workid = 'qid{0}'.format(self.__querySeqID)
            self.__sendSorRequest(workid, sTaskID, sParms, SorReqType.SecInvQty)
        else:
            self._trader.OnError(MTPYError(RCode.ACCOUNT_NOT_FOUND, f'Account Not Found Error: tradingAccount={tradingAccount}'))
        return workid
    
    def QryProdCrQty_Rayin(self, tradingAccount: str, symbol:str) -> str:
        """查詢資券配額 .註:先查資、再查券"""
        if len(tradingAccount) < 7:
                tradingAccount = tradingAccount.zfill(7)
        acc = self.__getTradingAccount(tradingAccount)
        if acc:
            sParmAcNo = 'acno={0}-{1}'.format(acc.BrkNo(), acc.IvacNo())
            sTaskID = 'RayDisp.KL.sor.symb.cr'
            sSymbol = 'symb={0}'.format(symbol)
            sParms = [sSymbol, sParmAcNo, 'ScDetail=*', 'table=TwsSfDetail']
            self.__querySeqID += 1
            workid = 'qid{0}'.format(self.__querySeqID)
            self.__prodmap[workid] = symbol
            self.__accmap[workid] = tradingAccount
            self.__sendSorRequest(workid, sTaskID, sParms, SorReqType.ProdCrQty)
        else:
            self._trader.OnError(MTPYError(RCode.ACCOUNT_NOT_FOUND, f'Account Not Found Error: tradingAccount={tradingAccount}'))
        return workid  

    def QryProdDbQty_Rayin(self, tradingAccount: str, symbol:str) -> str:
        """查詢券配額"""
        if len(tradingAccount) < 7:
                tradingAccount = tradingAccount.zfill(7)
        acc = self.__getTradingAccount(tradingAccount)
        if acc:
            sParmAcNo = 'acno={0}-{1}'.format(acc.BrkNo(), acc.IvacNo())
            sTaskID = 'RayDisp.KL.sor.symb.db'
            sSymbol = 'symb={0}'.format(symbol)
            sParms = [sSymbol, sParmAcNo, 'ScDetail=*', 'table=TwsSfDetail']
            self.__querySeqID += 1
            workid = 'qid{0}'.format(self.__querySeqID)
            self.__prodmap[workid] = symbol
            self.__accmap[workid] = tradingAccount
            self.__sendSorRequest(workid, sTaskID, sParms, SorReqType.ProdDbQty)
        else:
            self._trader.OnError(MTPYError(RCode.ACCOUNT_NOT_FOUND, f'Account Not Found Error: tradingAccount={tradingAccount}'))
        return workid
    

    def ReqInventoryOpen(self, tradingAccount: str) -> str:
        """期初庫存"""
        if len(tradingAccount) < 7:
                tradingAccount = tradingAccount.zfill(7)
        acc = self.__getTradingAccount(tradingAccount)
        if acc:
            sParmAcNo = 'acno={0}-{1}'.format(acc.BrkNo(), acc.IvacNo())
            sTaskID = 'RayDisp.KL.sor.ivac'            
            sParms = [sParmAcNo, 'ScDetail=*', 'table=TwsIvacMatch']
            self.__querySeqID += 1
            workid = 'qid{0}'.format(self.__querySeqID)
            self.__sendSorRequest(workid, sTaskID, sParms, SorReqType.INVENTORY_S)
        else:
            self._trader.OnError(MTPYError(RCode.ACCOUNT_NOT_FOUND, f'Account Not Found Error: tradingAccount={tradingAccount}'))
        return workid
    
    def ReqInventory_Ori(self, tradingAccount: str) -> str:
        if len(tradingAccount) < 7:
                tradingAccount = tradingAccount.zfill(7)
        acc = self.__getTradingAccount(tradingAccount)
        if acc:
            sParmAcNo = 'acno={0}-{1}'.format(acc.BrkNo(), acc.IvacNo())
            sTaskID = 'KL.sor.ivac'
            sParms = [sParmAcNo, 'ScDetail=*', 'table=TwsIvacStkBal']
            self.__querySeqID += 1
            workid = 'qid{0}'.format(self.__querySeqID)
            self.__sendSorRequest(workid, sTaskID, sParms, SorReqType.INVENTORY)
        else:
            self._trader.OnError(MTPYError(RCode.ACCOUNT_NOT_FOUND, f'Account Not Found Error: tradingAccount={tradingAccount}'))
        return workid
    
    def ReqInventoryRayinTotal(self, tradingAccount: str) -> str:
        """庫存"""
        if len(tradingAccount) < 7:
                tradingAccount = tradingAccount.zfill(7)
        acc = self.__getTradingAccount(tradingAccount)
        if acc:
            sParmAcNo = 'acno={0}-{1}'.format(acc.BrkNo(), acc.IvacNo())
            sTaskID = 'RayDisp.KL.sor.ivac'
            sParms = [sParmAcNo, 'ScDetail=*', 'table=TwsIvacMatch']
            self.__querySeqID += 1
            workid = 'qid{0}'.format(self.__querySeqID)
            self.__sendSorRequest(workid, sTaskID, sParms, SorReqType.INVENTORY)
        else:
            self._trader.OnError(MTPYError(RCode.ACCOUNT_NOT_FOUND, f'Account Not Found Error: tradingAccount={tradingAccount}'))
        return workid

    def ReqInventoryRayin_Ori(self, tradingAccount: str) -> str:
        if len(tradingAccount) < 7:
                tradingAccount = tradingAccount.zfill(7)
        acc = self.__getTradingAccount(tradingAccount)
        if acc:
            sParmAcNo = 'acno={0}-{1}'.format(acc.BrkNo(), acc.IvacNo())
            sTaskID = 'sor.ivac'
            sParms = [sParmAcNo, 'ScDetail=*', 'table=RayinSubacBal']
            self.__querySeqID += 1
            workid = 'qid{0}'.format(self.__querySeqID)
            self.__sendSorRequest(workid, sTaskID, sParms, SorReqType.INVENTORY)
        else:
            self._trader.OnError(MTPYError(RCode.ACCOUNT_NOT_FOUND, f'Account Not Found Error: tradingAccount={tradingAccount}'))
        return workid
    
    def ReqInventory(self, brkNo: str, tradingAccount: str) -> str:
        sParmAcNo = 'acno={0}-{1}'.format(brkNo, tradingAccount)
        sTaskID = 'RayDisp.KL.sor.ivac'
        sParms = [sParmAcNo, 'ScDetail=*', 'table=TwsIvacStkBal']
        self.__querySeqID += 1
        workid = 'qid{0}'.format(self.__querySeqID)
        self.__sendSorRequest(workid, sTaskID, sParms, SorReqType.INVENTORY)
        
    def ReqBasic(self, symbol: str) -> str:
        log.info(f"api.ReqBasic: symbol={symbol}")
        sTaskID = 'KL.sor.symb'
        sParms = [f'symb={symbol}','table=TwsSymbol']
        self.__querySeqID += 1
        workid = 'qid{0}'.format(self.__querySeqID)
        self.__sendSorRequest(workid, sTaskID, sParms, SorReqType.BASIC)
        return workid
                          
    def IsReady(self) -> bool:
        return self.sorapi.ApReady()
    
    def __sendSorRequest(self, workid: str, sTaskID, sParms, type: SorReqType):      
        SOH = '\x01'
        self.__qidmap[workid] = type
        reqstr = "{1}{0}{2}{0}{3}".format(SOH, workid, sTaskID, '\x01'.join(sParms))
        result = self.sorapi.SendSorRequest(0x80, '-----' + reqstr)
        log.info('...Sent and wait!')
        if result == None:
            log.info("送出 0x80 Request {0}".format(workid))
        else:
            log.info("查詢傳送失敗(可能原因:流量管制或斷線) {0}".format(reqstr))
        
    def __sendCmd(self, tableType: str, cmdR: str, argMap: Map, tradingAccount: str) -> RCode:
        for acc in self.tradeAccs.Values():
            if (acc.CAErrCode() == CAErrCode.ERR_Success 
                and bin(acc.MktFlag() & SorMktFlags.TwStk.value) != '0b0'
                and acc.IvacNo() == tradingAccount):
                self.sorapi.SendRequest(tableType, cmdR, argMap, acc)
                return RCode.OK
            
        return RCode.FAIL
    
    def __getTradingAccount(self, tradingAccount: str):
        for acc in self.tradeAccs.Values():
            if(acc.CAErrCode() == CAErrCode.ERR_Success):
                if (bin(acc.MktFlag() & SorMktFlags.TwStk.value) != '0b0'
                    and acc.IvacNo() == tradingAccount):
                    return acc
            else:
                self._trader.OnError(MTPYError(RCode.ACCOUNT_CA_ERROR, f'CA Error: tradingAccount={tradingAccount}'))
                break
        return None
    
    def __newOrder(self, trading_session: TradingSession, side: Side, symbol: str, price_type: PriceType,
                 price: float, qty: str, orderType: OrderType, userDef: str, tradingAccount) -> RCode:
        if tradingAccount == None:
            return RCode.ACCOUNT_NOT_FOUND
            
        table_type = 'REQ'
        cmdR = 'TwsNew'
  
        argMap = Map()
        argMap.Set('Src', Src.API.encode(self.sorapi.Codeing))
        argMap.Set('SegMkt', trading_session.encode(self.sorapi.Codeing))
        argMap.Set('BrkNo', tradingAccount.BrkNo().encode(self.sorapi.Codeing))
        argMap.Set('IvacNo', tradingAccount.IvacNo().encode(self.sorapi.Codeing))
        argMap.Set('Side', side.encode(self.sorapi.Codeing))
        argMap.Set('Symbol', symbol.encode(self.sorapi.Codeing))
        argMap.Set('PriType', price_type.encode(self.sorapi.Codeing))
        argMap.Set('Price', price.encode(self.sorapi.Codeing))
        argMap.Set('TIF', orderType.encode(self.sorapi.Codeing))
        argMap.Set('Qty', qty.encode(self.sorapi.Codeing))
        argMap.Set('OType', TradingType.CUSTODY.encode(self.sorapi.Codeing))
        argMap.Set('UsrDef', userDef.encode(self.sorapi.Codeing)) 
        # argMap.Set('FromUID', ''.encode(self.sorapi.Codeing))
        # argMap.Set('DigSgn', ''.encode(self.sorapi.Codeing))
           
        self.sorapi.SendRequest(table_type, cmdR, argMap, tradingAccount)
        return RCode.OK
        
    def CheckAcc(self, tradingAccount: str) -> RCode:
        table_type = 'REQ'
        cmdR = 'CACHKNew'
        argMap = Map()
        
        acc = self.__getTradingAccount(tradingAccount)
        if acc == None:
            return RCode.ACCOUNT_NOT_FOUND
        argMap.Set('BrkNo', acc.BrkNo().encode(self.sorapi.Codeing))
        argMap.Set('IvacNo', acc.IvacNo().encode(self.sorapi.Codeing))
        self.sorapi.SendRequest(table_type, cmdR, argMap, acc)
        return RCode.OK
    
    def CheckAccs(self, tradingAccounts: typing.List[str]) -> RCode:
        ret = RCode.OK
        for account in tradingAccounts:
            ret = self.CheckAcc(account)
            if(ret != RCode.OK):
                return ret
        return RCode.OK
                               
    def NewOrder(self, o: Order) -> RCode:
        if len(o.tradingAccount) < 7:
                o.tradingAccount = o.tradingAccount.zfill(7)
        return self.__newOrder(o.tradingSession, o.side, o.symbol, o.priceType, o.price, o.qty, o.orderType, o.userDef,
                               self.__getTradingAccount(o.tradingAccount))
                        
    def __chgOrderQty(self, ordNo: str, qty: str, tradingAccount) -> RCode:
        if tradingAccount == None:
            return RCode.ACCOUNT_NOT_FOUND
        
        table_type = 'REQ'
        cmdR = 'TwsChgQty'
  
        argMap = Map()
        ordID = f'{tradingAccount.BrkNo()}-{ordNo}'
        argMap.Set('OrdID', ordID.encode(self.sorapi.Codeing))
        argMap.Set('Src', Src.API.encode(self.sorapi.Codeing))
        argMap.Set('Qty', qty.encode(self.sorapi.Codeing))
        # argMap.Set('FromUID', ''.encode(self.sorapi.Codeing))
        # argMap.Set('DigSgn', ''.encode(self.sorapi.Codeing))
        self.sorapi.SendRequest(table_type, cmdR, argMap, tradingAccount)
        return RCode.OK
    
    def __chgOrderPrice(self, ordNo: str, price: str, tradingAccount) -> RCode:
        if tradingAccount == None:
            return RCode.ACCOUNT_NOT_FOUND
        
        table_type = 'REQ'
        cmdR = 'TwsChgPri'
  
        argMap = Map()
        ordID = f'{tradingAccount.BrkNo()}-{ordNo}'
        argMap.Set('OrdID', ordID.encode(self.sorapi.Codeing))
        argMap.Set('Src', Src.API.encode(self.sorapi.Codeing))
        argMap.Set('Price', price.encode(self.sorapi.Codeing))
        # argMap.Set('FromUID', ''.encode(self.sorapi.Codeing))
        # argMap.Set('DigSgn', ''.encode(self.sorapi.Codeing))
        self.sorapi.SendRequest(table_type, cmdR, argMap, tradingAccount)
        return RCode.OK
    
    def ChangeOrderQty(self, o: OrderQtyChange) -> RCode:
        if len(o.tradingAccount) < 7:
                o.tradingAccount = o.tradingAccount.zfill(7)
        return self.__chgOrderQty(o.ordNo, o.qty, self.__getTradingAccount(o.tradingAccount))
              
    def ChangeOrderPrice(self, o: OrderPriceChange) -> RCode:
        if len(o.tradingAccount) < 7:
                o.tradingAccount = o.tradingAccount.zfill(7)
        return self.__chgOrderPrice(o.ordNo, o.price, self.__getTradingAccount(o.tradingAccount))
    
    def OnSorConnect(self, sorapi, args):
        msg = args.Get('errmsg')
        if msg:
            log.info(f'[OnSorConnectEvent]{msg}')
            self._trader.OnSystemEvent(SystemEvent(RCode.FAIL, msg))
        return
    
    def CheckResult(self) -> typing.Dict[str, Order]:
        workID = self.args.Get('WorkID')
        type = self.__qidmap[workID]
        log.info(f"[OnSorTaskResult]TableCount={self.args.Get('TableCount')}, wid={self.args.Get('WorkID')}, type={type}")     
        origResults = self.args.Get('OrigResult').split(self.sorapi.LF)
        resultList = list()
        rowCount = 0
        for idx, o in enumerate(origResults):
            if idx >= 1:
                result = '{0}'.format(o.decode(self.sorapi.Codeing).replace('\x01', '|'))
                log.info(f'[OnSorTaskResult]{result}')
                if result.find("rowCount") != -1:
                    rowCount = int(result[result.index('=')+1:])

                resultList.append(result)
                
        if rowCount == 0:
            self._trader.OnReqResult(workID, "No Data(CheckResult)")
            return
        
        if type == SorReqType.BASIC:
            log.info("[OnSorTaskResult]Basic Data-----")
            reqResults = ReqResults(workID, resultList)
            for idx in range(reqResults.rowCount):
                symbol = reqResults.GetData(idx + 1, BasicReqResult.StkNo)
                name = reqResults.GetData(idx + 1, BasicReqResult.Name)
                ref = reqResults.GetData(idx + 1, BasicReqResult.PriRef)
                riseStop = reqResults.GetData(idx + 1, BasicReqResult.PriUpLmt)
                fallStop = reqResults.GetData(idx + 1, BasicReqResult.PriDnLmt)
                basic = Basic(symbol, name, ref, riseStop, fallStop)
                self._trader.OnReqResult(basic)
                log.info(basic)
                self.__basic[symbol] = basic
            log.info("[OnSorTaskResult]-----Basic Data")
        elif type == SorReqType.INVENTORY:
            log.info("[OnSorTaskResult]Inventory Data-----")
            reqResults = ReqResults(workID, resultList)
            for idx in range(reqResults.rowCount):
                symbol = reqResults.GetData(idx + 1, InventoryReqResult.stock_no)
                qty = reqResults.GetData(idx + 1, InventoryReqResult.qtycn)
                qtycr = reqResults.GetData(idx + 1, InventoryReqResult.qtycr)
                qtydb = reqResults.GetData(idx + 1, InventoryReqResult.qtydb)
                qtyzr = reqResults.GetData(idx + 1, InventoryReqResult.qtyzero)
                inventory = Inventory(symbol, qty, qtycr, qtydb, qtyzr)
                self._trader.OnReqResult(workID, inventory)
                log.info(inventory)
                self.__inventory[symbol] = inventory
            log.info("[OnSorTaskResult]-----Inventory Data")
        else:
            log.error("[OnSorTaskResult]Unknown Result")
            return
            
    def OnSorApReady(self, sorapi, args):
        log.info("[OnSorApReady]Retrieving Trading accounts...")
        #取出可用帳號 & 載入簽章憑證.
        sgnact = 0
        if args.Get('head') != None:
            tableHead = args.Get('head')
            idxSgn = tableHead.GetFieldIndex('sgnact')
            if (idxSgn):
                data = tableHead.RecordData[0].split('\x01')
                sgnact = int(data[idxSgn])
        if args.Get('Accs') != None:
            tableAccs = args.Get('Accs')
            from .pySsoSorApi import pySorApi
            self.tradeAccs.SorTableParser(tableAccs, f'{os.path.dirname(os.path.abspath(pySorApi.__file__))}\\SorApiCA.dll', sgnact)
            for acc in self.tradeAccs.Values():
                if (acc.CAErrCode() != CAErrCode.ERR_Success):   #驗憑證
                    log.info('[OnSorApReady]{} CA Error: {}'.format(acc.Key(), acc.CAErrCode()))

                if (bin(acc.MktFlag() & SorMktFlags.TwStk.value) != '0b0'):
                    log.info('[OnSorApReady]TWSE tradingAccount={}'.format(acc.IvacNo()))
                
            #   取出流量管制參數.
            Rate = 0
            RateMS = 0
            if args.Get('FlowCtrl') != None:
                tableFlowCtrl = args.Get('FlowCtrl')
                idxRate = tableFlowCtrl.GetFieldIndex('ORate')
                idxRateMS = tableFlowCtrl.GetFieldIndex('ORateMS')
                if (idxRate != None and idxRateMS != None):
                    data = tableFlowCtrl.RecordData[0].split('\x01')
                    if (len(data) > 0):
                        Rate = int(data[idxRate])
                        RateMS = int(data[idxRateMS])
                        self.sorapi.SorFlowCtrlSender_.SetFlowCtrl(Rate, RateMS)
                if (Rate <=0 or RateMS <=0):
                    log.info('[OnSorApReady]No FlowCtrl Parameter')
                else:
                    if (RateMS >= 1000):
                        p1 = RateMS / 1000.0
                        p2 = 'second'
                    else:
                        p1 = RateMS
                        p2 = 'ms'
                    log.info('[OnSorApReady]FlowCtrl Parameter: {} lot / {} {}'.format(Rate, p1, p2))

            args.Get('sender').RecoverAll() #   回補全部
            return
      
    def OnSorRequestAck(self, sorapi, args):
        msgCode = args.Get('msgCode')
        result = args.Get('result').split('\x01')
        log.info('[OnSorRequestAck]msgCode={0};result={1}'.format(msgCode,result))

        self.sorapi.SorFlowCtrlSender_.AckParser(msgCode, args.Get('result'))
        log.info('[OnSorRequestAck]Pending Count: {}'.format(self.sorapi.SorFlowCtrlSender_.PendingCount()))
        return
    
    def OnSorTaskResult(self, sorapi, args):
        self.args = args
        workID = args.Get('WorkID')
        type = self.__qidmap[workID]
        log.info(f"[OnSorTaskResult]TableCount={args.Get('TableCount')}, wid={args.Get('WorkID')}, type={type}")         
        origResults = args.Get('OrigResult').split(sorapi.LF)        
        resultList = list()
        rowCount = 0
        for idx, o in enumerate(origResults):
            if idx >= 1:
                result = '{0}'.format(o.decode(self.sorapi.Codeing).replace('\x01', '|'))                
                # print(f"result:{result}")
                log.info(f'[OnSorTaskResult]{result}')
                if result.find("rowCount") != -1:
                    rowCount = int(result[result.index('=')+1:])

                resultList.append(result)
                
        if rowCount == 0:
            self._trader.OnReqResult(workID, "No Data(OnSorTaskResult)")
            return

        if type == SorReqType.BASIC:
            log.info("[OnSorTaskResult]Basic Data-----")
            reqResults = ReqResults(workID, resultList)
            for idx in range(reqResults.rowCount):
                symbol = reqResults.GetData(idx + 1, BasicReqResult.StkNo)
                name = reqResults.GetData(idx + 1, BasicReqResult.Name)
                ref = reqResults.GetData(idx + 1, BasicReqResult.PriRef)
                riseStop = reqResults.GetData(idx + 1, BasicReqResult.PriUpLmt)
                fallStop = reqResults.GetData(idx + 1, BasicReqResult.PriDnLmt)
                basic = Basic(symbol, name, ref, riseStop, fallStop)
                if self.__crQtyAndDbQty.get(symbol):
                #region 資券配額
                    isBelowRefSBL = reqResults.GetData(idx + 1, BasicReqResult.IsBelowRefSBL)#平盤下是否可下券(Y/N)
                    dtMark = reqResults.GetData(idx + 1, BasicReqResult.DTMark)#X=可現股當沖;Y=僅可先買後賣沖;其他為不可現股當沖
                    ret_CrQtyAndDbQty = self.__crQtyAndDbQty[symbol]
                    ret_CrQtyAndDbQty.CanShortUnderUnchanged = isBelowRefSBL
                    ret_CrQtyAndDbQty.DayTrade = dtMark
                    if dtMark == "X":
                        ret_CrQtyAndDbQty.DayTradeCName = "可現股當沖"
                    elif dtMark == "Y":
                        ret_CrQtyAndDbQty.DayTradeCName = "僅可先買後賣沖"
                    else:
                        ret_CrQtyAndDbQty.DayTradeCName = "不可現股當沖"
                    retCrDb = ""
                    retCr = retDb = "0"
                    bStop = False
                    if ret_CrQtyAndDbQty.crflag == "Y":
                        retCrDb += "無信用交易資格"
                    else:
                        retCrDb +=""
                        #是否停資、融資配額股數
                        if ret_CrQtyAndDbQty.IsCrStop == "Y":  #停資
                            bStop = True                          
                            retCr = "停資" if ret_CrQtyAndDbQty.CrQty == "" else ret_CrQtyAndDbQty.CrQty
                        else:#不停資
                            if '限' in ret_CrQtyAndDbQty.s_crQty:
                                retCr = ret_CrQtyAndDbQty.s_crQty
                            else:
                                try:
                                    retCr = str(Decimal(ret_CrQtyAndDbQty.s_crQty))
                                except:
                                    retCr = "0"
                        #是否停券、融券配額股數
                        if ret_CrQtyAndDbQty.IsDbStop == "Y":#停券
                            bStop = True
                            retDb = "停券" if ret_CrQtyAndDbQty.DbQty == "" else ret_CrQtyAndDbQty.DbQty   
                        else:#不停券
                            if '限' in ret_CrQtyAndDbQty.s_dbQty:
                                retDb = ret_CrQtyAndDbQty.s_dbQty
                            else:
                                try:
                                    retDb = str(Decimal(ret_CrQtyAndDbQty.s_dbQty))
                                except:
                                    retDb = "0"
                        #處理資券乘數:資60/券90
                        if bStop == False:
                            try:
                                retCrDb += "資{0:.0f}".format(Decimal(ret_CrQtyAndDbQty.CrRate)*100)
                            except:
                                pass
                            try:
                                retCrDb += "/券{0:.0f}".format(Decimal(ret_CrQtyAndDbQty.DbRate)*100)
                            except:
                                pass
                        if ret_CrQtyAndDbQty.lumsg != "":#平盤下可券
                            # print(f"ret_CrQtyAndDbQty.lumsg{ret_CrQtyAndDbQty.lumsg}")
                            retCrDb += (" " + ret_CrQtyAndDbQty.lumsg)                        
                        if ret_CrQtyAndDbQty.dtemsg != "":#平盤下可券
                            # print(f"ret_CrQtyAndDbQty.dtemsg{ret_CrQtyAndDbQty.dtemsg}")
                            retCrDb += (" " + ret_CrQtyAndDbQty.dtemsg)
                    ret_CrQtyAndDbQty.result = "{0};{1};{2}".format(retCr, retDb, retCrDb)
                    self._trader.OnReqResult(workID, ret_CrQtyAndDbQty)
                    self.__crQtyAndDbQty[symbol] = None
                #endregion 資券配額    
                else:
                    self._trader.OnReqResult(workID, basic)
                log.info(basic)
                self.__basic[symbol] = basic
            log.info("[OnSorTaskResult]-----Basic Data")
        elif type == SorReqType.INVENTORY_S:
            log.info("[OnSorTaskResult]Inventory_S Data-----")
            reqResults = ReqResults(workID, resultList)
            for idx in range(reqResults.rowCount):
                symbol = reqResults.GetData(idx + 1, InventoryReqResult.stock_no)
                qty = reqResults.GetData(idx + 1, InventoryReqResult.qtycn)
                qtycr = reqResults.GetData(idx + 1, InventoryReqResult.qtycr)
                qtydb = reqResults.GetData(idx + 1, InventoryReqResult.qtydb)
                qtyzr = reqResults.GetData(idx + 1, InventoryReqResult.qtyzero)
                inventory_s = Inventory_S(symbol, qty, qtycr, qtydb, qtyzr)
                self._trader.OnReqResult(workID, inventory_s)
                log.info(inventory_s)
                self.__inventory_s[symbol] = inventory_s
            log.info("[OnSorTaskResult]-----Inventory_S Data")    
        elif type == SorReqType.INVENTORY:
            log.info("[OnSorTaskResult]Inventory Data-----")
            reqResults = ReqResults(workID, resultList)
            for idx in range(reqResults.rowCount):
                symbol = reqResults.GetData(idx + 1, InventoryReqResult.stock_no)
                qty = reqResults.GetData(idx + 1, InventoryReqResult.qtycnn)
                qtycr = reqResults.GetData(idx + 1, InventoryReqResult.qtycrn)
                qtydb = reqResults.GetData(idx + 1, InventoryReqResult.qtydbn)
                qtyzr = reqResults.GetData(idx + 1, InventoryReqResult.qtyap5n)
                inventory = Inventory(symbol, qty, qtycr, qtydb, qtyzr)
                self._trader.OnReqResult(workID, inventory)
                log.info(inventory)
                self.__inventory[symbol] = inventory
            log.info("[OnSorTaskResult]-----Inventory Data")
        elif type == SorReqType.SecInvQty:            
            log.info("[OnSorTaskResult]SecInvQty Data-----")
            reqResults = ReqResults(workID, resultList)            
            for idx in range(reqResults.rowCount):                               
                symbol = reqResults.GetData(idx + 1, SecInvQtyResult.symbol)
                secInvQty = reqResults.GetData(idx + 1, SecInvQtyResult.secInvQty)
                usedQty = reqResults.GetData(idx + 1, SecInvQtyResult.usedQty)
                isecInvQty = int(secInvQty)*1000
                iusedQty = int(usedQty) *1000
                
                ret_secInvQty = SecInvQty(symbol, isecInvQty, iusedQty)                
                self._trader.OnReqResult(workID, ret_secInvQty)
                log.info(ret_secInvQty)
                self.__secInvQty[symbol] = ret_secInvQty
            log.info("[OnSorTaskResult]-----SecInvQty Data")
        elif type == SorReqType.ProdCrQty:            
            log.info("[OnSorTaskResult]ProdCrQty Data-----")
            reqResults = ReqResults(workID, resultList)                   
            symbol = self.__prodmap[workID]
            for idx in range(reqResults.rowCount):                
                isCrStop = reqResults.GetData(idx + 1, CrQtyAndDbQtyResult.IsCrStop)#是否停資(Y/N)
                crQty = "0"
                s_crQty = ""
                if isCrStop == "Y":
                    crQty = ""   
                else:
                    s_crQty = reqResults.GetData(idx + 1, CrQtyAndDbQtyResult.CrQty)#融資配額股數
                    if '不限' in s_crQty:
                        crQty = "999999000"#給這個值, 前端APP得以顯示"不限資"
                    elif ' 限' in s_crQty:
                        crQty = "99999900" #給小於999999000值, 前端APP得以顯示"限資"
                    else:
                        try:
                            crQty = str(Decimal(s_crQty) * 1000)#雷影傳回張數, 將值乘1000, 因為APP會除1000
                        except Exception as ex:
                            crQty = "0" #給這個值, 前端APP得以顯示"資0"                    
                #資成數
                crRate = "0"
                s_crRate = reqResults.GetData(idx + 1, CrQtyAndDbQtyResult.CrRate)
                try:
                    crRate = str(Decimal(s_crRate) / 1000)#雷影傳回張數, 將值乘1000, 因為APP會除1000
                except Exception as ex:
                    crRate = "0" #給這個值, 前端APP得以顯示"資0"   
                crflag = reqResults.GetData(idx + 1, CrQtyAndDbQtyResult.crflag)#信用交易資格           
                ret_CrQtyAndDbQty = CrQtyAndDbQty(symbol, isCrStop, crQty,s_crQty, "", "", "", crRate, "", "", "","",crflag,"","","")                
                log.info(ret_CrQtyAndDbQty)
                self.__crQtyAndDbQty[symbol] = ret_CrQtyAndDbQty
                self.QryProdDbQty_Rayin(self.__accmap[workID], symbol) #在查券
                # print(f"cr self.__crQtyAndDbQty[symbol]:{self.__crQtyAndDbQty[symbol]}")                
            log.info("[OnSorTaskResult]-----ProdCrQty Data")
            
        elif type == SorReqType.ProdDbQty:            
            log.info("[OnSorTaskResult]ProdDbQty Data-----")
            reqResults = ReqResults(workID, resultList)                        
            for idx in range(reqResults.rowCount):
                symbol = self.__prodmap[workID]                 
                isDbStop = reqResults.GetData(idx + 1, CrQtyAndDbQtyResult.IsDbStop)#是否停券(Y/N)
                dbQty = "0"
                s_dbQty = ""
                if isDbStop == "Y":
                    dbQty = ""   
                else:
                    s_dbQty = reqResults.GetData(idx + 1, CrQtyAndDbQtyResult.DbQty)#融券配額股數
                    if '不限' in s_dbQty:
                        dbQty = "999999000"#給這個值, 前端APP得以顯示"不限券"
                    elif ' 限' in s_dbQty:
                        dbQty = "99999900" #給小於999999000值, 前端APP得以顯示"限券"
                    else:
                        try:
                            dbQty = str(Decimal(s_dbQty) * 1000)#雷影傳回張數, 將值乘1000, 因為APP會除1000
                        except Exception as ex:
                            dbQty = "0" #給這個值, 前端APP得以顯示"券0"
                #券成數
                dbRate = "0"
                s_dbRate = reqResults.GetData(idx + 1, CrQtyAndDbQtyResult.DbRate)
                try:
                    dbRate = str(Decimal(s_dbRate) / 1000)#雷影傳回張數, 將值乘1000, 因為APP會除1000
                except Exception as ex:
                    dbRate = "0" #給這個值, 前端APP得以顯示"券0"   
                lumsg = reqResults.GetData(idx + 1, CrQtyAndDbQtyResult.lumsg)#平盤下可券
                dtemsg = reqResults.GetData(idx + 1, CrQtyAndDbQtyResult.dtemsg)#可當沖

                if self.__crQtyAndDbQty.get(symbol):
                    ret_CrQtyAndDbQty = self.__crQtyAndDbQty[symbol]
                    ret_CrQtyAndDbQty.IsDbStop = isDbStop
                    ret_CrQtyAndDbQty.DbQty = dbQty
                    ret_CrQtyAndDbQty.s_dbQty = s_dbQty                    
                    ret_CrQtyAndDbQty.DbRate = dbRate
                    ret_CrQtyAndDbQty.s_dbRate = s_dbRate
                    ret_CrQtyAndDbQty.lumsg = lumsg
                    ret_CrQtyAndDbQty.dtemsg = dtemsg
                    
                    log.info(ret_CrQtyAndDbQty)
                    self.__crQtyAndDbQty[symbol] = ret_CrQtyAndDbQty
                    self.ReqBasic(symbol)#再查商品資訊                    
                    # print(f"db self.__crQtyAndDbQty[symbol]:{self.__crQtyAndDbQty[symbol]}")
                else:
                    log.info("[OnSorTaskResult]no ProdDbQty data")
            log.info("[OnSorTaskResult]-----ProdDbQty Data")        
        else:
            log.error("[OnSorTaskResult]Unknown Result")
            return
    
    def OnSorReport(self, sorapi, args):
        self.args = args
        log.info("[OnSorReport]Processing start...")     
        argList = self.sorapi.ParseSorReport(args.Get('result'))
        for r in argList:            
            key = r.Get('OrgSorRID')
            if key:
                tb = r.Get('Table')
                tbname = tb.GetName()                
                order = Order(tradingSession=r.Get('SegMkt'), 
                    side=r.Get('Side'), 
                    symbol=r.Get('Symbol'), 
                    priceType=r.Get('PriType'), 
                    price=r.Get('Pri'), 
                    qty=r.Get('OrgQty'), 
                    orderType=r.Get('TIF'), 
                    userDef = r.Get('OrgUsrDef'),
                    tradingAccount=r.Get('IvacNo'))
                if len(order.tradingAccount) < 7:
                    order.tradingAccount = order.tradingAccount.zfill(7)
                order.ordNo = r.Get('OrdNo')
                order.leavesQty = r.Get('LeavesQty')
                #+++
                order.cumQty = r.Get('CumQty')
                order.status = r.Get('OrderSt')
                order.status = f"{order.status}){self.getStatusMap(order.status)}"
                dlPri = r.Get('DealPri')
                if dlPri:
                    order.dealPri = dlPri
                order.tableName = tbname
                #+++
                order.trxTime = Helper.formatExchangeTime(r.Get('TrxHHMMSSsss'))
                order.lastdealTime = Helper.formatExchangeTime(r.Get('LastDealHHMMSSsss'))
                
                orgOrder = Order(tradingSession=r.Get('SegMkt'), 
                    side=r.Get('Side'), 
                    symbol=r.Get('Symbol'), 
                    priceType=r.Get('OrgPriType'), 
                    price=r.Get('OrgPri'), 
                    qty=r.Get('OrgQty'), 
                    orderType=r.Get('OrgTIF'), 
                    tradingAccount=r.Get('IvacNo'),
                    userDef=r.Get('OrgUsrDef'))
                if len(orgOrder.tradingAccount) < 7:
                    orgOrder.tradingAccount = orgOrder.tradingAccount.zfill(7)
                orgOrder.sorRID = r.Get('OrgSorRID')
                reportOrder = ReportOrder(orgOrder, order)
                reportOrder.scBalance = r.Get('ScBalance')
                reportOrder.lastMessage = r.Get('LastMessage')
                if isinstance(reportOrder.lastMessage, bytes):
                    reportOrder.lastMessage = reportOrder.lastMessage.decode(self.sorapi.Codeing)    #   轉為繁中
                self.orderReportDict[key] = reportOrder
                self._trader.OnReport(reportOrder)
            
        log.info(f"[OnSorReport]Processing finished. total report count:{len(self.orderReportDict)}")
        return
    def getStatusMap(self, status:str):
        
        if status == '0':# TReqStep_Pending ='0'               #委託要求處理中
            return "委託要求處理中"
        elif status == '3': #TReqStep_BackConfirm = '3'          #本機委託要求退回給使用者(或營業主管)確定or強迫
            return "本機委託要求退回給使用者(或營業主管)確定or強迫"
        elif status == '5':#TReqStep_Queuing = '5'              #本機委託要求排隊中
            return "本機委託要求排隊中"
        elif status == '6':#TReqStep_Sending = '6'              #本機委託要求傳送中
            return "本機委託要求傳送中"
        elif status == '7':#TReqStep_Sent = '7'                 #本機委託要求已送出(等回報)
            return "本機委託要求已送出(等回報)"
        elif status == '88':#TReqStep_PartReject = '88'          #部份結束(失敗):例如:收到報價單的Bid失敗,Offer尚未回覆
            return "部份結束(失敗):例如:收到報價單的Bid失敗,Offer尚未回覆"
        elif status == '89':#TReqStep_PartFinish = '89'          #部份結束:例如收到報價單的其中一邊,還缺另一邊
            return "部份結束:例如收到報價單的其中一邊,還缺另一邊"
        elif status == '90':#TReqStep_Finished = '90'            #委託要求已結束
            return "委託要求已結束"
        elif status == '91':#TReqStep_DupFinished = '91'         #重複的[結束]回報,例如:報價單,先收到Bid成交,再收到Offer成功,此時Offer成功的回報就是TReqStep_DupFinished
            return "重複的[結束]回報,例如:報價單,先收到Bid成交,再收到Offer成功,此時Offer成功的回報就是TReqStep_DupFinished"
        elif status == '95':#TReqStep_UnknownFail = '95'         #委託要求狀態不明(例如:送出後斷線)
            return "委託要求狀態不明(例如:送出後斷線)"
        elif status == '99':#TReqStep_Reject = '99'              #委託要求拒絕
            return "委託要求拒絕"
        elif status == '100':#TReqStep_RptSuggestNew = '100'      #先收到成交回報,所建立的新單(遺漏正常新單回報)
            return "先收到成交回報,所建立的新單(遺漏正常新單回報)"
        elif status == '110':#TReqStep_RptPartFilled = '110'      #配合 TReqKind_RptFilled: 部份成交
            return "部份成交"
        elif status == '111':#TReqStep_RptFullFilled = '111'      #配合 TReqKind_RptFilled: 全部成交
            return "全部成交"
        elif status == '120':#TReqStep_RptExchgKilled = '120'     #委託因IOC/FOK未成交而取消
            return "委託因IOC/FOK未成交而取消"
        #TOrderSt_NewPending = TReqStep_Pending             #尚未處理
        # TOrderSt_Force = TReqStep_BackConfirm              #新單要求退回給使用者(或營業主管)確定or強迫
        # TOrderSt_NewQueuing = TReqStep_Queuing             #新單排隊中
        # TOrderSt_NewSending = TReqStep_Sending             #新單傳送中
        # TOrderSt_Sent = TReqStep_Sent                      #新單已送出(等回報)
        elif status == '81':#TOrderSt_InternalCanceling ='81'                   #內部刪除 [其他主機 NewQueuing] 的委託.
            return "內部刪除 [其他主機 NewQueuing] 的委託"
        elif status == '91':#TOrderSt_InternalCanceled ='91'                    #新單尚未送出就被刪單
            return "新單尚未送出就被刪單"
        # TOrderSt_NewUnknownFail = TReqStep_UnknownFail     #新單要求狀態不明(例如:送出後斷線)
        # TOrderSt_NewReject = TReqStep_Reject               #新單要求拒絕
        elif status == '101':#TOrderSt_Accepted = '101'                          #委託已接受(交易所已接受)
            return "委託已接受(交易所已接受)"
        # TOrderSt_PartFilled = TReqStep_RptPartFilled       #部份成交
        # TOrderSt_FullFilled = TReqStep_RptFullFilled       #全部成交
        # TOrderSt_IOCFOKNotFilled = TReqStep_RptExchgKilled #一般:委託因IOC/FOK未成交而取消.報價:時間到自動刪單,有新報價舊報價自動刪單.
        # TOrderSt_ExchgKilled = TOrderSt_IOCFOKNotFilled
        else:
            return ""

    def __Handle_Reveice_Msg(self, msg: 'InboundMessage'):    
        if msg.get_payload_as_bytes() == None:
            log.error(f"QuoteHandler.OnMessage Exception Null Data, topic:{msg.get_destination_name()}")
            sysevt = SystemEvent(code=RCode.FAIL, message=f"QuoteHandler.OnMessage Exception: Null Data, topic:{msg.get_destination_name()}")
            self._trader.OnSystemEvent(sysevt)
            return
        message:str = msg.get_payload_as_bytes().decode('utf-8')
        topic:str = msg.get_destination_name()
        # message_type=message.get_cache_status()
        # if message_type.value ==  message_type.LIVE.value:#CacheStatus.LIVE:
        #     print("1.LIVE.")
        # elif message_type.value == message_type.CACHED.value:#CacheStatus.CACHED:
        #     print("2.cached.")
        #     cache_request_id = message.get_cache_request_id()
        # elif message_type.value == message_type.SUSPECT.value:#CacheStatus.SUSPECT
        #     print("3.SUSPECT")            
        # else:
        #     print("Message is from a suspected cache instance. Check your cache instance.")

        matcher_SysAnnTWS = re.match(self.config.SYSANNTWS, topic)

        if matcher_SysAnnTWS: #系統公告           
            self._trader.OnAnnouncementEvent(message)#公告

class TSolMsgThrdClass(MessageHandler):
    """create thread get receive to list and then call UI mesage"""    

    def __init__(self, name: str, log, MsgHdr_proc):
        self._name = name
        self._msgHandler = MsgHdr_proc
        self._lock = Lock()
        self._log = log
        self._list = []
        self._run = True
        self.thrd = threading.Thread(target=self.OnThread, name=self._name)
        self.thrd.start()

    def OnThread(self):
        list_date = []
        iCnt_Now, iCnt_Last, i = 0, 0, 0
        while self._run:
            # print("loop(0.001)...",end='')
            try:
                with self._lock:
                    list_date = self._list.copy()
                    iCnt_Now = len(list_date)
                    if(len(self._list) > 1000):
                        self._list = []

                for i in range(iCnt_Last, iCnt_Now):
                    self._msgHandler(list_date[i])
                    # self._msgHandler.on_message(da)#call the message
                iCnt_Last = iCnt_Now
            except Exception as ex:
                self._log.error(f"TSolMsgThrdClass send_request exception! exception={ex}")
            finally:
                sleep(0.001)

    def Add(self, message: 'InboundMessage'):
        with self._lock:
            self._list.append(message)

    def on_message(self, message: 'InboundMessage'):
        """ Message receive callback """
        self.Add(message)