import os
import logging

LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()
MTPY_LOG_PATH = os.environ.get("MTPY_LOG_PATH", "mtpy.log")

allow_log_level = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
assert LOG_LEVEL in allow_log_level, "LOG_LEVEL not allow, choice {}".format(
    (", ").join(allow_log_level)
)
LOGGING_LEVEL = getattr(logging, LOG_LEVEL)
log = logging.getLogger("mtpy")
log.setLevel(LOGGING_LEVEL)

file_handler = logging.FileHandler(MTPY_LOG_PATH)
file_handler.setLevel(LOGGING_LEVEL)
log_formatter = logging.Formatter(
    "[%(levelname)1.1s %(asctime)s %(pathname)s:%(lineno)d:%(funcName)s] %(message)s"
)
file_handler.setFormatter(log_formatter)
log.addHandler(file_handler)

# console_handler = logging.StreamHandler()
# console_handler.setLevel(logging.INFO)
# console_handler.setFormatter(logging.Formatter(
#     '%(asctime)-15s %(name)-5s %(levelname)-7s - %(message)s'
# ))
# log.addHandler(console_handler)

