from dataclasses import dataclass
from solace.messaging.messaging_service import MessagingService, ReconnectionListener, ReconnectionAttemptListener, ServiceInterruptionListener, RetryStrategy, ServiceEvent
from solace.messaging.resources.topic_subscription import TopicSubscription
from solace.messaging.receiver.message_receiver import MessageHandler, InboundMessage
from solace.messaging.receiver.direct_message_receiver import DirectMessageReceiver
from solace.messaging.publisher.outbound_message import OutboundMessage
from solace.messaging.publisher.request_reply_message_publisher import RequestReplyMessagePublisher
from solace.messaging.resources.topic import Topic
from solace.messaging.publisher.direct_message_publisher import PublishFailureListener, FailedPublishEvent
from solace.messaging.utils.life_cycle_control import TerminationNotificationListener, TerminationEvent
from MasterTradePy.constant import RCode, Config
from MasterTradePy.model import MarketTrader, SystemEvent
from solace.messaging.resources.cached_message_subscription_request import CachedMessageSubscriptionRequest
from solace.messaging.utils.cache_request_outcome_listener import CacheRequestOutcomeListener
from solace.messaging.utils.cache_request_outcome import CacheRequestOutcome
from threading import Lock
from datetime import datetime
import re

class TradeMessageHandler(MessageHandler): 
    def __init__(self, trader: MarketTrader):
        self._trader = trader
        
    def on_message(self, msg: InboundMessage):
        topic:str = msg.get_destination_name()
        message:str = msg.get_payload_as_bytes().decode('utf-8')
        matcher_SysAnnTWS = re.match("DAPI/Quote/TWS/ANN", topic)

        if matcher_SysAnnTWS: #系統公告           
            self._trader.OnAnnouncementEvent(message)#公告       
                  
class ServiceEventHandler(ReconnectionListener, ReconnectionAttemptListener, ServiceInterruptionListener, PublishFailureListener, TerminationNotificationListener):
    def __init__(self, trader: MarketTrader):
        self._trader = trader
        
    def on_reconnected(self, e: ServiceEvent):
        self._trader.OnSystemEvent(SystemEvent(RCode.RECONNECTED, e.get_message()))
    
    def on_reconnecting(self, e: ServiceEvent):
        self._trader.OnSystemEvent(SystemEvent(RCode.IN_PROGRESS, e.get_message()))

    def on_service_interrupted(self, e: ServiceEvent):
        self._trader.OnSystemEvent(SystemEvent(RCode.FAIL, e.get_message()))
        
    def on_failed_publish(self, e: FailedPublishEvent):
        self._trader.OnSystemEvent(SystemEvent(RCode.FAIL, e.get_message()))
        
    def on_termination(self, e: TerminationEvent):
        self._trader.OnSystemEvent(SystemEvent(RCode.FAIL, e.message))
        
            
class SolClient():
    _reply_timeout = 10000
    def __init__(self, clientname: str, sol_config, username:str=''):
        self.lockObj = Lock()
        self.lock_RequestID = Lock()
        self._is_connected = False
        self._message_service: MessagingService
        self._message_receiver: DirectMessageReceiver
        self._message_requester: RequestReplyMessagePublisher
        config = sol_config
        self._host: str = config.SOL_SESSION_HOST
        self._vpn: str = config.SOL_SESSION_VPN_NAME
        self._username: str = config.SOL_SESSION_USERNAME if username == '' else username
        self._password: str = config.SOL_SESSION_PASSWORD
        self._clientname: str = clientname
        self._fLast_RequestID = 0
        
    def create_connection(self, message_handler, service_handler: ServiceEventHandler) -> RCode:
        broker_props = {
            "solace.messaging.transport.host": self._host,
            "solace.messaging.service.vpn-name": self._vpn,
            "solace.messaging.authentication.scheme.basic.username": self._username,
            "solace.messaging.authentication.scheme.basic.password": self._password,
        }

        # if not self._clientname:
        #     self._message_service = MessagingService.builder().from_properties(broker_props)\
        #         .with_reconnection_retry_strategy(RetryStrategy.parametrized_retry(5, 3000))\
        #         .build()
        # else:
        #     self._message_service = MessagingService.builder().from_properties(broker_props)\
        #         .with_reconnection_retry_strategy(RetryStrategy.parametrized_retry(5, 3000))\
        #         .build(self._clientname)      
        self._message_service = MessagingService.builder().from_properties(broker_props).build()#改成跟行情一樣的方式     
        self._message_service.connect()
        # self._message_service.add_reconnection_listener(service_handler)
        # self._message_service.add_reconnection_attempt_listener(service_handler)
        # self._message_service.add_service_interruption_listener(service_handler)
        self._message_receiver = self._message_service.create_direct_message_receiver_builder().build()
        self._message_receiver.start()
        self._message_receiver.receive_async(message_handler)
        self._message_requester = self._message_service.request_reply() \
            .create_request_reply_message_publisher_builder().build().start()
        self._is_connected = self._message_service.is_connected
        if self._is_connected:
            return RCode.OK
        else:
            return RCode.FAIL
            
    def disconnect(self):
        if self._message_service:
            self._message_receiver.terminate()
            self._message_service.disconnect()
            self._is_connected = False
    
    def send_request(self, topic: str, msg: str) -> str:
        encoding = 'utf-8'
        payloadByte = bytearray(f'{msg}', encoding)
        message: OutboundMessage = self._message_service.message_builder().build(
                payload=payloadByte)
        try:
            with self.lockObj:
                reply = self._message_requester.publish_await_response(request_message=message,
                                                                request_destination=Topic.of(topic),
                                                                reply_timeout=self._reply_timeout)
                payload_str = reply.get_payload_as_bytes().decode(encoding)
                return payload_str
        except Exception as ex:
            print(f"Error send_request:{ex}")
        return ""  
    def add_subscription(self, topic: str):
        try:
            with self.lockObj:
                self._message_receiver.add_subscription(TopicSubscription.of(topic))
        except Exception as ex:
            print(f"Error subscriptioin:{ex}")
        
    def remove_subscription(self, topic: str):
        try:
            with self.lockObj:                
                self._message_receiver.remove_subscription(TopicSubscription.of(topic))
        except Exception as ex:
            print(f"Error remove subscriptioin:{ex}")

    def request_cached_only(self, cachename:str, topic:str, timeout:int, cacheId:int):
        try:
            with self.lockObj:  
                cached_message_subscription_request = CachedMessageSubscriptionRequest.cached_only(cachename, TopicSubscription.of(topic), timeout)                
                cache_request_outcome_listener = MyCacheRequestOutcomeListener(self)

                self._message_receiver.request_cached(cached_message_subscription_request, cacheId, cache_request_outcome_listener)
        except Exception as ex:
            print(f"Error request_cached_only:{ex}")
    
    def GetRequestID(self):
        try:
            with self.lock_RequestID:
                res = int(datetime.now().strftime("%y%m%d%H%M%S%f"))
                if res < self._fLast_RequestID:
                    res = self._fLast_RequestID + 1
                self._fLast_RequestID = res        
                return res        
        except Exception as ex:
            print(f"Error GetRequestID:{ex}")       
    

class MyCacheRequestOutcomeListener(CacheRequestOutcomeListener):
    def __init__(self, sol) -> None:
        self._sol = sol
        
    def on_completion(self, result: CacheRequestOutcome, correlation_id: int, e: Exception):
        if result == CacheRequestOutcome.FAILED:
            print(f"cache completion fail: result:{result} id:{correlation_id} exception:{e}")
        